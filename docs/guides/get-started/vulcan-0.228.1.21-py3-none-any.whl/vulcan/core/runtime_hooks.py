from __future__ import annotations

import typing as t


class RuntimeHooks(t.Protocol):
    def initialize(self, config: t.Any) -> None: ...
    def on_plan_metrics(
        self,
        plan_activity: t.Any,
        plan: t.Any,
        config: t.Any,
        snapshots: t.Any,
    ) -> None: ...
    def on_run_metrics(self, run_activity: t.Any, config: t.Any) -> None: ...
    def on_test_metrics(
        self,
        result: t.Any,
        config: t.Any,
        environment: str,
        total_models: int,
        models_with_tests: int,
    ) -> None: ...
    def on_snapshot_env_metrics(
        self,
        config: t.Any,
        snapshot_count: int,
        environment_count: int,
        environment: str,
    ) -> None: ...
    def on_scheduler_metrics(
        self,
        config: t.Any,
        environment: str,
        queue_depth: int,
        model_lags: t.Optional[t.Dict[str, float]] = None,
        snapshots: t.Any = None,
        get_max_interval_end_per_model: t.Optional[t.Callable] = None,
    ) -> None: ...
    def on_activity_event_metrics(self, config: t.Any, event_type: str, success: bool) -> None: ...
    def on_backfill_metrics(self, stage: t.Any, plan: t.Any) -> None: ...
    def on_audit_metrics(
        self,
        audit_results: t.Any,
        snapshot: t.Any,
        environment: str,
        has_blocking_errors: bool = False,
    ) -> None: ...


class NoOpRuntimeHooks:
    def initialize(self, config: t.Any) -> None:
        pass

    def on_plan_metrics(
        self,
        plan_activity: t.Any,
        plan: t.Any,
        config: t.Any,
        snapshots: t.Any,
    ) -> None:
        pass

    def on_run_metrics(self, run_activity: t.Any, config: t.Any) -> None:
        pass

    def on_test_metrics(
        self,
        result: t.Any,
        config: t.Any,
        environment: str,
        total_models: int,
        models_with_tests: int,
    ) -> None:
        pass

    def on_snapshot_env_metrics(
        self,
        config: t.Any,
        snapshot_count: int,
        environment_count: int,
        environment: str,
    ) -> None:
        pass

    def on_scheduler_metrics(
        self,
        config: t.Any,
        environment: str,
        queue_depth: int,
        model_lags: t.Optional[t.Dict[str, float]] = None,
        snapshots: t.Any = None,
        get_max_interval_end_per_model: t.Optional[t.Callable] = None,
    ) -> None:
        pass

    def on_activity_event_metrics(self, config: t.Any, event_type: str, success: bool) -> None:
        pass

    def on_backfill_metrics(self, stage: t.Any, plan: t.Any) -> None:
        pass

    def on_audit_metrics(
        self,
        audit_results: t.Any,
        snapshot: t.Any,
        environment: str,
        has_blocking_errors: bool = False,
    ) -> None:
        pass


_hooks: RuntimeHooks = NoOpRuntimeHooks()


def set_runtime_hooks(hooks: RuntimeHooks) -> None:
    global _hooks
    _hooks = hooks


def get_runtime_hooks() -> RuntimeHooks:
    return _hooks
