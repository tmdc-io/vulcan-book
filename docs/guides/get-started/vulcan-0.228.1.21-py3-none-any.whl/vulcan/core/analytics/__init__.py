from __future__ import annotations

import atexit
import logging
import typing as t
from functools import wraps

from vulcan.core.analytics.collector import AnalyticsCollector
from vulcan.core.analytics.dispatcher import AsyncEventDispatcher, EventEmitter, NoopEventDispatcher

logger = logging.getLogger(__name__)

if t.TYPE_CHECKING:
    import sys

    if sys.version_info >= (3, 10):
        from typing import ParamSpec
    else:
        from typing_extensions import ParamSpec

    _P = ParamSpec("_P")
    _T = t.TypeVar("_T")


# Starts as Noop, replaced by Context after config loads. See AnalyticsConfig docstring for rationale.
collector: AnalyticsCollector = AnalyticsCollector(dispatcher=NoopEventDispatcher())


def _shutdown_collector() -> None:
    """Shutdown handler that always references the current global collector."""
    global collector
    collector.shutdown(flush=True)


def init_collector_from_config(
    enabled: bool = True,
    base_url: str = "",
    api_key: str = "",
    tenant: str = "",
    source_name: str = "vulcan",
    enable_search: bool = True,
    retention_days: int = 30,
    timeout: int = 10,
    product_name: t.Optional[str] = None,
) -> AnalyticsCollector:
    """Initialize analytics collector from config values.
    
    Called by Context after configuration is loaded (including .env files).
    Returns NoopEventDispatcher if analytics is disabled or credentials are not provided.
    
    Args:
        enabled: Whether analytics collection is enabled (default: True)
        base_url: Base URL for the CloudEvents collector API (required when enabled)
        api_key: API key for authentication with the collector (required when enabled)
        tenant: Tenant identifier (required when enabled)
        source_name: Source name for events (default: "vulcan")
        enable_search: Enable search indexing (default: True)
        retention_days: Data retention in days (default: 30)
        timeout: HTTP timeout in seconds (default: 10)
        product_name: Product/project name (optional, for event context)
    
    Returns:
        AnalyticsCollector instance
    """
    # Return Noop if explicitly disabled
    if not enabled:
        return AnalyticsCollector(dispatcher=NoopEventDispatcher())
    
    # Validate required config when enabled - graceful degradation with warning
    missing = []
    if not base_url or not base_url.strip():
        missing.append("base_url")
    if not api_key or not api_key.strip():
        missing.append("api_key")
    if not tenant or not tenant.strip():
        missing.append("tenant")
    
    if missing:
        logger.warning(
            f"Analytics enabled but missing required config: {', '.join(missing)}. "
            "Analytics will be disabled. Set analytics.enabled: false to suppress this warning, "
            "or provide the missing configuration in config.yaml."
        )
        return AnalyticsCollector(dispatcher=NoopEventDispatcher())
    
    emitter = EventEmitter(
        base_url=base_url,
        api_key=api_key,
        tenant=tenant,
        source_name=source_name,
        enable_search=enable_search,
        search_retention_days=retention_days,
        read_timeout_sec=timeout,
        connect_timeout_sec=timeout,
    )
    dispatcher = AsyncEventDispatcher(emitter=emitter)
    return AnalyticsCollector(
        dispatcher=dispatcher,
        product_name=product_name,
        tenant_name=tenant,
    )


# Register shutdown handler (uses function to always get current global collector)
atexit.register(_shutdown_collector)


def disable_analytics() -> None:
    """Disable analytics by replacing collector with Noop."""
    global collector
    collector.shutdown(flush=False)
    collector = AnalyticsCollector(dispatcher=NoopEventDispatcher())


def cli_analytics(func: t.Callable[_P, _T]) -> t.Callable[_P, _T]:
    """Decorator for CLI commands to track analytics."""
    @wraps(func)
    def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T:
        import click
        from click.core import ParameterSource

        arg_keys = set()
        command_chain = []

        cli_context: click.Context = click.get_current_context()
        cli_context_cursor: t.Optional[click.Context] = cli_context
        while cli_context_cursor:
            arg_keys |= {
                k
                for k, source in cli_context_cursor._parameter_source.items()
                if source == ParameterSource.COMMANDLINE
            }
            command_chain.append(cli_context_cursor.info_name)
            cli_context_cursor = cli_context_cursor.parent

        command_name, *parent_command_names = command_chain

        common_context: t.Dict[str, t.Any] = {
            "command_name": command_name,
            "command_args": arg_keys,
            "parent_command_names": parent_command_names,
        }

        if "github" in parent_command_names:
            cicd_bot_config = None
            github_controller = cli_context.obj.get("github")
            if github_controller:
                cicd_bot_config = github_controller._context.config.cicd_bot
            collector.on_cicd_command(**common_context, cicd_bot_config=cicd_bot_config)
        else:
            collector.on_cli_command(**common_context)

        return func(*args, **kwargs)

    return wrapper


def python_api_analytics(func: t.Callable[_P, _T]) -> t.Callable[_P, _T]:
    """Decorator for Python API methods to track analytics."""
    @wraps(func)
    def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T:
        import inspect

        from vulcan import magics

        should_log = True

        try:
            stack = inspect.stack()
        except Exception:
            stack = []

        for frame in stack:
            if "click/" in frame.filename or frame.filename == magics.__file__:
                # Magics and CLI are reported separately.
                should_log = False
                break

        if should_log:
            collector.on_python_api_command(command_name=func.__name__, command_args=kwargs)

        return func(*args, **kwargs)

    return wrapper
