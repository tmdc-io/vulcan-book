from __future__ import annotations

import abc
import json
import logging
import platform
import typing as t
from functools import cached_property
from threading import Event, Lock, Thread

import requests
from sqlglot._version import __version__ as sqlglot_version

from vulcan.utils.errors import ApiClientError

from cloudevents.http import CloudEvent
from cloudevents.conversion import to_structured
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class EventEmitter:
    """Single point of contact for all CloudEvents API calls.
    
    Handles both event publishing (batched) and source/schema registration (one-time).
    All API calls use requests (synchronous, fits Vulcan's sync architecture).
    See AnalyticsConfig docstring for design rationale.
    """

    @cached_property
    def _user_agent(self) -> str:
        """Get user agent string with version (lazy to avoid circular import)."""
        try:
            from vulcan import __version__ as vulcan_version
            return f"Vulcan/{vulcan_version}"
        except ImportError:
            return "Vulcan/unknown"

    def __init__(
        self,
        base_url: t.Optional[str] = None,
        read_timeout_sec: int = 10,
        connect_timeout_sec: int = 10,
        api_key: t.Optional[str] = None,
        tenant: t.Optional[str] = None,
        source_name: str = "vulcan",
        enable_search: bool = True,
        search_retention_days: int = 30,
    ):
        # Single base URL for all CloudEvents API calls
        if not base_url or not base_url.strip():
            raise ValueError("Base URL is required and cannot be empty. Pass base_url parameter.")
        self.base_url = base_url.rstrip("/")
        self.read_timeout = read_timeout_sec
        self.connect_timeout = connect_timeout_sec

        # Required configuration - validate once during init
        if not api_key or not api_key.strip():
            raise ValueError("CloudEvents API key is required and cannot be empty. Pass api_key parameter.")
        self.api_key = api_key
        
        if not tenant or not tenant.strip():
            raise ValueError("Tenant is required and cannot be empty. Pass tenant parameter.")
        self.tenant = tenant

        if not source_name or not source_name.strip():
            raise ValueError("Source name is required and cannot be empty.")
        self.source_name = source_name
        self.enable_search = enable_search
        self.search_retention_days = search_retention_days

        # Single session for all API calls (events + registration)
        self._session = requests.Session()

        # Set headers (version added lazily via property to avoid circular import)
        # Note: Content-Type is set per-request in emit() for CloudEvents
        self._session.headers.update(
            {
                "User-Agent": self._user_agent,
                "Authorization": f"Bearer {self.api_key}",
            }
        )
        
        # Register source and schemas at initialization
        try:
            self.register_source(enable_search=enable_search, search_retention_days=search_retention_days)
            self._register_all_schemas()
        except Exception as e:
            logger.warning(f"Failed to register source/schemas at init: {e}")
            # Continue anyway - emit will still work, just without schemas
    
    def _register_all_schemas(self) -> None:
        """Load and register all Avro schemas from schemas directory."""
        from pathlib import Path
        
        schema_dir = Path(__file__).parent / "schemas"
        if not schema_dir.exists():
            logger.warning(f"Schema directory not found: {schema_dir}")
            return
        
        for schema_file in schema_dir.glob("*.avsc"):
            event_type = schema_file.stem  # "plan_apply_start.avsc" -> "plan_apply_start"
            try:
                with open(schema_file, 'r') as f:
                    schema_json = f.read()
                self.register_schema(event_type, schema_json)
                logger.debug(f"Registered schema for: {event_type}")
            except Exception as e:
                logger.warning(f"Failed to register schema for {event_type}: {e}")

    def _make_request(
        self,
        url: str,
        payload: t.Union[t.Dict[str, t.Any], t.List[t.Dict[str, t.Any]]],
        context: str = "API request"
    ) -> t.Optional[t.Dict[str, t.Any]]:
        """Make HTTP POST request with consistent error handling.
        
        Args:
            url: The URL to POST to
            payload: Dict or list of dicts to send as JSON
            context: Context string for error messages
            
        Returns:
            Response JSON if successful, None if no response body
            
        Raises:
            Original requests exception on network/connection errors
            ApiClientError: If response status is not 200/201
        """
        try:
            response = self._session.post(
                url,
                json=payload,
                timeout=(self.connect_timeout, self.read_timeout),
            )
        except Exception:
            logger.info(f"{context} failed: {url}")
            raise
        
        if response.status_code in (200, 201):
            return response.json() if response.content else None
        
        error_msg = f"{context} failed: HTTP {response.status_code}"
        if response.text:
            error_msg += f" - {response.text}"
        raise ApiClientError(error_msg, code=response.status_code)

    def emit(self, events: t.List[t.Dict[str, t.Any]]) -> None:
        """Publish events (sync, called frequently in batches)."""
        payload, content_type = self._format_as_cloudevents(events)
        self._session.headers["Content-Type"] = content_type        
        
        # Build event publishing URL: {base_url}/tenants/{tenant}/events/batch
        url = f"{self.base_url}/tenants/{self.tenant}/events/batch"
        
        self._make_request(url, payload, context="Emit events")

    def _format_as_cloudevents(self, events: t.List[t.Dict[str, t.Any]]) -> t.Tuple[t.Union[t.Dict[str, t.Any], t.List[t.Dict[str, t.Any]]], str]:
        """Format events as CloudEvents v1.0 using official SDK.
        
        Enriches event data with project and version metadata.
        
        Spec: https://github.com/cloudevents/spec/blob/v1.0/spec.md
        SDK: https://github.com/cloudevents/sdk-python
        """
        
        # Parse versions dict once (reuse across all events in batch)
        versions_dict = json.loads(self._versions)
        
        formatted_events = []
        for event in events:
            # Parse nested event data
            try:
                event_data = json.loads(event.get("event", "{}"))
            except (json.JSONDecodeError, TypeError):
                event_data = {}
            
            # Extract context object (for facets structure)
            context = event.get("context", {})
            
            # Extract kwargs if present (for optional fields like executed_by, gateway_name, etc.)
            kwargs = event.get("kwargs", {})
            
            # Merge kwargs into event_data, but only if they're present and not None
            # This allows optional fields to be added dynamically
            optional_fields = [
                "executed_by",
                "gateway_name",
                "git_commit_sha",
                "apply_duration",
                "check_duration",
                "run_duration",
                "failures_by_dimension",
                "warnings_by_dimension",
            ]
            for field in optional_fields:
                if field in kwargs and kwargs[field] is not None:
                    event_data[field] = kwargs[field]
            
            # Enrich data with metadata
            enriched_data = {
                **event_data,  # Original event data (spread first so _meta can't be overwritten)
                "facets": {
                    "context": context,  # Context object with user_id, process_id, seq_num, product_name, tenant_name
                    "versions": versions_dict
                }
            }
            
            # Convert timestamp from milliseconds to seconds (client_ts is at top level for CloudEvents time attribute)
            timestamp_sec = event.get("client_ts", 0) / 1000.0
            event_time = datetime.fromtimestamp(timestamp_sec, tz=timezone.utc)
            
            # Create CloudEvent with required attributes
            # SDK auto-generates id and sets specversion=1.0
            attributes = {
                "source": self.source_name,  # Use registered source name
                "type": event['event_type'].lower(),
                "datacontenttype": "application/json",
                "time": event_time.isoformat(),  # Convert to ISO string
            }
            
            # Create CloudEvent object with enriched data
            cloud_event = CloudEvent(attributes, enriched_data)
            
            # Convert to structured format (proper JSON serialization)
            _, body = to_structured(cloud_event)
            
            # Parse the body back to dict for batch handling
            structured = json.loads(body.decode("utf-8"))
            formatted_events.append(structured)
        
        # Always return array for batch endpoint (even single events)
        return formatted_events, "application/cloudevents-batch+json"

    def register_source(
        self,
        enable_search: bool = True,
        search_retention_days: int = 30
    ) -> t.Dict[str, t.Any]:
        """Register source with CloudEvents API (sync, called once during init).
        
        Args:
            enable_search: Whether to enable search functionality for the source
            search_retention_days: Number of days to retain search data
            
        Returns:
            Response from the API on success
            
        Raises:
            ApiClientError: If registration fails
        """
        # Build source registration URL: {base_url}/tenants/{tenant}/sources/{source_name}
        url = f"{self.base_url}/tenants/{self.tenant}/sources/{self.source_name}"
        logger.info(url)
        payload = {
            "enable_search": enable_search,
            "search_retention_period_days": search_retention_days
        }
        
        response_body = self._make_request(
            url,
            payload,
            context=f"Register CloudEvents source '{self.source_name}'"
        )
        return {} if response_body is None else response_body

    def register_schema(
        self,
        type_name: str,
        schema_json: str
    ) -> t.Dict[str, t.Any]:
        """Register schema with CloudEvents API (sync, called once per event type).
        
        Args:
            type_name: The event type name (e.g., "project_loaded")
            schema_json: JSON string containing the schema definition
            
        Returns:
            Response from the API on success
            
        Raises:
            ApiClientError: If registration fails
        """
        # Build schema registration URL: {base_url}/tenants/{tenant}/sources/{source_name}/types/{type_name}/schemas
        url = f"{self.base_url}/tenants/{self.tenant}/sources/{self.source_name}/types/{type_name}/schemas"
        payload = {"schema": schema_json}
        
        response_body = self._make_request(
            url,
            payload,
            context=f"Register CloudEvents schema for type '{type_name}'"
        )
        return {} if response_body is None else response_body

    def close(self) -> None:
        """Close requests session."""
        self._session.close()

    @cached_property
    def _versions(self) -> str:
        import pydantic

        from vulcan import __version__ as vulcan_version

        versions = {
            "vulcan": vulcan_version,
            "sqlglot": sqlglot_version,
            "python": platform.python_version(),
            "pydantic": pydantic.__version__,
            "os_name": platform.system(),
            "platform": platform.platform(),
        }
        return json.dumps(versions)


class EventDispatcher(abc.ABC):
    """Dispatches events to an emitter."""

    @abc.abstractmethod
    def add_event(self, event: t.Dict[str, t.Any]) -> None:
        """Add an event to be emitted.

        Args:
            event: The event data.
        """

    @abc.abstractmethod
    def flush(self) -> None:
        """Flushes the collected events to the emitter."""

    @abc.abstractmethod
    def shutdown(self, flush: bool = True) -> None:
        """Shuts down this dispatcher and releases any resources.

        Args:
            flush: Whether to flush the collected events before shutting down.
        """


class AsyncEventDispatcher(EventDispatcher):
    def __init__(
        self,
        emit_interval_sec: int = 5,
        max_emit_interval_sec: int = 120,
        max_queue_size: int = 50,
        emitter: t.Optional[EventEmitter] = None,
    ):
        self._emit_interval_sec = emit_interval_sec
        self._max_emit_interval_sec = max_emit_interval_sec
        self._max_queue_size = max_queue_size
        
        # EventEmitter must be provided (fails fast if credentials missing)
        if emitter is None:
            raise ValueError("EventEmitter is required. Provide emitter parameter.")
        self.emitter = emitter

        self._events: t.List[t.Dict[str, t.Any]] = []
        self._events_lock = Lock()

        self._shutdown_event = Event()
        self._emitter_thread = Thread(target=self._run_flush, name="event-emitter", daemon=True)
        self._emitter_thread.start()

    def add_event(self, event: t.Dict[str, t.Any]) -> None:
        self._add_events([event])

    def flush(self) -> None:
        with self._events_lock:
            events_to_emit = self._events
            self._events = []

        if not events_to_emit:
            return

        logger.debug("Emitting %d events", len(events_to_emit))
        try:
            self.emitter.emit(events_to_emit)
        except Exception as e:
            logger.info("Failed to emit events: %s", e)
            if isinstance(e, ApiClientError):
                if e.code == 429 and self._emit_interval_sec < self._max_emit_interval_sec:
                    self._emit_interval_sec = min(
                        self._emit_interval_sec * 2, self._max_emit_interval_sec
                    )
                    logger.debug(
                        "Increasing the emit interval to %s seconds", self._emit_interval_sec
                    )
                elif e.code in (400, 403, 404, 405, 426):
                    logger.info(
                        "Non-retriable client error (%s) occurred, shutting down the event dispatcher",
                        e.code,
                    )
                    self.shutdown(flush=False)
                    return
            self._add_events(events_to_emit, prepend=True)

    def shutdown(self, flush: bool = True) -> None:
        if self._shutdown_event.is_set():
            return
        logging.info("Shutting down the event dispatcher")
        self._shutdown_event.set()
        self._emitter_thread.join()
        if flush and self._events:
            # Reduce the connect timeout to avoid blocking the shutdown.
            self.emitter.connect_timeout = 2
            self.flush()
        self.emitter.close()

    def _add_events(self, events: t.List[t.Dict[str, t.Any]], prepend: bool = False) -> None:
        with self._events_lock:
            if not prepend:
                self._events.extend(events)
            else:
                self._events = events + self._events

            if len(self._events) > self._max_queue_size:
                drop_count = len(self._events) - self._max_queue_size
                logger.info("Event queue is full, dropping %s events", drop_count)
                self._events = self._events[drop_count:]

    def _run_flush(self) -> None:
        while not self._shutdown_event.wait(self._emit_interval_sec):
            self.flush()


class NoopEventDispatcher(EventDispatcher):
    def add_event(self, event: t.Dict[str, t.Any]) -> None:
        logger.debug("Analytics is disabled, dropping event")

    def flush(self) -> None:
        pass

    def shutdown(self, flush: bool = True) -> None:
        pass
