from __future__ import annotations

import json
import re
import typing as t
from functools import cached_property

from typing import get_args

from pydantic import Field, field_validator, model_validator
from typing_extensions import Literal

from sqlglot import exp

from schema._semantic_types import (
    AiContextSpec as AiContextSpec,
    JoinRelationshipValue as JoinRelationshipValue,
    LogicalTypeValue as LogicalTypeValue,
    MeasureTypeValue as MeasureTypeValue,
    MetricGranularityValue as MetricGranularityValue,
    RollingWindowSpec as RollingWindowSpec,
    TimeGranularitySpec as _WireTimeGranularitySpec,
)
from vulcan.core.types import Tag, Term
from vulcan.utils.errors import ConfigError
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel

MAX_IDENTIFIER_LENGTH = 64
VALID_FIELD_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")
VALID_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

_METRIC_ADJUNCT_NAME_RESERVED = frozenset({"measure", "time", "ts"})

# SQL types treated as semantic TIME (timestamp family only).
STRICT_TIMESTAMP_TYPES: t.Final[t.Tuple[exp.DataType.Type, ...]] = (
    exp.DataType.Type.TIMESTAMP,
    exp.DataType.Type.TIMESTAMPTZ,
    exp.DataType.Type.TIMESTAMPNTZ,
    exp.DataType.Type.TIMESTAMPLTZ,
    exp.DataType.Type.DATETIME,
)


class NamingError(ValueError):
    """Invalid semantic identifier or qualified reference."""


def _hash(obj: t.Any) -> str:
    return hash_data([json.dumps(obj, sort_keys=True, default=str)])


def sql_dtype_to_logical_type(col_type: t.Optional[exp.DataType]) -> LogicalTypeValue:
    """
    Map a SQL column type to a coarse logical type.

    Returns one of ``"number"``, ``"string"``, ``"time"``, or ``"boolean"`` (stable labels for
    metadata export and similar consumers). Used for dimensions and measures from their SQL types.
    """
    if not col_type:
        return "string"
    if col_type.is_type(*exp.DataType.INTEGER_TYPES, *exp.DataType.REAL_TYPES):
        return "number"
    if col_type.is_type(*STRICT_TIMESTAMP_TYPES):
        return "time"
    if col_type.is_type(exp.DataType.Type.BOOLEAN):
        return "boolean"
    return "string"


def _parse_qualified_reference(ref: str) -> t.Tuple[str, str] | None:
    parts = ref.split(".")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        return None
    return parts[0], parts[1]


def _validate_field(value: str, *, context: str = "field") -> str:
    if not value:
        raise NamingError(f"{context} must not be empty")
    if not VALID_FIELD_PATTERN.match(value):
        raise NamingError(f"{context} must match {VALID_FIELD_PATTERN.pattern}, got {value!r}")
    return value


def _validate_name(value: str, *, context: str = "name") -> str:
    if not value:
        raise NamingError(f"{context} must not be empty")
    if not VALID_NAME_PATTERN.match(value):
        raise NamingError(f"{context} must match {VALID_NAME_PATTERN.pattern}, got {value!r}")
    return value


def _validate_qualified_reference(ref: str, *, context: str = "reference") -> str:
    parsed = _parse_qualified_reference(ref)
    if not parsed:
        raise NamingError(
            f"{context} must be exactly one qualified reference in the form 'name.field', got {ref!r}"
        )
    semantic_name, field = parsed
    _validate_name(semantic_name, context=f"{context} (semantic model name)")
    _validate_field(field, context=f"{context} (field)")
    return ref


def _literal(s: str) -> exp.Expression:
    return exp.Literal.string(s)


def _text(s: str) -> exp.Expression:
    return exp.Identifier(this=s, quoted=True)


def _upper(s: str) -> exp.Expression:
    return exp.to_identifier(s.upper().replace("-", "_"))


def _is_unquoted_identifier(s: str) -> bool:
    """True if ``s`` can be rendered as an unquoted identifier (not a string literal).

    Matches a conservative ASCII token: ``[a-zA-Z_][a-zA-Z0-9_]*``. Used when building
    sqlglot trees for semantic ``render_exp`` output; it is not a full catalog/dialect
    identifier validation.
    """
    return bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", s))


def _entry(d: "DimensionSpec") -> exp.Expression:
    name = d.name
    return exp.to_identifier(name) if _is_unquoted_identifier(name) else _literal(name)


def _require_unique(kind: str, values: t.List[str]) -> None:
    dupes = {x for x in values if values.count(x) > 1}
    if dupes:
        raise ValueError(f"duplicate {kind}: {sorted(dupes)}")


def _segment_name_from_ref(ref: str) -> str:
    """Build a metric segment column name from ``semantic.field`` (both parts, lowercased)."""

    parsed = _parse_qualified_reference(ref)
    if not parsed:
        raise NamingError(
            f"segment ref must be exactly one qualified reference in the form 'name.field', got {ref!r}"
        )
    semantic_name, field = parsed
    return f"{semantic_name}_{field}".lower()


def _coerce_metric_dimensions_yaml(entries: t.Any, *, context: str = "dimensions") -> t.List[t.Dict[str, t.Any]]:
    """Normalize YAML ``dimensions`` entries into dicts for :class:`MetricNamedRefSpec`."""

    if not isinstance(entries, list):
        raise ValueError(f"{context} must be a list")

    shorthand_refs_by_derived_name: t.Dict[str, t.List[str]] = {}
    out: t.List[t.Dict[str, t.Any]] = []

    for i, x in enumerate(entries):
        loc = f"{context}[{i}]"
        if isinstance(x, str):
            ref = _validate_qualified_reference(x.strip(), context=loc)
            parsed = _parse_qualified_reference(ref)
            if not parsed:
                raise NamingError(f"{loc}: invalid qualified reference {ref!r}")
            _, field_name = parsed
            _validate_name(field_name, context=f"{loc} (name derived from ref field)")
            shorthand_refs_by_derived_name.setdefault(field_name, []).append(ref)
            out.append({"name": field_name, "ref": ref})
        elif isinstance(x, dict):
            out.append(dict(x))
        else:
            raise ValueError(
                f"{loc}: entry must be a qualified reference string or a dict, got {type(x).__name__}"
            )

    clashes = {
        name: refs
        for name, refs in shorthand_refs_by_derived_name.items()
        if len(set(refs)) > 1
    }
    if clashes:
        detail = "; ".join(f"{name!r}: {refs}" for name, refs in sorted(clashes.items()))
        raise ValueError(
            "duplicate dimension name derived from qualified refs; use an explicit object "
            f"entry with 'name' for one dimension: {detail}"
        )

    return out


def _coerce_metric_segments_yaml(entries: t.Any, *, context: str = "segments") -> t.List[t.Dict[str, t.Any]]:
    """Normalize YAML ``segments`` (list of qualified refs) into dicts for :class:`MetricNamedRefSpec`."""

    if not isinstance(entries, list):
        raise ValueError(f"{context} must be a list")

    out: t.List[t.Dict[str, t.Any]] = []

    for i, x in enumerate(entries):
        loc = f"{context}[{i}]"
        if not isinstance(x, str):
            raise ValueError(f"{loc}: segment must be a qualified reference string, got {type(x).__name__}")
        ref = _validate_qualified_reference(x.strip(), context=loc)
        derived = _segment_name_from_ref(ref)
        _validate_name(derived, context=f"{loc} (name derived as semantic_field)")
        out.append({"name": derived, "ref": ref})

    return out


class MeasureSpec(PydanticModel):
    """Aggregated metric on a semantic model (sum, count, distinct, etc.).

    - name: lowercase semantic identifier; the name count is reserved for the implicit count measure.
    - type: measure kind, normalized to lowercase; must be a known kind (see ``_MEASURE_TYPES``).
      Only ``count`` may omit ``expression``; all other kinds require a non-empty expression.
    - expression: SQL-ish definition; filters, rolling_window where applicable.
    - description, public, tags, terms, ai_context: optional.
    """

    # Closed set (aligned with product semantics).
    _MEASURE_TYPES: t.ClassVar[frozenset[str]] = frozenset(get_args(MeasureTypeValue))
    _RESERVED_MEASURE_NAMES: t.ClassVar[frozenset[str]] = frozenset({"count"})
    _MEASURE_TYPES_ALLOWING_FILTERS: t.ClassVar[frozenset[str]] = frozenset(
        {
            "sum",
            "avg",
            "min",
            "max",
            "count",
            "count_distinct",
            "count_distinct_approx",
        }
    )

    name: str
    type: MeasureTypeValue
    expression: str = ""
    description: str = ""
    filters: t.List[str] = Field(default_factory=list)
    rolling_window: t.Optional[RollingWindowSpec] = None
    public: bool = True
    tags: t.List[Tag] = Field(default_factory=list)
    terms: t.List[Term] = Field(default_factory=list)
    ai_context: t.Optional[AiContextSpec] = None

    @model_validator(mode="before")
    @classmethod
    def normalize_type(cls, data: t.Any) -> t.Any:
        if isinstance(data, dict) and "type" in data and isinstance(data["type"], str):
            data = {**data, "type": data["type"].strip().lower()}
        return data

    @model_validator(mode="after")
    def validate_measure_name(self) -> MeasureSpec:
        _validate_name(self.name, context="measure name")
        return self

    @model_validator(mode="after")
    def validate_expression_required(self) -> MeasureSpec:
        if self.type == "count":
            return self
        if not self.expression.strip():
            raise ValueError(
                f"Measure {self.name!r} of type {self.type!r} requires a non-empty expression"
            )
        return self

    @model_validator(mode="after")
    def validate_filters_nonempty(self) -> MeasureSpec:
        for i, f in enumerate(self.filters):
            if not str(f).strip():
                raise ValueError(f"Measure {self.name!r} has empty filter at index {i}")
        return self

    @model_validator(mode="after")
    def validate_number_no_filters(self) -> MeasureSpec:
        if self.type == "number" and self.filters:
            raise ValueError(
                f"Measure {self.name!r}: type 'number' cannot be combined with filters"
            )
        return self

    @model_validator(mode="after")
    def validate_filters_allowed_for_type(self) -> MeasureSpec:
        if self.filters and self.type not in type(self)._MEASURE_TYPES_ALLOWING_FILTERS:
            raise ValueError(
                f"Measure {self.name!r}: filters are not allowed for type {self.type!r}"
            )
        return self

    @classmethod
    def implicit_count(cls) -> MeasureSpec:
        """
        Canonical implicit row-count measure (reserved name ``count``).

        Returns:
            ``COUNT(*)`` style measure aligned with Cube row counts (``expression`` is ``'*'``).
        """
        return cls(
            name="count",
            type="count",
            expression="*",
            description="",
            filters=[],
            rolling_window=None,
            public=True,
            tags=[],
            terms=[],
            ai_context=None,
        )

    def data_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            exclude={"description", "public", "tags", "terms", "ai_context"},
        )
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            include={
                "name",
                "description",
                "tags",
                "terms",
                "ai_context",
                "public",
            },
        )
        return _hash(raw)

    @cached_property
    def exp(self) -> exp.DataType:
        k = self.type
        if k in ("sum", "avg", "min", "max", "number"):
            return exp.DataType.build("DOUBLE")
        if k in ("count", "count_distinct", "count_distinct_approx"):
            return exp.DataType.build("BIGINT")
        if k == "string":
            return exp.DataType.build("VARCHAR")
        if k == "time":
            return exp.DataType.build("TIMESTAMP")
        if k == "boolean":
            return exp.DataType.build("BOOLEAN")
        return exp.DataType.build("UNKNOWN")

    def render_exp(self) -> exp.Expression:
        inner: t.List[exp.Expression] = [
            exp.Property(this=exp.to_identifier("type"), value=_upper(self.type)),
        ]
        if self.expression:
            inner.append(
                exp.Property(this=exp.to_identifier("expression"), value=_text(self.expression))
            )
        if self.filters:
            inner.append(
                exp.Property(
                    this=exp.to_identifier("filters"),
                    value=exp.Tuple(expressions=[_text(str(f)) for f in self.filters]),
                )
            )
        if self.rolling_window is not None:
            rw = self.rolling_window.model_dump(mode="json", exclude_none=True)
            inner.append(
                exp.Property(
                    this=exp.to_identifier("rolling_window"),
                    value=_literal(json.dumps(rw, sort_keys=True)),
                )
            )
        return exp.Property(
            this=exp.to_identifier(self.name),
            value=exp.Tuple(expressions=inner),
        )


class TimeGranularitySpec(_WireTimeGranularitySpec):
    """
    Engine extension of the wire :class:`schema._semantic_types.TimeGranularitySpec`.

    Inherits the wire fields and validators, and adds producer-side helpers
    (``data_hash``, ``metadata_hash``, ``render_exp``) that the engine uses for
    fingerprinting and rendering back to a sqlglot expression.
    """

    def data_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            exclude={"description", "ai_context"},
        )
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"name", "interval", "description", "ai_context"},
        )
        return _hash(raw)

    def render_exp(self) -> exp.Expression:
        inner: t.List[exp.Expression] = [
            exp.Property(this=exp.to_identifier("interval"), value=_text(self.interval)),
        ]
        for key, val in (("offset", self.offset), ("origin", self.origin)):
            if val is not None:
                inner.append(exp.Property(this=exp.to_identifier(key), value=_text(val)))
        return exp.Property(
            this=exp.to_identifier(self.name),
            value=exp.Tuple(expressions=inner),
        )


class DimensionSpec(PydanticModel):
    """One dimension column with optional labels and optional nested time grains.

    - name: column field token (mixed case allowed for warehouse identifiers).
    - granularities: optional list of grains; each grain name must be unique within this dimension.
    - description, tags, terms, format, ai_context, public: optional.
    """

    name: str
    description: t.Optional[str] = None
    tags: t.List[Tag] = Field(default_factory=list)
    terms: t.List[Term] = Field(default_factory=list)
    format: t.Optional[str] = None
    granularities: t.List[TimeGranularitySpec] = Field(default_factory=list)
    ai_context: t.Optional[AiContextSpec] = None
    public: bool = True

    @classmethod
    def implicit_grain(cls, grain: exp.Expression) -> DimensionSpec:
        e = grain.unnest()
        if isinstance(e, exp.Tuple):
            raise ConfigError(
                "MODEL grains must list each column separately (e.g. grains (a, b)); "
                f"got a composite grain expression: {e.sql()}"
            )
        if isinstance(e, exp.Column):
            name = str(e.name)
        elif isinstance(e, exp.Identifier):
            name = str(e.name)
        else:
            raise ConfigError(
                "MODEL grains must be simple column identifiers; "
                f"got {e.sql()} ({type(e).__name__})"
            )
        return cls(
            name=_validate_field(name, context="implicit grain dimension name"),
            description=None,
            tags=[],
            terms=[],
            format=None,
            granularities=[],
            ai_context=None,
            public=False,
        )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return _validate_field(v, context="dimension name")

    @model_validator(mode="after")
    def validate_granularity_names_unique(self) -> DimensionSpec:
        names = [g.name for g in self.granularities]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ValueError(
                f"Duplicate granularity names on dimension {self.name!r}: {sorted(dupes)}"
            )
        return self

    def render_exp(self) -> exp.Expression:
        if not self.format and not self.granularities:
            return _entry(self)
        inner: t.List[exp.Expression] = []
        if self.format:
            inner.append(exp.Property(this=exp.to_identifier("format"), value=_text(self.format)))
        if self.granularities:
            inner.append(
                exp.Property(
                    this=exp.to_identifier("granularities"),
                    value=exp.Tuple(
                        expressions=[
                            g.render_exp() for g in sorted(self.granularities, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        return exp.Property(
            this=exp.to_identifier(self.name)
            if _is_unquoted_identifier(self.name)
            else _literal(self.name),
            value=exp.Tuple(expressions=inner),
        )

    def data_hash(self) -> str:
        raw = self.model_dump(mode="json", exclude_none=True, include={"name", "format", "public"})
        raw["granularities"] = [
            g.data_hash() for g in sorted(self.granularities, key=lambda x: x.name)
        ]
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"name", "description", "tags", "terms", "ai_context"},
        )
        raw["granularities"] = [
            g.metadata_hash() for g in sorted(self.granularities, key=lambda x: x.name)
        ]
        return _hash(raw)


class SegmentSpec(PydanticModel):
    """Boolean filter on the current semantic model only (SQL-like condition).

    - name: lowercase semantic identifier.
    - expression: predicate for this segment.
    - description, public, tags, terms, ai_context: optional.
    """

    name: str
    expression: str
    description: str = ""
    public: bool = True
    tags: t.List[Tag] = Field(default_factory=list)
    terms: t.List[Term] = Field(default_factory=list)
    ai_context: t.Optional[AiContextSpec] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return _validate_name(v, context="segment name")

    @cached_property
    def exp(self) -> exp.DataType:
        return exp.DataType.build("BOOLEAN")

    def data_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            exclude={"description", "tags", "terms", "ai_context", "public"},
        )
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            include={
                "name",
                "description",
                "tags",
                "terms",
                "ai_context",
                "public",
            },
        )
        return _hash(raw)

    def render_exp(self) -> exp.Expression:
        return exp.Property(
            this=exp.to_identifier(self.name),
            value=exp.Tuple(
                expressions=[
                    exp.Property(this=exp.to_identifier("expression"), value=_text(self.expression))
                ]
            ),
        )


class JoinSpec(PydanticModel):
    """Join from this semantic model to another declared semantic model.

    - name: lowercase semantic identifier; must match the target semantic model name.
    - type: relationship cardinality (one_to_one, one_to_many, or many_to_one).
    - expression: join predicate (SQL-like), typically referencing both models name.field style.
    - ai_context: optional.
    - fqn: fully qualified name of the join target semantic model
    """

    name: str
    type: JoinRelationshipValue
    expression: str
    ai_context: t.Optional[AiContextSpec] = None
    fqn: t.Optional[str] = Field(default=None)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return _validate_name(v, context="join name")

    @field_validator("type", mode="before")
    @classmethod
    def normalize_relationship(cls, v: t.Any) -> t.Any:
        if isinstance(v, str):
            return v.strip().lower()
        return v

    def data_hash(self) -> str:
        raw = self.model_dump(mode="json", exclude_none=True, exclude={"ai_context"})
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(mode="json", exclude_none=True, include={"name", "ai_context"})
        return _hash(raw)

    def render_exp(self) -> exp.Expression:
        return exp.Property(
            this=exp.to_identifier(self.name),
            value=exp.Tuple(
                expressions=[
                    exp.Property(this=exp.to_identifier("type"), value=_upper(self.type)),
                    exp.Property(
                        this=exp.to_identifier("expression"), value=_text(self.expression)
                    ),
                ]
            ),
        )


class SemanticModelSpec(PydanticModel):
    kind: Literal["semantic"] = "semantic"
    name: str
    depends_on: str
    description: t.Optional[str] = None
    owner: t.Optional[str] = None
    tags: t.Optional[t.List[Tag]] = None
    terms: t.Optional[t.List[Term]] = None
    ai_context: t.Optional[AiContextSpec] = None
    measures: t.List[MeasureSpec] = Field(default_factory=list)
    segments: t.List[SegmentSpec] = Field(default_factory=list)
    joins: t.List[JoinSpec] = Field(default_factory=list)
    dimensions: t.List[DimensionSpec] = Field(...)

    @field_validator("dimensions", mode="before")
    @classmethod
    def coerce_dimension_inputs(cls, v: t.Any) -> t.List[DimensionSpec]:
        if not isinstance(v, list):
            raise ValueError("dimensions must be a list")

        def _coerce_dimension(x: t.Any) -> DimensionSpec:
            if isinstance(x, DimensionSpec):
                return x
            if isinstance(x, str):
                return DimensionSpec(name=_validate_field(x, context="dimension column"))
            if isinstance(x, dict):
                return DimensionSpec.model_validate(x)
            raise ValueError(
                "dimension entry must be str, dict, or DimensionSpec, "
                f"got {type(x).__name__}"
            )

        return [_coerce_dimension(x) for x in v]

    @model_validator(mode="after")
    def validate_root(self) -> SemanticModelSpec:
        _validate_name(self.name, context="semantic model name")
        if not self.dimensions:
            raise ValueError("semantic model must declare a non-empty 'dimensions' allow-list")

        _require_unique("measure names", [m.name for m in self.measures])
        _require_unique("segment names", [s.name for s in self.segments])
        _require_unique("join names", [j.name for j in self.joins])

        reserved = MeasureSpec._RESERVED_MEASURE_NAMES
        for m in self.measures:
            if m.name in reserved:
                raise ValueError(
                    f"Measure name {m.name!r} is reserved (automatic count is implied)"
                )

        for j in self.joins:
            if j.name == self.name:
                raise ValueError(f"join name {j.name!r} must not equal to name {self.name!r}")

        return self

    def data_hash(self) -> str:
        top = self.model_dump(
            mode="json", exclude_none=True, include={"kind", "name", "depends_on"}
        )
        payload = {
            **top,
            "dimensions": [d.data_hash() for d in self.dimensions],
            "measures": [m.data_hash() for m in sorted(self.measures, key=lambda x: x.name)],
            "segments": [s.data_hash() for s in sorted(self.segments, key=lambda x: x.name)],
            "joins": [j.data_hash() for j in sorted(self.joins, key=lambda x: x.name)],
        }
        return _hash(payload)

    def metadata_hash(self) -> str:
        top = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"name", "description", "owner", "tags", "terms", "ai_context"},
        )
        payload = {
            **top,
            "dimensions": [d.metadata_hash() for d in self.dimensions],
            "measures": [m.metadata_hash() for m in sorted(self.measures, key=lambda x: x.name)],
            "segments": [s.metadata_hash() for s in sorted(self.segments, key=lambda x: x.name)],
            "joins": [j.metadata_hash() for j in sorted(self.joins, key=lambda x: x.name)],
        }
        return _hash(payload)

    def render_exps(self) -> t.List[exp.Property]:
        out: t.List[exp.Property] = [
            exp.Property(this=exp.to_identifier("depends_on"), value=_literal(self.depends_on)),
            exp.Property(
                this=exp.to_identifier("dimensions"),
                value=exp.Tuple(
                    expressions=[
                        d.render_exp() for d in sorted(self.dimensions, key=lambda x: x.name)
                    ]
                ),
            ),
        ]
        if self.measures:
            out.append(
                exp.Property(
                    this=exp.to_identifier("measures"),
                    value=exp.Tuple(
                        expressions=[
                            m.render_exp() for m in sorted(self.measures, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        if self.segments:
            out.append(
                exp.Property(
                    this=exp.to_identifier("segments"),
                    value=exp.Tuple(
                        expressions=[
                            s.render_exp() for s in sorted(self.segments, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        if self.joins:
            out.append(
                exp.Property(
                    this=exp.to_identifier("joins"),
                    value=exp.Tuple(
                        expressions=[
                            j.render_exp() for j in sorted(self.joins, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        return out


class MetricNamedRefSpec(PydanticModel):
    """Named qualified reference on a metric (``dimensions`` / ``segments`` lists).

    Optional ``description``, ``tags``, and ``terms`` annotate the metric output column for that
    slice (overriding semantic-field metadata when present).
    """

    name: str
    ref: str
    description: str = ""
    tags: t.List[Tag] = Field(default_factory=list)
    terms: t.List[Term] = Field(default_factory=list)
    ai_context: t.Optional[AiContextSpec] = None

    @model_validator(mode="after")
    def validate_name_and_ref(self) -> MetricNamedRefSpec:
        _validate_name(self.name, context="metric dimension or segment name")
        _validate_qualified_reference(self.ref, context="metric dimension or segment ref")
        return self

    def data_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            exclude={"description", "tags", "terms", "ai_context"},
        )
        return _hash(raw)

    def metadata_hash(self) -> str:
        raw = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"name", "ref", "description", "tags", "terms", "ai_context"},
        )
        return _hash(raw)

    def render_exp(self) -> exp.Property:
        name_expr = (
            exp.to_identifier(self.name)
            if _is_unquoted_identifier(self.name)
            else _literal(self.name)
        )
        if not self.description.strip() and not self.tags and not self.terms:
            return exp.Property(this=name_expr, value=_literal(self.ref))

        inner: t.List[exp.Expression] = [
            exp.Property(this=exp.to_identifier("ref"), value=_literal(self.ref)),
        ]
        if self.description.strip():
            inner.append(
                exp.Property(
                    this=exp.to_identifier("description"),
                    value=_text(self.description.strip()),
                )
            )
        if self.tags:
            inner.append(
                exp.Property(
                    this=exp.to_identifier("tags"),
                    value=exp.Tuple(expressions=[_literal(str(tag)) for tag in self.tags]),
                )
            )
        if self.terms:
            inner.append(
                exp.Property(
                    this=exp.to_identifier("terms"),
                    value=exp.Tuple(expressions=[_literal(str(term)) for term in self.terms]),
                )
            )
        return exp.Property(this=name_expr, value=exp.Tuple(expressions=inner))


MetricDimensionSpec = MetricNamedRefSpec
MetricSegmentSpec = MetricNamedRefSpec


class MetricSpec(PydanticModel):
    """
    Metric definition from YAML.

    Fields ``measure``, ``ts`` (qualified time dimension ref), ``granularity``, ``dimensions``, and
    ``segments`` match the authoring shape (no nested time object).
    """

    kind: Literal["metric"] = "metric"
    name: str
    measure: str
    ts: str
    granularity: MetricGranularityValue
    dimensions: t.List[MetricNamedRefSpec] = Field(default_factory=list)
    segments: t.List[MetricNamedRefSpec] = Field(default_factory=list)
    description: str = ""
    owner: str = ""
    tags: t.List[Tag] = Field(default_factory=list)
    terms: t.List[Term] = Field(default_factory=list)
    ai_context: t.Optional[AiContextSpec] = None

    @model_validator(mode="before")
    @classmethod
    def reject_legacy_metric_yaml_keys(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data
        forbidden = [k for k in ("time", "slices") if k in data]
        if forbidden:
            raise ValueError(
                "invalid metric YAML keys "
                f"{forbidden!r}: use top-level 'ts', 'granularity', and 'dimensions' instead"
            )
        return data

    @field_validator("granularity", mode="before")
    @classmethod
    def normalize_granularity(cls, v: t.Any) -> t.Any:
        if isinstance(v, str):
            return v.strip().lower()
        return v

    @field_validator("ts")
    @classmethod
    def validate_ts(cls, v: str) -> str:
        if not isinstance(v, str):
            raise ValueError(
                f"metric ts must be a string qualified reference, got {type(v).__name__}"
            )
        return _validate_qualified_reference(v.strip(), context="metric ts")

    @field_validator("dimensions", mode="before")
    @classmethod
    def coerce_dimensions(cls, v: t.Any) -> t.List[t.Dict[str, t.Any]]:
        return _coerce_metric_dimensions_yaml(v if v is not None else [])

    @field_validator("segments", mode="before")
    @classmethod
    def coerce_segments(cls, v: t.Any) -> t.List[t.Dict[str, t.Any]]:
        return _coerce_metric_segments_yaml(v if v is not None else [])

    @model_validator(mode="after")
    def validate_metric(self) -> MetricSpec:
        _validate_name(self.name, context="metric name")
        all_refs = [
            self.measure,
            self.ts,
            *[s.ref for s in self.dimensions],
            *[s.ref for s in self.segments],
        ]
        for ref in all_refs:
            _validate_qualified_reference(ref, context="metric item")
        _require_unique("metric refs", all_refs)

        all_names = [s.name for s in self.dimensions] + [s.name for s in self.segments]
        _require_unique("dimension/segment names", all_names)
        for n in all_names:
            if n.lower() in _METRIC_ADJUNCT_NAME_RESERVED:
                raise ValueError(f"name {n!r} is reserved")
        return self

    @property
    def depends_on_semantic_names(self) -> t.FrozenSet[str]:
        names: t.Set[str] = set()
        for ref in (
            self.measure,
            self.ts,
            *[s.ref for s in self.dimensions],
            *[s.ref for s in self.segments],
        ):
            parsed = _parse_qualified_reference(ref)
            if parsed:
                names.add(parsed[0])
        return frozenset(names)

    def data_hash(self) -> str:
        top = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"kind", "name", "measure"},
        )
        payload = {
            **top,
            "ts": self.ts,
            "granularity": self.granularity,
            "dimensions": [s.data_hash() for s in sorted(self.dimensions, key=lambda x: x.name)],
            "segments": [s.data_hash() for s in sorted(self.segments, key=lambda x: x.name)],
        }
        return _hash(payload)

    def metadata_hash(self) -> str:
        top = self.model_dump(
            mode="json",
            exclude_none=True,
            include={"name", "description", "owner", "tags", "terms"},
        )
        payload = {
            **top,
            "ai_context": self.ai_context.model_dump(mode="json", exclude_none=True)
            if self.ai_context
            else None,
            "ts": self.ts,
            "granularity": self.granularity,
            "dimensions": [s.metadata_hash() for s in sorted(self.dimensions, key=lambda x: x.name)],
            "segments": [s.metadata_hash() for s in sorted(self.segments, key=lambda x: x.name)],
        }
        return _hash(payload)

    def render_exps(self) -> t.List[exp.Property]:
        out: t.List[exp.Property] = [
            exp.Property(this=exp.to_identifier("measure"), value=_literal(self.measure)),
            exp.Property(this=exp.to_identifier("ts"), value=_literal(self.ts)),
            exp.Property(this=exp.to_identifier("granularity"), value=_literal(self.granularity)),
        ]
        if self.dimensions:
            out.append(
                exp.Property(
                    this=exp.to_identifier("dimensions"),
                    value=exp.Tuple(
                        expressions=[
                            s.render_exp() for s in sorted(self.dimensions, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        if self.segments:
            out.append(
                exp.Property(
                    this=exp.to_identifier("segments"),
                    value=exp.Tuple(
                        expressions=[
                            s.render_exp() for s in sorted(self.segments, key=lambda x: x.name)
                        ]
                    ),
                )
            )
        return out
