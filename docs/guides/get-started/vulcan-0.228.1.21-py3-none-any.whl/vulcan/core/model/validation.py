from __future__ import annotations

import typing as t
from collections import Counter
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path

from sqlglot import ParseError
from sqlglot import expressions as exp

from vulcan.core.dialect import extract_expression_references
from vulcan.core.model.definition import MetricModel, Model, SemanticModel
from vulcan.core.model.semantic import (
    STRICT_TIMESTAMP_TYPES,
    _parse_qualified_reference,
)
from vulcan.utils.dag import DAG
from vulcan.utils.errors import ConfigError


class JoinDAG(DAG[str]):
    """Graph of which semantic model names may be joined to which others.

    Each model lists join targets by name; we add an edge from that model to each target that also
    exists in the project. Cycle detection follows those edges forward and reports a directed loop.
    Path checks test connectivity from both of the two names (not only one direction).
    """

    @classmethod
    def from_models(cls, models: t.Iterable[Model]) -> JoinDAG:
        joinables = [m for m in models if isinstance(m, SemanticModel)]
        names = {s.name for s in joinables}
        dag = cls()
        for s in joinables:
            dag.add(s.name)
        for s in joinables:
            targets = [j.name for j in s.joins if j.name in names]
            if targets:
                dag.add(s.name, targets)
        return dag

    def join_path_exists(self, start: str, end: str) -> bool:
        """Whether ``end`` is reachable from ``start`` in the join DAG (undirected check, legacy parity)."""
        if start == end:
            return True
        try:
            return end in set(self.downstream(start)) or start in set(self.downstream(end))
        except ValueError:
            return False

    def cycles(self) -> t.List[str]:
        graph = self.graph
        if not graph:
            return []

        visited: t.Set[str] = set()
        rec_stack: t.Set[str] = set()
        path: t.List[str] = []

        def directed_cycle_from(node: str) -> t.Optional[t.List[str]]:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            for nb in sorted(graph.get(node, ())):
                if nb not in visited:
                    c = directed_cycle_from(nb)
                    if c:
                        return c
                elif nb in rec_stack:
                    i = path.index(nb)
                    return path[i:] + [nb]
            path.pop()
            rec_stack.remove(node)
            return None

        for n in sorted(graph):
            if n not in visited:
                cycle = directed_cycle_from(n)
                if cycle:
                    cycle_fmt = " -> ".join(f"'{x}'" for x in cycle)
                    return [
                        f"Circular join dependency detected: {cycle_fmt}. "
                        "Declare joins so the relationship graph between semantic models is acyclic."
                    ]
        return []


@dataclass(frozen=True)
class Issue:
    message: str
    fqn: t.Optional[str] = None
    hint: t.Optional[str] = None

    @classmethod
    def with_fqn(
        cls,
        fqn: t.Optional[str],
        msg: str,
        *,
        hint: t.Optional[str] = None,
    ) -> Issue:
        return cls(message=msg, fqn=fqn, hint=hint)


@dataclass(frozen=True)
class _LinkedSemantic:
    name: str
    semantic: SemanticModel
    physical: Model
    physical_columns: t.Mapping[str, exp.DataType]
    physical_column_names: frozenset[str]
    dimension_names: frozenset[str]
    measure_names: frozenset[str]
    segment_names: frozenset[str]
    members: frozenset[str]


@dataclass
class ModelValidationContext:
    """Working state for validating a loaded model map: dialect, paths, and lookups derived on demand
    (semantic and metric subsets, name indexes, join graph between semantic models).

    When this object is built, every semantic model is matched to the single physical model it
    declares in ``depends_on``. Successful pairings go into ``semantic_bases``; anything wrong with that
    link (missing dependency, wrong count, empty list) becomes an entry in ``issues``. Later checks
    (joins, metrics, and the rest) add to that same ``issues`` list via ``extend_issues``.
    """

    models: t.Mapping[str, Model]
    dialect: str
    config_path: Path
    default_catalog: t.Optional[str] = None

    semantic_bases: t.Dict[str, t.Tuple[SemanticModel, Model]] = field(
        init=False, default_factory=dict, repr=False
    )
    issues: t.List[Issue] = field(init=False, default_factory=list, repr=False)

    @cached_property
    def semantic_models(self) -> t.Tuple[SemanticModel, ...]:
        return tuple(m for m in self.models.values() if isinstance(m, SemanticModel))

    @cached_property
    def metric_models(self) -> t.Tuple[MetricModel, ...]:
        return tuple(m for m in self.models.values() if isinstance(m, MetricModel))

    @cached_property
    def semantic_by_name(self) -> t.Dict[str, SemanticModel]:
        return {sm.name: sm for sm in self.semantic_models}

    @cached_property
    def declared_semantic_names(self) -> frozenset[str]:
        return frozenset(self.semantic_by_name.keys())

    @cached_property
    def join_dag(self) -> JoinDAG:
        return JoinDAG.from_models(self.models.values())

    def __post_init__(self) -> None:
        bases: t.Dict[str, t.Tuple[SemanticModel, Model]] = {}
        dep_issues: t.List[Issue] = []
        for sm in self.semantic_models:
            deps = sm.depends_on
            if not deps:
                dep_issues.append(Issue.with_fqn(sm.fqn, "semantic model has empty depends_on."))
                continue
            if len(deps) != 1:
                dep_issues.append(
                    Issue.with_fqn(
                        sm.fqn,
                        "semantic model must depend on exactly one physical model.",
                    )
                )
                continue
            dep_fqn = next(iter(deps))
            base = self.models.get(dep_fqn)
            if base is None:
                dep_issues.append(
                    Issue.with_fqn(
                        sm.fqn,
                        f"depends_on {dep_fqn!r} not found in loaded models "
                        f"(semantic YAML 'depends_on' must match a physical model name in this project).",
                    )
                )
                continue
            bases[sm.name] = (sm, base)
        self.semantic_bases = bases
        self.issues = dep_issues

    def extend_issues(self, found: t.Iterable[Issue]) -> None:
        self.issues.extend(found)

    def linked_semantic(self, semantic_name: str) -> _LinkedSemantic:
        """Projection for one linked semantic model (names + physical column types), built on demand.

        ``members`` is the set of declared semantic fields (dimensions, measures, segments) only; it
        excludes physical-only columns so metric refs cannot rely on undeclared table columns.
        """
        sm, physical = self.semantic_bases[semantic_name]
        physical_columns = physical.columns_to_types or {}
        physical_column_names = frozenset(physical_columns.keys())
        dimension_names = frozenset(d.name for d in sm.dimensions)
        measure_names = frozenset(m.name for m in sm.measures)
        segment_names = frozenset(s.name for s in sm.segments)
        members = dimension_names | measure_names | segment_names
        return _LinkedSemantic(
            name=semantic_name,
            semantic=sm,
            physical=physical,
            physical_columns=physical_columns,
            physical_column_names=physical_column_names,
            dimension_names=dimension_names,
            measure_names=measure_names,
            segment_names=segment_names,
            members=members,
        )

    def format_issues(self, issues: t.Optional[t.Sequence[Issue]] = None) -> str:
        rows = self.issues if issues is None else issues
        lines: t.List[str] = []
        for issue in rows:
            prefix = self._issue_location_prefix(issue.fqn)
            lines.append(f"{prefix} -")
            lines.append(f"  {issue.message}")
            if issue.hint:
                lines.append(f"  HINT: {issue.hint}")
        return "\n".join(lines)

    def _path_relative_to_config(self, path: Path) -> str:
        try:
            return str(path.resolve().relative_to(self.config_path.resolve()))
        except ValueError:
            return str(path)

    def _issue_location_prefix(self, fqn: t.Optional[str]) -> str:
        if fqn and fqn in self.models:
            m = self.models[fqn]
            if m._path:
                return self._path_relative_to_config(m._path)
            return f"{m.name} ({fqn})"
        if fqn:
            return fqn
        return str(self.config_path)


def _strict_ts_message_and_hint(
    column_type: exp.DataType, field_name: str
) -> t.Optional[t.Tuple[str, t.Optional[str]]]:
    if not column_type:
        return f"'{field_name}' has unknown column type", None
    if column_type.is_type(*STRICT_TIMESTAMP_TYPES):
        return None
    if column_type.is_type(exp.DataType.Type.DATE):
        return (
            f"'{field_name}' uses DATE type. Time dimensions require TIMESTAMP.",
            f"CAST({field_name} AS TIMESTAMP) AS {field_name}",
        )
    if column_type.is_type(exp.DataType.Type.TIME):
        return (
            f"'{field_name}' uses TIME type (time-of-day only). Time dimensions need full timestamps.",
            f"CAST(CONCAT(date_column, ' ', {field_name}) AS TIMESTAMP)",
        )
    if column_type.is_type(exp.DataType.Type.INTERVAL):
        return (
            f"'{field_name}' uses INTERVAL type (duration). Time dimensions need point-in-time values.",
            f"base_timestamp + {field_name}",
        )
    return (
        f"'{field_name}' requires TIMESTAMP type for time dimensions, got {column_type}",
        None,
    )


def _qualified_refs_in_expression(
    expression: str,
    dialect: str,
    *,
    into: t.Optional[t.Type[exp.Expression]] = None,
) -> t.Tuple[t.Optional[t.List[t.Tuple[str, str, str]]], t.Optional[str]]:
    """Returns ``(refs, parse_error)``. ``refs`` is ``None`` iff extraction raised."""
    try:
        cols = extract_expression_references(expression, dialect, into=into)
    except (ParseError, ValueError) as e:
        return None, str(e)
    out: t.List[t.Tuple[str, str, str]] = []
    for col in cols:
        if not col.table or not col.name:
            continue
        ref = f"{col.table}.{col.name}"
        parsed = _parse_qualified_reference(ref)
        if not parsed:
            continue
        model_name, field = parsed
        out.append((ref, model_name, field))
    return out, None


def _declared_but_unresolved_msg(ctx: ModelValidationContext, model_name: str) -> str:
    if model_name not in ctx.declared_semantic_names:
        return (
            f"semantic model {model_name!r} is not declared "
            f"(declared: {sorted(ctx.declared_semantic_names)})."
        )
    return (
        f"semantic model {model_name!r} is declared but has no linked physical base "
        "(check depends_on)."
    )


def _semantic_grains(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Check that the physical model backing this semantic model is safe to join on.

    - If the physical model has no grains, report that grains are required.
    - If this semantic model declares joins to others but the physical model still has no grains,
      report that mismatch (joins need a grained physical base).
    """
    sm = ls.semantic
    physical = ls.physical
    sm_fqn = sm.fqn
    grains_ok = bool(physical.grains)
    out: t.List[Issue] = []
    if not grains_ok:
        out.append(
            Issue.with_fqn(
                sm_fqn,
                f"physical model {physical.name!r} must define grains.",
            )
        )
    if sm.joins and not grains_ok:
        out.append(
            Issue.with_fqn(
                sm_fqn,
                f"semantic model {ls.name!r} declares joins but physical model "
                f"{physical.name!r} has no grains.",
            )
        )
    return out


def _semantic_dimensions(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Check dimension columns against the physical table and time-dimension typing.

    - When we know physical columns, flag dimensions whose names are not present on the physical
      model (unknown column references).
    - For object dimensions with granularities, ensure the backing column type is strict-timestamp
      compatible (DATE/TIME/INTERVAL and similar get hints toward TIMESTAMP).
    """
    sm = ls.semantic
    sm_fqn = sm.fqn
    out: t.List[Issue] = []
    if ls.physical_column_names:
        missing_dims = ls.dimension_names - ls.physical_column_names
        if missing_dims:
            out.append(
                Issue.with_fqn(
                    sm_fqn,
                    f"dimensions reference unknown columns: {sorted(missing_dims)}.",
                )
            )
        for d in sm.dimensions:
            if d.granularities and d.name in ls.physical_columns:
                msg_hint = _strict_ts_message_and_hint(ls.physical_columns[d.name], d.name)
                if msg_hint:
                    msg, hint = msg_hint
                    out.append(Issue.with_fqn(sm_fqn, msg, hint=hint))
    return out


def _semantic_field_uniqueness(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Ensure measure, segment, and dimension names do not collide within one semantic model.

    - Build the combined list of measure names, segment names, and dimension names, then report
      any name that appears more than once.
    """
    sm = ls.semantic
    sm_fqn = sm.fqn
    all_field_names = (
        [m.name for m in sm.measures] + [s.name for s in sm.segments] + sorted(ls.dimension_names)
    )
    dupes = {n for n, c in Counter(all_field_names).items() if c > 1}
    if not dupes:
        return []
    return [
        Issue.with_fqn(
            sm_fqn,
            f"duplicate names across dimensions, measures, segments: {sorted(dupes)}.",
        )
    ]


def _semantic_measures(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Validate measure filters and expressions: parse errors, joins, and field references.

    - Filters: parse each filter expression; for each qualified ref, require a join path to the
      other semantic model when it differs from this one, require that model to be linked to a
      physical base, and require filter fields to be declared dimensions on the target semantic model.
    - Expressions: same join and linkage rules; fields must be declared dimensions on the target
      semantic model (not merely columns on the physical table).
    """
    sm = ls.semantic
    semantic_name = ls.name
    sm_fqn = sm.fqn
    bases = ctx.semantic_bases
    out: t.List[Issue] = []
    for measure in sm.measures:
        mname = measure.name

        for filt in measure.filters:
            qrefs, parse_err = _qualified_refs_in_expression(filt, ctx.dialect, into=exp.Condition)
            if parse_err is not None:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"measure {mname!r} filter could not be parsed ({parse_err}): {filt!r}.",
                    )
                )
                continue
            if qrefs is None:
                continue
            for ref, model_name, field in qrefs:
                if model_name != semantic_name:
                    if not ctx.join_dag.join_path_exists(semantic_name, model_name):
                        out.append(
                            Issue.with_fqn(
                                sm_fqn,
                                f"measure {mname!r} filter {ref!r}: no join path between "
                                f"{semantic_name!r} and {model_name!r}.",
                            )
                        )
                        continue
                if model_name not in bases:
                    out.append(
                        Issue.with_fqn(
                            sm_fqn,
                            f"measure {mname!r} filter {ref!r}: "
                            f"{_declared_but_unresolved_msg(ctx, model_name)}",
                        )
                    )
                    continue
                target_ls = ctx.linked_semantic(model_name)
                if field not in target_ls.dimension_names:
                    out.append(
                        Issue.with_fqn(
                            sm_fqn,
                            f"measure {mname!r} filter {ref!r}: unknown dimension {field!r} "
                            f"in {model_name!r}.",
                        )
                    )

        if measure.expression.strip():
            qrefs, parse_err = _qualified_refs_in_expression(measure.expression, ctx.dialect)
            if parse_err is not None:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"measure {mname!r} expression could not be parsed ({parse_err}).",
                    )
                )
            elif qrefs is not None:
                for ref, model_name, field in qrefs:
                    if model_name != semantic_name:
                        if not ctx.join_dag.join_path_exists(semantic_name, model_name):
                            out.append(
                                Issue.with_fqn(
                                    sm_fqn,
                                    f"measure {mname!r} {ref!r}: no join path between "
                                    f"{semantic_name!r} and {model_name!r}.",
                                )
                            )
                            continue
                    if model_name not in bases:
                        out.append(
                            Issue.with_fqn(
                                sm_fqn,
                                f"measure {mname!r} {ref!r}: "
                                f"{_declared_but_unresolved_msg(ctx, model_name)}",
                            )
                        )
                        continue
                    target_dims = ctx.linked_semantic(model_name).dimension_names
                    if field not in target_dims:
                        out.append(
                            Issue.with_fqn(
                                sm_fqn,
                                f"measure {mname!r}: unknown dimension {field!r} in {model_name!r}.",
                            )
                        )
    return out


def _semantic_segments(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Validate segment expressions: parsing and references scoped to this semantic model.

    - Parse each segment's expression; failures become issues with the raw expression attached.
    - Qualified refs must target this semantic model only (no cross-model refs in segments).
    - Each field must be a declared dimension on this semantic model.
    """
    sm = ls.semantic
    semantic_name = ls.name
    sm_fqn = sm.fqn
    out: t.List[Issue] = []
    for seg in sm.segments:
        sname = seg.name
        qrefs, parse_err = _qualified_refs_in_expression(
            seg.expression, ctx.dialect, into=exp.Condition
        )
        if parse_err is not None:
            out.append(
                Issue.with_fqn(
                    sm_fqn,
                    f"segment {sname!r} expression could not be parsed ({parse_err}): "
                    f"{seg.expression!r}.",
                )
            )
            continue
        if qrefs is None:
            continue
        for ref, model_name, field in qrefs:
            if model_name != semantic_name:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"segment {sname!r} may only reference the current semantic model, "
                        f"not {ref!r}.",
                    )
                )
            elif field not in ls.dimension_names:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"segment {sname!r}: unknown dimension {field!r}.",
                    )
                )
    return out


def _semantic_joins(ctx: ModelValidationContext, ls: _LinkedSemantic) -> t.List[Issue]:
    """Validate declared joins to other semantic models: targets, grains, and join predicates.

    - Join target name must be a declared semantic model and must have a linked physical base.
    - Join predicates are skipped when this model's physical base has no grains (same rule as
      elsewhere: grains required before join SQL is checked).
    - Parse the join expression; each qualified ref must use only this model's name or the join
      target's name as the table, and fields must be declared dimensions on that semantic model.
    """
    sm = ls.semantic
    semantic_name = ls.name
    physical = ls.physical
    sm_fqn = sm.fqn
    bases = ctx.semantic_bases
    grains_ok = bool(physical.grains)
    out: t.List[Issue] = []
    for join in sm.joins:
        jn = join.name
        if jn not in ctx.declared_semantic_names:
            out.append(
                Issue.with_fqn(
                    sm_fqn,
                    f"join {jn!r} target is not a declared semantic model name.",
                )
            )
            continue
        if jn not in bases:
            out.append(
                Issue.with_fqn(
                    sm_fqn,
                    f"join {jn!r} has no linked physical model.",
                )
            )
            continue
        if not grains_ok:
            continue
        target_ls = ctx.linked_semantic(jn)
        qrefs, parse_err = _qualified_refs_in_expression(
            join.expression, ctx.dialect, into=exp.Condition
        )
        if parse_err is not None:
            out.append(
                Issue.with_fqn(
                    sm_fqn,
                    f"join {jn!r} expression could not be parsed ({parse_err}): "
                    f"{join.expression!r}.",
                )
            )
            continue
        if qrefs is None:
            continue
        for _ref, table_name, column_name in qrefs:
            if table_name not in (semantic_name, jn):
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"join {jn!r}: expected tables {semantic_name!r} or {jn!r}, "
                        f"got {table_name!r}.",
                    )
                )
            elif table_name == semantic_name and column_name not in ls.dimension_names:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"join {jn!r}: unknown dimension {column_name!r} for {semantic_name!r}.",
                    )
                )
            elif table_name == jn and column_name not in target_ls.dimension_names:
                out.append(
                    Issue.with_fqn(
                        sm_fqn,
                        f"join {jn!r}: unknown dimension {column_name!r} for {jn!r}.",
                    )
                )
    return out


def _metric_field_and_time_checks(
    ctx: ModelValidationContext,
    mm: MetricModel,
    ref: str,
) -> t.List[Issue]:
    """Field membership and strict timestamp for the metric time dimension ref."""
    parsed = _parse_qualified_reference(ref)
    if not parsed:
        return []
    model_name, field_name = parsed
    mm_fqn = mm.fqn
    out: t.List[Issue] = []
    ls_ref = ctx.linked_semantic(model_name)
    cols_t = ls_ref.physical_columns
    if field_name not in ls_ref.members:
        out.append(
            Issue.with_fqn(
                mm_fqn,
                f"unknown field {field_name!r} in semantic model {model_name!r}.",
            )
        )
    if ref == mm.ts:
        ct = cols_t.get(field_name)
        if ct:
            msg_hint = _strict_ts_message_and_hint(ct, field_name)
            if msg_hint:
                msg, hint = msg_hint
                out.append(Issue.with_fqn(mm_fqn, msg, hint=hint))
    return out


def _metric_ref_strings(mm: MetricModel) -> t.List[str]:
    """Collect every ref string from a metric definition for downstream parsing.

    - measure and time.dimension.
    - each metric dimension's ``ref``, in dimension name order.
    - each segment's ``ref``, in segment name order.

    Order matches how metric validation walks the model.
    """
    return [
        mm.measure,
        mm.ts,
        *[s.ref for s in mm.dimensions],
        *[s.ref for s in mm.segments],
    ]


def _metric_reference_issues(
    ctx: ModelValidationContext,
    mm: MetricModel,
) -> t.List[Issue]:
    """Validate metric refs after parsing each ``model.field`` string.

    - Skip refs that do not parse as qualified references.
    - If the semantic model name is not declared, report once per unknown name (with declared names).
    - If the name is declared but not linked to a physical base (``depends_on``), report once per name.
    - For refs that resolve, run field membership against declared semantic ``members``
      (dimensions, measures, segments; not raw physical columns) and, for the time dimension ref
      only, strict-timestamp checks on the physical column type.
    """
    out: t.List[Issue] = []
    mm_fqn = mm.fqn
    metric_reported: t.Set[str] = set()

    for ref in _metric_ref_strings(mm):
        parsed = _parse_qualified_reference(ref)
        if not parsed:
            continue
        model_name, _ = parsed
        if model_name not in ctx.semantic_by_name:
            if model_name not in metric_reported:
                metric_reported.add(model_name)
                out.append(
                    Issue.with_fqn(
                        mm_fqn,
                        f"unknown semantic model {model_name!r} (see {ref!r}); "
                        f"declared: {sorted(ctx.declared_semantic_names)}.",
                    )
                )
            continue
        if model_name not in ctx.semantic_bases:
            if model_name not in metric_reported:
                metric_reported.add(model_name)
                out.append(
                    Issue.with_fqn(
                        mm_fqn,
                        f"{ref!r}: {_declared_but_unresolved_msg(ctx, model_name)}",
                    )
                )
            continue

        out.extend(_metric_field_and_time_checks(ctx, mm, ref))

    return out


def _metric_join_pairs(
    ctx: ModelValidationContext,
    mm: MetricModel,
) -> t.List[Issue]:
    """Check that every pair of *linked* semantic models used by the metric can reach each other in the join DAG.

    - Build the set of semantic short names from metric refs that parse and appear in ``semantic_bases``.
    - For each unordered pair, if there is no join path in ``ctx.join_dag``, emit an issue on the metric.
    """
    out: t.List[Issue] = []
    resolved = list(
        {
            n
            for ref in _metric_ref_strings(mm)
            if (p := _parse_qualified_reference(ref)) and (n := p[0]) in ctx.semantic_bases
        }
    )
    for i, a in enumerate(resolved):
        for b in resolved[i + 1 :]:
            if not ctx.join_dag.join_path_exists(a, b):
                out.append(
                    Issue.with_fqn(
                        mm.fqn,
                        f"no join path between semantic models {a!r} and {b!r}.",
                    )
                )
    return out


def _validate_semantic_joins_unlinked(ctx: ModelValidationContext) -> t.List[Issue]:
    """Validate declared join targets when the semantic model has no resolved physical base."""

    out: t.List[Issue] = []
    linked = frozenset(ctx.semantic_bases.keys())
    declared = ctx.declared_semantic_names
    for sm in ctx.semantic_models:
        if sm.name in linked:
            continue
        for join in sm.joins:
            jn = join.name
            if jn not in declared:
                out.append(
                    Issue.with_fqn(
                        sm.fqn,
                        f"join {jn!r} target is not a declared semantic model name.",
                    )
                )
    return out


def _validate_semantics(ctx: ModelValidationContext) -> t.List[Issue]:
    out: t.List[Issue] = []
    for msg in ctx.join_dag.cycles():
        out.append(Issue.with_fqn(None, msg))

    out.extend(_validate_semantic_joins_unlinked(ctx))

    for semantic_name in ctx.semantic_bases:
        ls = ctx.linked_semantic(semantic_name)
        for fn in (
            _semantic_grains,
            _semantic_dimensions,
            _semantic_field_uniqueness,
            _semantic_measures,
            _semantic_segments,
            _semantic_joins,
        ):
            out.extend(fn(ctx, ls))
    return out


def _validate_metrics(ctx: ModelValidationContext) -> t.List[Issue]:
    out: t.List[Issue] = []
    for mm in ctx.metric_models:
        for fn in (_metric_reference_issues, _metric_join_pairs):
            out.extend(fn(ctx, mm))
    return out


class ModelValidationError(ConfigError):
    def __init__(self, ctx: ModelValidationContext) -> None:
        self.ctx = ctx
        text = (
            "Model validation failed:\n" + ctx.format_issues()
            if ctx.issues
            else "Model validation failed."
        )
        super().__init__(text, location=ctx.config_path)

    @property
    def issues(self) -> t.List[Issue]:
        return self.ctx.issues


def validate(
    models: t.Mapping[str, Model],
    *,
    dialect: str,
    config_path: Path,
    default_catalog: t.Optional[str] = None,
) -> None:
    """Validate the full loaded model map.

    Runs semantic/metric checks (when the project defines semantic or metric models) and raises
    :class:`ModelValidationError` on failure. Dependency issues are attached during
    :class:`ModelValidationContext` construction.
    """
    ctx = ModelValidationContext(
        models=models,
        dialect=dialect,
        config_path=config_path,
        default_catalog=default_catalog,
    )
    if ctx.semantic_models or ctx.metric_models:
        ctx.extend_issues(_validate_semantics(ctx))
        ctx.extend_issues(_validate_metrics(ctx))
    if ctx.issues:
        raise ModelValidationError(ctx)
