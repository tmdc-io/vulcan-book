from __future__ import annotations

import copy
import logging
import os
import re
import typing as t
from functools import lru_cache
from urllib.parse import urlsplit

from vulcan.core import constants as c
from vulcan.core.config.connection import _parse_dataos_depot_name

logger = logging.getLogger(__name__)
_TRAILING_V1 = re.compile(r"/v1/?$")

_HERA_GEN_SCHEMA_PKG = "hera_sdk.generated"
_HERA_INGEST_PKG = "hera_sdk.ingestion"


def _ensure_hera_sdk_available() -> None:
    """
    Ensure generated schema and ingestion modules from ``hera-sdk`` are importable.

    Raises:
        ImportError: If the ``hera_sdk`` distribution is not installed.
    """
    import importlib.util

    if importlib.util.find_spec("hera_sdk.generated.schema.entity.data.table") is None:
        raise ImportError(
            "Hera catalog sync requires `hera_sdk` (install `hera-sdk`)."
        )


def _schema_mod(subpath: str):
    """Import generated schema module ``hera_sdk.generated.{subpath}``."""

    import importlib

    return importlib.import_module(f"{_HERA_GEN_SCHEMA_PKG}.{subpath}")


def _ingest_mod(subpath: str):
    """Import ingestion helper module ``hera_sdk.ingestion.{subpath}``."""

    import importlib

    return importlib.import_module(f"{_HERA_INGEST_PKG}.{subpath}")


_ensure_hera_sdk_available()

from hera_sdk.generated.schema.entity.services.connections.metadata.heraConnection import (
    AuthProvider,
    ExtraHeaders,
    HeraConnection,
)
from hera_sdk.generated.schema.security.client.heraJWTClientConfig import (
    HeraJWTClientConfig,
)
from hera_sdk.generated.schema.security.ssl.verifySSLConfig import VerifySSL
from hera_sdk.ingestion.hera_meta.hera_api import Hera


@lru_cache(maxsize=1)
def _hera_generated_schema():
    """
    Load generated catalog wire types bundled with ``hera-sdk`` (schema + ingest helpers).

    Returns:
        A simple namespace object (see ``HeraSchemaTypes``) with request/model classes.
    """
    CreateDatabaseRequest = _schema_mod("schema.api.data.createDatabase").CreateDatabaseRequest
    CreateDatabaseSchemaRequest = _schema_mod("schema.api.data.createDatabaseSchema").CreateDatabaseSchemaRequest
    CreateTableRequest = _schema_mod("schema.api.data.createTable").CreateTableRequest
    CreateDataProductRequest = _schema_mod("schema.api.domains.createDataProduct").CreateDataProductRequest
    CreateDomainRequest = _schema_mod("schema.api.domains.createDomain").CreateDomainRequest
    CreateTenantRequest = _schema_mod("schema.api.domains.createTenant").CreateTenantRequest
    AddLineageRequest = _schema_mod("schema.api.lineage.addLineage").AddLineageRequest
    CreateDatabaseServiceRequest = _schema_mod(
        "schema.api.services.createDatabaseService"
    ).CreateDatabaseServiceRequest
    Column = _schema_mod("schema.entity.data.table").Column
    Table = _schema_mod("schema.entity.data.table").Table
    TableType = _schema_mod("schema.entity.data.table").TableType
    DataProduct = _schema_mod("schema.entity.domains.dataProduct").DataProduct
    QualityStatus = _schema_mod("schema.entity.domains.dataProduct").QualityStatus
    RunStatus = _schema_mod("schema.entity.domains.dataProduct").RunStatus
    Domain = _schema_mod("schema.entity.domains.domain").Domain
    DomainType = _schema_mod("schema.entity.domains.domain").DomainType
    Tenant = _schema_mod("schema.entity.domains.tenant").Tenant
    ConnectionOptions = _schema_mod("schema.entity.services.connections.connectionBasicType").ConnectionOptions
    mod_cdb = _schema_mod("schema.entity.services.connections.database.customDatabaseConnection")
    CustomDatabaseConnection = mod_cdb.CustomDatabaseConnection
    CustomDatabaseType = mod_cdb.CustomDatabaseType
    mod_ds = _schema_mod("schema.entity.services.databaseService")
    DatabaseConnection = mod_ds.DatabaseConnection
    DatabaseService = mod_ds.DatabaseService
    DatabaseServiceType = mod_ds.DatabaseServiceType
    User = _schema_mod("schema.entity.teams.user").User
    mod_basic = _schema_mod("schema.type.basic")
    EntityName = mod_basic.EntityName
    FullyQualifiedEntityName = mod_basic.FullyQualifiedEntityName
    Timestamp = mod_basic.Timestamp
    EntitiesEdge = _schema_mod("schema.type.entityLineage").EntitiesEdge
    EntityReference = _schema_mod("schema.type.entityReference").EntityReference
    EntityReferenceList = _schema_mod("schema.type.entityReferenceList").EntityReferenceList
    TagLabel = _schema_mod("schema.type.tagLabel").TagLabel
    ColumnTag = _ingest_mod("models.table_metadata").ColumnTag

    return type("HeraSchemaTypes", (), {k: v for k, v in locals().items()})


def step(name: str, fn: t.Callable[[], t.Any]) -> t.Any:
    try:
        return fn()
    except Exception:
        logger.exception("Hera step '%s' failed", name)
        return None


def is_prod(environment: str) -> bool:
    return environment == c.PROD


def normalize(value: t.Optional[str]) -> str:
    return (value or "").strip()


def sanitize(value: t.Optional[str]) -> str:
    if not value:
        return ""
    return value.strip().strip('"').strip("'")


def parse_fqn(fqn: str, default_db: str, default_schema: str) -> tuple[str, str, str]:
    parts = [sanitize(part) for part in (fqn or "").split(".") if sanitize(part)]
    if len(parts) >= 3:
        return parts[-3], parts[-2], parts[-1]
    if len(parts) == 2:
        return default_db, parts[0], parts[1]
    if len(parts) == 1:
        return default_db, default_schema, parts[0]
    return default_db, default_schema, "unknown"


def resolve_connection_kind_for_hera(connection_type: t.Optional[str]) -> str:
    mapping = {
        "postgres": "Postgres",
        "postgresql": "Postgres",
        "snowflake": "Snowflake",
        "bigquery": "BigQuery",
        "databricks": "Databricks",
        "mysql": "Mysql",
        "mssql": "Mssql",
        "redshift": "Redshift",
        "trino": "Trino",
        "clickhouse": "Clickhouse",
        "athena": "Athena",
        "spark": "Spark",
        "oracle": "Oracle",
    }
    return mapping.get((connection_type or "").lower(), "CustomDatabase")


def source_depot_name() -> t.Optional[str]:
    depot_address = os.getenv("DATAOS_SOURCE_DEPOT_ADDRESS")
    if not depot_address:
        return None
    try:
        return _parse_dataos_depot_name(depot_address)
    except Exception:
        logger.debug("Could not parse depot name from DATAOS_SOURCE_DEPOT_ADDRESS=%s", depot_address)
        return None


def _normalize_url(url: str) -> str:
    return _TRAILING_V1.sub("", url.rstrip("/"))


def create_hera_client(url: str, token: str, verify_ssl: bool = False) -> t.Any:
    """
    Build the catalog client from ``hera_sdk``.

    Returns:
        The Hera SDK client used for typed catalog CRUD operations.
    """

    normalized = _normalize_url(url)
    conn = HeraConnection(
        hostPort=normalized,
        authProvider=AuthProvider.hera,
        verifySSL=VerifySSL.validate if verify_ssl else VerifySSL.no_ssl,
        securityConfig=HeraJWTClientConfig(jwtToken=token),
        # extraHeaders=ExtraHeaders(root={"X-Hera-Producer": "vulcan"}), #TODO: time increase if set, need to debug in hera
        enableVersionValidation=False,
    )
    return Hera(config=conn)


def source_service_name(connection_uri: str) -> str:
    parsed = urlsplit(connection_uri or "")
    engine = sanitize((parsed.scheme or "").split("+")[0]) or "unknown"
    parts = [engine]
    host = sanitize(parsed.hostname or "")
    if host:
        parts.append(host)
    if parsed.port:
        parts.append(str(parsed.port))
    elif not host:
        path = sanitize(parsed.path)
        if path:
            parts.append(path)
    return "_".join(part for part in parts if part) or "unknown"


def vulcan_service_name(tenant: t.Optional[str], product: t.Optional[str]) -> str:
    parts = [sanitize(tenant), sanitize(product)]
    name = "_".join(part for part in parts if part)
    return name or "vulcan"


def data_product_name(tenant: str, product: str) -> str:
    return "_".join(part for part in (sanitize(tenant), sanitize(product)) if part)


def _logical_to_wire_dtype(logical: str) -> tuple[str, t.Optional[int]]:
    mapping: dict[str, tuple[str, t.Optional[int]]] = {
        "number": ("NUMERIC", None),
        "string": ("STRING", None),
        "time": ("TIMESTAMP", None),
        "boolean": ("BOOLEAN", None),
    }
    return mapping.get(logical, ("STRING", None))


def entity_tags(tags: t.Iterable[t.Any], terms: t.Iterable[t.Any]) -> list[dict[str, str]]:
    labels: list[dict[str, str]] = []
    for tag in tags or []:
        value = normalize(str(tag))
        if not value:
            continue
        quoted = f'"{value}"' if "." in value else value
        labels.append(
            {
                "tagFQN": f"{_VULCAN_CLASSIFICATION}.{quoted}",
                "source": "Classification",
                "labelType": "Automated",
                "state": "Confirmed",
            }
        )
    for term in terms or []:
        value = normalize(str(term))
        if value:
            labels.append(
                {
                    "tagFQN": value,
                    "source": "Glossary",
                    "labelType": "Automated",
                    "state": "Confirmed",
                }
            )
    return labels


def _column_tag_labels(tags: t.Iterable[t.Any], terms: t.Iterable[t.Any]) -> list[dict[str, str]]:
    return entity_tags(tags, terms)


def result_columns_for_hera(result_columns: list[dict[str, str]]) -> list[t.Any]:
    hr = _hera_generated_schema()
    DataType = _schema_mod("schema.entity.data.table").DataType
    cols: list[t.Any] = []
    for column in result_columns or []:
        data_type = (column.get("type") or "string").lower()
        if data_type in {"integer", "int", "bigint", "smallint"}:
            mapped = DataType.INT
        elif data_type in {"decimal", "float", "double", "number"}:
            mapped = DataType.NUMERIC
        elif data_type in {"boolean", "bool"}:
            mapped = DataType.BOOLEAN
        elif data_type in {"timestamp", "datetime", "time"}:
            mapped = DataType.TIMESTAMP
        else:
            mapped = DataType.STRING
        cols.append(hr.Column(name=column["name"], dataType=mapped))
    return cols


def attach_tags(hera: t.Any, entity: t.Any, tag_labels: list[dict[str, str]]) -> None:
    hr = _hera_generated_schema()
    Table = _schema_mod("schema.entity.data.table").Table
    TagLabel = _schema_mod("schema.type.tagLabel").TagLabel
    PatchOperation = _ingest_mod("hera_meta.mixins.patch_mixin_utils").PatchOperation

    desired_fqns = {label["tagFQN"] for label in tag_labels}

    try:
        fresh = hera.get_by_id(entity=Table, entity_id=entity.id, fields=["tags"])
        existing_tags = (fresh.tags if fresh else None) or []
    except Exception:
        existing_tags = []

    existing_fqns = {tag.tagFQN.root for tag in existing_tags}
    stale_fqns = existing_fqns - desired_fqns
    if stale_fqns:
        stale_labels = [tag for tag in existing_tags if tag.tagFQN.root in stale_fqns]
        try:
            hera.patch_tags(
                entity=Table, source=entity, tag_labels=stale_labels, operation=PatchOperation.REMOVE,
            )
        except Exception as exc:
            logger.debug("Could not remove stale tags from %s: %s", getattr(entity, "fullyQualifiedName", entity), exc)

    if not tag_labels:
        return

    CreateTagRequest = _schema_mod("schema.api.classification.createTag").CreateTagRequest
    for label in tag_labels:
        fqn = label["tagFQN"]
        if label.get("source") == "Classification" and "." in fqn:
            classification, tag_name = fqn.split(".", 1)
            try:
                hera.create_or_update(data=CreateTagRequest(
                    classification=classification,
                    name=tag_name,
                    description="",
                ))
            except Exception:
                pass

    try:
        hera.patch_tags(entity=Table, source=entity, tag_labels=[TagLabel(**label) for label in tag_labels])
    except Exception as exc:
        logger.warning("Skipping tag attach for %s: %s", getattr(entity, "fullyQualifiedName", entity), exc)


def collect_column_tags(entity_fqn: str, columns: list[dict[str, t.Any]]) -> list[t.Any]:
    hr = _hera_generated_schema()
    tags: list[t.Any] = []
    for column in columns or []:
        for label in column.get("tags") or []:
            tags.append(
                hr.ColumnTag(
                    column_fqn=f"{entity_fqn}.{column['name']}",
                    tag_label=hr.TagLabel(**label),
                )
            )
    return tags


def attach_column_tags(hera: t.Any, entity: t.Any, column_tags: list[t.Any]) -> None:
    if not column_tags:
        return

    CreateTagRequest = _schema_mod("schema.api.classification.createTag").CreateTagRequest
    for ct in column_tags:
        label = ct.tag_label if hasattr(ct, "tag_label") else getattr(ct, "tagLabel", None)
        if not label:
            continue
        fqn = label.tagFQN.root if hasattr(label.tagFQN, "root") else str(label.tagFQN)
        source = label.source.value if hasattr(label.source, "value") else str(label.source)
        if source == "Classification" and "." in fqn:
            classification, tag_name = fqn.split(".", 1)
            try:
                hera.create_or_update(data=CreateTagRequest(
                    classification=classification,
                    name=tag_name,
                    description="",
                ))
            except Exception:
                pass

    try:
        hera.patch_column_tags(table=entity, column_tags=column_tags)
    except Exception as exc:
        logger.warning("Skipping column tag attach for %s: %s", getattr(entity, "fullyQualifiedName", entity), exc)


def _clone_entity(entity: t.Any) -> t.Any:
    if hasattr(entity, "model_copy"):
        return entity.model_copy(deep=True)
    if hasattr(entity, "copy"):
        try:
            return entity.copy(deep=True)
        except TypeError:
            return entity.copy()
    return copy.deepcopy(entity)


def _resolve_user_id(hera: t.Any, candidate: str) -> t.Optional[str]:
    if not candidate:
        return None
    hr = _hera_generated_schema()
    try:
        user = hera.get_by_name(entity=hr.User, fqn=candidate)
    except Exception:
        return None
    if not user or not getattr(user, "id", None):
        return None
    return user.id.root if hasattr(user.id, "root") else user.id


def resolve_owner_refs(
    hera: t.Any,
    users: t.Optional[list[dict[str, t.Any]]] = None,
) -> t.Optional[list[t.Any]]:
    """
    Resolve a data-product owner from the config ``users`` list.

    Selection order:
        1. First user whose ``type`` (case-insensitive) equals ``"owner"``.
        2. First user in the list regardless of type.

    The selected username is looked up in Hera to obtain its UUID.
    Model-level ``owner`` fields are **not** handled here; that
    validation belongs in Vulcan, not the sync layer.

    Args:
        hera: Hera client instance.
        users: Config-level users list (dicts with ``name``/``username``
            and optional ``type`` keys).

    Returns:
        A single-element list with the resolved ``EntityReference``,
        or ``None`` if no candidate could be resolved.
    """
    if not users:
        return None

    hr = _hera_generated_schema()
    owner_user = next(
        (u for u in users if (u.get("type") or "").strip().lower() == "owner"),
        None,
    )
    fallback = owner_user or users[0]
    candidate = normalize(fallback.get("name") or fallback.get("username"))
    if not candidate:
        return None

    user_id = _resolve_user_id(hera, candidate)
    if user_id:
        return [hr.EntityReference(id=user_id, type="user", name=candidate)]

    logger.warning("Owner user '%s' not found in Hera; skipping owner assignment.", candidate)
    return None


def resolve_user_owner_ref(hera: t.Any, username: t.Optional[str]) -> t.Optional[list[t.Any]]:
    """
    Resolve a single username (e.g. from an API token) to an owner reference.

    Performs a Hera lookup to obtain the user's UUID. If the user does not
    exist in Hera, logs a warning and returns ``None``.

    Args:
        hera: Hera client instance.
        username: The username to resolve (typically from the authenticated
            caller's token).

    Returns:
        A single-element list with the resolved ``EntityReference``,
        or ``None`` if the user was not found.
    """
    candidate = normalize(username)
    if not candidate:
        return None
    hr = _hera_generated_schema()
    user_id = _resolve_user_id(hera, candidate)
    if user_id:
        return [hr.EntityReference(id=user_id, type="user", name=candidate)]
    logger.warning("Owner user '%s' not found in Hera; skipping owner assignment.", candidate)
    return None


def attach_tenant_to_service(hera: t.Any, service_fqn: str, tenant_name: str) -> None:
    hr = _hera_generated_schema()
    DatabaseService = _schema_mod("schema.entity.services.databaseService").DatabaseService

    tenant = _ensure_tenant(hera, tenant_name)
    service = hera.get_by_name(entity=DatabaseService, fqn=service_fqn, fields=["tenants"])
    if not tenant or not getattr(tenant, "id", None) or not service:
        logger.debug("Skipping tenant attach for service '%s'; tenant or service missing", service_fqn)
        return
    tenant_id = tenant.id.root if hasattr(tenant.id, "root") else tenant.id

    current_tenants = _tenant_list(getattr(service, "tenants", None))
    merged_tenants = _merge_tenants(hr, current_tenants, tenant_id, tenant_name)
    try:
        hera.patch_tenant(
            entity=DatabaseService,
            source=service,
            tenants=hr.EntityReferenceList(root=merged_tenants),
        )
        logger.info("Attached tenant '%s' to service '%s'", tenant_name, service_fqn)
    except Exception as exc:
        logger.warning("Skipping tenant attach for %s: %s", service_fqn, exc)


def attach_tenant_to_data_product(
    hera: t.Any,
    data_product_fqn: str,
    tenant_name: str,
    current_tenants: t.Optional[t.Iterable[t.Any]] = None,
) -> None:
    hr = _hera_generated_schema()
    DataProduct = _schema_mod("schema.entity.domains.dataProduct").DataProduct

    tenant = _ensure_tenant(hera, tenant_name)
    data_product = hera.get_by_name(entity=DataProduct, fqn=data_product_fqn, fields=["tenants"])
    if not tenant or not getattr(tenant, "id", None) or not data_product:
        logger.debug("Skipping tenant attach for data product '%s'; tenant or data product missing", data_product_fqn)
        return
    tenant_id = tenant.id.root if hasattr(tenant.id, "root") else tenant.id

    tenant_source = current_tenants if current_tenants is not None else getattr(data_product, "tenants", None)
    merged_tenants = _merge_tenants(hr, _tenant_list(tenant_source), tenant_id, tenant_name)
    try:
        hera.patch_tenant(
            entity=DataProduct,
            source=data_product,
            tenants=hr.EntityReferenceList(root=merged_tenants),
        )
        logger.info("Attached tenant '%s' to data product '%s'", tenant_name, data_product_fqn)
    except Exception as exc:
        logger.warning("Skipping tenant attach for data product %s: %s", data_product_fqn, exc)


def _ensure_tenant(hera: t.Any, tenant_name: str) -> t.Any:
    hr = _hera_generated_schema()
    tenant = hera.get_by_name(entity=hr.Tenant, fqn=tenant_name)
    if tenant and getattr(tenant, "id", None):
        return tenant
    try:
        tenant = hera.create_or_update(
            data=hr.CreateTenantRequest(
                name=hr.EntityName(tenant_name),
                fullyQualifiedName=hr.FullyQualifiedEntityName(tenant_name),
                displayName=tenant_name,
                description="",
            )
        )
        logger.info("Created Hera tenant '%s'", tenant_name)
        return tenant
    except Exception as exc:
        logger.warning("Skipping tenant creation for '%s': %s", tenant_name, exc)
        return None


def _merge_tenants(
    hr: t.Any, current_tenants: t.Iterable[t.Any], tenant_id: str, tenant_name: str
) -> list[t.Any]:
    merged_tenants = list(current_tenants)
    existing_ids = {_tenant_ref_id(tenant_ref) for tenant_ref in merged_tenants}
    if tenant_id in existing_ids:
        return merged_tenants
    merged_tenants.append(
        hr.EntityReference(
            id=tenant_id,
            type="tenant",
            name=tenant_name,
            fullyQualifiedName=tenant_name,
        )
    )
    return merged_tenants


def _tenant_list(tenants: t.Any) -> list[t.Any]:
    if tenants is None:
        return []
    root = getattr(tenants, "root", None)
    if root is not None:
        return list(root)
    return list(tenants)


def _tenant_ref_id(tenant_ref: t.Any) -> t.Any:
    tenant_ref_id = getattr(tenant_ref, "id", None)
    return tenant_ref_id.root if hasattr(tenant_ref_id, "root") else tenant_ref_id


def _patch_depot_onto_service(hera: t.Any, service_fqn: str, depot: str) -> None:
    DatabaseService = _schema_mod("schema.entity.services.databaseService").DatabaseService

    svc = hera.get_by_name(entity=DatabaseService, fqn=service_fqn)
    if not svc:
        return
    current_depot = getattr(svc, "depot", None)
    if current_depot and str(current_depot) == depot:
        return
    destination = _clone_entity(svc)
    destination.depot = depot
    hera.patch(entity=DatabaseService, source=svc, destination=destination, override_metadata=True, skip_on_failure=False)


def ensure_source_service(
    hera: t.Any,
    service_name: str,
    hera_service_kind: str,
    tenant_name: t.Optional[str] = None,
    depot: t.Optional[str] = None,
) -> str:
    hr = _hera_generated_schema()
    DatabaseService = _schema_mod("schema.entity.services.databaseService").DatabaseService

    existing = hera.get_by_name(entity=DatabaseService, fqn=service_name)
    if existing and getattr(existing, "fullyQualifiedName", None):
        fqn = existing.fullyQualifiedName.root
        if tenant_name:
            attach_tenant_to_service(hera, fqn, tenant_name)
        if depot:
            _patch_depot_onto_service(hera, fqn, depot)
        return fqn
    svc_type = getattr(hr.DatabaseServiceType, hera_service_kind, hr.DatabaseServiceType.CustomDatabase)
    request = hr.CreateDatabaseServiceRequest(
        name=hr.EntityName(service_name),
        serviceType=svc_type,
        connection=None,
        depot=depot,
    )
    entity = hera.create_or_update(data=request)
    fqn = entity.fullyQualifiedName.root
    if tenant_name:
        attach_tenant_to_service(hera, fqn, tenant_name)
    return fqn


def ensure_vulcan_service(
    hera: t.Any,
    tenant: str,
    project: str,
    vulcan_api_url: str,
    display_name: t.Optional[str] = None,
    tenant_name: t.Optional[str] = None,
) -> str:
    hr = _hera_generated_schema()
    DatabaseService = _schema_mod("schema.entity.services.databaseService").DatabaseService

    service_name = vulcan_service_name(tenant, project)
    existing = hera.get_by_name(entity=DatabaseService, fqn=service_name)
    if existing and getattr(existing, "fullyQualifiedName", None):
        fqn = existing.fullyQualifiedName.root
        if tenant_name:
            attach_tenant_to_service(hera, fqn, tenant_name)
        return fqn
    request = hr.CreateDatabaseServiceRequest(
        name=hr.EntityName(service_name),
        serviceType=hr.DatabaseServiceType.CustomDatabase,
        connection=hr.DatabaseConnection(
            config=hr.CustomDatabaseConnection(
                type=hr.CustomDatabaseType.CustomDatabase,
                sourcePythonClass="vulcan.core.hera",
                connectionOptions=hr.ConnectionOptions(root={"vulcan_api_url": vulcan_api_url}),
            )
        ),
        displayName=display_name or None,
    )
    entity = hera.create_or_update(data=request)
    fqn = entity.fullyQualifiedName.root
    if tenant_name:
        attach_tenant_to_service(hera, fqn, tenant_name)
    return fqn


def ensure_db_schema(
    hera: t.Any,
    service_fqn: str,
    database_name: str,
    schema_name: str,
    domain_fqn: t.Optional[str] = None,
) -> str:
    hr = _hera_generated_schema()
    db_kwargs: dict[str, t.Any] = {"name": hr.EntityName(database_name), "service": hr.FullyQualifiedEntityName(service_fqn)}
    if domain_fqn:
        db_kwargs["domains"] = [domain_fqn]
    db = hera.create_or_update(data=hr.CreateDatabaseRequest(**db_kwargs))
    schema_kwargs: dict[str, t.Any] = {"name": hr.EntityName(schema_name), "database": hr.FullyQualifiedEntityName(db.fullyQualifiedName.root)}
    if domain_fqn:
        schema_kwargs["domains"] = [domain_fqn]
    schema = hera.create_or_update(data=hr.CreateDatabaseSchemaRequest(**schema_kwargs))
    return schema.fullyQualifiedName.root


def ensure_domain(hera: t.Any, domain_name: str) -> str:
    hr = _hera_generated_schema()
    entity = hera.create_or_update(
        data=hr.CreateDomainRequest(
            name=hr.EntityName(domain_name),
            domainType=hr.DomainType.Aggregate,
            description="",
        )
    )
    return entity.fullyQualifiedName.root if entity.fullyQualifiedName else domain_name


_VULCAN_CLASSIFICATION = "Vulcan"
_DP_ALIGNMENT_CLASSIFICATION = "DataProductAlignment"
_DP_ALIGNMENT_TAGS = ("source_aligned", "consumer_aligned")


def _data_product_alignment_tag_fqn(category: str) -> str:
    return f"{_DP_ALIGNMENT_CLASSIFICATION}.{normalize(category)}"


def _patch_data_product_alignment(hera: t.Any, entity: t.Any, product_name: str, category: str) -> None:
    hr = _hera_generated_schema()
    TagLabel = _schema_mod("schema.type.tagLabel").TagLabel
    PatchOperation = _ingest_mod("hera_meta.mixins.patch_mixin_utils").PatchOperation
    desired_fqn = _data_product_alignment_tag_fqn(category)

    try:
        current = hera.get_by_name(entity=hr.DataProduct, fqn=product_name, fields=["tags"])
        current_tags = (getattr(current, "tags", None) if current else None) or []
    except Exception:
        current_tags = []

    current_fqns = {getattr(tag.tagFQN, "root", tag.tagFQN) for tag in current_tags}
    stale_tags = [
        tag for tag in current_tags
        if getattr(tag.tagFQN, "root", tag.tagFQN).startswith(f"{_DP_ALIGNMENT_CLASSIFICATION}.")
        and getattr(tag.tagFQN, "root", tag.tagFQN) != desired_fqn
    ]
    if stale_tags:
        try:
            logger.info("Replacing data product alignment on '%s' with '%s'", product_name, desired_fqn)
            hera.patch_tags(entity=hr.DataProduct, source=entity, tag_labels=stale_tags, operation=PatchOperation.REMOVE)
        except Exception as exc:
            logger.debug("Could not remove stale alignment tag from '%s': %s", product_name, exc)

    if desired_fqn in current_fqns:
        return

    try:
        hera.patch_tags(
            entity=hr.DataProduct,
            source=entity,
            tag_labels=[
                TagLabel(
                    tagFQN=desired_fqn,
                    source="Classification",
                    labelType="Automated",
                    state="Confirmed",
                )
            ],
        )
        logger.info("Patched data product alignment on '%s' to '%s'", product_name, desired_fqn)
    except Exception as exc:
        logger.debug("Could not patch data product alignment for '%s': %s", product_name, exc)


def ensure_alignment_tags(hera: t.Any) -> None:
    """
    Ensure the Vulcan and DataProductAlignment classifications exist in Hera.

    Called once at sync startup. Individual Vulcan tags are created lazily
    inside ``attach_tags`` when first encountered.
    """
    CreateClassificationRequest = _schema_mod("schema.api.classification.createClassification").CreateClassificationRequest
    CreateTagRequest = _schema_mod("schema.api.classification.createTag").CreateTagRequest

    for cls_name, desc, exclusive in (
        (_VULCAN_CLASSIFICATION, "Tags managed by Vulcan data product sync", False),
        (_DP_ALIGNMENT_CLASSIFICATION, "Data product alignment category", True),
    ):
        try:
            hera.create_or_update(data=CreateClassificationRequest(
                name=cls_name,
                description=desc,
                mutuallyExclusive=exclusive,
            ))
        except Exception as exc:
            logger.debug("Could not ensure classification '%s': %s", cls_name, exc)

    for tag_name in _DP_ALIGNMENT_TAGS:
        try:
            hera.create_or_update(data=CreateTagRequest(
                classification=_DP_ALIGNMENT_CLASSIFICATION,
                name=tag_name,
                description=f"{tag_name.replace('-', ' ').title()} data product",
            ))
        except Exception as exc:
            logger.debug("Could not ensure tag '%s.%s': %s", _DP_ALIGNMENT_CLASSIFICATION, tag_name, exc)


def ensure_data_product(
    hera: t.Any,
    product_name: str,
    domain_fqn: t.Optional[str],
    description: str,
    display_name: t.Optional[str] = None,
    owners: t.Optional[list[t.Any]] = None,
    tenant_fqn: t.Optional[str] = None,
    category: t.Optional[str] = None,
    product_tags: t.Optional[list[t.Any]] = None,
) -> t.Optional[str]:
    hr = _hera_generated_schema()
    existing_entity = None
    existing_display_name: t.Optional[str] = None
    try:
        existing_entity = hera.get_by_name(entity=hr.DataProduct, fqn=product_name)
    except Exception:
        existing_entity = None
    if not display_name:
        existing_display = getattr(existing_entity, "displayName", None) if existing_entity else None
        existing_display_name = existing_display.root if hasattr(existing_display, "root") else existing_display
    request_kwargs: dict[str, t.Any] = {
        "name": hr.EntityName(product_name),
        "description": description or "",
        "domains": [hr.FullyQualifiedEntityName(domain_fqn)] if domain_fqn else [],
    }
    if display_name or existing_display_name:
        request_kwargs["displayName"] = display_name or existing_display_name
    if owners:
        request_kwargs["owners"] = hr.EntityReferenceList(root=owners)
    if tenant_fqn:
        request_kwargs["tenants"] = [tenant_fqn]
    try:
        action = "update" if existing_entity else "create"
        log_message = "Hera data product %s requested: name='%s', domain='%s'"
        log_args: tuple[t.Any, ...] = (action, product_name, domain_fqn or "")
        if tenant_fqn:
            log_message += ", tenant='%s'"
            log_args += (tenant_fqn,)
        logger.info(log_message, *log_args)
        entity = hera.create_or_update(data=hr.CreateDataProductRequest(**request_kwargs))
        logger.info(
            "Hera data product %s completed: name='%s', fqn='%s'",
            action,
            product_name,
            entity.fullyQualifiedName.root if entity.fullyQualifiedName else product_name,
        )
        if owners:
            try:
                hera.patch_owner(
                    entity=hr.DataProduct, source=entity, owners=hr.EntityReferenceList(root=owners), force=True,
                )
            except Exception as exc:
                logger.debug("Could not patch data product owner for '%s': %s", product_name, exc)
        all_tag_labels: list[t.Any] = []
        TagLabel = _schema_mod("schema.type.tagLabel").TagLabel
        CreateTagRequest = _schema_mod("schema.api.classification.createTag").CreateTagRequest
        for tag in product_tags or []:
            value = normalize(str(tag))
            if value:
                quoted = f'"{value}"' if "." in value else value
                tag_fqn = f"{_VULCAN_CLASSIFICATION}.{quoted}"
                try:
                    hera.create_or_update(data=CreateTagRequest(
                        classification=_VULCAN_CLASSIFICATION,
                        name=value,
                        description="",
                    ))
                except Exception:
                    pass
                all_tag_labels.append(TagLabel(
                    tagFQN=tag_fqn,
                    source="Classification",
                    labelType="Automated",
                    state="Confirmed",
                ))
        if category:
            _patch_data_product_alignment(hera, entity, product_name, category)
        if all_tag_labels:
            try:
                logger.info("Patching %d Vulcan tag(s) on data product '%s'", len(all_tag_labels), product_name)
                hera.patch_tags(entity=hr.DataProduct, source=entity, tag_labels=all_tag_labels)
                logger.info("Patched %d Vulcan tag(s) on data product '%s'", len(all_tag_labels), product_name)
            except Exception as exc:
                logger.debug("Could not tag data product '%s': %s", product_name, exc)
        return entity.fullyQualifiedName.root if entity.fullyQualifiedName else product_name
    except Exception as exc:
        logger.warning("Failed to create data product '%s': %s", product_name, exc)
        return None


def attach_data_product_assets(hera: t.Any, data_product_fqn: str, asset_fqns: list[str]) -> None:
    hr = _hera_generated_schema()
    unique_assets = list(dict.fromkeys(asset_fqns))
    refs: list[t.Any] = []
    unresolved: list[str] = []
    for asset_fqn in unique_assets:
        try:
            table = hera.get_by_name(entity=hr.Table, fqn=asset_fqn)
        except Exception:
            table = None
        if table and getattr(table, "id", None):
            refs.append(hr.EntityReference(id=table.id.root, type="table", fullyQualifiedName=asset_fqn))
        else:
            unresolved.append(asset_fqn)
    if refs:
        try:
            hera.add_assets_to_data_product(name=data_product_fqn, assets=refs)
        except Exception as exc:
            logger.warning("Failed to attach assets to data product '%s': %s", data_product_fqn, exc)
    if unresolved:
        logger.warning(
            "Data product '%s': %d/%d assets unresolved",
            data_product_fqn,
            len(unresolved),
            len(unique_assets),
        )


def update_data_product_status(
    hera: t.Any,
    product_name: str,
    last_run_status: t.Optional[str] = None,
    last_run_at: t.Optional[int] = None,
    quality_status: t.Optional[str] = None,
) -> bool:
    hr = _hera_generated_schema()
    existing = hera.get_by_name(entity=hr.DataProduct, fqn=product_name)
    if not existing:
        logger.warning("Data product '%s' not found, skipping status update", product_name)
        return False
    destination = _clone_entity(existing)
    changed = False
    if last_run_status is not None:
        destination.lastRunStatus = hr.RunStatus(last_run_status)
        changed = True
    if last_run_at is not None:
        destination.lastRunAt = hr.Timestamp(root=last_run_at)
        changed = True
    if quality_status is not None:
        destination.qualityStatus = hr.QualityStatus(quality_status)
        changed = True
    if not changed:
        return True
    try:
        hera.patch(
            entity=hr.DataProduct,
            source=existing,
            destination=destination,
            override_metadata=True,
            skip_on_failure=False,
        )
    except Exception as exc:
        logger.warning("Failed to update data product status '%s': %s", product_name, exc)
        return False
    return True


def associate_domain(hera: t.Any, domain_fqn: str, table_fqns: list[str]) -> None:
    hr = _hera_generated_schema()
    domain = hera.get_by_name(entity=hr.Domain, fqn=domain_fqn)
    if not domain:
        logger.warning("Domain %s not found for association", domain_fqn)
        return
    domain_ref = hr.EntityReference(id=domain.id.root, type="domain", fullyQualifiedName=domain_fqn)
    domains_list = hr.EntityReferenceList(root=[domain_ref])
    patched = 0
    for fqn in table_fqns:
        try:
            table = hera.get_by_name(entity=hr.Table, fqn=fqn)
            if table and hasattr(hera, "patch_domain"):
                hera.patch_domain(entity=hr.Table, source=table, domains=domains_list)
                patched += 1
        except Exception as exc:
            logger.warning("Domain patch for %s failed: %s", fqn, exc)
    logger.info("Domain %s associated with %d/%d tables", domain_fqn, patched, len(table_fqns))
