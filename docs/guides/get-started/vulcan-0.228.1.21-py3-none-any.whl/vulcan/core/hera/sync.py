from __future__ import annotations

import logging
import os
import typing as t
from collections import defaultdict

from schema.metadata import ColumnEntry, Metadata, ModelEntry

from vulcan.core.config import Config
from vulcan.core.context import Context
from vulcan.core.hera.config import HeraConfig

from .utils import (
    _column_tag_labels,
    _hera_generated_schema,
    _logical_to_wire_dtype,
    _schema_mod,
    attach_column_tags,
    attach_data_product_assets,
    attach_tenant_to_data_product,
    attach_tags,
    attach_tenant_to_service,
    data_product_name,
    collect_column_tags,
    create_hera_client,
    ensure_alignment_tags,
    ensure_data_product,
    ensure_db_schema,
    ensure_domain,
    ensure_source_service,
    ensure_vulcan_service,
    is_prod,
    normalize,
    parse_fqn,
    resolve_connection_kind_for_hera,
    resolve_owner_refs,
    resolve_user_owner_ref,
    result_columns_for_hera,
    sanitize,
    source_depot_name,
    source_service_name,
    step,
    update_data_product_status,
    associate_domain,
    entity_tags,
    vulcan_service_name,
)

logger = logging.getLogger(__name__)


def canonical_dep_ref(dep: t.Any) -> t.Optional[str]:
    raw = sanitize(str(dep or ""))
    if not raw:
        return None
    return raw.replace('"', "").replace("'", "")


def _entry_dep_fqns(entry: ModelEntry, mctx: "_EntriesIndex") -> list[str]:
    return [mctx._name_fqn.get(dep, dep) for dep in entry.depends_on if dep]


class _EntriesIndex:
    """Name/FQN lookup over :class:`~schema.metadata.ModelEntry` exports."""

    def __init__(self, entries: t.Sequence[ModelEntry]) -> None:
        self._by_name = {e.name: e for e in entries if e.name}
        self._by_fqn = {e.fqn: e for e in entries if e.fqn}
        self._name_fqn = {e.name: e.fqn for e in entries if e.name and e.fqn}

    @classmethod
    def from_entries(cls, entries: t.Sequence[ModelEntry]) -> "_EntriesIndex":
        return cls(entries)

    def by_name(self, name: str) -> t.Optional[ModelEntry]:
        return self._by_name.get(name)

    def by_fqn(self, fqn: str) -> t.Optional[ModelEntry]:
        return self._by_fqn.get(fqn)

    def resolve_fqn(self, name: str) -> str:
        return self._name_fqn.get(name, name)


def _column_entry_to_hera(col: ColumnEntry, ordinal: int, *, emit_pk: bool = True) -> dict[str, t.Any]:
    data_type, data_length = _logical_to_wire_dtype(col.ltype)
    result: dict[str, t.Any] = {
        "name": col.name or "unknown",
        "dataType": data_type,
        "ordinalPosition": ordinal,
    }
    if data_length is not None:
        result["dataLength"] = data_length
    if emit_pk and col.primary_key:
        result["constraint"] = "PRIMARY_KEY"
    if col.description:
        result["description"] = col.description
    tags = _column_tag_labels(col.tags, col.terms)
    if tags:
        result["tags"] = tags
    return result


def _columns_to_hera(entry: ModelEntry) -> list[dict[str, t.Any]]:
    """
    Convert entry columns to Hera column dicts, suppressing PRIMARY_KEY
    when multiple grains exist (Hera rejects multiple PK constraints).
    """
    cols = entry.columns
    pk_count = sum(1 for c in cols if c.primary_key)
    emit_pk = pk_count <= 1
    return [_column_entry_to_hera(c, idx, emit_pk=emit_pk) for idx, c in enumerate(cols, start=1)]


def _lineage_identity_keys(node: t.Any) -> list[str]:
    """
    Canonical Vulcan lineage identity for ``node``.

    Snapshot ``depends_on`` values denote upstreams using the same identity as ``node.fqn``
    (after ``canonical_dep_ref``). Names, aliases, and derived physical table paths are not
    used as lineage keys because they diverge from ``depends_on``.

    Args:
        node: Loaded snapshot node.

    Returns:
        Deduped list of lineage map keys for this node (normally one entry).
    """
    try:
        fqn = node.fqn
    except AttributeError:
        logger.warning(
            "Hera lineage: %s has no fqn attribute; lineage may miss edges for this node",
            type(node).__name__,
        )
        return []
    except Exception:
        logger.warning(
            "Hera lineage: failed to read fqn from %s",
            type(node).__name__,
            exc_info=True,
        )
        return []
    if not fqn:
        return []
    return _lineage_ref_keys(fqn)


def _connection_info(context: Context) -> tuple[t.Optional[str], t.Optional[str]]:
    try:
        conn = context.config.get_connection()
    except Exception:
        return None, None
    connection_type = getattr(conn, "type_", None) or getattr(conn, "type", None)
    connection_uri = None
    try:
        if hasattr(conn, "get_connection_uri"):
            connection_uri = conn.get_connection_uri() or None
    except Exception:
        connection_uri = None
    return connection_type, connection_uri


def _lineage_ref_keys(*values: t.Any) -> list[str]:
    keys: list[str] = []
    for value in values:
        key = canonical_dep_ref(value)
        if key and key not in keys:
            keys.append(key)
    return keys


def _phys_view_column_lineage(phys_fqn: str, view_fqn: str, entry: ModelEntry) -> list[t.Any]:
    hr = _hera_generated_schema()
    mod = _schema_mod("schema.type.entityLineage")
    ColumnLineage = mod.ColumnLineage
    FullyQualifiedEntityName = _schema_mod("schema.type.basic").FullyQualifiedEntityName
    lineages: list[t.Any] = []
    for col in entry.columns:
        col_name = sanitize(col.name)
        if not col_name:
            continue
        lineages.append(
            ColumnLineage(
                fromColumns=[FullyQualifiedEntityName(root=f"{phys_fqn}.{col_name}")],
                toColumn=FullyQualifiedEntityName(root=f"{view_fqn}.{col_name}"),
            )
        )
    return lineages


class _LineageCollector:
    def __init__(self, hera: t.Any, mctx: t.Optional["_EntriesIndex"] = None) -> None:
        self._hera = hera
        self._mctx: _EntriesIndex = mctx or _EntriesIndex.from_entries([])
        self._ref_to_fqn: dict[str, str] = {}
        self._disabled_keys: set[str] = set()
        self._pending: list[tuple[str, list[str]]] = []
        self._entity_id_cache: dict[str, t.Optional[str]] = {}
        self._entries_for_columns: list[tuple[ModelEntry, str]] = []
        self._metrics_for_columns: list[tuple[ModelEntry, str]] = []

    def register_entity(self, ref_keys: list[str], fqn: str) -> None:
        for ref_key in ref_keys:
            key = canonical_dep_ref(ref_key)
            if not key or key in self._disabled_keys:
                continue
            existing = self._ref_to_fqn.get(key)
            if existing and existing != fqn:
                logger.warning(
                    "Lineage key collision for %s: %s vs %s; disabling key",
                    key,
                    existing,
                    fqn,
                )
                self._disabled_keys.add(key)
                self._ref_to_fqn.pop(key, None)
                continue
            self._ref_to_fqn[key] = fqn

    def queue_edges(self, to_fqn: str, depends_on: t.Iterable[str]) -> None:
        refs = [key for key in (canonical_dep_ref(dep) for dep in depends_on or []) if key]
        if refs:
            self._pending.append((to_fqn, refs))

    def queue_entry_column_lineage(self, entry: ModelEntry, hera_table_fqn: str) -> None:
        self._entries_for_columns.append((entry, hera_table_fqn))

    def queue_metric_column_lineage(self, entry: ModelEntry, hera_table_fqn: str) -> None:
        self._metrics_for_columns.append((entry, hera_table_fqn))

    def _column_lineage_maps_by_edge(self) -> dict[tuple[str, str], list[t.Any]]:
        FullyQualifiedEntityName = _schema_mod("schema.type.basic").FullyQualifiedEntityName
        ColumnLineage = _schema_mod("schema.type.entityLineage").ColumnLineage

        by_edge: dict[tuple[str, str], list[t.Any]] = {}
        for entry, to_hera in self._entries_for_columns:
            allowed_parents = set(_entry_dep_fqns(entry, self._mctx))
            for col in entry.columns:
                merged: dict[str, set[str]] = defaultdict(set)
                for ref in col.depends_on:
                    parent_name = ref.model
                    parent_col = ref.column
                    if not parent_name or not parent_col:
                        continue
                    parent_fqn = self._mctx._name_fqn.get(parent_name, parent_name)
                    if allowed_parents and parent_fqn not in allowed_parents:
                        continue
                    parent_key = canonical_dep_ref(parent_fqn)
                    from_hera = self._ref_to_fqn.get(parent_key) if parent_key else None
                    if not from_hera:
                        continue
                    merged[from_hera].add(parent_col)
                to_col = sanitize(col.name)
                if not to_col:
                    continue
                for from_hera, parent_cols in merged.items():
                    from_col_fqns = [f"{from_hera}.{sanitize(pc)}" for pc in parent_cols if sanitize(str(pc))]
                    if not from_col_fqns:
                        continue
                    entry_lineage = ColumnLineage(
                        fromColumns=[FullyQualifiedEntityName(root=c) for c in from_col_fqns],
                        toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{to_col}"),
                    )
                    by_edge.setdefault((from_hera, to_hera), []).append(entry_lineage)
        self._merge_metric_column_lineage(by_edge)
        return by_edge

    def _merge_metric_column_lineage(self, by_edge: dict[tuple[str, str], list[t.Any]]) -> None:
        """
        Two-hop entry lookup: metric column → semantic entry column → physical depends_on.

        Resolves physical upstream entirely from pre-built ModelEntry data without
        needing Context.get_model() or column_dependencies() AST parsing.
        """
        FullyQualifiedEntityName = _schema_mod("schema.type.basic").FullyQualifiedEntityName
        ColumnLineage = _schema_mod("schema.type.entityLineage").ColumnLineage

        for entry, to_hera in self._metrics_for_columns:
            for col in entry.columns:
                col_name = sanitize(col.name)
                if not col_name:
                    continue

                emitted = False
                fallback_sem_hera: t.Optional[str] = None
                fallback_sem_col: t.Optional[str] = None

                for dep in col.depends_on:
                    sem_name = dep.model
                    sem_col = dep.column
                    if not sem_name or not sem_col:
                        continue

                    sem_fqn = self._mctx._name_fqn.get(sem_name, sem_name)
                    sem_key = canonical_dep_ref(sem_fqn)
                    sem_hera = self._ref_to_fqn.get(sem_key) if sem_key else None
                    if not sem_hera:
                        continue
                    fallback_sem_hera = sem_hera
                    fallback_sem_col = str(sem_col)

                    sem_entry = self._mctx.by_name(sem_name)
                    if sem_entry is None:
                        continue
                    sem_col_entry = next((c for c in sem_entry.columns if c.name == sem_col), None)
                    if sem_col_entry is None:
                        continue
                    for phys_dep in sem_col_entry.depends_on:
                        phys_model = phys_dep.model
                        phys_col = phys_dep.column
                        if not phys_model or not phys_col:
                            continue
                        phys_fqn = self._mctx._name_fqn.get(str(phys_model), str(phys_model))
                        pk = canonical_dep_ref(phys_fqn)
                        phys_hera = self._ref_to_fqn.get(pk) if pk else None
                        if not phys_hera:
                            continue
                        edge = ColumnLineage(
                            fromColumns=[FullyQualifiedEntityName(root=f"{phys_hera}.{sanitize(str(phys_col))}")],
                            toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{col_name}"),
                        )
                        by_edge.setdefault((phys_hera, to_hera), []).append(edge)
                        emitted = True

                if not emitted and fallback_sem_hera and fallback_sem_col:
                    edge = ColumnLineage(
                        fromColumns=[FullyQualifiedEntityName(root=f"{fallback_sem_hera}.{sanitize(fallback_sem_col)}")],
                        toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{col_name}"),
                    )
                    by_edge.setdefault((fallback_sem_hera, to_hera), []).append(edge)

    def _entity_id_for_fqn(self, fqn: str) -> t.Optional[str]:
        if fqn in self._entity_id_cache:
            return self._entity_id_cache[fqn]
        hr = _hera_generated_schema()
        try:
            entity = self._hera.get_by_name(entity=hr.Table, fqn=fqn)
        except Exception:
            entity = None
        if not entity or not getattr(entity, "id", None):
            self._entity_id_cache[fqn] = None
            return None
        entity_id = entity.id.root if hasattr(entity.id, "root") else entity.id
        self._entity_id_cache[fqn] = entity_id
        return entity_id

    def flush(self) -> None:
        edge_columns = self._column_lineage_maps_by_edge()
        emitted_pairs: set[tuple[str, str]] = set()

        def _emit(from_fqn: str, to_fqn: str, col_maps: t.Optional[list[t.Any]]) -> None:
            emitted_pairs.add((from_fqn, to_fqn))
            _add_lineage(
                self._hera,
                from_fqn,
                to_fqn,
                self._entity_id_cache,
                columns_lineage=col_maps,
            )

        for to_fqn, refs in self._pending:
            to_id = self._entity_id_for_fqn(to_fqn)
            if not to_id:
                logger.warning("Lineage downstream not created: %s", to_fqn)
                continue
            for ref in refs:
                from_fqn = self._ref_to_fqn.get(ref)
                if not from_fqn:
                    logger.warning("Lineage upstream ref unresolvable: %s -> %s", ref, to_fqn)
                    continue
                from_id = self._entity_id_for_fqn(from_fqn)
                if not from_id:
                    logger.warning(
                        "Lineage upstream table not present in Hera: %s (edge to %s)",
                        from_fqn,
                        to_fqn,
                    )
                    continue
                col_maps = edge_columns.get((from_fqn, to_fqn))
                _emit(from_fqn, to_fqn, col_maps)

        for from_fqn, to_fqn in sorted(edge_columns.keys()):
            if (from_fqn, to_fqn) in emitted_pairs:
                continue
            col_maps = edge_columns[(from_fqn, to_fqn)]
            if not col_maps:
                continue
            if not self._entity_id_for_fqn(from_fqn) or not self._entity_id_for_fqn(to_fqn):
                logger.warning(
                    "Lineage column-only upstream/downstream missing for %s -> %s",
                    from_fqn,
                    to_fqn,
                )
                continue
            _emit(from_fqn, to_fqn, col_maps)


def _hera_table_entity_id(
    hera: t.Any,
    hr: t.Any,
    table_fqn: str,
    entity_id_cache: dict[str, t.Optional[str]],
) -> t.Optional[str]:
    """Resolve and cache Hera table entity id for ``table_fqn``."""
    if table_fqn not in entity_id_cache:
        table = hera.get_by_name(entity=hr.Table, fqn=table_fqn)
        tid = None
        if table and getattr(table, "id", None):
            tid = table.id.root if hasattr(table.id, "root") else table.id
        entity_id_cache[table_fqn] = tid
    return entity_id_cache.get(table_fqn)


def _add_lineage(
    hera: t.Any,
    from_fqn: str,
    to_fqn: str,
    entity_id_cache: t.Optional[dict[str, t.Optional[str]]] = None,
    *,
    columns_lineage: t.Optional[list[t.Any]] = None,
) -> None:
    mod_el = _schema_mod("schema.type.entityLineage")
    LineageDetails, Source = mod_el.LineageDetails, mod_el.Source

    hr = _hera_generated_schema()
    cache = entity_id_cache or {}
    from_table_id = _hera_table_entity_id(hera, hr, from_fqn, cache)
    to_table_id = _hera_table_entity_id(hera, hr, to_fqn, cache)
    if not from_table_id:
        return
    if not to_table_id:
        return
    lineage_kwargs: dict[str, t.Any] = {
        "fromEntity": hr.EntityReference(id=from_table_id, type="table"),
        "toEntity": hr.EntityReference(id=to_table_id, type="table"),
    }
    if columns_lineage:
        lineage_kwargs["lineageDetails"] = LineageDetails(columnsLineage=columns_lineage, source=Source.Manual)

    try:
        hera.add_lineage(
            data=hr.AddLineageRequest(edge=hr.EntitiesEdge(**lineage_kwargs)),
            check_patch=bool(columns_lineage),
        )
    except Exception as exc:
        logger.warning("Lineage %s -> %s failed: %s", from_fqn, to_fqn, exc)


def _create_table(
    hera: t.Any,
    *,
    entry: t.Optional[ModelEntry] = None,
    table_name: t.Optional[str] = None,
    schema_fqn: str,
    columns: t.Optional[list[t.Any]] = None,
    description: str = "",
    table_type: t.Any = None,
    display_name: t.Optional[str] = None,
    owners: t.Optional[list[t.Any]] = None,
) -> t.Optional[tuple[str, t.Any]]:
    hr = _hera_generated_schema()

    def _column_payload(item: t.Any) -> dict[str, t.Any]:
        if isinstance(item, dict):
            return dict(item)
        if hasattr(item, "model_dump"):
            return t.cast(dict[str, t.Any], item.model_dump())
        if hasattr(item, "dict"):
            return t.cast(dict[str, t.Any], item.dict())
        return {k: v for k, v in getattr(item, "__dict__", {}).items() if not k.startswith("_")}

    if entry is not None:
        columns = _columns_to_hera(entry)
        table_name = entry.name or table_name
        description = (entry.description or description) or ""
    else:
        columns = [_column_payload(col) for col in (columns or [])]
    try:
        kwargs: dict[str, t.Any] = {
            "name": hr.EntityName(sanitize(table_name or "unknown")),
            "databaseSchema": hr.FullyQualifiedEntityName(schema_fqn),
            "columns": [hr.Column(**{k: v for k, v in column.items() if k != "tags"}) for column in columns],
            "description": description or "",
        }
        if table_type is not None:
            kwargs["tableType"] = table_type
        if display_name and table_type == _hera_generated_schema().TableType.Perspective:
            kwargs["displayName"] = display_name
        if owners:
            kwargs["owners"] = owners
        entity = hera.create_or_update(data=hr.CreateTableRequest(**kwargs))
        if not owners:
            try:
                hera.patch_owner(entity=hr.Table, source=entity, owners=None, force=True)
            except Exception as exc:
                logger.debug("Could not clear owner on '%s': %s", table_name, exc)
        return entity.fullyQualifiedName.root, entity
    except Exception as exc:
        logger.warning(
            "Failed to create table '%s' in %s: %s",
            table_name or (entry.name if entry else "unknown"),
            schema_fqn,
            exc,
        )
        return None


def _sync_source_tables(
    hera: t.Any,
    mctx: "_EntriesIndex",
    entries: t.Sequence[ModelEntry],
    service_fqn: str,
    default_db: str,
    default_schema: str,
    domain_fqn: t.Optional[str] = None,
    lineage: t.Optional[_LineageCollector] = None,
) -> tuple[list[str], dict[str, str], dict[str, ModelEntry]]:
    fqns: list[str] = []
    phys_to_view: dict[str, str] = {}
    phys_to_entry: dict[str, ModelEntry] = {}
    schema_cache: dict[tuple[str, str, str], str] = {}
    for entry in entries:
        table = entry.table
        owner_ref = resolve_user_owner_ref(hera, entry.owner)
        lineage_fqn = None

        if table and table.physical:
            phys_db, phys_schema, phys_table = parse_fqn(
                table.physical.name,
                default_db,
                default_schema,
            )
            phys_cache_key = (service_fqn, phys_db, phys_schema)
            if phys_cache_key not in schema_cache:
                schema_fqn = step(
                    "source_schema_physical",
                    lambda: ensure_db_schema(
                        hera,
                        service_fqn,
                        database_name=phys_db,
                        schema_name=phys_schema,
                        domain_fqn=domain_fqn,
                    ),
                )
                if not schema_fqn:
                    continue
                schema_cache[phys_cache_key] = schema_fqn
            created = _create_table(
                hera,
                table_name=phys_table,
                schema_fqn=schema_cache[phys_cache_key],
                columns=_columns_to_hera(entry),
                description=entry.description or "",
                owners=owner_ref,
            )
            if not created:
                continue
            phys_fqn, phys_entity = created
            fqns.append(phys_fqn)
            phys_to_entry[phys_fqn] = entry
            attach_tags(hera, phys_entity, entity_tags(entry.tags, entry.terms))
            attach_column_tags(hera, phys_entity, collect_column_tags(phys_fqn, _columns_to_hera(entry)))

            if table.virtual:
                view_db, view_schema, view_table = parse_fqn(
                    table.virtual.name,
                    default_db,
                    default_schema,
                )
                view_cache_key = (service_fqn, view_db, view_schema)
                if view_cache_key not in schema_cache:
                    schema_fqn = step(
                        "source_schema_virtual",
                        lambda: ensure_db_schema(
                            hera,
                            service_fqn,
                            database_name=view_db,
                            schema_name=view_schema,
                            domain_fqn=domain_fqn,
                        ),
                    )
                    if not schema_fqn:
                        continue
                    schema_cache[view_cache_key] = schema_fqn
                created = _create_table(
                    hera,
                    table_name=view_table,
                    schema_fqn=schema_cache[view_cache_key],
                    columns=_columns_to_hera(entry),
                    description=entry.description or "",
                    table_type=_hera_generated_schema().TableType.View,
                    owners=owner_ref,
                )
                if not created:
                    continue
                view_fqn, view_entity = created
                fqns.append(view_fqn)
                phys_to_view[phys_fqn] = view_fqn
                lineage_fqn = view_fqn
                attach_tags(hera, view_entity, entity_tags(entry.tags, entry.terms))
                attach_column_tags(hera, view_entity, collect_column_tags(view_fqn, _columns_to_hera(entry)))
            else:
                lineage_fqn = phys_fqn
        else:
            logger.warning(
                "Skipping entry '%s': no table.physical metadata available.",
                entry.name,
            )
            continue

        if lineage and lineage_fqn:
            lineage.register_entity(_lineage_ref_keys(entry.fqn), lineage_fqn)
            lineage.queue_edges(lineage_fqn, _entry_dep_fqns(entry, mctx))
            lineage.queue_entry_column_lineage(entry, lineage_fqn)

    return fqns, phys_to_view, phys_to_entry


def _sync_physical_to_view_lineage(
    hera: t.Any,
    phys_to_view: dict[str, str],
    phys_to_entry: dict[str, ModelEntry],
) -> None:
    if not phys_to_view:
        return
    for phys_fqn, view_fqn in phys_to_view.items():
        entry = phys_to_entry.get(phys_fqn)
        if not entry:
            continue
        lineage = _phys_view_column_lineage(phys_fqn, view_fqn, entry)
        if lineage:
            _add_lineage(hera, phys_fqn, view_fqn, columns_lineage=lineage)


_TABLE_TYPE_MAP: dict[str, str] = {
    "semantic": "Semantic",
    "metric": "BusinessMetric",
}


def _sync_typed_entries(
    hera: t.Any,
    mctx: "_EntriesIndex",
    schema_fqn: str,
    entries: t.Sequence[ModelEntry],
    *,
    source_type: str,
    lineage: t.Optional[_LineageCollector] = None,
) -> list[str]:
    """
    Upsert semantic or metric model entries into Hera.

    Args:
        hera: Hera client instance.
        mctx: Index of all model entries for dependency resolution.
        schema_fqn: Fully-qualified Hera schema to register tables under.
        entries: Model entries to sync (must all share the given source_type).
        source_type: Either ``"semantic"`` or ``"metric"``.
        lineage: Optional lineage collector for edge/column tracking.

    Returns:
        List of created Hera table FQNs.
    """
    hr = _hera_generated_schema()
    table_type = getattr(hr.TableType, _TABLE_TYPE_MAP[source_type])
    fqns: list[str] = []
    for entry in entries:
        created = _create_table(
            hera,
            entry=entry,
            schema_fqn=schema_fqn,
            table_type=table_type,
            owners=resolve_user_owner_ref(hera, entry.owner),
        )
        if not created:
            continue
        fqn, entity = created
        fqns.append(fqn)
        if lineage:
            lineage.register_entity(_lineage_ref_keys(entry.fqn), fqn)
            lineage.queue_edges(fqn, _entry_dep_fqns(entry, mctx))
            if source_type == "metric":
                lineage.queue_metric_column_lineage(entry, fqn)
            else:
                lineage.queue_entry_column_lineage(entry, fqn)
        attach_tags(hera, entity, entity_tags(entry.tags, entry.terms))
        attach_column_tags(hera, entity, collect_column_tags(fqn, _columns_to_hera(entry)))
    return fqns


def _sync_perspectives(
    hera: t.Any,
    schema_fqn: str,
    query_state: t.Any,
    current_user_id: str = "",
    lineage: t.Optional[_LineageCollector] = None,
) -> list[str]:
    hr = _hera_generated_schema()
    fqns: list[str] = []
    if not hasattr(query_state, "list_perspectives"):
        return fqns
    offset = 0
    while True:
        try:
            perspectives, has_more = query_state.list_perspectives(
                current_user_id=current_user_id or "",
                is_public=None,
                limit=100,
                offset=offset,
            )
        except Exception as exc:
            logger.warning("Could not list perspectives for Hera sync: %s", exc)
            break
        if not perspectives:
            break
        for perspective in perspectives:
            raw_columns = _perspective_raw_columns(query_state, perspective)
            created = _create_table(
                hera,
                table_name=sanitize(perspective.slug),
                schema_fqn=schema_fqn,
                columns=raw_columns,
                description=perspective.description or "",
                table_type=hr.TableType.Perspective,
                display_name=perspective.name,
                owners=resolve_user_owner_ref(hera, getattr(perspective, "owner", None)),
            )
            if not created:
                continue
            fqn, entity = created
            fqns.append(fqn)
            if lineage:
                lineage.queue_edges(fqn, getattr(perspective, "depends_on", None) or [])
            attach_tags(
                hera,
                entity,
                entity_tags(getattr(perspective, "tags", []) or [], getattr(perspective, "terms", []) or []),
            )
        if not has_more:
            break
        offset += len(perspectives)
    return fqns


def _hera_client(hera_cfg: HeraConfig) -> t.Any:
    """
    Wrap :func:`~vulcan.core.hera.utils.create_hera_client` for config blocks on Context.
    """
    return create_hera_client(
        url=hera_cfg.url,
        token=hera_cfg.token.get_secret_value(),
        verify_ssl=hera_cfg.verify_ssl,
    )


class _HeraDomainInfo(t.NamedTuple):
    tenant: str
    project: str
    domain_fqn: t.Optional[str]
    source_svc_fqn: t.Optional[str]
    vulcan_svc_fqn: t.Optional[str]
    schema_fqn: t.Optional[str]


def _hera_domain_and_vulcan_schema(
    hera: t.Any,
    product: Config,
    connection_type: t.Optional[str],
    connection_uri: t.Optional[str],
) -> "_HeraDomainInfo":
    """
    Shared domain, source service, Vulcan service, and project schema FQNs from product config.

    Used by full snapshot sync and single-perspective sync (no snapshot state).
    """
    tenant = normalize(product.tenant)
    project = normalize(product.project or product.name)
    domain_name = normalize(product.domain)

    ensure_alignment_tags(hera)

    domain_fqn = (
        step("domain", lambda: ensure_domain(hera, domain_name))
        if domain_name
        else None
    )
    vulcan_api_url = os.getenv("VULCAN_API_URL", "http://localhost:8000")
    source_svc_fqn = None
    if connection_uri:
        source_svc_fqn = step(
            "source_service",
            lambda: ensure_source_service(
                hera,
                source_service_name(connection_uri),
                resolve_connection_kind_for_hera(connection_type),
                tenant_name=tenant,
                depot=source_depot_name(),
            ),
        )
        if source_svc_fqn:
            step("source_service_tenant", lambda: attach_tenant_to_service(hera, source_svc_fqn, tenant))
    vulcan_svc_fqn = step(
        "vulcan_service",
        lambda: ensure_vulcan_service(
            hera,
            tenant,
            project,
            vulcan_api_url,
            display_name=product.display_name,
            tenant_name=tenant,
        ),
    )
    schema_fqn = None
    if vulcan_svc_fqn:
        schema_fqn = step(
            "vulcan_schema",
            lambda: ensure_db_schema(
                hera,
                vulcan_svc_fqn,
                database_name=tenant,
                schema_name=project,
                domain_fqn=domain_fqn,
            ),
        )
    return _HeraDomainInfo(
        tenant=tenant,
        project=project,
        domain_fqn=domain_fqn,
        source_svc_fqn=source_svc_fqn,
        vulcan_svc_fqn=vulcan_svc_fqn,
        schema_fqn=schema_fqn,
    )


def _perspective_raw_columns(query_state: t.Any, perspective: t.Any) -> list[t.Any]:
    """Load result columns for a perspective from ``query_state``, or return []."""
    raw_columns: list[t.Any] = []
    if not getattr(perspective, "request_id", None):
        return raw_columns
    slug = getattr(perspective, "slug", "perspective")
    try:
        request = query_state.get_request_by_id(perspective.request_id)
        if request and getattr(request, "result_id", None):
            result = query_state.get_result_by_id(request.result_id)
            if result:
                raw_columns = result_columns_for_hera(result.columns)
    except Exception as exc:
        logger.warning("Could not load perspective result for %s: %s", slug, exc)
    return raw_columns


def _snapshot_catalog(
    hera: t.Any,
    context: Context,
    environment: str,
    *,
    metadata: Metadata,
    query_state: t.Optional[t.Any] = None,
) -> dict[str, t.Any]:
    """
    Orchestrate Hera upserts from environment ``Metadata`` models plus optional perspective query-state.

    Callers must pass ``Metadata`` (use ``metadata.models``); physical, semantic, and metric tables come
    from that list only — no snapshot rebuild here. Perspectives, if present, are query-state only.
    """
    connection_type, connection_uri = _connection_info(context)

    md_env = metadata.env or ""
    if md_env and md_env != environment:
        logger.warning(
            "Hera sync metadata.env (%s) does not match environment argument (%s); continuing with caller metadata",
            md_env,
            environment,
        )

    models = metadata.models
    mctx = _EntriesIndex.from_entries(models)

    source_entries = [e for e in models if e.source_type not in ("semantic", "metric")]
    semantic_entries = [e for e in models if e.source_type == "semantic"]
    metric_entries = [e for e in models if e.source_type == "metric"]

    product = context.config
    info = _hera_domain_and_vulcan_schema(hera, product, connection_type, connection_uri)
    sync_user = normalize(product.username or info.tenant or info.project)
    lineage = _LineageCollector(hera, mctx)
    data_product_fqn = None
    product_meta = metadata.product
    scoped_data_product_name = data_product_name(info.tenant, product.name)
    data_product_tenants = None
    if metadata.product.domain and metadata.discoverable:
        try:
            data_product = hera.get_by_name(
                entity=_hera_generated_schema().DataProduct, fqn=scoped_data_product_name, fields=["tenants"]
            )
            data_product_tenants = getattr(data_product, "tenants", None) if data_product else None
        except Exception:
            data_product_tenants = None
    if metadata.product.domain and metadata.discoverable:
        data_product_fqn = step(
            "data_product",
            lambda: ensure_data_product(
                hera,
                product_name=scoped_data_product_name,
                domain_fqn=metadata.product.domain,
                description=product_meta.description or "",
                display_name=product_meta.display_name,
                owners=resolve_owner_refs(hera, product_meta.users),
                category=metadata.alignment,
                product_tags=list(product_meta.tags) or None,
            ),
        )
        if data_product_fqn and info.tenant:
            step(
                "data_product_tenant",
                lambda: attach_tenant_to_data_product(
                    hera, data_product_fqn, info.tenant, current_tenants=data_product_tenants
                ),
            )

    source_fqns: list[str] = []
    semantic_fqns: list[str] = []
    metric_fqns: list[str] = []
    perspective_fqns: list[str] = []
    phys_to_view: dict[str, str] = {}
    phys_to_entry: dict[str, ModelEntry] = {}

    if info.source_svc_fqn:
        source_result = step(
            "source_tables",
            lambda: _sync_source_tables(
                hera,
                mctx,
                source_entries,
                info.source_svc_fqn,
                default_db=info.tenant,
                default_schema=info.project,
                domain_fqn=info.domain_fqn,
                lineage=lineage,
            ),
        ) or ([], {}, {})
        source_fqns, phys_to_view, phys_to_entry = source_result

    if info.schema_fqn:
        semantic_fqns = step(
            "semantic_models",
            lambda: _sync_typed_entries(
                hera,
                mctx,
                info.schema_fqn,
                semantic_entries,
                source_type="semantic",
                lineage=lineage,
            ),
        ) or []
        metric_fqns = step(
            "metrics",
            lambda: _sync_typed_entries(
                hera,
                mctx,
                info.schema_fqn,
                metric_entries,
                source_type="metric",
                lineage=lineage,
            ),
        ) or []
        if query_state:
            perspective_fqns = step(
                "perspectives",
                lambda: _sync_perspectives(
                    hera,
                    info.schema_fqn,
                    query_state,
                    current_user_id=sync_user,
                    lineage=lineage,
                ),
            ) or []

    _sync_physical_to_view_lineage(hera, phys_to_view, phys_to_entry)

    all_assets = [*source_fqns, *semantic_fqns, *metric_fqns, *perspective_fqns]
    lineage.flush()

    if info.domain_fqn and all_assets:
        step("domain_assoc", lambda: associate_domain(hera, info.domain_fqn, all_assets))

    if data_product_fqn:
        step("data_product_assets", lambda: attach_data_product_assets(hera, data_product_fqn, all_assets))

    return {
        "environment": environment,
        "tables_synced": len(all_assets),
        "models": len(source_entries),
        "semantic_models": len(semantic_entries),
        "metrics": len(metric_entries),
        "data_product": data_product_fqn,
    }


def sync_to_hera(
    context: Context,
    environment: str,
    *,
    metadata: Metadata,
    query_state: t.Optional[t.Any] = None,
) -> dict[str, t.Any]:
    if not is_prod(environment):
        return {"skipped": True, "reason": "prod_only"}
    hera_cfg = context.config.hera
    if not hera_cfg or not hera_cfg.enabled:
        return {"skipped": True}
    hera = _hera_client(hera_cfg)
    return _snapshot_catalog(
        hera,
        context,
        environment,
        metadata=metadata,
        query_state=query_state,
    )


def _latest_run_status(context: Context, environment: str) -> t.Optional[tuple[bool, t.Optional[int]]]:
    activity_state = getattr(context.state_sync, "activity_state", None)
    if not activity_state:
        return None
    runs_table = getattr(activity_state, "runs_table", None)
    engine_adapter = getattr(activity_state, "engine_adapter", None)
    if not runs_table or not engine_adapter:
        return None
    runs_tbl = runs_table.sql(dialect=engine_adapter.dialect, identify=True)
    sql = f"""
    SELECT success, end_ts
    FROM {runs_tbl}
    WHERE environment = %s
    ORDER BY start_ts DESC
    LIMIT 1
    """
    try:
        with engine_adapter.transaction():
            engine_adapter.cursor.execute(sql, [environment])
            row = engine_adapter.cursor.fetchone()
    except Exception as exc:
        logger.error("Failed to fetch latest run status for Hera: %s", exc, exc_info=True)
        return None
    if row is None:
        return None
    success_raw, end_ts_raw = row
    if success_raw is None:
        return None
    return bool(success_raw), end_ts_raw


def sync_latest_run_status(context: Context, environment: str) -> dict[str, t.Any]:
    if not is_prod(environment):
        return {"skipped": True, "reason": "prod_only"}
    hera_cfg = context.config.hera
    if not hera_cfg or not hera_cfg.enabled:
        return {"skipped": True}
    run_record = _latest_run_status(context, environment)
    if run_record is None:
        return {"skipped": True, "reason": "no_run_record"}
    hera = _hera_client(hera_cfg)
    run_succeeded, last_run_at = run_record
    last_run_status = "PASS" if run_succeeded else "FAIL"
    if not update_data_product_status(
        hera=hera,
        product_name=data_product_name(context.config.tenant, context.config.name),
        last_run_status=last_run_status,
        last_run_at=last_run_at,
        quality_status=last_run_status,
    ):
        return {"skipped": True, "reason": "data_product_missing"}
    return {"environment": environment, "last_run_status": last_run_status, "last_run_at": last_run_at}


def _sync_single_perspective(
    hera: t.Any,
    context: Context,
    query_state: t.Any,
    perspective: t.Any,
    environment: str = "prod",
) -> None:
    """
    Upsert one perspective table into Hera (query-state artifact, not a Vulcan snapshot).

    Reuses Vulcan service / schema wiring from product config plus :func:`_connection_info`;
    does not load ``Environment`` snapshot ids or call :meth:`StateSync.get_snapshots`.
    """
    if not is_prod(environment):
        return
    connection_type, connection_uri = _connection_info(context)
    product = context.config
    info = _hera_domain_and_vulcan_schema(hera, product, connection_type, connection_uri)
    if not info.schema_fqn:
        return
    perspective_fqn = None
    raw_columns = _perspective_raw_columns(query_state, perspective)
    created = _create_table(
        hera,
        table_name=sanitize(perspective.slug),
        schema_fqn=info.schema_fqn,
        columns=raw_columns,
        description=perspective.description or "",
        table_type=_hera_generated_schema().TableType.Perspective,
        display_name=perspective.name,
        owners=resolve_user_owner_ref(hera, getattr(perspective, "owner", None)),
    )
    if created:
        perspective_fqn, table = created
        attach_tags(
            hera,
            table,
            entity_tags(getattr(perspective, "tags", []) or [], getattr(perspective, "terms", []) or []),
        )
    if not perspective_fqn:
        return


def sync_perspective_by_id_to_hera(
    context: Context,
    query_state: t.Any,
    perspective_id: str,
    environment: str = "prod",
) -> bool:
    if not perspective_id:
        return False
    perspective = query_state.get_perspective_by_id(perspective_id)
    if not perspective:
        return False
    sync_perspective_to_hera(context, query_state, perspective, environment=environment)
    return True


def sync_perspective_to_hera(
    context: Context,
    query_state: t.Any,
    perspective: t.Any,
    environment: str = "prod",
) -> None:
    if not is_prod(environment):
        return
    hera_cfg = context.config.hera
    if not hera_cfg or not hera_cfg.enabled:
        return
    hera = _hera_client(hera_cfg)
    _sync_single_perspective(hera, context, query_state, perspective, environment)


def delete_perspective_from_hera(context: Context, slug: str, environment: str = "prod") -> None:
    if not is_prod(environment):
        return
    hera_cfg = context.config.hera
    if not hera_cfg or not hera_cfg.enabled:
        return
    hera = _hera_client(hera_cfg)
    hr = _hera_generated_schema()
    fqn = f"{vulcan_service_name(context.config.tenant, context.config.project)}.{normalize(context.config.tenant)}.{normalize(context.config.project)}.{sanitize(slug)}"
    try:
        table = hera.get_by_name(entity=hr.Table, fqn=fqn)
        if table and getattr(table, "id", None):
            hera.delete(entity=hr.Table, entity_id=table.id.root)
    except Exception as exc:
        logger.warning("Failed to delete perspective '%s' from Hera: %s", slug, exc)
