"""Batch reads over quality / run / profile state tables.

Provides query methods kept out of the shared ``QualityState`` class for
historical reasons. The adapter wraps the engine adapter and table references
from the existing state sync without modifying its public API.

.. note::
    This module uses PostgreSQL-specific SQL constructs (``jsonb_agg``,
    ``jsonb_build_object``, ``FILTER (WHERE ...)``, ``= ANY(%s)``).
    It requires a PostgreSQL state backend and will not work with
    DuckDB, SQLite, or other engines.
"""

from __future__ import annotations

import logging
import typing as t
from collections import defaultdict

from decimal import Decimal

from vulcan.core.soda3.spec import (
    CheckMetricResult,
    CheckOutcome,
    CheckResultWithRunId,
    CheckRuns,
    FieldStatistics,
    ModelProfile,
)
from vulcan.core.state_sync.db.quality import (
    _parse_diagnostics,
    _parse_metric_value,
    _parse_outcome_reasons,
)
from vulcan.core.state_sync.db.utils import json_to_list

logger = logging.getLogger(__name__)


def _parse_timestamp_ms(value: t.Any) -> t.Optional[int]:
    """Normalize DB-returned timestamp values to Unix milliseconds."""
    if value is None:
        return None
    try:
        if isinstance(value, Decimal):
            return int(value)
        if isinstance(value, str):
            return int(float(value))
        return int(value)
    except (TypeError, ValueError):
        return None


def _build_check_metric_map(
    metrics: t.List[t.Dict[str, t.Any]],
) -> t.Dict[str, t.List[CheckMetricResult]]:
    by_check: t.Dict[str, t.List[CheckMetricResult]] = defaultdict(list)
    for m in metrics:
        check_identity = m.get("check_identity")
        if not check_identity:
            continue
        by_check[check_identity].append(
            CheckMetricResult(
                metric_name=m.get("metric_name") or "unknown",
                column_name=m.get("column_name"),
                partition_name=m.get("partition_name"),
                value=_parse_metric_value(m),
                measured_at=_parse_timestamp_ms(m.get("measured_at")),
            )
        )
    for check_identity in by_check:
        by_check[check_identity].sort(
            key=lambda metric: (metric.metric_name, metric.column_name or "")
        )
    return by_check


class QualityBatchStateAdapter:
    """Efficient batch reads for quality metrics, checks, runs, and profiles.

    Wraps the engine adapter and table references from the state sync.
    """

    def __init__(self, state_sync: t.Any) -> None:
        self._qs = getattr(state_sync, "quality_state", state_sync)

    @property
    def _engine_adapter(self):
        return self._qs.engine_adapter

    @property
    def _dialect(self) -> str:
        return self._qs.engine_adapter.dialect

    def get_check_metrics_by_identity(
        self,
        environment: str,
        check_identities: t.List[str],
        run_ids: t.Optional[t.List[str]] = None,
    ) -> t.Dict[str, t.List[CheckMetricResult]]:
        """Fetch persisted metrics for the requested check identities in one batch.

        Args:
            run_ids: When provided, only return metrics produced by these runs.
                Without this constraint *all* historical metrics for each
                identity are returned, which grows unboundedly over time.
        """
        if not environment or not check_identities:
            return {}

        metrics_tbl = self._qs.check_metrics_table.sql(dialect=self._dialect, identify=True)
        run_clause = "\n          AND run_id = ANY(%s)" if run_ids else ""
        sql = f"""
        SELECT
            check_identity, metric_name, column_name, partition_name,
            value_text, value_number, value_json, value_type, measured_at
        FROM {metrics_tbl}
        WHERE environment = %s
          AND check_identity = ANY(%s){run_clause}
        ORDER BY check_identity, metric_name, column_name
        """

        params: t.List[t.Any] = [environment, check_identities]
        if run_ids:
            params.append(run_ids)

        with self._engine_adapter.transaction():
            self._engine_adapter.cursor.execute(
                sql,
                params,
            )
            rows = self._engine_adapter.cursor.fetchall()

        metrics = [
            {
                "check_identity": ci,
                "metric_name": mn,
                "column_name": cn,
                "partition_name": pn,
                "value_text": vt,
                "value_number": vn,
                "value_json": vj,
                "value_type": vtp,
                "measured_at": ma,
            }
            for (ci, mn, cn, pn, vt, vn, vj, vtp, ma) in rows
        ]
        return _build_check_metric_map(metrics)

    def list_latest_checks_for_models(
        self,
        environment: str,
        model_names: t.List[str],
        runs_per_check: int = 1,
    ) -> t.List[CheckRuns]:
        """Return every check definition for *model_names* with its latest run(s).

        Unlike ``QualityState.list_checks`` this never paginates definitions —
        the ``model_names`` filter is the only boundary.  Each returned
        ``CheckRuns`` carries at most *runs_per_check* runs (the most recent).
        """
        if not environment or not model_names:
            return []

        defs_tbl = self._qs.checks_definitions_table.sql(dialect=self._dialect, identify=True)
        results_tbl = self._qs.check_results_table.sql(dialect=self._dialect, identify=True)

        sql = f"""
        WITH checks_from_def AS (
            SELECT check_identity, check_name, check_type, column_name,
                   dimension, definition, model_name
            FROM {defs_tbl}
            WHERE environment = %s
              AND model_name = ANY(%s)
            ORDER BY model_name NULLS LAST, column_name NULLS LAST, check_name
        ),
        ranked AS (
            SELECT cr.*,
                ROW_NUMBER() OVER (
                    PARTITION BY cr.check_identity ORDER BY cr.start_ts DESC
                ) AS rn
            FROM {results_tbl} cr
            WHERE cr.environment = %s
              AND cr.check_identity IN (SELECT check_identity FROM checks_from_def)
        )
        SELECT
            d.check_identity, d.check_name, d.check_type, d.column_name,
            d.dimension, d.definition, d.model_name,
            COALESCE(
                jsonb_agg(
                    jsonb_build_object(
                        'run_id', r.run_id,
                        'start_ts', r.start_ts,
                        'end_ts', r.end_ts,
                        'check_identity', d.check_identity,
                        'check_name', d.check_name,
                        'check_type', d.check_type,
                        'model_name', d.model_name,
                        'column_name', d.column_name,
                        'dimension', d.dimension,
                        'definition', d.definition,
                        'outcome', r.outcome,
                        'outcome_reasons', r.outcome_reasons,
                        'diagnostics', r.diagnostics
                    ) ORDER BY r.start_ts DESC
                ) FILTER (WHERE r.rn > 0 AND r.rn <= %s),
                '[]'::jsonb
            ) AS runs_json
        FROM checks_from_def d
        LEFT JOIN ranked r ON r.check_identity = d.check_identity
        GROUP BY d.check_identity, d.check_name, d.check_type,
                 d.column_name, d.dimension, d.definition, d.model_name
        ORDER BY d.model_name NULLS LAST, d.column_name NULLS LAST, d.check_name
        """

        params: t.List[t.Any] = [environment, model_names, environment, runs_per_check]

        try:
            with self._engine_adapter.transaction():
                self._engine_adapter.cursor.execute(
                    sql,
                    params,
                )
                rows = self._engine_adapter.cursor.fetchall()

            if not rows:
                return []

            result: t.List[CheckRuns] = []
            for row in rows:
                (ci, cn, ct, col, dim, defn, mn, runs_json) = row
                metadata = {
                    "check_identity": ci,
                    "check_name": cn,
                    "check_type": ct,
                    "column_name": col,
                    "dimension": dim,
                    "definition": defn,
                    "model_name": mn,
                }
                runs_list = json_to_list(runs_json)
                runs = []
                for r in runs_list:
                    if not isinstance(r, dict):
                        continue
                    try:
                        outcome = CheckOutcome(r.get("outcome") or "not_evaluated")
                    except ValueError:
                        outcome = CheckOutcome.NOT_EVALUATED
                    run_id = r.get("run_id")
                    start_ts = r.get("start_ts")
                    if run_id is None or start_ts is None:
                        logger.warning("Skipping run with missing run_id/start_ts: %s", r)
                        continue
                    runs.append(
                        CheckResultWithRunId(
                            **metadata,
                            outcome=outcome,
                            outcome_reasons=_parse_outcome_reasons(r.get("outcome_reasons")),
                            diagnostics=(
                                _parse_diagnostics(r.get("diagnostics"))
                                if outcome != CheckOutcome.PASS
                                else {}
                            ),
                            run_id=run_id,
                            start_ts=start_ts,
                            end_ts=r.get("end_ts"),
                        )
                    )
                result.append(CheckRuns(**metadata, runs=runs))
            return result

        except Exception as e:
            logger.error("Failed to fetch checks for batch adapter: %s", e, exc_info=True)
            return []

    def get_latest_run_status(
        self,
        environment: str,
    ) -> t.Optional[t.Tuple[bool, t.Optional[int]]]:
        """Return the success flag and end timestamp of the latest run for *environment*.

        Queries the shared ``_runs`` table by ``start_ts DESC LIMIT 1``.

        Returns:
            ``(success, end_ts_ms)`` for the most recent run, or ``None`` when no
            run record exists for the environment.  ``end_ts_ms`` may itself be
            ``None`` if the run record lacks an end timestamp.
        """
        runs_tbl = self._qs.runs_table.sql(dialect=self._dialect, identify=True)
        sql = f"""
        SELECT success, end_ts
        FROM {runs_tbl}
        WHERE environment = %s
        ORDER BY start_ts DESC
        LIMIT 1
        """
        try:
            with self._engine_adapter.transaction():
                self._engine_adapter.cursor.execute(sql, [environment])
                row = self._engine_adapter.cursor.fetchone()
        except Exception as e:
            logger.error("Failed to fetch latest run status: %s", e, exc_info=True)
            return None

        if row is None:
            return None

        success_raw, end_ts_raw = row
        if success_raw is None:
            logger.warning(
                "Latest run for environment '%s' has NULL success, skipping run status read",
                environment,
            )
            return None
        success = bool(success_raw)
        end_ts = _parse_timestamp_ms(end_ts_raw)
        return success, end_ts

    def list_latest_profiles_by_model(
        self,
        environment: str,
        model_names: t.List[str],
    ) -> t.Dict[str, ModelProfile]:
        """Return the latest profile for each model, with ``profiled_at`` populated.

        Unlike ``QualityState.list_latest_runs_by_model`` this fetches only
        profile data (no quality checks or run metadata) and extracts the
        ``profiled_at`` timestamp directly from the ``_profiles`` table.
        """
        if not environment or not model_names:
            return {}

        runs_tbl = self._qs.runs_table.sql(dialect=self._dialect, identify=True)
        profiles_tbl = self._qs.profiles_table.sql(dialect=self._dialect, identify=True)

        latest_run_sql = f"""
        WITH expanded AS (
            SELECT
                r.run_id,
                expanded_models.model_name,
                ROW_NUMBER() OVER (
                    PARTITION BY expanded_models.model_name
                    ORDER BY r.start_ts DESC
                ) AS rn
            FROM {runs_tbl} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS expanded_models(model_name)
            WHERE r.environment = %s
              AND r.models_affected IS NOT NULL
              AND expanded_models.model_name = ANY(%s)
        )
        SELECT model_name, run_id
        FROM expanded
        WHERE rn = 1
        """

        with self._engine_adapter.transaction():
            self._engine_adapter.cursor.execute(latest_run_sql, [environment, model_names])
            latest_rows = list(self._engine_adapter.cursor.fetchall())

        if not latest_rows:
            return {}

        run_ids = [run_id for _, run_id in latest_rows]
        model_by_run: dict[str, str] = {run_id: model_name for model_name, run_id in latest_rows}

        profile_sql = f"""
        SELECT
            run_id, model_name, column_name, profile_type,
            value_text, value_number, value_json, value_type, profiled_at
        FROM {profiles_tbl}
        WHERE run_id = ANY(%s)
          AND model_name = ANY(%s)
        ORDER BY run_id, model_name, column_name, profile_type
        """

        with self._engine_adapter.transaction():
            self._engine_adapter.cursor.execute(profile_sql, [run_ids, model_names])
            profile_rows = self._engine_adapter.cursor.fetchall()

        profiles_raw: dict[str, dict[str, t.Any]] = defaultdict(
            lambda: {"columns": defaultdict(dict), "profiled_at": None}
        )
        for row in profile_rows:
            (
                _run_id,
                model_name,
                column_name,
                profile_type,
                value_text,
                value_number,
                value_json,
                value_type,
                profiled_at,
            ) = row
            entry = profiles_raw[model_name]
            ts = _parse_timestamp_ms(profiled_at)
            if ts is not None and (entry["profiled_at"] is None or ts > entry["profiled_at"]):
                entry["profiled_at"] = ts

            parsed_value = _parse_metric_value(
                {
                    "value_text": value_text,
                    "value_number": value_number,
                    "value_json": value_json,
                    "value_type": value_type,
                }
            )
            if column_name is None:
                entry[profile_type] = parsed_value
            else:
                entry["columns"][column_name][profile_type] = parsed_value

        result: dict[str, ModelProfile] = {}
        for model_name, data in profiles_raw.items():
            columns = {
                col_name: FieldStatistics(**col_metrics)
                for col_name, col_metrics in data.pop("columns", {}).items()
                if col_metrics
            }
            result[model_name] = ModelProfile(
                model_name=model_name,
                profiled_at=data.get("profiled_at"),
                row_count=data.get("row_count"),
                columns=columns,
            )
        return result
