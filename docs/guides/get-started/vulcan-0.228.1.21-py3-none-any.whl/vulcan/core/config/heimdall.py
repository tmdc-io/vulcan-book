"""Heimdall authorization service configuration."""

from __future__ import annotations

from pydantic import model_validator

from vulcan.core.config.base import BaseConfig


class HeimdallConfig(BaseConfig):
    """Heimdall authorization service configuration.
    
    Heimdall is used to validate Bearer tokens and authorize API requests.
    Only used by the Vulcan API service, not by Vulcan CLI.
    
    Attributes:
        base_url: Heimdall service base URL (required when enabled=true)
        timeout: Request timeout in seconds
        enabled: Whether authorization is enabled (default: False for safety)
    
    Example config.yaml:
        heimdall:
          base_url: "https://glacier-121525.dataos.app/heimdall"
          timeout: 10
          enabled: true
    """
    
    # Heimdall service base URL (required when enabled=true)
    base_url: str = ""
    # HTTP timeout in seconds for Heimdall requests
    timeout: float = 10.0
    # Enable/disable authorization (default: False for safety in development)
    enabled: bool = False
    
    @model_validator(mode="after")
    def validate_base_url_required_when_enabled(self) -> "HeimdallConfig":
        """Validate that base_url is set when enabled=true."""
        if self.enabled and not self.base_url:
            raise ValueError(
                "heimdall.base_url is required when heimdall.enabled=true. "
                "Either provide a valid Heimdall URL or set heimdall.enabled=false."
            )
        return self

