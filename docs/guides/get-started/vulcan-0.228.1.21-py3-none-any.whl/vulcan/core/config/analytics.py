from __future__ import annotations

from pydantic import Field
from vulcan.core.config.base import BaseConfig


class AnalyticsConfig(BaseConfig):
    """Analytics/telemetry configuration for Vulcan.
    
    Configures the CloudEvents-based analytics collector that sends
    telemetry events (plan, apply, run, etc.) to a remote service.
    
    Design Decision (Dec 2025):
        Vulcan uses its own CloudEvents-based analytics system, which completely
        replaces the original Vulcan anonymized analytics (Tobiko). This was 
        originally implemented using `disable_anonymized_analytics` 
        (inherited from Vulcan) as the control flag`.
        
        We consolidated this into a single nested `AnalyticsConfig` for consistency
        with other config patterns (pgq, graphql, etc.). The `enabled` field is now
        the single source of truth for enabling/disabling analytics, replacing the
        legacy `disable_anonymized_analytics` field.
        
        Key decisions:
        - `analytics.enabled` replaces `disable_anonymized_analytics` (inverted logic)
        - Configuration loaded from config.yaml, not environment variables
        - NoopEventDispatcher used at import time (before config loads)
        - CLI_COMMAND events before config loading are not captured (acceptable trade-off)
        - Validation happens at runtime in init_collector_from_config(), not at config load
          (to avoid import-time failures when creating default AnalyticsConfig())
    
    Args:
        enabled: Whether analytics collection is enabled. Defaults to True.
        base_url: Base URL for the CloudEvents collector API. Required when enabled.
        api_key: API key for authentication with the collector. Required when enabled.
        source_name: Source identifier for events. Defaults to "vulcan".
        enable_search: Whether to enable search indexing on the collector. Defaults to True.
        retention_days: Number of days to retain analytics data. Defaults to 30.
        timeout: HTTP timeout in seconds for collector requests. Defaults to 10.
    
    Example:
        analytics:
          enabled: true
          base_url: "https://collector.example.com/api"
          api_key: "${ANALYTICS_API_KEY}"
          source_name: "vulcan"
          retention_days: 30
    """
    
    enabled: bool = Field(
        default=True,
        description="Whether analytics collection is enabled",
    )
    base_url: str = Field(
        default="",
        description="Base URL for the CloudEvents collector API (required when enabled)",
    )
    api_key: str = Field(
        default="",
        description="API key for authentication with the collector (required when enabled)",
    )
    source_name: str = Field(
        default="vulcan",
        description="Source identifier for events",
    )
    enable_search: bool = Field(
        default=True,
        description="Whether to enable search indexing on the collector",
    )
    retention_days: int = Field(
        default=30,
        ge=1,
        le=365,
        description="Number of days to retain analytics data",
    )
    timeout: int = Field(
        default=10,
        ge=1,
        le=300,
        description="HTTP timeout in seconds for collector requests",
    )
