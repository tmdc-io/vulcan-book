from __future__ import annotations

import pickle
import re
import typing as t
import zlib
import os

from pydantic import Field, field_validator
from pydantic.functional_validators import BeforeValidator
from sqlglot import exp
from sqlglot.helper import first
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers

from vulcan.cicd.config import CICDBotConfig
from vulcan.core import constants as c
from vulcan.core.console import get_console
from vulcan.core.config.common import (
    DataProductAlignment,
    EnvironmentSuffixTarget,
    TableNamingConvention,
    VirtualEnvironmentMode,
)
from vulcan.core.config.base import BaseConfig, UpdateStrategy
from vulcan.core.config.common import variables_validator, compile_regex_mapping
from vulcan.core.config.connection import (
    ConnectionConfig,
    DuckDBConnectionConfig,
    SerializableConnectionConfig,
    connection_config_validator,
)
from vulcan.core.config.format import FormatConfig
from vulcan.core.config.gateway import GatewayConfig
from vulcan.core.config.janitor import JanitorConfig
from vulcan.core.config.migration import MigrationConfig
from vulcan.core.config.model import ModelDefaultsConfig
from vulcan.core.config.naming import NameInferenceConfig as NameInferenceConfig
from vulcan.core.config.linter import LinterConfig as LinterConfig
from vulcan.core.config.plan import PlanConfig
from vulcan.core.config.run import RunConfig
from vulcan.core.config.dbt import DbtConfig
from vulcan.core.config.scheduler import (
    BuiltInSchedulerConfig,
    SchedulerConfig,
    scheduler_config_validator,
)
from vulcan.core.config.ui import UIConfig
from vulcan.core.config.object_store import ObjectStoreConfig
from vulcan.core.config.transpiler import TranspilerConfig
from vulcan.core.config.graphql import GraphQLConfig
from vulcan.core.config.pgq import PGQConfig
from vulcan.core.config.analytics import AnalyticsConfig
from vulcan.core.config.heimdall import HeimdallConfig
from vulcan.core.config.before_after import BeforeAfterEntry
from vulcan.core.hera.config import HeraConfig
from vulcan.core.loader import Loader, SqlMeshLoader
from vulcan.core.notification_target import NotificationTarget
from vulcan.core.types import Tag, Term
from vulcan.core.user import User
from schema.issue_tracker import IssueTracker
from schema.usage import Usage
from vulcan.utils.date import to_timestamp, now
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import model_validator


def match_merge_or_log_with_env(
    *,
    env_key: str,
    current_value: t.Any,
    config_label: str,
    match: bool,
    merge_tags: bool = False,
    log_override_message: t.Optional[str] = None,
) -> t.Any:
    """
    Read env var `env_key` and either:
    - match=True: enforce it matches `current_value` (raise ConfigError on mismatch)
    - match=False: log a warning and override `current_value` (if env is set and non-empty
      AND the env value actually differs from `current_value`)
    - merge_tags=True: merge tags from env var into `current_value`

    The override warning is only emitted when the env value would actually change
    `current_value`. This avoids noisy warnings on every API/CLI startup in
    DataOS deployments where the env mirrors `config.yaml` (the common case).
    """
    raw = os.getenv(env_key)
    if raw is None:
        return current_value

    raw = raw.strip()
    if not raw:
        return current_value

    if merge_tags:
        # Comma-separated tags.
        raw_tags = [s.strip() for s in raw.split(",")]
        parsed_tags = [Tag(s) for s in raw_tags if s]
        if not parsed_tags:
            return list(current_value or [])

        existing = list(current_value or [])
        existing_set = {str(t) for t in existing}
        merged_set = existing_set | {str(t) for t in parsed_tags}
        merged = [Tag(t) for t in sorted(merged_set)]

        if log_override_message and (merged_set != existing_set or len(existing) != len(existing_set)):
            get_console().log_warning(log_override_message)
        return merged

    if match:
        if raw != current_value:
            raise ConfigError(
                f"Config validation failed: config.yaml {config_label}='{current_value}' does not match "
                f"{config_label} ='{raw}'."
            )
        return current_value

    # Only warn when the env value actually changes `current_value`. Comparing
    # against `str(current_value)` lets callers pass non-string defaults (e.g.
    # None for an unset description) without false positives when the env value
    # encodes the same logical value.
    if log_override_message and raw != current_value and raw != str(current_value or ""):
        get_console().log_warning(
            f"{log_override_message} (env {env_key}='{raw}', config.yaml {config_label}='{current_value}')"
        )
    return raw


def validate_no_past_ttl(v: str) -> str:
    current_time = now()
    if to_timestamp(v, relative_base=current_time) < to_timestamp(current_time):
        raise ValueError(
            f"TTL '{v}' is in the past. Please specify a relative time in the future. Ex: `in 1 week` instead of `1 week`."
        )
    return v


def gateways_ensure_dict(value: t.Dict[str, t.Any]) -> t.Dict[str, t.Any]:
    try:
        if not isinstance(value, GatewayConfig):
            GatewayConfig.parse_obj(value)
        return {"": value}
    except Exception:
        # Normalize all gateway keys to lowercase for case-insensitive matching
        if isinstance(value, dict):
            return {k.lower(): v for k, v in value.items()}
        return value


def validate_regex_key_dict(value: t.Dict[str | re.Pattern, t.Any]) -> t.Dict[re.Pattern, t.Any]:
    return compile_regex_mapping(value)


if t.TYPE_CHECKING:
    from vulcan.core._typing import Self

    NoPastTTLString = str
    GatewayDict = t.Dict[str, GatewayConfig]
    RegexKeyDict = t.Dict[re.Pattern, str]
else:
    NoPastTTLString = t.Annotated[str, BeforeValidator(validate_no_past_ttl)]
    GatewayDict = t.Annotated[t.Dict[str, GatewayConfig], BeforeValidator(gateways_ensure_dict)]
    RegexKeyDict = t.Annotated[t.Dict[re.Pattern, str], BeforeValidator(validate_regex_key_dict)]


_VDE_FORBIDDEN_WAREHOUSE_TYPES = frozenset(
    {
        "spark",
        "trino"
    }
)

# SemVer 2.0 (https://semver.org/) — same grammar as the project's suggested regex.
_DATA_PRODUCT_VERSION_PATTERN = re.compile(
    r"^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)"
    r"(?:-(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*)?"
    r"(?:\+[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*)?$"
)


class Config(BaseConfig):
    """An object used by a Context to configure your Vulcan project.

    Args:
        gateways: Supported gateways and their configurations. Key represents a unique name of a gateway.
        default_connection: The default connection to use if one is not specified in a gateway.
        default_test_connection: The default connection to use for tests if one is not specified in a gateway.
        default_scheduler: The default scheduler configuration to use if one is not specified in a gateway.
        default_gateway: The default gateway.
        notification_targets: The notification targets to use.
        name: The name of this project. This will override the project field if provided.
        tenant: The tenant of this project.
        description: A description of this project.
        discoverable: Whether this project is listed for search and discovery in catalog surfaces.
        version: Data product release version (SemVer 2.0, e.g. ``1.2.3`` or ``1.0.0-rc.1+meta``).
        alignment: Whether the product is source-aligned or consumer-aligned.
        tags: Tags for categorization.
        terms: Glossary terms.
        usage: Product usage guidance loaded from ``usage.yml`` beside the project config.
        issue_tracker: External issue tracking system for this data product.
        project: The project name of this config. Used for multi-repo setups. Will be overridden by name if name is provided.
        snapshot_ttl: The period of time that a model snapshot that is not a part of any environment should exist before being deleted.
        environment_ttl: The period of time that a development environment should exist before being deleted.
        ignore_patterns: Files that match glob patterns specified in this list are ignored when scanning the project folder.
        time_column_format: The default format to use for all model time columns. Defaults to %Y-%m-%d.
            This time format uses python format codes. https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes.
        users: A list of users that can be used for approvals/notifications.
        username: Name of a single user who should receive approvals/notification, instead of all users in the `users` list.
        pinned_environments: A list of development environment names that should not be deleted by the janitor task.
        loader: Loader class used for loading project files.
        loader_kwargs: Key-value arguments to pass to the loader instance.
        env_vars: A dictionary of environmental variable names and values.
        model_defaults: Default values for model definitions.
        physical_schema_mapping: A mapping from regular expressions to names of schemas in which physical tables for corresponding models will be placed.
        environment_suffix_target: Indicates whether to append the environment name to the schema or table name.
        physical_table_naming_convention: Indicates how tables should be named at the physical layer
        vde: When true, enables full Virtual Data Environments
        virtual_environment_mode: Derived from ``vde`` after validation (per-model overrides remain separate).
        gateway_managed_virtual_layer: Whether the models' views in the virtual layer are created by the model-specific gateway rather than the default gateway.
        infer_python_dependencies: Whether to statically analyze Python code to automatically infer Python package requirements.
        environment_catalog_mapping: A mapping from regular expressions to catalog names. The catalog name is used to determine the target catalog for a given environment.
        default_target_environment: The name of the environment that will be the default target for the `vulcan plan` and `vulcan run` commands.
        log_limit: The default number of logs to keep.
        format: The formatting options for SQL code.
        ui: The UI configuration for Vulcan.
        plan: The plan configuration.
        migration: The migration configuration.
        variables: A dictionary of variables that can be used in models / macros.
        before_all: SQL statements, macros, or `file:` references (see BeforeAfterFileRef) for the start of `vulcan plan` and `vulcan run`.
        after_all: Same as `before_all`, run at the end of those commands.
        cache_dir: The directory to store the Vulcan cache. Defaults to .cache in the project folder.
        object_store: Configuration for query-result object storage.
        pgq: Configuration for PostgreSQL Queue (PGQ) async job processing.
        analytics: Analytics/telemetry configuration for event collection.
    """

    gateways: GatewayDict = {"": GatewayConfig()}
    default_connection: t.Optional[SerializableConnectionConfig] = None
    default_test_connection_: t.Optional[SerializableConnectionConfig] = Field(
        default=None, alias="default_test_connection"
    )
    default_scheduler: SchedulerConfig = BuiltInSchedulerConfig()
    default_gateway: str = ""
    notification_targets: t.List[NotificationTarget] = []
    name: str
    tenant: t.Optional[str] = None
    display_name: t.Optional[str] = None
    description: str = Field(default="DataOS Vulcan Data Product. This is a default description for the data product.")
    domain: t.Optional[str] = None
    discoverable: bool = c.DEFAULT_DISCOVERABLE
    version: str = c.DEFAULT_VERSION
    alignment: DataProductAlignment = Field(default_factory=lambda: DataProductAlignment(c.DEFAULT_ALIGNMENT))
    tags: t.List[Tag] = []
    terms: t.List[Term] = []
    usage: Usage = Field(default_factory=Usage)
    issue_tracker: t.Optional[IssueTracker] = None
    hera: HeraConfig = Field(default_factory=HeraConfig)
    project: str = ""
    snapshot_ttl: NoPastTTLString = c.DEFAULT_SNAPSHOT_TTL
    environment_ttl: t.Optional[NoPastTTLString] = c.DEFAULT_ENVIRONMENT_TTL
    ignore_patterns: t.List[str] = c.IGNORE_PATTERNS
    time_column_format: str = c.DEFAULT_TIME_COLUMN_FORMAT
    users: t.List[User] = []
    model_defaults: ModelDefaultsConfig = ModelDefaultsConfig()
    pinned_environments: t.Set[str] = set()
    loader: t.Type[Loader] = SqlMeshLoader
    loader_kwargs: t.Dict[str, t.Any] = {}
    env_vars: t.Dict[str, str] = {}
    username: str = ""
    physical_schema_mapping: RegexKeyDict = {}
    environment_suffix_target: EnvironmentSuffixTarget = EnvironmentSuffixTarget.default
    physical_table_naming_convention: TableNamingConvention = TableNamingConvention.default
    vde: bool = False
    virtual_environment_mode: VirtualEnvironmentMode = VirtualEnvironmentMode.default
    gateway_managed_virtual_layer: bool = False
    infer_python_dependencies: bool = True
    environment_catalog_mapping: RegexKeyDict = {}
    default_target_environment: str = c.PROD
    log_limit: int = c.DEFAULT_LOG_LIMIT
    cicd_bot: t.Optional[CICDBotConfig] = None
    run: RunConfig = RunConfig()
    format: FormatConfig = FormatConfig()
    ui: UIConfig = UIConfig()
    plan: PlanConfig = PlanConfig()
    migration: MigrationConfig = MigrationConfig()
    model_naming: NameInferenceConfig = NameInferenceConfig()
    variables: t.Dict[str, t.Any] = {}
    before_all: t.Optional[t.List[BeforeAfterEntry]] = None
    after_all: t.Optional[t.List[BeforeAfterEntry]] = None
    linter: LinterConfig = LinterConfig()
    janitor: JanitorConfig = JanitorConfig()
    cache_dir: t.Optional[str] = None
    dbt: t.Optional[DbtConfig] = None
    object_store: t.Optional[ObjectStoreConfig] = None
    transpiler: TranspilerConfig = TranspilerConfig()
    graphql: GraphQLConfig = GraphQLConfig()
    state: t.Optional[SerializableConnectionConfig] = None
    pgq: PGQConfig = PGQConfig()
    analytics: AnalyticsConfig = AnalyticsConfig()  # See AnalyticsConfig docstring for design rationale
    heimdall: HeimdallConfig = HeimdallConfig()  # Used by Vulcan API for authentication

    @field_validator("version")
    @classmethod
    def _validate_version_semver(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("version cannot be empty or whitespace")
        if not _DATA_PRODUCT_VERSION_PATTERN.fullmatch(stripped):
            raise ValueError(
                "version must be a valid SemVer 2.0 string "
                "(e.g. 0.0.0, 1.2.3, 1.0.0-alpha.1+build.42)"
            )
        return stripped

    @field_validator("domain")
    @classmethod
    def _validate_domain(cls, value: t.Optional[str]) -> t.Optional[str]:
        if value is None:
            return value
        stripped = value.strip()
        if not stripped:
            raise ValueError("domain cannot be empty or whitespace")
        return stripped

    @model_validator(mode="before")
    @classmethod
    def _capture_depot_address(cls, values: t.Any) -> t.Any:
        """Extract the depot address from the default gateway's raw connection
        dict and expose it as ``DATAOS_SOURCE_DEPOT_ADDRESS`` so downstream
        components can read the depot name without coupling
        to config internals.

        Runs before field validators so the raw ``{type: depot, address: ...}``
        dict is still available.
        """
        if not isinstance(values, dict):
            return values
        gateways = values.get("gateways", {})
        if not isinstance(gateways, dict):
            return values
        default_gw = values.get("default_gateway", "")
        for gw_key in (default_gw, "default", ""):
            gw = gateways.get(gw_key)
            if isinstance(gw, dict):
                conn = gw.get("connection")
                if isinstance(conn, dict) and conn.get("type") == "depot":
                    address = conn.get("address", "")
                    if address:
                        os.environ["DATAOS_SOURCE_DEPOT_ADDRESS"] = address
                break
        return values

    @model_validator(mode="after")
    def _validate_dataos_name_env(self) -> "Self":
        """
        DataOS Deployment overrides:
        - if DATAOS_RESOURCE_NAME is set, it overrides config.yaml `name` (data product identity)
        - DATAOS_TENANT_ID provides the effective `tenant`
        - if DATAOS_RESOURCE_DESCRIPTION is set, it overrides config.yaml `description`
        - if DATAOS_RESOURCE_TAGS is set, it merges with config.yaml `tags`
        """
        self.name = match_merge_or_log_with_env(
            env_key="DATAOS_RESOURCE_NAME",
            current_value=self.name,
            config_label="name",
            match=False,
            log_override_message="DATAOS_RESOURCE_NAME is set, overriding config.yaml name for data product identity.",
        )
        self.tenant = (os.getenv("DATAOS_TENANT_ID") or "").strip() or self.tenant

        self.description = match_merge_or_log_with_env(
            env_key="DATAOS_RESOURCE_DESCRIPTION",
            current_value=self.description,
            config_label="description",
            match=False,
            log_override_message=(
                "resource description is provided in vulcan resource, config.yaml description will be overwritten with the resource description."
            ),
        )

        self.tags = match_merge_or_log_with_env(
            env_key="DATAOS_RESOURCE_TAGS",
            current_value=self.tags or [],
            config_label="tags",
            match=False,
            merge_tags=True,
            log_override_message="resource tags are provided in vulcan resource, config.yaml tags will be merged with the resource tags.",
        )

        return self

    _FIELD_UPDATE_STRATEGY: t.ClassVar[t.Dict[str, UpdateStrategy]] = {
        "gateways": UpdateStrategy.NESTED_UPDATE,
        "notification_targets": UpdateStrategy.EXTEND,
        "ignore_patterns": UpdateStrategy.EXTEND,
        "users": UpdateStrategy.EXTEND,
        "model_defaults": UpdateStrategy.NESTED_UPDATE,
        "auto_categorize_changes": UpdateStrategy.NESTED_UPDATE,
        "pinned_environments": UpdateStrategy.EXTEND,
        "physical_schema_override": UpdateStrategy.KEY_UPDATE,
        "run": UpdateStrategy.NESTED_UPDATE,
        "format": UpdateStrategy.NESTED_UPDATE,
        "ui": UpdateStrategy.NESTED_UPDATE,
        "loader_kwargs": UpdateStrategy.KEY_UPDATE,
        "plan": UpdateStrategy.NESTED_UPDATE,
        "before_all": UpdateStrategy.EXTEND,
        "after_all": UpdateStrategy.EXTEND,
        "linter": UpdateStrategy.NESTED_UPDATE,
        "dbt": UpdateStrategy.NESTED_UPDATE,
        "object_store": UpdateStrategy.NESTED_UPDATE,
        "transpiler": UpdateStrategy.NESTED_UPDATE,
        "graphql": UpdateStrategy.NESTED_UPDATE,
        "pgq": UpdateStrategy.NESTED_UPDATE,
        "analytics": UpdateStrategy.NESTED_UPDATE,
        # Do not add ``issue_tracker`` (or other ``schema`` wire models like ``Usage``):
        # NESTED_UPDATE requires ``BaseConfig``; these use default REPLACE instead.
    }

    _connection_config_validator = connection_config_validator
    _scheduler_config_validator = scheduler_config_validator  # type: ignore
    _variables_validator = variables_validator

    @model_validator(mode="before")
    def _load_state_connection_from_file(cls, data: t.Any) -> t.Any:
        """Load state connection from external file if it exists."""
        if not isinstance(data, dict):
            return data

        import os
        import pathlib
        from vulcan.utils.yaml import load as yaml_load
        from vulcan.utils.errors import ConfigError

        # Check if state_connection.yaml exists in /etc/dataos/secret/ (or custom DATAOS_SECRET_DIR)
        secret_dir = os.getenv("DATAOS_SECRET_DIR", "/etc/dataos/secret")

        state_config_path = pathlib.Path(secret_dir) / f"state_connection_config.yaml"

        if state_config_path.exists() and state_config_path.is_file():
            try:
                state_config = yaml_load(state_config_path)
                if isinstance(state_config, dict) and "connection" in state_config:
                    # Override the state field with the loaded connection
                    data["state"] = state_config["connection"]
                    get_console().log_status_update(
                        f"Loaded state connection from {state_config_path}"
                    )
            except Exception as e:
                raise ConfigError(f"Failed to load state connection from {state_config_path}: {e}")

        return data

    @model_validator(mode="before")
    def _normalize_and_validate_fields(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data

        if "gateways" not in data and "gateway" in data:
            data["gateways"] = data.pop("gateway")

        # TODO: regex validation on tenant and name
        # Backward compatibility: if name is not provided but project is, use project for name
        if "name" not in data and "project" in data:
            data["name"] = data["project"]
        # If description is not provided
        if "description" not in data:
            data["description"] = ""

        for plan_deprecated in ("auto_categorize_changes", "include_unmodified"):
            if plan_deprecated in data:
                raise ConfigError(
                    f"The `{plan_deprecated}` config is deprecated. Please use the `plan.{plan_deprecated}` config instead."
                )

        if "physical_schema_override" in data:
            get_console().log_warning(
                "`physical_schema_override` is deprecated. Please use `physical_schema_mapping` instead."
            )

            if "physical_schema_mapping" in data:
                raise ConfigError(
                    "Only one of `physical_schema_override` and `physical_schema_mapping` can be specified."
                )

            physical_schema_override: t.Dict[str, str] = data.pop("physical_schema_override")
            # translate physical_schema_override to physical_schema_mapping
            data["physical_schema_mapping"] = {
                f"^{k}$": v for k, v in physical_schema_override.items()
            }

        return data

    def _validate_vde_warehouse_engines(self) -> None:
        if not self.vde or not isinstance(self.gateways, dict):
            return

        forbidden_list = ", ".join(sorted(_VDE_FORBIDDEN_WAREHOUSE_TYPES))
        for gw_name, gw in self.gateways.items():
            conn = gw.connection or self.default_connection
            if conn is None:
                continue
            if conn.type_ in _VDE_FORBIDDEN_WAREHOUSE_TYPES:
                label = repr(gw_name) if gw_name else "''"
                raise ConfigError(
                    f"`vde: true` is not supported for engine types ({forbidden_list}); "
                    f"gateway {label} has `{conn.type_}`."
                )

    @model_validator(mode="after")
    def _normalize_fields_after(self) -> Self:
        dialect = self.model_defaults.dialect

        def _normalize_identifiers(key: str) -> None:
            setattr(
                self,
                key,
                {
                    k: normalize_identifiers(v, dialect=dialect).name
                    for k, v in getattr(self, key, {}).items()
                },
            )

        # Validate that name, tenant and description are provided
        if not self.name or not self.name.strip():
            raise ConfigError("The 'name' field is required and cannot be empty.")
        if not self.tenant or not self.tenant.strip():
            raise ConfigError("Tenant must be provided via DATAOS_TENANT_ID environment variable.")
        if self.tenant and not self.domain:
            raise ConfigError(
                "The 'domain' field is required in config.yaml (e.g. domain: marketing)."
            )
        if not self.description or not self.description.strip():
            raise ConfigError("The 'description' field is required and cannot be empty.")

        # name overrides project
        if self.name:
            self.project = self.name

        # ``vde`` is source of truth for root VDE mode; forbid Spark/Trino when full.
        self.virtual_environment_mode = VirtualEnvironmentMode.FULL if self.vde else VirtualEnvironmentMode.DEV_ONLY
        self._validate_vde_warehouse_engines()

        if (
            self.environment_suffix_target == EnvironmentSuffixTarget.CATALOG
            and self.environment_catalog_mapping
        ):
            raise ConfigError(
                f"'environment_suffix_target: catalog' is mutually exclusive with 'environment_catalog_mapping'.\n"
                "Please specify one or the other"
            )

        if self.plan.use_finalized_state and not self.virtual_environment_mode.is_full:
            raise ConfigError(
                "Using the finalized state is only supported when full Virtual Data Environments "
                "are enabled (`vde: true`)."
            )

        if self.environment_catalog_mapping:
            _normalize_identifiers("environment_catalog_mapping")
        if self.physical_schema_mapping:
            _normalize_identifiers("physical_schema_mapping")

        return self

    @model_validator(mode="after")
    def _inherit_project_config_in_cicd_bot(self) -> Self:
        if self.cicd_bot:
            # inherit the project-level settings into the CICD bot if they have not been explicitly overridden
            if self.cicd_bot.auto_categorize_changes_ is None:
                self.cicd_bot.auto_categorize_changes_ = self.plan.auto_categorize_changes

            if self.cicd_bot.pr_include_unmodified_ is None:
                self.cicd_bot.pr_include_unmodified_ = self.plan.include_unmodified

        return self

    def get_default_test_connection(
        self,
        default_catalog: t.Optional[str] = None,
        default_catalog_dialect: t.Optional[str] = None,
    ) -> ConnectionConfig:
        return self.default_test_connection_ or DuckDBConnectionConfig(
            catalogs=(
                None
                if default_catalog is None
                else {
                    # transpile catalog name from main connection dialect to DuckDB
                    exp.parse_identifier(default_catalog, dialect=default_catalog_dialect).sql(
                        dialect="duckdb"
                    ): ":memory:"
                }
            )
        )

    def get_gateway(self, name: t.Optional[str] = None) -> GatewayConfig:
        if isinstance(self.gateways, dict):
            if name is None:
                if self.default_gateway:
                    # Normalize default_gateway name to lowercase for lookup
                    default_key = self.default_gateway.lower()
                    if default_key not in self.gateways:
                        raise ConfigError(f"Missing gateway with name '{self.default_gateway}'")
                    return self.gateways[default_key]

                if "" in self.gateways:
                    return self.gateways[""]

                return first(self.gateways.values())

            # Normalize lookup name to lowercase since gateway keys are already lowercase
            lookup_key = name.lower()
            if lookup_key not in self.gateways:
                raise ConfigError(f"Missing gateway with name '{name}'.")

            return self.gateways[lookup_key]
        if name is not None:
            raise ConfigError("Gateway name is not supported when only one gateway is configured.")
        return self.gateways

    def get_connection(self, gateway_name: t.Optional[str] = None) -> ConnectionConfig:
        connection = self.get_gateway(gateway_name).connection or self.default_connection
        if connection is None:
            msg = f" for gateway '{gateway_name}'" if gateway_name else ""
            raise ConfigError(f"No connection configured{msg}.")
        return connection

    def get_state_connection(
        self, gateway_name: t.Optional[str] = None
    ) -> t.Optional[ConnectionConfig]:
        # Root-level state connection takes precedence over gateway-level
        return self.state or self.get_gateway(gateway_name).state_connection

    def get_test_connection(
        self,
        gateway_name: t.Optional[str] = None,
        default_catalog: t.Optional[str] = None,
        default_catalog_dialect: t.Optional[str] = None,
    ) -> ConnectionConfig:
        return self.get_gateway(gateway_name).test_connection or self.get_default_test_connection(
            default_catalog=default_catalog, default_catalog_dialect=default_catalog_dialect
        )

    def get_scheduler(self, gateway_name: t.Optional[str] = None) -> SchedulerConfig:
        return self.get_gateway(gateway_name).scheduler or self.default_scheduler

    def get_state_schema(self, gateway_name: t.Optional[str] = None) -> t.Optional[str]:
        # If root-level state connection is provided (deployment mode), use normalized tenant and project name.
        if self.state and self.tenant and self.name:

            def normalize(value: str) -> str:
                return value.lower().replace("-", "_").replace(".", "_").replace(" ", "_")

            return f"{normalize(self.tenant)}_{normalize(self.name)}"

        # Otherwise use gateway's state_schema (local development mode)
        return self.get_gateway(gateway_name).state_schema

    @property
    def default_gateway_name(self) -> str:
        if self.default_gateway:
            return self.default_gateway
        if "" in self.gateways:
            return ""
        return first(self.gateways)

    @property
    def dialect(self) -> t.Optional[str]:
        return self.model_defaults.dialect

    @property
    def fingerprint(self) -> str:
        return str(zlib.crc32(pickle.dumps(self.dict(exclude={"loader", "notification_targets"}))))
