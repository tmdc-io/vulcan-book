from __future__ import annotations

import logging
import smtplib
import sys
import typing as t
from datetime import datetime, timezone
from email.message import EmailMessage
from enum import Enum

import requests
from pydantic import Field, SecretStr

from vulcan.core.console import Console, get_console
from vulcan.integrations import slack
from vulcan.utils.errors import (
    ApiClientError,
    AuditError,
    ConfigError,
    MissingDependencyError,
    raise_for_status,
)
from vulcan.utils.pydantic import PydanticModel
from vulcan.utils.pydantic import PydanticModel


logger = logging.getLogger(__name__)

if t.TYPE_CHECKING:
    from slack_sdk import WebClient, WebhookClient


def _vulcan_version() -> str:
    try:
        from vulcan import __version__

        return __version__
    except ImportError:
        return "0.0.0"


class NotificationStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    WARNING = "warning"
    INFO = "info"
    PROGRESS = "progress"

    @property
    def is_success(self) -> bool:
        return self == NotificationStatus.SUCCESS

    @property
    def is_failure(self) -> bool:
        return self == NotificationStatus.FAILURE

    @property
    def is_info(self) -> bool:
        return self == NotificationStatus.INFO

    @property
    def is_warning(self) -> bool:
        return self == NotificationStatus.WARNING

    @property
    def is_progress(self) -> bool:
        return self == NotificationStatus.PROGRESS


class NotificationEvent(str, Enum):
    APPLY_START = "apply_start"
    APPLY_END = "apply_end"
    RUN_START = "run_start"
    RUN_END = "run_end"
    MIGRATION_START = "migration_start"
    MIGRATION_END = "migration_end"
    APPLY_FAILURE = "apply_failure"
    RUN_FAILURE = "run_failure"
    AUDIT_FAILURE = "audit_failure"
    MIGRATION_FAILURE = "migration_failure"

    PLAN_CHANGE = "plan_change"
    
    CHECK_START = "check_start"
    CHECK_END = "check_end"
    CHECK_FAILURE = "check_failure"


class BaseNotificationTarget(PydanticModel, frozen=True):
    """
    Base notification target model. Provides a command for sending notifications that is currently only used
    by the built-in scheduler.

    Notification functions follow a naming convention of `notify_` + NotificationEvent value.
    """

    type_: str
    notify_on: t.FrozenSet[NotificationEvent] = frozenset()

    def send(self, notification_status: NotificationStatus, msg: str, **kwargs: t.Any) -> None:
        """Sends notification with the provided message.

        Args:
            notification_status: The status of the notification. One of: success, failure, warning, info, or progress.
            msg: The message to send.
        """

    def notify_apply_start(
        self, environment: str, plan_id: str, *args: t.Any, **kwargs: t.Any
    ) -> None:
        """Notify when an apply starts.

        Args:
            environment: The target environment of the plan.
            plan_id: plan_id that is being applied.
        """
        self.send(
            NotificationStatus.INFO,
            f"Plan `{plan_id}` apply started for environment `{environment}`.",
        )

    def notify_apply_end(
        self, environment: str, plan_id: str, *args: t.Any, **kwargs: t.Any
    ) -> None:
        """Notify when an apply ends.

        Args:
            environment: The target environment of the plan.
            plan_id: plan_id that was applied.
        """
        self.send(
            NotificationStatus.SUCCESS,
            f"Plan `{plan_id}` apply finished for environment `{environment}`.",
        )

    def notify_run_start(self, environment: str, run_id: str, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify when a Vulcan run starts.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
        """
        self.send(NotificationStatus.INFO, f"Vulcan run `{run_id}` started for environment `{environment}`.")

    def notify_run_end(self, environment: str, run_id: str, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify when a Vulcan run ends.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
        """
        self.send(
            NotificationStatus.SUCCESS, f"Vulcan run `{run_id}` finished for environment `{environment}`."
        )

    def notify_run_failure(self, environment: str, run_id: str, exc: str, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify in the case of a run failure.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
            exc: The exception stack trace.
        """
        self.send(NotificationStatus.FAILURE, f"Vulcan run `{run_id}` failed for environment `{environment}`.", exc=exc)

    def notify_migration_start(self, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify when a Vulcan migration starts."""
        self.send(NotificationStatus.INFO, "Vulcan migration started.")

    def notify_migration_end(self, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify when a Vulcan migration ends."""
        self.send(NotificationStatus.SUCCESS, "Vulcan migration finished.")

    def notify_apply_failure(
        self, environment: str, plan_id: str, exc: str, *args: t.Any, **kwargs: t.Any
    ) -> None:
        """Notify in the case of an apply failure.

        Args:
            environment: The target environment of the run.
            plan_id: The plan id of the failed apply
            exc: The exception stack trace.
        """
        self.send(
            NotificationStatus.FAILURE,
            f"Plan `{plan_id}` in environment `{environment}` apply failed.",
            exc=exc,
        )

    def notify_audit_failure(self, audit_error: AuditError, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify in the case of an audit failure.

        Args:
            audit_error: The AuditError object.
        """
        self.send(NotificationStatus.FAILURE, "Audit failure.", audit_error=audit_error)

    def notify_migration_failure(self, exc: str, *args: t.Any, **kwargs: t.Any) -> None:
        """Notify in the case of a migration failure.

        Args:
            exc: The exception stack trace.
        """
        self.send(NotificationStatus.FAILURE, "Vulcan migration failed.", exc=exc)

    def notify_plan_change(
        self,
        environment: str,
        plan_id: str,
        added: int,
        modified: int,
        removed: int,
        directly_modified: t.List[str],
        downstream_affected: int,
        has_breaking_changes: bool,
        requires_backfill: bool,
        *args: t.Any,
        **kwargs: t.Any
    ) -> None:
        """Notify when a plan introduces code/data changes.
        
        Only fired when plan_diff.has_changes == True.
        
        Args:
            environment: The target environment.
            plan_id: Plan identifier.
            added: Number of new models/audits/checks added.
            modified: Number of models modified (total).
            removed: Number of models removed.
            directly_modified: List of directly modified model names (not FQN).
            downstream_affected: Number of models indirectly affected.
            has_breaking_changes: Whether plan contains breaking changes.
            requires_backfill: Whether plan requires data backfill.
        """
        # Build change summary
        total_changes = added + modified + removed
        msg = (
            f"Plan Change Applied\n"
            f"Environment: {environment} | Plan: {plan_id}\n\n"
            f"Summary: {total_changes} total changes\n"
            f"  - Added: {added}\n"
            f"  - Modified: {modified}\n"
            f"  - Removed: {removed}\n"
            f"  - Downstream affected: {downstream_affected}\n"
        )
        
        # Add directly modified models
        if directly_modified:
            msg += f"\nDirectly modified:\n"
            for model in directly_modified[:10]:
                msg += f"  - {model}\n"
            if len(directly_modified) > 10:
                msg += f"  ... and {len(directly_modified) - 10} more\n"
        
        # Add warnings for critical changes
        if has_breaking_changes:
            msg += "\n[WARNING] Breaking changes detected\n"
        
        if requires_backfill:
            msg += "[INFO] Backfills required\n"
        
        self.send(NotificationStatus.SUCCESS, msg)

    def _format_check_issues(
        self,
        title: str,
        issues_by_dimension: t.Dict[str, t.List[str]],
        indent: str = "  ",
    ) -> t.List[str]:
        """Format check issues (failures or warnings) by dimension.
        
        Args:
            title: Section title (e.g., "Failures:" or "Warnings:")
            issues_by_dimension: Dimension to list of model names.
            indent: Base indentation (default: 2 spaces). Models get double indent.
            
        Returns:
            List of formatted lines, or empty list if no issues.
        """
        if not issues_by_dimension:
            return []
        
        lines = ["", title]
        for dimension in sorted(issues_by_dimension.keys()):
            models = issues_by_dimension[dimension]
            lines.append(f"{indent}- {dimension}")
            for model in sorted(models):
                lines.append(f"{indent}{indent}→ {model}")
        
        return lines

    def notify_check_start(
        self,
        run_id: str,
        environment: str,
        model_count: int,
        *args: t.Any,
        **kwargs: t.Any
    ) -> None:
        """Notify when check execution starts.
        
        Args:
            run_id: Run identifier.
            environment: Target environment.
            model_count: Number of models with check suites.
        """
        self.send(
            NotificationStatus.INFO,
            f"Check execution started for run `{run_id}` in environment `{environment}` "
            f"({model_count} models)."
        )

    def notify_check_end(
        self,
        run_id: str,
        environment: str,
        total_checks: int,
        passed: int,
        failed: int,
        warned: int,
        not_evaluated: int,
        model_count: int,
        pass_rate: float,
        failures_by_dimension: t.Dict[str, t.List[str]],
        warnings_by_dimension: t.Dict[str, t.List[str]],
        *args: t.Any,
        **kwargs: t.Any
    ) -> None:
        """Notify when check execution completes.
        
        Args:
            run_id: Run identifier.
            environment: Target environment.
            total_checks: Total number of checks executed.
            passed: Number of passed checks.
            failed: Number of failed checks.
            warned: Number of warned checks.
            not_evaluated: Number of checks that couldn't be evaluated.
            model_count: Number of models checked.
            pass_rate: Pass rate percentage (0-100).
            failures_by_dimension: Dimension to list of failed model names.
            warnings_by_dimension: Dimension to list of warned model names.
        """
        lines = [
            "\n\n"
            "Check Execution Complete",
            f"Run: {run_id} | Environment: {environment}",
            "",
            f"Summary: {total_checks} checks executed",
            f"  - Passed: {passed}",
        ]
        
        if failed > 0:
            lines.append(f"  - Failed: {failed}")
        if warned > 0:
            lines.append(f"  - Warned: {warned}")
        if not_evaluated > 0:
            lines.append(f"  - Not evaluated: {not_evaluated}")
        
        lines.extend([
            "",
            f"Models checked: {model_count}",
            f"Score: {pass_rate:.2f}%",
        ])
        
        # Add failures and warnings by dimension
        lines.extend(self._format_check_issues("Failures:", failures_by_dimension))
        lines.extend(self._format_check_issues("Warnings:", warnings_by_dimension))
        
        # Determine status
        if failed > 0:
            status = NotificationStatus.FAILURE
        elif warned > 0:
            status = NotificationStatus.WARNING
        else:
            status = NotificationStatus.SUCCESS
        
        self.send(status, "\n".join(lines))

    def notify_check_failure(
        self,
        run_id: str,
        environment: str,
        total_checks: int,
        failed: int,
        warned: int,
        model_count: int,
        failures_by_dimension: t.Dict[str, t.List[str]],
        warnings_by_dimension: t.Dict[str, t.List[str]],
        pass_rate: float,
        *args: t.Any,
        **kwargs: t.Any
    ) -> None:
        """Notify when check execution completes with failures.
        
        Args:
            run_id: Run identifier.
            environment: Target environment.
            total_checks: Total number of checks executed.
            failed: Number of failed checks.
            warned: Number of warned checks.
            model_count: Number of models checked.
            failures_by_dimension: Dimension to list of failed model names.
            warnings_by_dimension: Dimension to list of warned model names.
            pass_rate: Pass rate percentage (0-100).
        """
        lines = [
            "\n\n"
            "Data Quality Failures",
            f"Run: {run_id} | Environment: {environment}",
            "",
            f"Summary: {total_checks} checks executed",
            f"  - Failed: {failed}",
        ]
        
        if warned > 0:
            lines.append(f"  - Warned: {warned}")
        
        lines.extend([
            "",
            f"Models checked: {model_count}",
            f"Score: {pass_rate:.2f}%",
        ])
        
        # Add failures and warnings by dimension
        lines.extend(self._format_check_issues("Failures:", failures_by_dimension))
        lines.extend(self._format_check_issues("Warnings:", warnings_by_dimension))
                
        self.send(NotificationStatus.FAILURE, "\n".join(lines))

    @property
    def is_configured(self) -> bool:
        return True


class BaseTextBasedNotificationTarget(BaseNotificationTarget):
    """
    A base class for unstructured notification targets (e.g.: console, email, etc.)
    """

    def send_text_message(self, notification_status: NotificationStatus, msg: str) -> None:
        """Send the notification message as text."""

    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        audit_error: t.Optional[AuditError] = None,
        exc: t.Optional[str] = None,
        **kwargs: t.Any,
    ) -> None:
        error = None
        if audit_error:
            error = str(audit_error)
        elif exc:
            error = exc

        self.send_text_message(notification_status, msg if error is None else f"{msg}\n{error}")


class ConsoleNotificationTarget(BaseTextBasedNotificationTarget):
    """
    Example console notification target. Keeping this around for testing purposes.
    """

    type_: t.Literal["console"] = Field(alias="type", default="console")
    _console: t.Optional[Console] = None

    @property
    def console(self) -> Console:
        if not self._console:
            self._console = get_console()
        return self._console

    def send_text_message(self, notification_status: NotificationStatus, msg: str) -> None:
        if notification_status.is_success:
            self.console.log_success(msg)
        elif notification_status.is_failure:
            self.console.log_error(msg)
        else:
            self.console.log_status_update(msg)


class BaseSlackNotificationTarget(BaseNotificationTarget):
    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        audit_error: t.Optional[AuditError] = None,
        exc: t.Optional[str] = None,
        **kwargs: t.Any,
    ) -> None:
        status_emoji = {
            NotificationStatus.PROGRESS: slack.SlackAlertIcon.START,
            NotificationStatus.SUCCESS: slack.SlackAlertIcon.SUCCESS,
            NotificationStatus.FAILURE: slack.SlackAlertIcon.FAILURE,
            NotificationStatus.WARNING: slack.SlackAlertIcon.WARNING,
            NotificationStatus.INFO: slack.SlackAlertIcon.INFO,
        }

        composed = slack.message().add_primary_blocks(
            slack.header_block(f"{status_emoji[notification_status]} Vulcan Notification"),
            slack.context_block(f"*Status:* `{notification_status.value}`"),
            slack.divider_block(),
            slack.text_section_block(f"*Message*: {msg}"),
        )

        details = []
        if audit_error:
            details = [
                slack.fields_section_block(
                    f"*Audit*: `{audit_error.audit_name}`",
                    f"*Model*: `{audit_error.model_name}`",
                    f"*Count*: `{audit_error.count}`",
                ),
                slack.preformatted_rich_text_block(audit_error.sql(pretty=True)),
            ]
        elif exc:
            details = [slack.preformatted_rich_text_block(exc)]

        composed.add_primary_blocks(
            *details,
            slack.divider_block(),
            slack.context_block(
                f"*Vulcan Version:* {_vulcan_version()}", f"*Python Version:* {sys.version}"
            ),
        )

        composed.add_text(msg)

        self._send_slack_message(
            composed=composed.slack_message,
        )

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        """Send a composed message Slack.

        Args:
            composed: the formatted message to send to Slack
        """


class SlackWebhookNotificationTarget(BaseSlackNotificationTarget):
    url: t.Optional[str] = None
    type_: t.Literal["slack_webhook"] = Field(alias="type", default="slack_webhook")
    _client: t.Optional[WebhookClient] = None

    @property
    def client(self) -> WebhookClient:
        if not self._client:
            try:
                from slack_sdk import WebhookClient
            except ModuleNotFoundError as e:
                raise MissingDependencyError(
                    "Missing Slack dependencies. Run `pip install 'vulcan[slack]'` to install them."
                ) from e

            if not self.url:
                raise ConfigError("Missing Slack webhook URL")

            self._client = WebhookClient(url=self.url)
        return self._client

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        self.client.send(
            text=composed["text"],
            blocks=composed["blocks"],
            attachments=composed["attachments"],  # type: ignore
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.url)


class SlackApiNotificationTarget(BaseSlackNotificationTarget):
    token: t.Optional[str] = None
    channel: t.Optional[str] = None
    type_: t.Literal["slack_api"] = Field(alias="type", default="slack_api")
    _client: t.Optional[WebClient] = None

    @property
    def client(self) -> WebClient:
        if not self._client:
            try:
                from slack_sdk import WebClient
            except ModuleNotFoundError as e:
                raise MissingDependencyError(
                    "Missing Slack dependencies. Run `pip install 'vulcan[slack]'` to install them."
                ) from e

            self._client = WebClient(token=self.token)
        return self._client

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        if not self.channel:
            raise ConfigError("Missing Slack channel for notification")

        self.client.chat_postMessage(
            channel=self.channel,
            text=composed["text"],
            blocks=composed["blocks"],
            attachments=composed["attachments"],  # type: ignore
        )

    @property
    def is_configured(self) -> bool:
        return all((self.token, self.channel))


class BasicSMTPNotificationTarget(BaseTextBasedNotificationTarget):
    host: t.Optional[str] = None
    port: int = 465
    user: t.Optional[str] = None
    password: t.Optional[SecretStr] = None
    sender: t.Optional[str] = None
    recipients: t.Optional[t.FrozenSet[str]] = None
    subject: t.Optional[str] = "Vulcan Notification"
    type_: t.Literal["smtp"] = Field(alias="type", default="smtp")

    def send_text_message(
        self,
        notification_status: NotificationStatus,
        msg: str,
    ) -> None:
        if not self.host:
            raise ConfigError("Missing SMTP host for notification")

        email = EmailMessage()
        email["Subject"] = self.subject
        email["To"] = ",".join(self.recipients or [])
        email["From"] = self.sender
        email.set_content(msg)
        with smtplib.SMTP_SSL(host=self.host, port=self.port) as smtp:
            if self.user and self.password:
                smtp.login(user=self.user, password=self.password.get_secret_value())
            smtp.send_message(email)

    @property
    def is_configured(self) -> bool:
        return all((self.host, self.user, self.password, self.sender))


class GenericNotificationTarget(BaseNotificationTarget):
    """A generic notification target that can be used to create custom notification targets.

    This target is not meant to be used directly, but rather as a base class for custom notification targets.

    The `send` method should be overridden to provide the actual notification functionality.

    Example:
    ```python
    class MyCustomNotificationTarget(GenericNotificationTarget):
        def send(self, notification_status: NotificationStatus, msg: str, audit_error: t.Optional[AuditError] = None, exc: t.Optional[str] = None, **kwargs: t.Any) -> None:
            error = None
            if audit_error:
                error = str(audit_error)
            elif exc:
                error = exc

            if error:
                msg = f"{error} - {msg}"
            print(f"Sending notification: {msg}")
    ```
    """

    type_: t.Literal["generic"] = Field(alias="type", default="generic")


class CloudEventsNotificationTarget(BaseNotificationTarget):
    """Notification target that forwards structured events as CloudEvents to an HTTP endpoint.

    This target intentionally ignores text formatting helpers in BaseNotificationTarget and instead
    builds a JSON payload from the notification arguments and wraps it in a CloudEvent.
    """

    url: str
    source: str = "/vulcan/notifications"
    # Optional extra HTTP headers to send with each request (e.g. auth tokens).
    # Kept as a dict for easy config authoring; __hash__ is overridden to use a hashable view.
    headers: t.Dict[str, str] = Field(default_factory=dict)
    timeout: int = 10
    type_: t.Literal["cloudevents"] = Field(alias="type", default="cloudevents")

    @property
    def is_configured(self) -> bool:
        return True

    def __hash__(self) -> int:  # type: ignore[override]
        """Custom hash so this target can be stored in sets despite dict headers."""
        return hash(
            (
                self.type_,
                self.url,
                self.source,
                self.timeout,
                frozenset(self.notify_on),
                tuple(sorted(self.headers.items())),
            )
        )

    def _emit(
        self,
        event: NotificationEvent,
        status: NotificationStatus,
        payload: t.Dict[str, t.Any],
        summary: str,
    ) -> None:
        if not self.url:
            # Misconfigured target, fail fast.
            raise ConfigError("Missing CloudEvents notification endpoint URL")

        # Import here to avoid hard dependency at module import time if unused.
        from cloudevents.conversion import to_structured
        from cloudevents.http import CloudEvent

        attributes = {
            "type": f"{event.value}",
            "source": self.source,
            "datacontenttype": "application/json",
            "time": datetime.now(timezone.utc).isoformat(),
        }

        data: t.Dict[str, t.Any] = {
            "status": status.value,
            "event": event.value,
            "summary": summary,
            "payload": payload,
        }

        cloud_event = CloudEvent(attributes, data)
        headers, body = to_structured(cloud_event)

        # Merge user-provided headers without clobbering CloudEvents-required ones.
        if self.headers:
            for key, value in self.headers.items():
                if key not in headers:
                    headers[key] = value

        # requests expects plain dict for headers and bytes for body.
        response = requests.post(self.url, data=body, headers=headers, timeout=self.timeout)
        try:
            # Reuse shared HTTP error handling logic, but keep notifications best-effort.
            raise_for_status(response)
        except ApiClientError as e:
            logger.error(
                "CloudEvents notification failed for event %s: | url: %s | status: %s | payload: %r",
                event.value,
                self.url,
                # e,
                e.code,
                payload,
            )

    # The notify_* methods below deliberately accept *args, **kwargs and use kwargs
    # as the structured payload. This keeps the mapping aligned with how Context
    # calls NotificationTargetManager.notify(...).

    def notify_apply_start(
        self,
        environment: str,
        plan_id: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "plan_id": plan_id, **kwargs}
        summary = (
            "Plan apply started\n"
            f"Environment: {environment}\n"
            f"Plan ID: {plan_id}"
        )
        self._emit(NotificationEvent.APPLY_START, NotificationStatus.INFO, payload, summary)

    def notify_apply_end(
        self,
        environment: str,
        plan_id: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "plan_id": plan_id, **kwargs}
        summary = (
            "Plan apply finished\n"
            f"Environment: {environment}\n"
            f"Plan ID: {plan_id}"
        )
        self._emit(NotificationEvent.APPLY_END, NotificationStatus.SUCCESS, payload, summary)

    def notify_run_start(
        self,
        environment: str,
        run_id: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "run_id": run_id, **kwargs}
        summary = (
            "Run started\n"
            f"Environment: {environment}"   
            f"Run ID: {run_id}"
        )
        self._emit(NotificationEvent.RUN_START, NotificationStatus.INFO, payload, summary)

    def notify_run_end(
        self,
        environment: str,
        run_id: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "run_id": run_id, **kwargs}
        summary = (
            "Run finished\n"
            f"Environment: {environment}"
            f"Run ID: {run_id}"
        )
        self._emit(NotificationEvent.RUN_END, NotificationStatus.SUCCESS, payload, summary)

    def notify_run_failure(
        self,
        environment: str,
        run_id: str,
        exc: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "run_id": run_id, "exc": exc, **kwargs}
        summary = "Run failed"
        self._emit(NotificationEvent.RUN_FAILURE, NotificationStatus.FAILURE, payload, summary)

    def notify_migration_start(
        self,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload: t.Dict[str, t.Any] = dict(**kwargs)
        summary = "Migration started"
        self._emit(NotificationEvent.MIGRATION_START, NotificationStatus.INFO, payload, summary)

    def notify_migration_end(
        self,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload: t.Dict[str, t.Any] = dict(**kwargs)
        summary = "Migration finished"
        self._emit(NotificationEvent.MIGRATION_END, NotificationStatus.SUCCESS, payload, summary)

    def notify_apply_failure(
        self,
        environment: str,
        plan_id: str,
        exc: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"environment": environment, "plan_id": plan_id, "exc": exc, **kwargs}
        summary = (
            "Plan apply failed\n"
            f"Environment: {environment}\n"
            f"Plan ID: {plan_id}"
        )
        self._emit(NotificationEvent.APPLY_FAILURE, NotificationStatus.FAILURE, payload, summary)

    def notify_audit_failure(
        self,
        audit_error: AuditError,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        # Serialize minimal audit error details for transport
        payload = {
            "audit_name": audit_error.audit_name,
            "model_name": audit_error.model_name,
            "count": audit_error.count,
            **kwargs,
        }
        summary = (
            "Audit failure\n"
            f"Audit: {audit_error.audit_name}\n"
            f"Model: {audit_error.model_name}\n"
            f"Count: {audit_error.count}"
        )
        self._emit(NotificationEvent.AUDIT_FAILURE, NotificationStatus.FAILURE, payload, summary)

    def notify_migration_failure(
        self,
        exc: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {"exc": exc, **kwargs}
        summary = "Migration failed"
        self._emit(
            NotificationEvent.MIGRATION_FAILURE, NotificationStatus.FAILURE, payload, summary
        )

    def notify_plan_change(
        self,
        environment: str,
        plan_id: str,
        added: int,
        modified: int,
        removed: int,
        directly_modified: t.List[str],
        downstream_affected: int,
        has_breaking_changes: bool,
        requires_backfill: bool,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {
            "environment": environment,
            "plan_id": plan_id,
            "added": added,
            "modified": modified,
            "removed": removed,
            "directly_modified": directly_modified,
            "downstream_affected": downstream_affected,
            "has_breaking_changes": has_breaking_changes,
            "requires_backfill": requires_backfill,
            **kwargs,
        }
        summary = (
            "Plan change detected\n"
            f"Environment: {environment}\n"
            f"Plan ID: {plan_id}\n"
            f"Added: {added}\n"
            f"Modified: {modified}\n"
            f"Removed: {removed}\n"
            f"Downstream affected: {downstream_affected}\n"
            f"Breaking changes: {bool(has_breaking_changes)}\n"
            f"Requires backfill: {bool(requires_backfill)}"
        )
        self._emit(NotificationEvent.PLAN_CHANGE, NotificationStatus.SUCCESS, payload, summary)

    def notify_check_start(
        self,
        run_id: str,
        environment: str,
        model_count: int,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {
            "run_id": run_id,
            "environment": environment,
            "model_count": model_count,
            **kwargs,
        }
        summary = (
            "Checks started\n"
            f"Environment: {environment}\n"
            f"Run ID: {run_id}\n"
            f"Models: {model_count}"
        )
        self._emit(NotificationEvent.CHECK_START, NotificationStatus.INFO, payload, summary)

    def notify_check_end(
        self,
        run_id: str,
        environment: str,
        total_checks: int,
        passed: int,
        failed: int,
        warned: int,
        not_evaluated: int,
        model_count: int,
        pass_rate: float,
        failures_by_dimension: t.Dict[str, t.List[str]],
        warnings_by_dimension: t.Dict[str, t.List[str]],
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {
            "run_id": run_id,
            "environment": environment,
            "total_checks": total_checks,
            "passed": passed,
            "failed": failed,
            "warned": warned,
            "not_evaluated": not_evaluated,
            "model_count": model_count,
            "pass_rate": pass_rate,
            "failures_by_dimension": failures_by_dimension,
            "warnings_by_dimension": warnings_by_dimension,
            **kwargs,
        }
        # Status mirrors text-based target semantics.
        if failed > 0:
            status = NotificationStatus.FAILURE
        elif warned > 0:
            status = NotificationStatus.WARNING
        else:
            status = NotificationStatus.SUCCESS

        summary = (
            "Check execution complete\n"
            f"Environment: {environment}\n"
            f"Run ID: {run_id}\n"
            f"Total checks: {total_checks}\n"
            f"Passed: {passed}\n"
            f"Failed: {failed}\n"
            f"Warned: {warned}\n"
            f"Not evaluated: {not_evaluated}\n"
            f"Score: {pass_rate:.2f}%"
        )
        self._emit(NotificationEvent.CHECK_END, status, payload, summary)

    def notify_check_failure(
        self,
        run_id: str,
        environment: str,
        total_checks: int,
        failed: int,
        warned: int,
        model_count: int,
        failures_by_dimension: t.Dict[str, t.List[str]],
        warnings_by_dimension: t.Dict[str, t.List[str]],
        pass_rate: float,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        payload = {
            "run_id": run_id,
            "environment": environment,
            "total_checks": total_checks,
            "failed": failed,
            "warned": warned,
            "model_count": model_count,
            "failures_by_dimension": failures_by_dimension,
            "warnings_by_dimension": warnings_by_dimension,
            "pass_rate": pass_rate,
            **kwargs,
        }
        summary = (
            "Check failures\n"
            f"Environment: {environment}\n"
            f"Run ID: {run_id}\n"
            f"Total checks: {total_checks}\n"
            f"Failed: {failed}\n"
            f"Warned: {warned}\n"
            f"Score: {pass_rate:.2f}%"
        )
        self._emit(
            NotificationEvent.CHECK_FAILURE,
            NotificationStatus.FAILURE,
            payload,
            summary,
        )


NotificationTarget = t.Annotated[
    t.Union[
        BasicSMTPNotificationTarget,
        GenericNotificationTarget,
        ConsoleNotificationTarget,
        SlackApiNotificationTarget,
        SlackWebhookNotificationTarget,
        CloudEventsNotificationTarget,
    ],
    Field(discriminator="type_"),
]


class NotificationTargetManager:
    """Wrapper around a list of notification targets.

    Calling a notification target's "notify_" method on this object will call it
    on all registered notification targets.
    """

    def __init__(
        self,
        notification_targets: t.Dict[NotificationEvent, t.Set[NotificationTarget]] | None = None,
        user_notification_targets: t.Dict[str, t.Set[NotificationTarget]] | None = None,
        username: str | None = None,
    ) -> None:
        self.notification_targets = notification_targets or {}
        self.user_notification_targets = user_notification_targets or {}
        self.username = username

    def notify(self, event: NotificationEvent, *args: t.Any, **kwargs: t.Any) -> None:
        """Call the 'notify_`event`' function of all notification targets that care about the event."""
        if self.username:
            self.notify_user(event, self.username, *args, **kwargs)
        else:
            for notification_target in self.notification_targets.get(event, set()):
                notify_func = self._get_notification_function(notification_target, event)
                notify_func(*args, **kwargs)

    def notify_user(
        self, event: NotificationEvent, username: str, *args: t.Any, **kwargs: t.Any
    ) -> None:
        """Call the 'notify_`event`' function of the user's notification targets that care about the event."""
        notification_targets = self.user_notification_targets.get(username, set())
        for notification_target in notification_targets:
            if event in notification_target.notify_on:
                notify_func = self._get_notification_function(notification_target, event)
                notify_func(*args, **kwargs)

    def _get_notification_function(
        self, notification_target: NotificationTarget, event: NotificationEvent
    ) -> t.Callable:
        """Fetch the function for a notification event"""
        return getattr(notification_target, f"notify_{event.value}")
