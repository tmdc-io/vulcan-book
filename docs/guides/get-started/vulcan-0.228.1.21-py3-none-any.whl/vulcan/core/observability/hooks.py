from __future__ import annotations

import typing as t

from vulcan.core.observability.facade import (
    emit_activity_event_metrics,
    emit_audit_metrics,
    emit_backfill_metrics,
    emit_plan_metrics,
    emit_run_metrics,
    emit_scheduler_metrics,
    emit_snapshot_env_metrics,
    emit_test_metrics,
    initialize_base_labels,
)
from vulcan.core.runtime_hooks import set_runtime_hooks


class ObservabilityRuntimeHooks:
    def initialize(self, config: t.Any) -> None:
        initialize_base_labels(config)

    def on_plan_metrics(
        self,
        plan_activity: t.Any,
        plan: t.Any,
        config: t.Any,
        snapshots: t.Any,
    ) -> None:
        emit_plan_metrics(plan_activity, plan, config, snapshots)

    def on_run_metrics(self, run_activity: t.Any, config: t.Any) -> None:
        emit_run_metrics(run_activity, config)

    def on_test_metrics(
        self,
        result: t.Any,
        config: t.Any,
        environment: str,
        total_models: int,
        models_with_tests: int,
    ) -> None:
        emit_test_metrics(result, config, environment, total_models, models_with_tests)

    def on_snapshot_env_metrics(
        self,
        config: t.Any,
        snapshot_count: int,
        environment_count: int,
        environment: str,
    ) -> None:
        emit_snapshot_env_metrics(config, snapshot_count, environment_count, environment)

    def on_scheduler_metrics(
        self,
        config: t.Any,
        environment: str,
        queue_depth: int,
        model_lags: t.Optional[t.Dict[str, float]] = None,
        snapshots: t.Any = None,
        get_max_interval_end_per_model: t.Optional[t.Callable] = None,
    ) -> None:
        emit_scheduler_metrics(
            config,
            environment,
            queue_depth,
            model_lags=model_lags,
            snapshots=snapshots,
            get_max_interval_end_per_model=get_max_interval_end_per_model,
        )

    def on_activity_event_metrics(self, config: t.Any, event_type: str, success: bool) -> None:
        emit_activity_event_metrics(config, event_type, success)

    def on_backfill_metrics(self, stage: t.Any, plan: t.Any) -> None:
        emit_backfill_metrics(stage, plan)

    def on_audit_metrics(
        self,
        audit_results: t.Any,
        snapshot: t.Any,
        environment: str,
        has_blocking_errors: bool = False,
    ) -> None:
        emit_audit_metrics(
            audit_results,
            snapshot,
            environment,
            has_blocking_errors=has_blocking_errors,
        )


def register_observability_hooks() -> None:
    set_runtime_hooks(ObservabilityRuntimeHooks())
