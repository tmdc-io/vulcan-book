"""Pushgateway integration.

Environment variables (all optional; safe defaults + bounded parsing):

- ``PUSHGATEWAY_URL``               Target Pushgateway. Unset or empty = disabled.
- ``PUSHGATEWAY_PUSH_TIMEOUT_S``    Push-side urlopen timeout. Default 2.0 s.
                                    Clamped to [0.1, 30.0]. Malformed values
                                    are logged (WARNING) and ignored.
- ``PUSHGATEWAY_FETCH_TIMEOUT_S``   Fetch-side urlopen timeout. Same default
                                    and bounds as the push-side.

Deprecated aliases (honored for one release, then removed):

- ``PUSHGATEWAY_TIMEOUT_S`` -> ``PUSHGATEWAY_PUSH_TIMEOUT_S``

Operators that set a deprecated name will see a one-time WARNING at module
import pointing them at the new name. The bounds are safety rails, not tuning
knobs: values below 0.1 s are effectively always-timeout and values above
30.0 s reintroduce the long event-loop freeze the clamp was introduced to
prevent.

Pusher lifecycle
----------------
``start_metrics_pusher`` returns a daemon ``Thread`` whose loop sleeps on a
``threading.Event``, not ``time.sleep``.  Lifespan/teardown code calls
``stop_metrics_pusher()`` (no args) to signal every pusher to exit and join
each one within the configured timeout (default 5 s), so SIGTERM never sits
blocked on the next ``max_backoff`` interval (up to 60 s under a dead
gateway).  Targeted shutdown is supported by passing the specific
``Thread`` returned from ``start_metrics_pusher``.
"""

import atexit
import os
import logging
import threading
import urllib.request
import typing as t

logger = logging.getLogger(__name__)

try:
    from prometheus_client import CollectorRegistry, pushadd_to_gateway
    from prometheus_client.exposition import default_handler as _prom_default_handler

    _PROM_AVAILABLE = True
except Exception as ex:
    CollectorRegistry = None
    pushadd_to_gateway = None
    _prom_default_handler = None
    _PROM_AVAILABLE = False
    logger.warning("prometheus_client unavailable — metrics disabled: %s", ex)

PUSHGATEWAY_URL = os.getenv("PUSHGATEWAY_URL")

# Bounded timeouts so a dead Pushgateway can never stall a caller for 30s+.
# Override via env for environments with a legitimately slow gateway; see the
# module docstring above for the exact env var names, defaults, and bounds.
_PUSH_TIMEOUT_FLOOR_S = 0.1
_PUSH_TIMEOUT_CEILING_S = 30.0
_PUSH_TIMEOUT_DEFAULT_S = 2.0


def _parse_timeout_env(
    name: str,
    default: float,
    *,
    deprecated_aliases: t.Tuple[str, ...] = (),
    floor: float = _PUSH_TIMEOUT_FLOOR_S,
    ceiling: float = _PUSH_TIMEOUT_CEILING_S,
) -> float:
    """Parse a Pushgateway timeout env var without ever raising.

    Bounds keep the caller safe from two failure modes: a too-small value that
    guarantees timeouts under normal latency, and a too-large value that
    re-introduces the event-loop freeze this timeout was introduced to
    prevent. Malformed values fall back to ``default`` with a WARNING so a
    misconfigured Helm template cannot crash-loop the pod on a metric knob.

    If ``name`` is unset or empty, each entry in ``deprecated_aliases`` is
    checked in order and honored with a WARNING pointing operators at the
    current name.  If both ``name`` and an alias are set, ``name`` wins and a
    WARNING flags that the alias is ignored.
    """
    resolved_name = name
    raw = os.getenv(name)
    name_is_empty = raw is None or raw.strip() == ""

    if name_is_empty:
        for alias in deprecated_aliases:
            alias_raw = os.getenv(alias)
            if alias_raw is not None and alias_raw.strip() != "":
                logger.warning(
                    "%s is deprecated; use %s instead.",
                    alias,
                    name,
                )
                resolved_name = alias
                raw = alias_raw
                break
    else:
        for alias in deprecated_aliases:
            alias_raw = os.getenv(alias)
            if alias_raw is not None and alias_raw.strip() != "":
                logger.warning(
                    "Both %s and %s are set; %s takes precedence and %s is ignored.",
                    name,
                    alias,
                    name,
                    alias,
                )

    if raw is None or raw.strip() == "":
        return default

    try:
        value = float(raw.strip())
    except ValueError:
        logger.warning(
            "Invalid %s=%r; using default %.2fs. Must be a number.",
            resolved_name,
            raw,
            default,
        )
        return default

    if value < floor:
        logger.warning(
            "%s=%.3fs is below floor %.2fs; clamping.",
            resolved_name,
            value,
            floor,
        )
        return floor
    if value > ceiling:
        logger.warning(
            "%s=%.3fs is above ceiling %.2fs; clamping to preserve event-loop safety.",
            resolved_name,
            value,
            ceiling,
        )
        return ceiling
    return value


_PUSH_TIMEOUT_S = _parse_timeout_env(
    "PUSHGATEWAY_PUSH_TIMEOUT_S",
    _PUSH_TIMEOUT_DEFAULT_S,
    deprecated_aliases=("PUSHGATEWAY_TIMEOUT_S",),  # deprecated alias, remove in vNEXT
)
_FETCH_TIMEOUT_S = _parse_timeout_env(
    "PUSHGATEWAY_FETCH_TIMEOUT_S",
    _PUSH_TIMEOUT_DEFAULT_S,
)


def _bounded_push_handler(url, method, timeout, headers, data):
    """Clamp prometheus_client's 30s default push timeout to _PUSH_TIMEOUT_S.

    prometheus_client's ``default_handler`` returns a zero-arg callable that
    executes the HTTP request when invoked by ``pushadd_to_gateway``.  We
    intercept the handler only to override the ``timeout`` argument so a dead
    Pushgateway can never block the calling thread for the prom library's
    default 30 seconds.
    """
    if _prom_default_handler is None:
        raise RuntimeError("prometheus_client not available")
    return _prom_default_handler(url, method, _PUSH_TIMEOUT_S, headers, data)


registry: t.Any = CollectorRegistry() if _PROM_AVAILABLE and CollectorRegistry is not None else None

_cached_values: t.Dict[str, float] = {}
_cache_lock = threading.Lock()

_tenant: t.Optional[str] = None
_data_product: t.Optional[str] = None


def set_base_labels(tenant: str, data_product: str) -> None:
    """Set tenant/data_product used by all metric recording functions.

    Call once at process startup (from context.py or api/main.py).
    """
    global _tenant, _data_product
    _tenant = tenant
    _data_product = data_product


def get_base_labels() -> t.Dict[str, str]:
    """Return ``{"tenant": ..., "data_product": ...}`` for metric labelling."""
    if not _tenant:
        raise RuntimeError("Prometheus base labels are unset: tenant was not initialized")
    if not _data_product:
        raise RuntimeError("Prometheus base labels are unset: data_product was not initialized")
    return {"tenant": _tenant, "data_product": _data_product}


# Job name isolates Workflow and API server pushes on the Pushgateway so they
# never overwrite each other's metric families.  Set via set_job().
_job: str = "vulcan-workflow"

_VERSION = os.getenv("VULCAN_VERSION", "latest")

_REQUIRED_GROUPING_ENV = [
    "DATAOS_RESOURCE_ID",
    "DATAOS_RESOURCE_NAME",
    "DATAOS_TYPE",
    "DATAOS_TENANT_ID",
    "DATAOS_INSTANCE_TENANT_ID",
    "DATAOS_FQDN",
    "DATAOS_RUN_AS_USER",
]

_grouping_key: t.Dict[str, str] = {}
_grouping_key_initialized = False
_shutdown_handlers_registered = False


def set_job(name: str) -> None:
    """Set the Pushgateway job name for this process (e.g. 'vulcan-api')."""
    global _job
    _job = name


def get_job() -> str:
    return _job


def set_grouping_key(key: str, value: str) -> None:
    """Override a grouping key field (e.g. for tests or custom deployments)."""
    global _grouping_key_initialized
    _grouping_key[key] = value
    _grouping_key_initialized = True


def get_grouping_key() -> t.Dict[str, str]:
    _initialize_grouping_key()
    return dict(_grouping_key)


def is_enabled() -> bool:
    return _PROM_AVAILABLE and bool(PUSHGATEWAY_URL)


def _initialize_grouping_key() -> bool:
    global _grouping_key_initialized

    if _grouping_key_initialized or not PUSHGATEWAY_URL:
        return bool(_grouping_key or not PUSHGATEWAY_URL)

    missing = [k for k in _REQUIRED_GROUPING_ENV if not os.getenv(k)]
    if missing:
        logger.warning(
            "Pushgateway grouping key incomplete; metrics push disabled until env vars are set: %s",
            missing,
        )
        return False

    _grouping_key.update(
        {
            "instance": os.environ.get("DATAOS_RESOURCE_ID"),
            "stack_name": "vulcan",
            "stack_version": _VERSION,
            "resource_id": os.environ.get("DATAOS_RESOURCE_ID"),
            "resource_type": os.environ.get("DATAOS_TYPE"),
            "tenant_name": os.environ.get("DATAOS_TENANT_ID"),
            "instance_name": os.environ.get("DATAOS_INSTANCE_TENANT_ID"),
            "dataplane_name": os.environ.get("DATAOS_FQDN"),
            "user_name": os.environ.get("DATAOS_RUN_AS_USER"),
        }
    )
    _grouping_key_initialized = True
    return True


def _flush_on_shutdown() -> None:
    """Flush metrics to Pushgateway during normal process exit."""
    if is_enabled():
        logger.info("Flushing metrics to Pushgateway before shutdown...")
        push_metrics()


def _register_shutdown_handlers() -> None:
    global _shutdown_handlers_registered
    if _shutdown_handlers_registered or not is_enabled():
        return
    atexit.register(_flush_on_shutdown)
    _shutdown_handlers_registered = True


def _fetch_current_values() -> None:
    """Read current metric values from Pushgateway into cache.

    Only caches lines belonging to this process's job + grouping key so that
    different deployments/users/processes don't interfere with each other.
    """
    if not is_enabled() or not _initialize_grouping_key():
        return

    fetched_values: t.Dict[str, float] = {}
    try:
        req = urllib.request.Request(f"{PUSHGATEWAY_URL}/metrics")
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT_S) as resp:
            filters = [f'job="{_job}"'] + [f'{k}="{v}"' for k, v in _grouping_key.items()]
            for line in resp.read().decode().splitlines():
                if line.startswith("#") or not line.strip():
                    continue
                parts = line.rsplit(" ", 1)
                if len(parts) == 2 and all(f in parts[0] for f in filters):
                    fetched_values[parts[0]] = float(parts[1])
    except Exception:
        pass
    with _cache_lock:
        _cached_values.clear()
        _cached_values.update(fetched_values)


def _build_cache_key(metric_name: str, labels: t.Dict[str, str]) -> str:
    """Build the Pushgateway-style cache key for a counter metric."""
    sorted_labels = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
    return f"{metric_name}_total{{{sorted_labels}}}"


def get_previous_value(metric_name: str, labels: t.Dict[str, str]) -> float:
    """Get the previous value of a metric from Pushgateway.

    Call _fetch_current_values() once before using this in a batch.
    """
    with _cache_lock:
        for cached_key, value in _cached_values.items():
            if metric_name in cached_key and all(
                f'{k}="{v}"' in cached_key for k, v in labels.items()
            ):
                if "_total{" in cached_key or (
                    cached_key.startswith(metric_name + "{")
                    and "_bucket" not in cached_key
                    and "_sum" not in cached_key
                    and "_count" not in cached_key
                    and "_created" not in cached_key
                ):
                    return value
    return 0.0


def update_cached_value(metric_name: str, labels: t.Dict[str, str], new_value: float) -> None:
    """Write the new counter value back to the local cache.

    This ensures that a subsequent _inc_counter call for the same
    metric+labels within the same batch reads the updated value
    instead of the stale one fetched at _begin_batch() time.
    """
    with _cache_lock:
        for cached_key in list(_cached_values.keys()):
            if metric_name in cached_key and all(
                f'{k}="{v}"' in cached_key for k, v in labels.items()
            ):
                if "_total{" in cached_key or (
                    cached_key.startswith(metric_name + "{")
                    and "_bucket" not in cached_key
                    and "_sum" not in cached_key
                    and "_count" not in cached_key
                    and "_created" not in cached_key
                ):
                    _cached_values[cached_key] = new_value
                    return
        _cached_values[_build_cache_key(metric_name, labels)] = new_value


def reserve_counter_value(metric_name: str, labels: t.Dict[str, str], amount: int = 1) -> float:
    """Atomically reserve the next counter value in the local cache."""
    with _cache_lock:
        prev = 0.0
        for cached_key, value in _cached_values.items():
            if metric_name in cached_key and all(
                f'{k}="{v}"' in cached_key for k, v in labels.items()
            ):
                if "_total{" in cached_key or (
                    cached_key.startswith(metric_name + "{")
                    and "_bucket" not in cached_key
                    and "_sum" not in cached_key
                    and "_count" not in cached_key
                    and "_created" not in cached_key
                ):
                    prev = value
                    break
        new_value = prev + amount
        update_key = None
        for cached_key in list(_cached_values.keys()):
            if metric_name in cached_key and all(
                f'{k}="{v}"' in cached_key for k, v in labels.items()
            ):
                if "_total{" in cached_key or (
                    cached_key.startswith(metric_name + "{")
                    and "_bucket" not in cached_key
                    and "_sum" not in cached_key
                    and "_count" not in cached_key
                    and "_created" not in cached_key
                ):
                    update_key = cached_key
                    break
        if update_key is not None:
            _cached_values[update_key] = new_value
        else:
            _cached_values[_build_cache_key(metric_name, labels)] = new_value
        return new_value


def push_metrics() -> bool:
    """Push all registered metrics to Pushgateway using pushadd (merge, not replace)."""
    if not is_enabled():
        return False
    if not _initialize_grouping_key():
        return False
    _register_shutdown_handlers()
    try:
        pushadd_to_gateway(
            PUSHGATEWAY_URL,
            job=_job,
            registry=registry,
            grouping_key=_grouping_key,
            handler=_bounded_push_handler,
        )
        logger.debug(f"Pushed metrics to Pushgateway ({PUSHGATEWAY_URL}, job={_job})")
        return True
    except Exception as e:
        logger.warning(f"Metrics push failed: {e}")
        return False


# Live pusher threads paired with the ``threading.Event`` that signals each
# loop to exit.  Tracked at module level so :func:`stop_metrics_pusher` can
# stop pushers without the caller having to remember the thread reference,
# while still supporting per-thread shutdown for tests that start more than
# one pusher.  Mutated only under ``_pushers_lock``.
_pushers: t.List[t.Tuple[threading.Thread, threading.Event]] = []
_pushers_lock = threading.Lock()


def start_metrics_pusher(interval: int = 10) -> threading.Thread:
    """Start a daemon thread that pushes metrics every ``interval`` seconds.

    Used by long-running processes (API server) so that in-memory metric
    updates are periodically flushed to Pushgateway without explicit push
    calls at every instrumentation site.

    The pusher uses an interruptible ``threading.Event.wait`` between
    attempts so the lifespan can shut it down cleanly via
    :func:`stop_metrics_pusher` instead of waiting up to ``max_backoff``
    seconds (60 s by default) for the next ``time.sleep`` to elapse.
    Without this, SIGTERM could sit blocked on the daemon thread long
    enough for Kubernetes to escalate to SIGKILL and lose any in-flight
    work the rest of lifespan was still draining.

    Returns the live ``Thread``; pass it to :func:`stop_metrics_pusher`
    for targeted shutdown, or call ``stop_metrics_pusher()`` with no
    argument to stop every pusher this process started.
    """

    _register_shutdown_handlers()

    shutdown_event = threading.Event()

    def _push_loop() -> None:
        # Initial backoff equals ``interval`` so a single failed push waits
        # the same as a healthy cadence; subsequent failures double up to
        # ``max_backoff`` to bound CPU and Pushgateway load under outage.
        backoff = float(interval)
        max_backoff = max(float(interval) * 12, 60.0)
        while not shutdown_event.is_set():
            ok = push_metrics()
            if ok:
                wait_s = float(interval)
                backoff = float(interval)
            else:
                wait_s = backoff
                backoff = min(backoff * 2.0, max_backoff)
            # ``Event.wait`` returns True the moment shutdown is signalled,
            # bounding teardown latency to the OS scheduler regardless of
            # how long ``wait_s`` would have been.
            if shutdown_event.wait(timeout=wait_s):
                break

    t_thread = threading.Thread(target=_push_loop, daemon=True, name="VulcanMetricsPusher")
    with _pushers_lock:
        _pushers.append((t_thread, shutdown_event))
    t_thread.start()
    logger.info("Started background metrics pusher (interval=%ds)", interval)
    return t_thread


def stop_metrics_pusher(
    thread: t.Optional[threading.Thread] = None,
    *,
    timeout: float = 5.0,
) -> bool:
    """Signal pusher thread(s) to exit and wait up to ``timeout`` for join.

    Args:
        thread: If provided, stop only that pusher.  When ``None`` (default),
            stop every pusher started in this process.
        timeout: Per-thread join timeout in seconds.  Shutdown events are
            signalled before any join is awaited, so targeted pushers wake in
            parallel, but the join loop may still wait up to ``timeout`` per
            thread if one or more pushers fail to exit promptly.

    Returns:
        ``True`` when every targeted pusher exited within the timeout;
        ``False`` if any thread is still alive (treat as best-effort —
        daemon threads die with the process, but a stuck pusher worth
        warning about).

    Idempotent and safe to call from teardown chains: a pusher that has
    already exited (or whose ``stop`` was previously called) is a no-op.
    Concurrent calls race for the registry under ``_pushers_lock`` so
    each thread is signalled exactly once; subsequent ``stop`` calls
    simply find an empty registry and return ``True``.
    """
    with _pushers_lock:
        if thread is None:
            targets = list(_pushers)
            _pushers.clear()
        else:
            targets = [(t_thread, evt) for t_thread, evt in _pushers if t_thread is thread]
            _pushers[:] = [(t_thread, evt) for t_thread, evt in _pushers if t_thread is not thread]

    # Phase 1: signal every shutdown event so wait()s wake up immediately.
    # Done outside the join phase so multiple pushers can wake in parallel.
    for _t_thread, evt in targets:
        evt.set()

    # Phase 2: bounded join.  Waiting at most ``timeout`` per thread keeps
    # the total shutdown cost within the operator-visible budget.
    all_exited = True
    for t_thread, _evt in targets:
        t_thread.join(timeout=timeout)
        if t_thread.is_alive():
            logger.warning(
                "VulcanMetricsPusher %r did not exit within %.1fs of stop signal",
                t_thread.name,
                timeout,
            )
            all_exited = False

    return all_exited


async def start_queue_depth_poller(
    queue_manager: t.Any,
    tenant: str,
    data_product: str,
    interval: int = 10,
) -> None:
    """Async loop that polls PGQueuer queue depth and records the gauge.

    Meant to be launched as an ``asyncio.create_task`` from the API server
    lifespan.  Falls back to entrypoint name ``query_execution`` when the
    registry is empty (worker hasn't registered yet).

    Args:
        queue_manager: PGQueuer ``QueueManager`` instance.
        tenant: Prometheus ``tenant`` label value.
        data_product: Prometheus ``data_product`` label value.
        interval: Seconds between polls (default 10, aligned with pusher).
    """
    import asyncio

    while True:
        try:
            eps = list(queue_manager.entrypoint_registry.keys()) or ["query_execution"]
            for ep in eps:
                try:
                    depth = await queue_manager.queries.queued_work([ep])
                except Exception:
                    depth = 0
                try:
                    from vulcan.core.observability.recorder import record_query_queue_depth

                    record_query_queue_depth(
                        tenant=tenant,
                        data_product=data_product,
                        entrypoint=ep,
                        depth=depth,
                    )
                except Exception:
                    pass
        except Exception as e:
            logger.debug(f"Queue depth poll failed: {e}")

        await asyncio.sleep(interval)
