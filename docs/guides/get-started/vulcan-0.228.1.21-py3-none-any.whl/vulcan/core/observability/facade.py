"""Thin facade that accepts raw domain objects from core code and records metrics.

Core files (context.py, evaluator.py, scheduler.py) call exactly one function
from this module.  All data extraction, formatting, and metric manipulation is
encapsulated here so that the observability footprint in core files is a single
try/except line — making upstream Vulcan merges trivial.

Submit-side bounding
--------------------
When the Pushgateway is dead or slow, every ``emit_*`` call queues a task on
``_METRICS_EXECUTOR``.  Without a cap, the executor's internal queue grows
without bound — a slow memory leak we observed in prod during Pushgateway
outages.  A ``threading.BoundedSemaphore`` guards ``submit`` so the executor
holds at most ``VULCAN_METRICS_QUEUE_MAX`` outstanding tasks (default 256);
additional submits increment ``_DROPPED_COUNT`` and log a rate-limited
WARNING.  The slot is released inside ``_safe_run`` on both success and
failure paths.
"""

import asyncio
import logging
import os
import threading
import typing as t
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)


# Bounded-submit knobs.  Defaults are sized for a bursty metric emit rate
# under a broken gateway: 256 outstanding tasks absorbs ~2 minutes of
# normal emit traffic at the clamped 2 s push timeout before we start
# dropping.  Malformed / out-of-range values fall back to the default with
# a WARNING (see ``_parse_positive_int_env`` below).
_METRICS_QUEUE_FLOOR = 8
_METRICS_QUEUE_CEILING = 4096
_METRICS_QUEUE_DEFAULT = 256


def _parse_positive_int_env(
    name: str,
    *,
    default: int,
    floor: int,
    ceiling: int,
) -> int:
    """Minimal int-env parser.

    Local to this module so ``vulcan/core/observability/`` stays self-
    contained; the broader ``_parse_*_env`` consolidation with
    :mod:`api.utils.env` is tracked as a separate cleanup plan.
    """
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = int(raw.strip())
    except ValueError:
        logger.warning("Invalid %s=%r; using default %d.", name, raw, default)
        return default
    if value < floor:
        logger.warning("%s=%d below floor %d; clamping.", name, value, floor)
        return floor
    if value > ceiling:
        logger.warning("%s=%d above ceiling %d; clamping.", name, value, ceiling)
        return ceiling
    return value


_METRICS_QUEUE_MAX = _parse_positive_int_env(
    "VULCAN_METRICS_QUEUE_MAX",
    default=_METRICS_QUEUE_DEFAULT,
    floor=_METRICS_QUEUE_FLOOR,
    ceiling=_METRICS_QUEUE_CEILING,
)

# Dedicated, small thread pool for pushing metrics so that async hot-path
# emits (auth middleware, query endpoints) never block the event loop on
# Pushgateway HTTP round-trips.  Size is intentionally small: metric pushes
# are cheap, bounded by ``PUSHGATEWAY_PUSH_TIMEOUT_S`` (see push_gateway.py), and
# under a broken gateway we prefer to drop pushes rather than queue threads.
_METRICS_EXECUTOR: t.Optional[ThreadPoolExecutor] = None

# Bounded submit-slot counter.  ``_offload`` acquires non-blocking; every
# successful acquire must be paired with a release inside ``_safe_run``.
_SUBMIT_SLOTS = threading.BoundedSemaphore(value=_METRICS_QUEUE_MAX)

# Monotonic drop counter, exposed via ``get_metrics_drop_count`` for the
# future ``/_internal/debug/runtime`` endpoint.  Drops are logged at WARNING
# level but rate-limited so a dead gateway does not flood the logs.
_DROPPED_LOCK = threading.Lock()
_DROPPED_COUNT = 0
_DROP_LOG_STRIDE = 256


def _get_metrics_executor() -> ThreadPoolExecutor:
    global _METRICS_EXECUTOR
    if _METRICS_EXECUTOR is None:
        _METRICS_EXECUTOR = ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix="VulcanMetricsEmit",
        )
    return _METRICS_EXECUTOR


def get_metrics_drop_count() -> int:
    """Return the total number of metric emits dropped due to submit saturation.

    Exposed for the future ``/_internal/debug/runtime`` endpoint and used by
    tests to assert the drop path was exercised.  Safe to call from any
    thread.
    """
    with _DROPPED_LOCK:
        return _DROPPED_COUNT


def _record_drop(fn_name: str) -> None:
    """Increment the drop counter and emit a rate-limited WARNING.

    We log at drop #1 (so operators see the first symptom promptly) and then
    at every ``_DROP_LOG_STRIDE`` multiple, matching the plan's "rate-limit
    to avoid log flood under a dead gateway" requirement.

    The log format is operator-visible and asserted by
    ``test_record_drop_logs_with_canonical_format``; do not change wording
    without updating that test.
    """
    global _DROPPED_COUNT
    with _DROPPED_LOCK:
        _DROPPED_COUNT += 1
        count = _DROPPED_COUNT
    if count == 1 or count % _DROP_LOG_STRIDE == 0:
        logger.warning(
            "Metrics emit queue saturated (%d total drops); dropping %s.",
            count,
            fn_name,
        )


def _offload(fn: t.Callable[..., None], *args: t.Any, **kwargs: t.Any) -> None:
    """Run *fn* without blocking the current asyncio event loop.

    If called from a running event loop, submit the work to the dedicated
    metrics thread pool (fire-and-forget).  Otherwise run inline so that
    synchronous callers (CLI, workers) preserve existing behaviour.

    The submit side is guarded by a bounded semaphore.  When the queue is
    saturated (e.g. under a dead Pushgateway) the emit is dropped rather
    than queued, preventing unbounded memory growth in the executor's work
    queue.

    Exceptions raised by *fn* are swallowed here — metric emission must never
    impact business logic.  Submissions beyond ``VULCAN_METRICS_QUEUE_MAX``
    in flight are dropped (rate-limited WARNING) to bound memory under a dead
    Pushgateway.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        try:
            fn(*args, **kwargs)
        except Exception as e:
            logger.debug(f"Metrics emit failed ({fn.__name__}): {e}")
        return

    if not _SUBMIT_SLOTS.acquire(blocking=False):
        _record_drop(fn.__name__)
        return

    try:
        _get_metrics_executor().submit(_safe_run, fn, args, kwargs)
    except Exception as e:
        # ``submit`` itself failed (executor shut down etc.); release the slot
        # so the drop counter is not falsely inflated by a genuine submit
        # error.
        _SUBMIT_SLOTS.release()
        logger.debug(f"Failed to offload metrics emit ({fn.__name__}): {e}")


def _safe_run(fn: t.Callable[..., None], args: tuple, kwargs: dict) -> None:
    try:
        fn(*args, **kwargs)
    except Exception as e:
        logger.debug(f"Metrics emit failed in thread ({fn.__name__}): {e}")
    finally:
        # Pair every acquire with exactly one release.  Wrapping in a
        # try/except guards against a double-release if a future refactor
        # accidentally releases elsewhere.
        try:
            _SUBMIT_SLOTS.release()
        except ValueError:
            logger.debug("Metrics submit slot released more than once")


def shutdown_metrics_executor() -> None:
    """Stop the metrics executor; called from the API lifespan on shutdown."""
    global _METRICS_EXECUTOR
    if _METRICS_EXECUTOR is not None:
        try:
            _METRICS_EXECUTOR.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        _METRICS_EXECUTOR = None


def initialize_base_labels(config: t.Any) -> None:
    """Initialize shared observability labels from the caller's config."""
    from vulcan.core.observability.push_gateway import set_base_labels

    set_base_labels(
        getattr(config, "tenant", None) or "",
        getattr(config, "project", None) or "",
    )


def _classify_gateway_error(error: Exception) -> str:
    error_name = type(error).__name__.lower()
    if "timeout" in error_name:
        return "timeout"
    if "connection" in error_name:
        return "connection"
    if "permission" in error_name or "auth" in error_name:
        return "auth"
    if "operational" in error_name:
        return "operational"
    if "database" in error_name or "sql" in error_name:
        return "database"
    return "unknown"


def emit_plan_metrics(
    plan_activity: t.Any,
    plan: t.Any,
    config: t.Any,
    snapshots: t.Any,
) -> None:
    """Extract plan data and record plan + virtual-update metrics.

    Called from context.py after a plan is applied. Handles both
    record_plan and record_virtual_update in a single call.

    Primitives are captured on the caller thread; only scalars cross the
    thread boundary when dispatched via ``_offload``.
    """
    try:
        if plan.restatements:
            plan_type = "restatement"
        elif plan.forward_only:
            plan_type = "forward_only"
        else:
            plan_type = "regular"

        environment = plan_activity.environment
        status = "success" if plan_activity.success else "failed"
        duration_s = (plan_activity.end_ts - plan_activity.start_ts) / 1000.0
        change_type = "breaking" if plan_activity.has_breaking_changes else "non_breaking"
        models_count = (
            len(plan_activity.changes.direct)
            + len(plan_activity.changes.indirect)
            + len(plan_activity.changes.added)
            + len(plan_activity.changes.removed)
            + len(plan_activity.changes.metadata)
        )
        dag_size = len(snapshots)
        has_changes = bool(plan_activity.has_changes)
    except Exception as e:
        logger.warning(f"Failed to resolve plan metric inputs: {e}")
        return

    def _impl(
        _environment: str,
        _status: str,
        _duration_s: float,
        _plan_type: str,
        _change_type: str,
        _models_count: int,
        _dag_size: int,
        _has_changes: bool,
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_plan

            bl = get_base_labels()
            tenant = bl["tenant"]
            data_product = bl["data_product"]

            record_plan(
                tenant=tenant,
                data_product=data_product,
                environment=_environment,
                status=_status,
                duration_s=_duration_s,
                plan_type=_plan_type,
                change_type=_change_type,
                models_count=_models_count,
                dag_size=_dag_size,
            )
        except Exception as e:
            logger.warning(f"Failed to record plan metrics: {e}")
            return

        if _has_changes:
            try:
                from vulcan.core.observability.recorder import record_virtual_update

                record_virtual_update(
                    tenant=tenant,
                    data_product=data_product,
                    environment=_environment,
                )
            except Exception as e:
                logger.warning(f"Failed to record virtual update metric: {e}")

    _offload(
        _impl,
        environment,
        status,
        duration_s,
        plan_type,
        change_type,
        models_count,
        dag_size,
        has_changes,
    )


def emit_run_metrics(
    run_activity: t.Any,
    config: t.Any,
) -> None:
    """Extract run/check/profile data and record all run-related metrics.

    Called from context.py after a run completes. Handles record_run,
    record_checks, and record_profiles_batch in a single call.

    Quality and profile payloads are materialized into primitive lists on
    the caller thread so the worker thread never touches live domain
    objects.
    """
    try:
        environment = run_activity.environment
        status = "success" if run_activity.success else "failed"
        duration_s = (run_activity.end_ts - run_activity.start_ts) / 1000.0
        models = run_activity.models_affected
        engine = config.dialect or "unknown"

        results: t.List[t.Dict[str, t.Any]] = []
        if run_activity.quality:
            for cr in run_activity.quality:
                results.append(
                    {
                        "check_name": cr.check_name if hasattr(cr, "check_name") else str(cr),
                        "check_type": cr.check_type if hasattr(cr, "check_type") else "unknown",
                        "status": cr.outcome.value if hasattr(cr, "outcome") else "unknown",
                        "duration_s": 0,
                    }
                )

        profiles: t.List[t.Dict[str, t.Any]] = []
        if run_activity.profile:
            for mp in run_activity.profile:
                col_count = len(mp.columns) if mp.columns else 0
                if col_count > 0:
                    profiles.append({"model": mp.model_name, "duration_s": 0, "columns": col_count})
    except Exception as e:
        logger.warning(f"Failed to resolve run metric inputs: {e}")
        return

    def _impl(
        _environment: str,
        _status: str,
        _duration_s: float,
        _models: t.Any,
        _engine: str,
        _results: t.List[t.Dict[str, t.Any]],
        _profiles: t.List[t.Dict[str, t.Any]],
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_run

            bl = get_base_labels()
            tenant = bl["tenant"]
            data_product = bl["data_product"]

            record_run(
                tenant=tenant,
                data_product=data_product,
                environment=_environment,
                status=_status,
                duration_s=_duration_s,
                models=_models,
                engine=_engine,
            )
        except Exception as e:
            logger.warning(f"Failed to record run metrics: {e}")
            return

        if _results:
            try:
                from vulcan.core.observability.recorder import record_checks

                record_checks(tenant=tenant, data_product=data_product, results=_results)
            except Exception as e:
                logger.warning(f"Failed to record check metrics: {e}")

        if _profiles:
            try:
                from vulcan.core.observability.recorder import record_profiles_batch

                record_profiles_batch(tenant=tenant, data_product=data_product, profiles=_profiles)
            except Exception as e:
                logger.warning(f"Failed to record profile metrics: {e}")

    _offload(_impl, environment, status, duration_s, models, engine, results, profiles)


def emit_test_metrics(
    result: t.Any,
    config: t.Any,
    environment: str,
    total_models: int,
    models_with_tests: int,
) -> None:
    """Extract test results and record test metrics.

    Called from context.py test() after tests complete.
    """
    try:
        passed = len(result.successes) if hasattr(result, "successes") else 0
        failed = len(result.failures) if hasattr(result, "failures") else 0
        errors = len(result.errors) if hasattr(result, "errors") else 0
        skipped = len(result.skipped) if hasattr(result, "skipped") else 0
        duration = result.duration if hasattr(result, "duration") and result.duration else 0
    except Exception as e:
        logger.warning(f"Failed to resolve test metric inputs: {e}")
        return

    def _impl(
        _environment: str,
        _passed: int,
        _failed: int,
        _errors: int,
        _skipped: int,
        _duration_s: float,
        _total_models: int,
        _models_with_tests: int,
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_tests

            bl = get_base_labels()
            record_tests(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                environment=_environment,
                passed=_passed,
                failed=_failed,
                errors=_errors,
                skipped=_skipped,
                duration_s=_duration_s,
                total_models=_total_models,
                models_with_tests=_models_with_tests,
            )
        except Exception as e:
            logger.warning(f"Failed to record test metrics: {e}")

    _offload(
        _impl,
        environment,
        passed,
        failed,
        errors,
        skipped,
        duration,
        total_models,
        models_with_tests,
    )


def emit_backfill_metrics(
    stage: t.Any,
    plan: t.Any,
) -> None:
    """Extract backfill data and record per-model backfill metrics.

    Called from evaluator.py visit_backfill_stage after scheduler completes.

    The snapshot-to-intervals mapping is materialized into a list of
    primitive ``(model_name, interval_count)`` tuples on the caller
    thread so the worker thread never walks the live snapshot graph.
    """
    try:
        trigger = "restatement" if plan.restatements else "plan"
        env = plan.environment.name if hasattr(plan.environment, "name") else str(plan.environment)

        items: t.List[t.Tuple[str, int]] = []
        for snapshot, intervals in (stage.snapshot_to_intervals or {}).items():
            model_name = snapshot.name if hasattr(snapshot, "name") else str(snapshot)
            interval_count = len(intervals) if intervals else 0
            items.append((model_name, interval_count))
    except Exception as e:
        logger.warning(f"Failed to resolve backfill metric inputs: {e}")
        return

    def _impl(_trigger: str, _env: str, _items: t.List[t.Tuple[str, int]]) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_backfill

            bl = get_base_labels()
            tenant = bl["tenant"]
            data_product = bl["data_product"]

            for model_name, interval_count in _items:
                record_backfill(
                    tenant=tenant,
                    data_product=data_product,
                    environment=_env,
                    model=model_name,
                    trigger=_trigger,
                    status="success",
                    duration_s=0,
                    intervals=interval_count,
                )
        except Exception as e:
            logger.warning(f"Failed to record backfill metrics: {e}")

    _offload(_impl, trigger, env, items)


def emit_audit_metrics(
    audit_results: t.Any,
    snapshot: t.Any,
    environment: str,
    has_blocking_errors: bool = False,
) -> None:
    """Extract audit results and record per-audit metrics.

    Called from scheduler.py _audit_snapshot after audits run.
    When *has_blocking_errors* is True, also records ``vulcan_audit_blocked_runs_total``.

    Audit results are materialized into a list of primitive
    ``(audit_name, status)`` tuples on the caller thread.
    """
    try:
        model_name = snapshot.name if hasattr(snapshot, "name") else str(snapshot)
        items: t.List[t.Tuple[str, str]] = []
        for result in audit_results:
            audit_name = result.audit.name if hasattr(result.audit, "name") else str(result.audit)
            if result.skipped:
                status = "skipped"
            elif result.count and result.count > 0:
                status = "failed"
            else:
                status = "passed"
            items.append((audit_name, status))
    except Exception as e:
        logger.warning(f"Failed to resolve audit metric inputs: {e}")
        return

    def _impl(
        _environment: str,
        _model_name: str,
        _items: t.List[t.Tuple[str, str]],
        _has_blocking_errors: bool,
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_audit

            bl = get_base_labels()
            tenant = bl["tenant"]
            data_product = bl["data_product"]

            for audit_name, status in _items:
                record_audit(
                    tenant=tenant,
                    data_product=data_product,
                    environment=_environment,
                    model=_model_name,
                    audit_name=audit_name,
                    status=status,
                    duration_s=0,
                )
        except Exception as e:
            logger.warning(f"Failed to record audit metrics: {e}")
            return

        if _has_blocking_errors:
            try:
                from vulcan.core.observability.recorder import record_audit_blocked_run

                record_audit_blocked_run(
                    tenant=tenant,
                    data_product=data_product,
                    environment=_environment,
                )
            except Exception as e:
                logger.warning(f"Failed to record audit blocked run metric: {e}")

    _offload(_impl, environment, model_name, items, has_blocking_errors)


def emit_snapshot_env_metrics(
    config: t.Any,
    snapshot_count: int,
    environment_count: int,
    environment: str,
) -> None:
    """Record active snapshot and environment counts.

    Called from context.py after plan apply.
    """

    def _impl(
        _environment: str,
        _snapshot_count: int,
        _environment_count: int,
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_snapshot_env

            bl = get_base_labels()
            record_snapshot_env(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                environment=_environment,
                snapshot_count=_snapshot_count,
                environment_count=_environment_count,
            )
        except Exception as e:
            logger.warning(f"Failed to record snapshot/env metrics: {e}")

    _offload(_impl, environment, snapshot_count, environment_count)


def emit_scheduler_metrics(
    config: t.Any,
    environment: str,
    queue_depth: int,
    model_lags: t.Optional[t.Dict[str, float]] = None,
    snapshots: t.Any = None,
    get_max_interval_end_per_model: t.Optional[t.Callable] = None,
) -> None:
    """Record scheduler queue depth and per-model run lag.

    Called from context.py during/after run.
    If *snapshots* and *get_max_interval_end_per_model* are provided,
    model lags are computed on the caller thread so the scheduler's
    snapshot graph never crosses the thread boundary.
    """
    try:
        if (
            model_lags is None
            and snapshots is not None
            and get_max_interval_end_per_model is not None
        ):
            from vulcan.utils.date import now

            model_lags = {}
            max_intervals = get_max_interval_end_per_model(snapshots, None)
            now_dt = now()
            for model_name, end_dt in max_intervals.items():
                lag_s = (now_dt - end_dt).total_seconds()
                if lag_s > 0:
                    model_lags[model_name] = lag_s

        resolved_model_lags: t.Optional[t.Dict[str, float]] = (
            dict(model_lags) if model_lags is not None else None
        )
    except Exception as e:
        logger.warning(f"Failed to resolve scheduler metric inputs: {e}")
        return

    def _impl(
        _environment: str,
        _queue_depth: int,
        _model_lags: t.Optional[t.Dict[str, float]],
    ) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_scheduler

            bl = get_base_labels()
            record_scheduler(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                environment=_environment,
                queue_depth=_queue_depth,
                model_lags=_model_lags,
            )
        except Exception as e:
            logger.warning(f"Failed to record scheduler metrics: {e}")

    _offload(_impl, environment, queue_depth, resolved_model_lags)


def emit_activity_event_metrics(
    config: t.Any,
    event_type: str,
    success: bool,
) -> None:
    """Record activity event emission success/failure.

    Called from context.py after store_plan_activity / store_run_activity.
    """

    def _impl(_event_type: str, _success: bool) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_activity_event

            bl = get_base_labels()
            record_activity_event(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                event_type=_event_type,
                success=_success,
            )
        except Exception as e:
            logger.warning(f"Failed to record activity event metrics: {e}")

    _offload(_impl, event_type, success)


def emit_query_queue_wait_metric(
    job: t.Any,
) -> None:
    """Record how long a query waited in the PGQueuer queue.

    Called from api/worker/executor.py at the start of process_job.
    Computes wait_seconds from the job's created timestamp to now.

    Args:
        job: PGQueuer Job instance (has .created and .entrypoint attributes).
    """
    from datetime import datetime, timezone

    try:
        now = datetime.now(timezone.utc)
        wait_seconds = max((now - job.created).total_seconds(), 0.0)
        entrypoint = job.entrypoint
    except Exception as e:
        logger.warning(f"Failed to resolve query queue wait metric inputs: {e}")
        return

    def _impl(_entrypoint: str, _wait_seconds: float) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_query_queue_wait

            bl = get_base_labels()
            record_query_queue_wait(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                entrypoint=_entrypoint,
                wait_seconds=_wait_seconds,
            )
        except Exception as e:
            logger.warning(f"Failed to record query queue wait metric: {e}")

    _offload(_impl, entrypoint, wait_seconds)


def emit_gateway_query_metric(
    context: t.Any,
    gateway: t.Optional[str],
    duration_s: float,
) -> None:
    """Record gateway query duration.

    Called from api/worker/executor.py after engine execution.
    Resolves tenant/data_product/engine from context + env vars.
    Offloaded so an async worker coroutine is never blocked on a push.
    """
    engine = (
        getattr(context.engine_adapter, "dialect", "unknown")
        if getattr(context, "engine_adapter", None)
        else "unknown"
    )

    def _impl(_gateway: t.Optional[str], _engine: str, _duration_s: float) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_gateway_query

            bl = get_base_labels()
            record_gateway_query(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                gateway=_gateway or "default",
                engine=_engine,
                duration_s=_duration_s,
            )
        except Exception as e:
            logger.warning(f"Failed to record gateway query metric: {e}")

    _offload(_impl, gateway, engine, duration_s)


def emit_gateway_error_metric(
    gateway: t.Optional[str],
    error: Exception,
) -> None:
    """Record gateway error.

    Called from api/worker/executor.py on query execution failure.
    Offloaded to the metrics thread pool when called from async context.
    """
    error_type = _classify_gateway_error(error)

    def _impl(_gateway: t.Optional[str], _error_type: str) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_gateway_error

            bl = get_base_labels()
            record_gateway_error(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                gateway=_gateway or "default",
                error_type=_error_type,
            )
        except Exception as e:
            logger.warning(f"Failed to record gateway error metric: {e}")

    _offload(_impl, gateway, error_type)


def emit_cache_event(kind: str) -> None:
    """Record a cache hit or miss metric.

    Called from api/endpoints/query/__init__.py on query cache lookup.
    *kind* must be ``"hit"`` or ``"miss"``.

    Offloaded to the metrics thread pool when an event loop is running.
    """

    def _impl(_kind: str) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels

            bl = get_base_labels()
            if _kind == "hit":
                from vulcan.core.observability.recorder import record_cache_hit

                record_cache_hit(tenant=bl["tenant"], data_product=bl["data_product"], api="query")
            else:
                from vulcan.core.observability.recorder import record_cache_miss

                record_cache_miss(tenant=bl["tenant"], data_product=bl["data_product"], api="query")
        except Exception as e:
            logger.debug(f"Failed to record cache event: {e}")

    _offload(_impl, kind)


def emit_policy_evaluation(
    duration_s: float,
    denied: bool = False,
    reason: str = "",
) -> None:
    """Record a Heimdall policy evaluation metric.

    Called from api/middleware/auth.py on every authorization decision.
    Offloaded to the metrics thread pool so the auth hot path never blocks
    the event loop on a Pushgateway round-trip.
    """

    def _impl(_duration_s: float, _denied: bool, _reason: str) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_policy_evaluation

            bl = get_base_labels()
            record_policy_evaluation(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                policy_type="heimdall",
                duration_s=_duration_s,
                denied=_denied,
                reason=_reason,
            )
        except Exception as e:
            logger.debug(f"Failed to record policy evaluation: {e}")

    _offload(_impl, duration_s, denied, reason)


def emit_semantic_compilation_metric(
    dialect: t.Optional[str],
    status: str,
    duration_s: float,
) -> None:
    """Record a semantic compilation (transpiler success/error).

    Called from api/endpoints/query/query.py after transpiler calls.
    Offloaded to the metrics thread pool when called from async context.
    """

    def _impl(_dialect: t.Optional[str], _status: str, _duration_s: float) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_semantic_compilation

            bl = get_base_labels()
            record_semantic_compilation(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                engine=_dialect or "unknown",
                status=_status,
                duration_s=_duration_s,
            )
        except Exception as e:
            logger.debug(f"Failed to record semantic compilation: {e}")

    _offload(_impl, dialect, status, duration_s)


def emit_transpiler_error_metric(
    dialect: t.Optional[str],
    api: str,
    error: Exception,
) -> None:
    """Record a transpiler error metric with classified error type.

    Called from api/endpoints/query/query.py on TranspilerError.
    Offloaded to the metrics thread pool when called from async context.
    """

    def _impl(_dialect: t.Optional[str], _api: str, _error: Exception) -> None:
        try:
            from vulcan.core.observability.push_gateway import get_base_labels
            from vulcan.core.observability.recorder import record_transpiler_error

            bl = get_base_labels()
            if getattr(_error, "is_connection_error", False):
                err_class = "connection_error"
            elif getattr(_error, "code", 0) == 503:
                err_class = "503"
            elif 400 <= getattr(_error, "code", 0) < 500:
                err_class = "bad_request"
            else:
                err_class = "unknown"

            record_transpiler_error(
                tenant=bl["tenant"],
                data_product=bl["data_product"],
                engine=_dialect or "unknown",
                api=_api,
                error_class=err_class,
            )
        except Exception as e:
            logger.debug(f"Failed to record transpiler error: {e}")

    _offload(_impl, dialect, api, error)
