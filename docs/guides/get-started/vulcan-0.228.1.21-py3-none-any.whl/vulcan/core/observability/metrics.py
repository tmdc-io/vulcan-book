"""Vulcan Prometheus metric definitions.

All metrics are declared here and registered to the shared registry.
To add a new metric, add one declaration below — no other file needs to change.

Bucket customization:
    Each client cluster can tune histogram bucket boundaries via environment
    variables. Set a comma-separated list of floats:

        PROM_DURATION_BUCKETS=10,30,60,300,600,1800,3600,7200
        PROM_FAST_DURATION_BUCKETS=0.01,0.05,0.1,0.5,1,5,10
        PROM_COUNT_BUCKETS=50,100,500,1000,5000,10000
        PROM_ROW_BUCKETS=1000,10000,100000,1000000,10000000
        PROM_BYTE_BUCKETS=1000000,10000000,100000000,1000000000

    If unset, sensible defaults are used.
"""

import os

from vulcan.core.observability.push_gateway import registry, is_enabled

if not is_enabled():
    raise ImportError(
        "Prometheus metrics are disabled. "
        "Install prometheus_client and set PUSHGATEWAY_URL to enable."
    )
else:
    from prometheus_client import Counter, Gauge, Histogram

    def _parse_buckets(env_var: str, default: str) -> list:
        raw = os.getenv(env_var, default)
        return sorted(float(x.strip()) for x in raw.split(",") if x.strip())

    BASE_LABELS = ["tenant", "data_product", "environment"]
    DURATION_BUCKETS = _parse_buckets(
        "PROM_DURATION_BUCKETS", "1,5,15,30,60,120,300,600,1200,1800,3600"
    )
    FAST_DURATION_BUCKETS = _parse_buckets(
        "PROM_FAST_DURATION_BUCKETS", "0.05,0.1,0.25,0.5,1,2.5,5,10,30,60"
    )
    COUNT_BUCKETS = _parse_buckets("PROM_COUNT_BUCKETS", "1,2,5,10,20,50,100,200,500")
    ROW_BUCKETS = _parse_buckets(
        "PROM_ROW_BUCKETS", "10,100,1000,10000,100000,1000000,10000000,100000000"
    )
    BYTE_BUCKETS = _parse_buckets(
        "PROM_BYTE_BUCKETS",
        "1000000,5000000,10000000,50000000,100000000,500000000,1000000000,10000000000,100000000000",
    )

    # ── 1. Plan Lifecycle ──

    vulcan_plan_total = Counter(
        "vulcan_plan_total",
        "Total plan invocations.",
        BASE_LABELS + ["status"],
        registry=registry,
    )

    vulcan_plan_duration_seconds = Histogram(
        "vulcan_plan_duration_seconds",
        "Plan duration distribution.",
        BASE_LABELS + ["plan_type"],
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_plan_models_affected = Histogram(
        "vulcan_plan_models_affected",
        "Blast radius — models affected per plan.",
        BASE_LABELS + ["change_type"],
        buckets=COUNT_BUCKETS,
        registry=registry,
    )

    vulcan_virtual_update_total = Counter(
        "vulcan_virtual_update_total",
        "Virtual layer updates that skip compute.",
        BASE_LABELS,
        registry=registry,
    )

    # ── 2. Model Execution (Run) ──

    vulcan_run_total = Counter(
        "vulcan_run_total",
        "Top-level run invocations.",
        BASE_LABELS + ["status"],
        registry=registry,
    )

    vulcan_run_duration_seconds = Histogram(
        "vulcan_run_duration_seconds",
        "End-to-end DAG wall clock.",
        BASE_LABELS,
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_model_run_total = Counter(
        "vulcan_model_run_total",
        "Model execution count aggregated by materialization kind.",
        BASE_LABELS + ["kind", "status"],
        registry=registry,
    )

    vulcan_model_run_duration_seconds = Histogram(
        "vulcan_model_run_duration_seconds",
        "Model execution duration aggregated by materialization kind.",
        BASE_LABELS + ["kind"],
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_model_rows_processed = Histogram(
        "vulcan_model_rows_processed",
        "Rows processed per model execution.",
        BASE_LABELS,
        buckets=ROW_BUCKETS,
        registry=registry,
    )

    vulcan_model_bytes_processed = Histogram(
        "vulcan_model_bytes_processed",
        "Bytes processed per model execution — cost and skew signal.",
        BASE_LABELS + ["engine"],
        buckets=BYTE_BUCKETS,
        registry=registry,
    )

    vulcan_model_intervals_processed = Histogram(
        "vulcan_model_intervals_processed",
        "Intervals evaluated per model execution.",
        BASE_LABELS,
        buckets=COUNT_BUCKETS,
        registry=registry,
    )

    vulcan_dag_node_count = Gauge(
        "vulcan_dag_node_count",
        "Total nodes in the resolved DAG.",
        BASE_LABELS,
        registry=registry,
    )

    # ── 3. Backfill ──

    vulcan_backfill_total = Counter(
        "vulcan_backfill_total",
        "Backfill invocations by trigger type.",
        BASE_LABELS + ["trigger", "status"],
        registry=registry,
    )

    vulcan_backfill_duration_seconds = Histogram(
        "vulcan_backfill_duration_seconds",
        "Backfill duration distribution.",
        BASE_LABELS,
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_backfill_intervals_total = Histogram(
        "vulcan_backfill_intervals_total",
        "Date intervals backfilled per run.",
        ["tenant", "data_product", "environment"],
        buckets=COUNT_BUCKETS,
        registry=registry,
    )

    vulcan_backfill_active = Gauge(
        "vulcan_backfill_active",
        "Currently active backfills.",
        BASE_LABELS,
        registry=registry,
    )

    # ── 4. Tests ──

    vulcan_test_total = Counter(
        "vulcan_test_total",
        "Unit test executions by status.",
        ["tenant", "data_product", "status"],
        registry=registry,
    )

    vulcan_test_duration_seconds = Histogram(
        "vulcan_test_duration_seconds",
        "Total test suite duration.",
        BASE_LABELS,
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_test_coverage_ratio = Gauge(
        "vulcan_test_coverage_ratio",
        "Ratio of models with at least one test.",
        ["tenant", "data_product"],
        registry=registry,
    )

    # ── 5. Audits ──

    vulcan_audit_total = Counter(
        "vulcan_audit_total",
        "Audit executions by status.",
        BASE_LABELS + ["status"],
        registry=registry,
    )

    vulcan_audit_duration_seconds = Histogram(
        "vulcan_audit_duration_seconds",
        "Audit execution duration.",
        BASE_LABELS,
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_audit_blocked_plans_total = Counter(
        "vulcan_audit_blocked_plans_total",
        "Plans blocked by audit failures.",
        BASE_LABELS,
        registry=registry,
    )

    vulcan_audit_blocked_runs_total = Counter(
        "vulcan_audit_blocked_runs_total",
        "Runs blocked by audit failures.",
        BASE_LABELS,
        registry=registry,
    )

    # ── 6. Checks ──

    vulcan_check_total = Counter(
        "vulcan_check_total",
        "Check executions by type and status.",
        ["tenant", "data_product", "check_type", "status"],
        registry=registry,
    )

    vulcan_check_duration_seconds = Histogram(
        "vulcan_check_duration_seconds",
        "Check execution duration.",
        ["tenant", "data_product", "check_type"],
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_check_warnings_total = Counter(
        "vulcan_check_warnings_total",
        "Check warning count.",
        ["tenant", "data_product", "check_type"],
        registry=registry,
    )

    # ── 7. Semantic Model Compilation & Serving ──

    vulcan_semantic_compilation_duration_seconds = Histogram(
        "vulcan_semantic_compilation_duration_seconds",
        "Semantic-to-SQL compilation duration.",
        ["tenant", "data_product", "engine"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_semantic_compilation_total = Counter(
        "vulcan_semantic_compilation_total",
        "Semantic compilation invocations.",
        ["tenant", "data_product", "engine", "status"],
        registry=registry,
    )

    vulcan_semantic_query_duration_seconds = Histogram(
        "vulcan_semantic_query_duration_seconds",
        "End-to-end semantic query duration (Vulcan + engine).",
        ["tenant", "data_product", "engine", "api"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_semantic_query_overhead_seconds = Histogram(
        "vulcan_semantic_query_overhead_seconds",
        "Vulcan processing time excluding engine execution.",
        ["tenant", "data_product", "api"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_semantic_query_total = Counter(
        "vulcan_semantic_query_total",
        "Semantic query volume and error rate.",
        ["tenant", "data_product", "engine", "api", "status"],
        registry=registry,
    )

    vulcan_semantic_transpiler_errors_total = Counter(
        "vulcan_semantic_transpiler_errors_total",
        "Transpiler service/transport failures (503, timeouts) separate from semantic compilation errors.",
        ["tenant", "data_product", "engine", "api", "error_class"],
        registry=registry,
    )

    # ── 8. Profiling ──

    vulcan_profile_duration_seconds = Histogram(
        "vulcan_profile_duration_seconds",
        "Column profiling duration.",
        ["tenant", "data_product"],
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_profile_columns_scanned_total = Counter(
        "vulcan_profile_columns_scanned_total",
        "Columns profiled.",
        ["tenant", "data_product"],
        registry=registry,
    )

    # ── 9. Cache ──

    vulcan_cache_hit_total = Counter(
        "vulcan_cache_hit_total",
        "Cache hits.",
        ["tenant", "data_product", "api"],
        registry=registry,
    )

    vulcan_cache_miss_total = Counter(
        "vulcan_cache_miss_total",
        "Cache misses.",
        ["tenant", "data_product", "api"],
        registry=registry,
    )

    # ── 10. Snapshot & Environment ──

    vulcan_snapshots_active = Gauge(
        "vulcan_snapshots_active",
        "Live snapshot versions.",
        BASE_LABELS,
        registry=registry,
    )

    vulcan_environments_active = Gauge(
        "vulcan_environments_active",
        "Active non-prod environments.",
        ["tenant", "data_product"],
        registry=registry,
    )

    # ── 11. Gateway / Engine Connectivity ──

    vulcan_gateway_query_duration_seconds = Histogram(
        "vulcan_gateway_query_duration_seconds",
        "Engine query duration.",
        ["tenant", "data_product", "gateway", "engine"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_gateway_errors_total = Counter(
        "vulcan_gateway_errors_total",
        "Engine connection/query errors.",
        ["tenant", "data_product", "gateway", "error_type"],
        registry=registry,
    )

    # ── 12. Access Policy Evaluation ──

    vulcan_policy_evaluation_duration_seconds = Histogram(
        "vulcan_policy_evaluation_duration_seconds",
        "Heimdall policy evaluation duration.",
        ["tenant", "data_product", "policy_type"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_policy_denial_total = Counter(
        "vulcan_policy_denial_total",
        "Policy denials.",
        ["tenant", "data_product", "subject_type", "reason"],
        registry=registry,
    )

    # ── 13. Scheduler ──

    vulcan_scheduled_run_lag_seconds = Histogram(
        "vulcan_scheduled_run_lag_seconds",
        "How late models are versus their cron schedule.",
        BASE_LABELS,
        buckets=DURATION_BUCKETS,
        registry=registry,
    )

    vulcan_scheduler_queue_depth = Gauge(
        "vulcan_scheduler_queue_depth",
        "Models waiting to execute.",
        BASE_LABELS,
        registry=registry,
    )

    vulcan_model_last_run_timestamp = Gauge(
        "vulcan_model_last_run_timestamp",
        "Latest epoch timestamp of a model run in the environment.",
        BASE_LABELS,
        registry=registry,
    )

    # ── 14. Query Queue Backpressure ──

    vulcan_query_queue_depth = Gauge(
        "vulcan_query_queue_depth",
        "Queries waiting in the execution queue (queued state).",
        ["tenant", "data_product", "entrypoint"],
        registry=registry,
    )

    vulcan_query_queue_wait_seconds = Histogram(
        "vulcan_query_queue_wait_seconds",
        "Time a query spent waiting in the PGQueuer queue before execution started.",
        ["tenant", "data_product", "entrypoint"],
        buckets=FAST_DURATION_BUCKETS,
        registry=registry,
    )

    # ── 15. Activity API Integration ──

    vulcan_activity_events_emitted_total = Counter(
        "vulcan_activity_events_emitted_total",
        "Events emitted to Activity API.",
        ["tenant", "data_product", "event_type"],
        registry=registry,
    )
