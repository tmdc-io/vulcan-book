"""Centralized metric recording logic.

Every instrumentation site in the codebase calls exactly one function from
this module.  The function accepts plain data, does all the metric
manipulation (read-then-increment for counters, observe for histograms,
set for gauges), and pushes to the Pushgateway.

Import pattern:
    try:
        from vulcan.core.observability.recorder import record_plan
    except Exception:
        pass

This keeps core files free of metric details and guarantees graceful
degradation if prometheus_client is not installed or the Pushgateway URL
is unset.
"""

import logging
import time
import typing as t
from functools import wraps

logger = logging.getLogger(__name__)


def _safe(fn: t.Callable[..., None]) -> t.Callable[..., None]:
    """Decorator: swallow any exception so metrics never break business logic."""

    @wraps(fn)
    def wrapper(*args: t.Any, **kwargs: t.Any) -> None:
        try:
            fn(*args, **kwargs)
        except Exception as e:
            logger.warning(f"Metrics recording failed ({fn.__name__}): {e}")

    return wrapper


def _inc_counter(counter: t.Any, labels: t.Dict[str, str], amount: int = 1) -> None:
    """Read-then-increment: fetch previous value from Pushgateway, then inc.

    The metric name is derived from the counter object itself (``counter._name``),
    so callers never need to pass a redundant string.

    After incrementing, the new value is written back to the local cache so
    that a subsequent call with the same metric+labels in the same batch
    reads the correct (updated) value instead of the stale one.
    """
    from vulcan.core.observability.push_gateway import reserve_counter_value

    name = counter._name
    child = counter.labels(**labels)
    new_value = reserve_counter_value(name, labels, amount=amount)

    current_value = 0.0
    value_ref = getattr(child, "_value", None)
    if value_ref is not None and hasattr(value_ref, "get"):
        try:
            current_value = float(value_ref.get())
        except Exception:
            current_value = 0.0

    delta = new_value - current_value
    if delta > 0:
        child.inc(delta)


def _begin_batch() -> None:
    """Fetch all current Pushgateway values into the local cache."""
    from vulcan.core.observability.push_gateway import _fetch_current_values

    _fetch_current_values()


def _flush() -> None:
    """Push all in-memory metrics to Pushgateway."""
    from vulcan.core.observability.push_gateway import push_metrics

    push_metrics()


# ── Plan ──


@_safe
def record_plan(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    status: str,
    duration_s: float,
    plan_type: str,
    change_type: str,
    models_count: int,
    dag_size: int,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_plan_total,
        vulcan_plan_duration_seconds,
        vulcan_plan_models_affected,
        vulcan_dag_node_count,
    )

    _begin_batch()
    base = dict(tenant=tenant, data_product=data_product, environment=environment)

    _inc_counter(vulcan_plan_total, {**base, "status": status})
    vulcan_plan_duration_seconds.labels(**base, plan_type=plan_type).observe(duration_s)
    vulcan_plan_models_affected.labels(**base, change_type=change_type).observe(models_count)
    vulcan_dag_node_count.labels(**base).set(dag_size)

    _flush()


# ── Virtual Update ──


@_safe
def record_virtual_update(
    *,
    tenant: str,
    data_product: str,
    environment: str,
) -> None:
    from vulcan.core.observability.metrics import vulcan_virtual_update_total

    _begin_batch()
    labels = dict(tenant=tenant, data_product=data_product, environment=environment)
    _inc_counter(vulcan_virtual_update_total, labels)
    _flush()


# ── Run ──


@_safe
def record_run(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    status: str,
    duration_s: float,
    models: t.List[t.Any],
    engine: str = "unknown",
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_run_total,
        vulcan_run_duration_seconds,
        vulcan_model_run_total,
        vulcan_model_run_duration_seconds,
        vulcan_model_rows_processed,
        vulcan_model_bytes_processed,
        vulcan_model_intervals_processed,
    )

    _begin_batch()
    base = dict(tenant=tenant, data_product=data_product, environment=environment)

    _inc_counter(vulcan_run_total, {**base, "status": status})
    vulcan_run_duration_seconds.labels(**base).observe(duration_s)

    for model in models:
        kind = model.model_kind.value if model.model_kind else "UNKNOWN"

        model_status = "success" if model.end_ts > 0 else "failed"
        _inc_counter(
            vulcan_model_run_total,
            {**base, "kind": kind, "status": model_status},
        )
        vulcan_model_run_duration_seconds.labels(**base, kind=kind).observe(
            model.evaluation_ms / 1000.0
        )
        vulcan_model_rows_processed.labels(**base).observe(model.rows_affected)
        if model.bytes_processed > 0:
            vulcan_model_bytes_processed.labels(**base, engine=engine).observe(
                model.bytes_processed
            )
        vulcan_model_intervals_processed.labels(**base).observe(model.total_batches)

    _flush()


# ── Backfill ──


@_safe
def record_backfill(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    model: str,
    trigger: str,
    status: str,
    duration_s: float,
    intervals: int,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_backfill_total,
        vulcan_backfill_duration_seconds,
        vulcan_backfill_intervals_total,
        vulcan_backfill_active,
    )

    _begin_batch()
    base = dict(tenant=tenant, data_product=data_product, environment=environment)
    _inc_counter(
        vulcan_backfill_total,
        {**base, "trigger": trigger, "status": status},
    )
    vulcan_backfill_duration_seconds.labels(**base).observe(duration_s)
    vulcan_backfill_intervals_total.labels(**base).observe(intervals)
    if status == "running":
        vulcan_backfill_active.labels(**base).inc()
    elif status in ("success", "failed"):
        vulcan_backfill_active.labels(**base).set(0)

    _flush()


# ── Tests ──


@_safe
def record_tests(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    passed: int,
    failed: int,
    errors: int,
    skipped: int,
    duration_s: float,
    total_models: int = 0,
    models_with_tests: int = 0,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_test_total,
        vulcan_test_duration_seconds,
        vulcan_test_coverage_ratio,
    )

    _begin_batch()
    base = dict(tenant=tenant, data_product=data_product)
    env_base = dict(**base, environment=environment)

    for status, count in [
        ("passed", passed),
        ("failed", failed),
        ("error", errors),
        ("skip", skipped),
    ]:
        if count > 0:
            _inc_counter(vulcan_test_total, {**base, "status": status}, amount=count)

    vulcan_test_duration_seconds.labels(**env_base).observe(duration_s)
    if total_models > 0:
        vulcan_test_coverage_ratio.labels(**base).set(models_with_tests / total_models)

    _flush()


# ── Audits ──


@_safe
def record_audit(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    model: str,
    audit_name: str,
    status: str,
    duration_s: float,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_audit_total,
        vulcan_audit_duration_seconds,
        vulcan_audit_blocked_plans_total,
    )

    _begin_batch()
    del model, audit_name

    labels = dict(tenant=tenant, data_product=data_product, environment=environment)
    _inc_counter(vulcan_audit_total, {**labels, "status": status})
    vulcan_audit_duration_seconds.labels(**labels).observe(duration_s)

    if status == "failed":
        _inc_counter(
            vulcan_audit_blocked_plans_total,
            dict(tenant=tenant, data_product=data_product, environment=environment),
        )

    _flush()


@_safe
def record_audit_blocked_run(
    *,
    tenant: str,
    data_product: str,
    environment: str,
) -> None:
    """Record a run blocked by audit failure (separate from plan-level blocking)."""
    from vulcan.core.observability.metrics import vulcan_audit_blocked_runs_total

    _begin_batch()
    _inc_counter(
        vulcan_audit_blocked_runs_total,
        dict(tenant=tenant, data_product=data_product, environment=environment),
    )
    _flush()


# ── Checks ──


@_safe
def record_checks(
    *,
    tenant: str,
    data_product: str,
    results: t.List[t.Dict[str, t.Any]],
) -> None:
    """Record check results.

    Each item in `results` should have: check_name, check_type, status, duration_s.
    """
    from vulcan.core.observability.metrics import (
        vulcan_check_total,
        vulcan_check_duration_seconds,
        vulcan_check_warnings_total,
    )

    _begin_batch()
    base = dict(tenant=tenant, data_product=data_product)

    for r in results:
        check_labels = {
            **base,
            "check_type": r["check_type"],
            "status": r["status"],
        }
        _inc_counter(vulcan_check_total, check_labels)
        vulcan_check_duration_seconds.labels(**base, check_type=r["check_type"]).observe(
            r.get("duration_s", 0)
        )
        if r["status"] == "warn":
            _inc_counter(
                vulcan_check_warnings_total,
                {**base, "check_type": r["check_type"]},
            )

    _flush()


# ── Profiling ──


@_safe
def record_profile(
    *,
    tenant: str,
    data_product: str,
    model: str,
    duration_s: float,
    columns: int,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_profile_duration_seconds,
        vulcan_profile_columns_scanned_total,
    )

    _begin_batch()
    del model
    labels = dict(tenant=tenant, data_product=data_product)
    vulcan_profile_duration_seconds.labels(**labels).observe(duration_s)
    _inc_counter(vulcan_profile_columns_scanned_total, labels, amount=columns)
    _flush()


@_safe
def record_profiles_batch(
    *,
    tenant: str,
    data_product: str,
    profiles: t.List[t.Dict[str, t.Any]],
) -> None:
    """Record profile metrics for multiple models in a single begin/flush cycle.

    Each item in `profiles` should have: model (str), duration_s (float), columns (int).
    Using a single batch avoids intermediate flushes that would wipe other
    models' data from Pushgateway via pushadd_to_gateway.
    """
    from vulcan.core.observability.metrics import (
        vulcan_profile_duration_seconds,
        vulcan_profile_columns_scanned_total,
    )

    _begin_batch()
    for p in profiles:
        labels = dict(tenant=tenant, data_product=data_product)
        vulcan_profile_duration_seconds.labels(**labels).observe(p.get("duration_s", 0))
        col_count = p.get("columns", 0)
        if col_count > 0:
            _inc_counter(vulcan_profile_columns_scanned_total, labels, amount=col_count)
    _flush()


# ── Semantic Transpiler ──


@_safe
def record_transpiler_error(
    *,
    tenant: str,
    data_product: str,
    engine: str,
    api: str,
    error_class: str,
) -> None:
    """Record a transpiler service/transport error (503, timeout, bad_request, unknown).

    Separate from vulcan_semantic_compilation_total which counts semantic-level errors.
    """
    from vulcan.core.observability.metrics import vulcan_semantic_transpiler_errors_total

    _begin_batch()
    _inc_counter(
        vulcan_semantic_transpiler_errors_total,
        dict(
            tenant=tenant,
            data_product=data_product,
            engine=engine,
            api=api,
            error_class=error_class,
        ),
    )
    _flush()


# ── Snapshot & Environment ──


@_safe
def record_snapshot_env(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    snapshot_count: int,
    environment_count: int,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_snapshots_active,
        vulcan_environments_active,
    )

    base = dict(tenant=tenant, data_product=data_product, environment=environment)
    vulcan_snapshots_active.labels(**base).set(snapshot_count)
    vulcan_environments_active.labels(tenant=tenant, data_product=data_product).set(
        environment_count
    )
    _flush()


# ── Scheduler ──


@_safe
def record_scheduler(
    *,
    tenant: str,
    data_product: str,
    environment: str,
    queue_depth: int,
    model_lags: t.Optional[t.Dict[str, float]] = None,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_scheduled_run_lag_seconds,
        vulcan_scheduler_queue_depth,
        vulcan_model_last_run_timestamp,
    )

    base = dict(tenant=tenant, data_product=data_product, environment=environment)
    vulcan_scheduler_queue_depth.labels(**base).set(queue_depth)

    if model_lags:
        now_ts = time.time()
        _Y2K_EPOCH = 946684800  # 2000-01-01 UTC
        latest_run_ts = 0.0
        for model_name, lag_s in model_lags.items():
            del model_name
            vulcan_scheduled_run_lag_seconds.labels(**base).observe(lag_s)
            last_run_ts = now_ts - lag_s
            if last_run_ts > _Y2K_EPOCH:
                latest_run_ts = max(latest_run_ts, last_run_ts)
        if latest_run_ts > 0:
            vulcan_model_last_run_timestamp.labels(**base).set(latest_run_ts)

    _flush()


# ── Query Queue Backpressure ──


@_safe
def record_query_queue_depth(
    *,
    tenant: str,
    data_product: str,
    entrypoint: str,
    depth: int,
) -> None:
    from vulcan.core.observability.metrics import vulcan_query_queue_depth

    vulcan_query_queue_depth.labels(
        tenant=tenant, data_product=data_product, entrypoint=entrypoint
    ).set(depth)
    _flush()


@_safe
def record_query_queue_wait(
    *,
    tenant: str,
    data_product: str,
    entrypoint: str,
    wait_seconds: float,
) -> None:
    from vulcan.core.observability.metrics import vulcan_query_queue_wait_seconds

    vulcan_query_queue_wait_seconds.labels(
        tenant=tenant, data_product=data_product, entrypoint=entrypoint
    ).observe(wait_seconds)
    _flush()


# ── Cache ──


@_safe
def record_cache_hit(
    *,
    tenant: str,
    data_product: str,
    api: str = "query",
) -> None:
    from vulcan.core.observability.metrics import vulcan_cache_hit_total

    _begin_batch()
    _inc_counter(
        vulcan_cache_hit_total,
        dict(tenant=tenant, data_product=data_product, api=api),
    )
    _flush()


@_safe
def record_cache_miss(
    *,
    tenant: str,
    data_product: str,
    api: str = "query",
) -> None:
    from vulcan.core.observability.metrics import vulcan_cache_miss_total

    _begin_batch()
    _inc_counter(
        vulcan_cache_miss_total,
        dict(tenant=tenant, data_product=data_product, api=api),
    )
    _flush()


# ── Semantic Compilation ──


@_safe
def record_semantic_compilation(
    *,
    tenant: str,
    data_product: str,
    engine: str,
    status: str,
    duration_s: float,
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_semantic_compilation_total,
        vulcan_semantic_compilation_duration_seconds,
    )

    _begin_batch()
    _inc_counter(
        vulcan_semantic_compilation_total,
        dict(tenant=tenant, data_product=data_product, engine=engine, status=status),
    )
    vulcan_semantic_compilation_duration_seconds.labels(
        tenant=tenant, data_product=data_product, engine=engine
    ).observe(duration_s)
    _flush()


# ── Gateway / Engine Connectivity ──


@_safe
def record_gateway_query(
    *,
    tenant: str,
    data_product: str,
    gateway: str,
    engine: str,
    duration_s: float,
) -> None:
    from vulcan.core.observability.metrics import vulcan_gateway_query_duration_seconds

    vulcan_gateway_query_duration_seconds.labels(
        tenant=tenant, data_product=data_product, gateway=gateway, engine=engine
    ).observe(duration_s)
    _flush()


@_safe
def record_gateway_error(
    *,
    tenant: str,
    data_product: str,
    gateway: str,
    error_type: str,
) -> None:
    from vulcan.core.observability.metrics import vulcan_gateway_errors_total

    _begin_batch()
    _inc_counter(
        vulcan_gateway_errors_total,
        dict(tenant=tenant, data_product=data_product, gateway=gateway, error_type=error_type),
    )
    _flush()


# ── Access Policy Evaluation ──


@_safe
def record_policy_evaluation(
    *,
    tenant: str,
    data_product: str,
    policy_type: str,
    duration_s: float,
    denied: bool = False,
    subject_type: str = "user",
    reason: str = "",
) -> None:
    from vulcan.core.observability.metrics import (
        vulcan_policy_evaluation_duration_seconds,
        vulcan_policy_denial_total,
    )

    vulcan_policy_evaluation_duration_seconds.labels(
        tenant=tenant, data_product=data_product, policy_type=policy_type
    ).observe(duration_s)

    if denied:
        _begin_batch()
        _inc_counter(
            vulcan_policy_denial_total,
            dict(
                tenant=tenant, data_product=data_product, subject_type=subject_type, reason=reason
            ),
        )

    _flush()


# ── Activity API ──


@_safe
def record_activity_event(
    *,
    tenant: str,
    data_product: str,
    event_type: str,
    success: bool,
) -> None:
    from vulcan.core.observability.metrics import vulcan_activity_events_emitted_total

    if not success:
        return

    _begin_batch()
    _inc_counter(
        vulcan_activity_events_emitted_total,
        dict(tenant=tenant, data_product=data_product, event_type=event_type),
    )
    _flush()
