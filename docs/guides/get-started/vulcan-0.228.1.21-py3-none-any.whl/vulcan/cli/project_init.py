import os
import typing as t
from enum import Enum
from pathlib import Path
from dataclasses import dataclass
from rich.prompt import Prompt
from rich.console import Console
from vulcan.utils.date import yesterday_ds
from vulcan.utils.errors import VulcanError
from vulcan.core.config.connection import (
    CONNECTION_CONFIG_TO_TYPE,
    DIALECT_TO_TYPE,
    INIT_DISPLAY_INFO_TO_TYPE,
)


PRIMITIVES = (str, int, bool, float)


def _yaml_quote(value: str) -> str:
    """Quote a scalar string for YAML in a safe, minimal way."""
    escaped = (value or "").replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


class ProjectTemplate(Enum):
    DEFAULT = "default"
    EMPTY = "empty"


class InitCliMode(Enum):
    DEFAULT = "default"
    FLOW = "flow"


def _gen_config(
    engine_type: t.Optional[str],
    settings: t.Optional[str],
    start: t.Optional[str],
    template: ProjectTemplate,
    cli_mode: InitCliMode,
    tenant: str,
    name: str,
    description: str,
    dialect: t.Optional[str] = None,
) -> str:
    project_dialect = dialect or DIALECT_TO_TYPE.get(engine_type)

    connection_settings = (
        settings
        or """      type: duckdb
      database: db.db"""
    )

    if not settings:
        if engine_type in CONNECTION_CONFIG_TO_TYPE:
            required_fields = []
            non_required_fields = []

            for field_key, field in CONNECTION_CONFIG_TO_TYPE[engine_type].model_fields.items():
                field_name = field.alias or field_key

                default_value = field.get_default()

                if isinstance(default_value, Enum):
                    default_value = default_value.value
                elif not isinstance(default_value, PRIMITIVES):
                    default_value = ""

                required = field.is_required() or field_name == "type"
                option_str = f"      {'# ' if not required else ''}{field_name}: {default_value}\n"

                # specify the DuckDB database field so quickstart runs out of the box
                if engine_type == "duckdb" and field_name == "database":
                    option_str = "      database: db.db\n"
                    required = True

                if required:
                    required_fields.append(option_str)
                else:
                    non_required_fields.append(option_str)

            connection_settings = "".join(required_fields + non_required_fields)

    default_configs = {
        ProjectTemplate.DEFAULT: f"""name: {_yaml_quote(name)}
display_name: "Human Friendly Name"
tenant: {_yaml_quote(tenant)}
description: {_yaml_quote(description)}
discoverable: true
version: "0.1.0"
alignment: source_aligned
domain: {_yaml_quote(tenant)}

# Optional categorization
tags: []  # e.g. ["marketing", "saas", "analytics"]
terms: []  # e.g. ["glossary.data_product", "glossary.business_intelligence"]

users:
  - username: "example"
    github_username: "example"
    email: "example@example.com"
    type: "MEMBER"
  - username: "owner"
    github_username: "owner"
    email: "owner@example.com"
    type: "OWNER"

# notification_targets:
#   - type: console
#     notify_on:
#       - apply_start
#       - apply_end
#       - run_start
#       - run_end
#       - migration_start
#       - migration_end
#       - apply_failure
#       - run_failure
#       - audit_failure
#       - migration_failure
#       - plan_change
#       - check_start
#       - check_end
#       - check_failure

# --- Gateway Connection ---
gateways:
  {engine_type}:
    connection:
{connection_settings}
    # State sync - use DuckDB by default for local projects
    state_connection:
      type: duckdb
      database: ./.state.db

model_defaults:
  dialect: {project_dialect}
  start: {start or yesterday_ds()} # Start date for backfill history
  cron: '@daily'    # Run models daily at 12am UTC (can override per model)

# --- Linting Rules ---
# Enforce standards for your team
linter:
  enabled: true
  rules:
    - ambiguousorinvalidcolumn
    - invalidselectstarexpansion
    - noambiguousprojections
""",
    }

    default_configs[ProjectTemplate.EMPTY] = default_configs[ProjectTemplate.DEFAULT]

    flow_cli_mode = """
# FLOW: Minimal prompts, automatic changes, summary output

plan:
  no_diff: true             # Hide detailed text differences for changed models
  no_prompts: true          # No interactive prompts
  auto_apply: true          # Apply changes automatically

# --- Optional: Set a default target environment ---
# This is intended for local development to prevent users from accidentally applying plans to the prod environment.
# It is a development only config and should NOT be committed to your git repo.

# Uncomment the following line to use a default target environment derived from the logged in user's name.
# default_target_environment: dev_{{ user() }}

# Example usage:
# vulcan plan            # Automatically resolves to: vulcan plan dev_yourname
# vulcan plan prod       # Specify `prod` to apply changes to production
"""

    return default_configs[template] + (flow_cli_mode if cli_mode == InitCliMode.FLOW else "")


@dataclass
class ExampleObjects:
    sql_models: t.Dict[str, str]
    python_models: t.Dict[str, str]
    seeds: t.Dict[str, str]
    tests: t.Dict[str, str]
    sql_macros: t.Dict[str, str]
    python_macros: t.Dict[str, str]
    semantic_models: t.Dict[str, str]
    metric_models: t.Dict[str, str]
    dq_models: t.Dict[str, str]


def _gen_example_objects(schema_name: str) -> ExampleObjects:
    sql_models: t.Dict[str, str] = {}
    python_models: t.Dict[str, str] = {}
    seeds: t.Dict[str, str] = {}
    tests: t.Dict[str, str] = {}
    sql_macros: t.Dict[str, str] = {}
    python_macros: t.Dict[str, str] = {"__init__": ""}
    semantic_models: t.Dict[str, str] = {}
    metric_models: t.Dict[str, str] = {}
    dq_models: t.Dict[str, str] = {}

    full_model_name = f"{schema_name}.full_model"
    incremental_model_name = f"{schema_name}.incremental_model"
    seed_model_name = f"{schema_name}.seed_model"

    sql_models[full_model_name] = f"""MODEL (
  name {full_model_name},
  kind FULL,
  owner 'example',
  cron '@daily',
  grains (item_id),
  tags ('example', 'summary', 'orders'),
  terms ('product.full_model', 'example.summary'),
  description 'Example aggregate model built from the incremental starter model',
  column_descriptions (
    item_id = 'Identifier for the grouped item',
    num_orders = 'Count of distinct records aggregated into the full model'
  ),
  column_tags (
    item_id = ('identifier', 'grouping'),
    num_orders = ('metric', 'aggregate')
  ),
  column_terms (
    item_id = ('example.item_id', 'reference.item_id'),
    num_orders = ('example.num_orders', 'metric.num_orders')
  ),
  assertions (
    not_null(columns := (item_id)),
    forall(criteria := (item_id > 0))
  ),
);

SELECT
  item_id,
  COUNT(DISTINCT id) AS num_orders,
FROM
  {incremental_model_name}
GROUP BY item_id
  """

    sql_models[incremental_model_name] = f"""MODEL (
  name {incremental_model_name},
  kind INCREMENTAL_BY_TIME_RANGE (
    time_column event_date
  ),
  owner 'example',
  start '2020-01-01',
  cron '@daily',
  grains [id, event_date],
  tags ('example', 'usage', 'events'),
  terms ('product.incremental_model', 'telemetry.events'),
  description 'Example incremental fact model used by the starter project',
  column_descriptions (
    id = 'Unique record identifier',
    item_id = 'Item identifier used for aggregation',
    event_date = 'Event date used as the incremental time column'
  ),
  column_tags (
    id = ('identifier', 'record'),
    item_id = ('identifier', 'foreign_key'),
    event_date = ('date', 'partition')
  ),
  column_terms (
    id = ('example.id', 'reference.id'),
    item_id = ('example.item_id', 'reference.item_id'),
    event_date = ('example.event_date', 'temporal.event_date')
  ),
  assertions (
    not_null(columns := (id, item_id, event_date)),
  ),
);

SELECT
  id,
  item_id,
  event_date::TIMESTAMP AS event_date,
FROM
  {seed_model_name}
WHERE
  event_date BETWEEN @start_date AND @end_date
  """

    sql_models[seed_model_name] = f"""MODEL (
  name {seed_model_name},
  kind SEED (
    path '../seeds/seed_data.csv'
  ),
  owner 'example',
  columns (
    id INTEGER,
    item_id INTEGER,
    event_date TIMESTAMP
  ),
  grains [id, event_date],
  tags ('example', 'seed', 'reference'),
  terms ('product.seed_model', 'reference.seed_data'),
  description 'Example seed model used by the starter project',
  column_descriptions (
    id = 'Unique row identifier',
    item_id = 'Item identifier for the seed row',
    event_date = 'Seed row event date'
  ),
  column_tags (
    id = ('identifier', 'primary_key'),
    item_id = ('identifier', 'foreign_key'),
    event_date = ('date', 'reference')
  ),
  column_terms (
    id = ('example.id', 'reference.id'),
    item_id = ('example.item_id', 'reference.item_id'),
    event_date = ('example.event_date', 'temporal.event_date')
  )
);
  """

    seeds["seed_data"] = """id,item_id,event_date
1,2,2020-01-01 00:00:00
2,1,2020-01-01 00:00:00
3,3,2020-01-03 00:00:00
4,1,2020-01-04 00:00:00
5,1,2020-01-05 00:00:00
6,1,2020-01-06 00:00:00
7,1,2020-01-07 00:00:00
"""

    tests["test_full_model"] = f"""test_example_full_model:
  model: {full_model_name}
  inputs:
    {incremental_model_name}:
      rows:
      - id: 1
        item_id: 1
      - id: 2
        item_id: 1
      - id: 3
        item_id: 2
  outputs:
    query:
      rows:
      - item_id: 1
        num_orders: 2
      - item_id: 2
        num_orders: 1
  """

    semantic_models["incremental_model"] = f"""# Canonical semantic example generated by `vulcan init`
kind: semantic
name: incremental_model
depends_on: {incremental_model_name}
description: Incremental event data (semantic layer)

dimensions:
  - id
  - item_id
  - event_date

measures:
  - name: total_events
    type: count
    description: Total number of events
    tags:
      - usage
      - events
      - metric
    terms:
      - product.total_events
      - usage.events
"""

    metric_models["event_activity"] = f"""# Metric example generated by `vulcan init`
kind: metric
name: event_activity
measure: incremental_model.total_events
ts: incremental_model.event_date
granularity: day
dimensions:
  - incremental_model.item_id
description: Daily event activity by item
tags:
  - engagement
  - metric
terms:
  - glossary.event_activity
  - glossary.daily_events
"""

    dq_models["full_model"] = f"""# Data quality example generated by `vulcan init`
kind: dq
name: full_model_dq
depends_on: {full_model_name}
rules:
  - missing_count(item_id) = 0:
      name: no_missing_item_ids
      dimension: completeness
      description: All rows must have an item_id

  - duplicate_count(item_id) = 0:
      name: unique_item_ids
      dimension: uniqueness
      description: item_id must be unique in the full model
"""

    return ExampleObjects(
        sql_models=sql_models,
        python_models=python_models,
        seeds=seeds,
        tests=tests,
        python_macros=python_macros,
        sql_macros=sql_macros,
        semantic_models=semantic_models,
        metric_models=metric_models,
        dq_models=dq_models,
    )


def init_example_project(
    path: t.Union[str, Path],
    engine_type: t.Optional[str],
    dialect: t.Optional[str] = None,
    template: ProjectTemplate = ProjectTemplate.DEFAULT,
    schema_name: str = "vulcan_example",
    cli_mode: InitCliMode = InitCliMode.DEFAULT,
    start: t.Optional[str] = None,
    tenant: t.Optional[str] = None,
    name: t.Optional[str] = None,
    description: t.Optional[str] = None,
) -> Path:
    root_path = Path(path)
    resolved_root_path = root_path.absolute()

    project_name = (name or resolved_root_path.name or root_path.name).strip()
    if not project_name:
        project_name = "vulcan_project"

    project_tenant = (tenant or os.getenv("DATAOS_TENANT_ID") or "default").strip()
    if not project_tenant:
        project_tenant = "default"

    project_description = (description or f"{project_name} Vulcan project.").strip()
    if not project_description:
        project_description = f"{project_name} Vulcan project."

    config_path = root_path / "config.yaml"

    audits_path = root_path / "audits"
    macros_path = root_path / "macros"
    models_path = root_path / "models"
    semantic_models_path = models_path / "semantics"
    metric_models_path = models_path / "metrics"
    dq_models_path = root_path / "dq"
    seeds_path = root_path / "seeds"
    tests_path = root_path / "tests"

    if config_path.exists():
        raise VulcanError(
            f"Found an existing config file '{config_path}'.\n\nPlease change to another directory or remove the existing file."
        )

    engine_types = "', '".join(CONNECTION_CONFIG_TO_TYPE)
    if engine_type is None:
        raise VulcanError(
            f"Missing `engine` argument to `vulcan init` - please specify a SQL engine for your project. Options: '{engine_types}'."
        )

    if engine_type and engine_type not in CONNECTION_CONFIG_TO_TYPE:
        raise VulcanError(
            f"Invalid engine '{engine_type}'. Please specify one of '{engine_types}'."
        )

    _create_config(
        config_path=config_path,
        engine_type=engine_type,
        dialect=dialect,
        settings=None,
        start=start,
        template=template,
        cli_mode=cli_mode,
        tenant=project_tenant,
        name=project_name,
        description=project_description,
    )

    _create_usage_file(
        root_path / "usage.yml",
        with_examples=template != ProjectTemplate.EMPTY,
    )

    _create_folders(
        [
            audits_path,
            macros_path,
            models_path,
            semantic_models_path,
            metric_models_path,
            dq_models_path,
            seeds_path,
            tests_path,
        ]
    )

    example_objects = _gen_example_objects(schema_name=schema_name)

    if template != ProjectTemplate.EMPTY:
        _create_object_files(models_path, example_objects.sql_models, "sql")
        _create_object_files(models_path, example_objects.python_models, "py")
        _create_object_files(seeds_path, example_objects.seeds, "csv")
        _create_object_files(tests_path, example_objects.tests, "yaml")
        _create_object_files(macros_path, example_objects.python_macros, "py")
        _create_object_files(macros_path, example_objects.sql_macros, "sql")
        _create_object_files(semantic_models_path, example_objects.semantic_models, "yml")
        _create_object_files(metric_models_path, example_objects.metric_models, "yml")
        _create_object_files(dq_models_path, example_objects.dq_models, "yml")

    return config_path


def _create_folders(target_folders: t.Sequence[Path]) -> None:
    for folder_path in target_folders:
        folder_path.mkdir(exist_ok=True)
        (folder_path / ".gitkeep").touch()


def _create_config(
    config_path: Path,
    engine_type: t.Optional[str],
    dialect: t.Optional[str],
    settings: t.Optional[str],
    start: t.Optional[str],
    template: ProjectTemplate,
    cli_mode: InitCliMode,
    tenant: str,
    name: str,
    description: str,
) -> None:
    project_config = _gen_config(
        engine_type=engine_type,
        settings=settings,
        start=start,
        template=template,
        cli_mode=cli_mode,
        tenant=tenant,
        name=name,
        description=description,
        dialect=dialect,
    )

    _write_file(
        config_path,
        project_config,
    )


def _create_object_files(path: Path, object_dict: t.Dict[str, str], file_extension: str) -> None:
    for object_name, object_def in object_dict.items():
        # file name is table component of catalog.schema.table
        _write_file(path / f"{object_name.split('.')[-1]}.{file_extension}", object_def)


def _create_usage_file(path: Path, *, with_examples: bool) -> None:
    if with_examples:
        payload = """\
good_for:
  - title: Example use case
    details: Describe who should use this product and why

not_for:
  - title: Example anti-pattern
    details: Describe when this product is the wrong choice

caveats:
  - title: Example caveat
    details: Data freshness, exclusions, or coverage limits
    severity: medium

references:
  - title: Documentation
    url: https://example.com/documentation
    type: doc
"""
    else:
        payload = """\
good_for: []
not_for: []
caveats: []
references: []
"""
    _write_file(path, payload)


def _write_file(path: Path, payload: str) -> None:
    with open(path, "w", encoding="utf-8") as fd:
        fd.write(payload)


def interactive_init(
    path: Path,
    console: Console,
    project_template: t.Optional[ProjectTemplate] = None,
) -> t.Tuple[ProjectTemplate, t.Optional[str], t.Optional[InitCliMode]]:
    console.print("──────────────────────────────")
    console.print("Welcome to Vulcan!")

    project_template = _init_template_prompt(console) if not project_template else project_template

    engine_type = _init_engine_prompt(console)
    cli_mode = _init_cli_mode_prompt(console)

    return (project_template, engine_type, cli_mode)


def _init_integer_prompt(
    console: Console, err_msg_entity: str, num_options: int, retry_func: t.Callable[[t.Any], t.Any]
) -> int:
    err_msg = "\nERROR: '{option_str}' is not a valid {err_msg_entity} number - please enter a number between 1 and {num_options} or exit with control+c\n"
    while True:
        option_str = Prompt.ask("Enter a number", console=console)

        value_error = False
        try:
            option_num = int(option_str)
        except ValueError:
            value_error = True

        if value_error or option_num < 1 or option_num > num_options:
            console.print(
                err_msg.format(
                    option_str=option_str, err_msg_entity=err_msg_entity, num_options=num_options
                ),
                style="red",
            )
            continue
        console.print("")
        return option_num


def _init_display_choices(values_dict: t.Dict[str, str], console: Console) -> t.Dict[int, str]:
    display_num_to_value = {}
    for i, value_str in enumerate(values_dict.keys()):
        console.print(f"    \\[{i + 1}] {' ' if i < 9 else ''}{value_str} {values_dict[value_str]}")
        display_num_to_value[i + 1] = value_str
    console.print("")
    return display_num_to_value


def _init_template_prompt(console: Console) -> ProjectTemplate:
    console.print("──────────────────────────────\n")
    console.print("What type of project do you want to set up?\n")

    # These are ordered for user display - do not reorder
    template_descriptions = {
        ProjectTemplate.DEFAULT.name: "- Create Vulcan example project models and files",
        ProjectTemplate.EMPTY.name: "  - Create a Vulcan configuration file and project directories only",
    }

    display_num_to_template = _init_display_choices(template_descriptions, console)

    template_num = _init_integer_prompt(
        console, "project type", len(template_descriptions), _init_template_prompt
    )

    return ProjectTemplate(display_num_to_template[template_num].lower())


def _init_engine_prompt(console: Console) -> str:
    console.print("──────────────────────────────\n")
    console.print("Choose your SQL engine:\n")

    # INIT_DISPLAY_INFO_TO_TYPE is a dict of {engine_type: (display_order, display_name)}
    DISPLAY_NAME_TO_TYPE = {v[1]: k for k, v in INIT_DISPLAY_INFO_TO_TYPE.items()}
    ordered_engine_display_names = {
        info[1]: "" for info in sorted(INIT_DISPLAY_INFO_TO_TYPE.values(), key=lambda x: x[0])
    }
    display_num_to_display_name = _init_display_choices(ordered_engine_display_names, console)

    engine_num = _init_integer_prompt(
        console, "engine", len(ordered_engine_display_names), _init_engine_prompt
    )

    return DISPLAY_NAME_TO_TYPE[display_num_to_display_name[engine_num]]


def _init_cli_mode_prompt(console: Console) -> InitCliMode:
    console.print("──────────────────────────────\n")
    console.print("Choose your Vulcan CLI experience:\n")

    cli_mode_descriptions = {
        InitCliMode.DEFAULT.name: "- See and control every detail",
        InitCliMode.FLOW.name: "   - Automatically run changes and show summary output",
    }

    display_num_to_cli_mode = _init_display_choices(cli_mode_descriptions, console)

    cli_mode_num = _init_integer_prompt(
        console, "config", len(cli_mode_descriptions), _init_cli_mode_prompt
    )

    return InitCliMode(display_num_to_cli_mode[cli_mode_num].lower())
