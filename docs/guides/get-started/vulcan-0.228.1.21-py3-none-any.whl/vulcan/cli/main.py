from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import os
import subprocess
import sys
import typing as t
from pathlib import Path

import click

from vulcan import configure_logging, remove_excess_logs
from vulcan.cli import error_handler
from vulcan.cli import options as opt
from vulcan.cli.project_init import (
    InitCliMode,
    ProjectTemplate,
    init_example_project,
    interactive_init,
)
from vulcan.core.analytics import cli_analytics
from vulcan.core.config import load_configs
from vulcan.core.console import configure_console, get_console
from vulcan.core.context import Context
from vulcan.core.query.transpiler import (
    RestQuery,
    TranspilerClient,
    get_transpiler_params_from_snapshots,
    make_transpiler_client,
)
from vulcan.utils.pydantic import pydantic_to_yaml
from vulcan.utils.errors import TranspilerError
from vulcan.utils import Verbosity
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import MissingDependencyError, VulcanError
from vulcan.utils.process import detect_docker_compose_command, get_host_ip

logger = logging.getLogger(__name__)


SKIP_LOAD_COMMANDS = (
    "clean",
    "create_deploy_yaml",
    "create_external_models",
    "destroy",
    "environments",
    "invalidate",
    "janitor",
    "metadata",
    "migrate",
    "rollback",
    "run",
    "table_name",
)
SKIP_CONTEXT_COMMANDS = ("init", "ui", "graphql", "create_deploy_yaml")  # Commands that don't need Context


def _vulcan_version() -> str:
    try:
        from vulcan import __version__

        return __version__
    except ImportError:
        return "0.0.0"


@click.group(no_args_is_help=True)
@click.version_option(version=_vulcan_version(), message="%(version)s")
@opt.paths
@opt.config
@click.option(
    "--gateway",
    type=str,
    help="The name of the gateway.",
    envvar="VULCAN_GATEWAY",
)
@click.option(
    "--ignore-warnings",
    is_flag=True,
    help="Ignore warnings.",
    envvar="VULCAN_IGNORE_WARNINGS",
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug mode.",
)
@click.option(
    "--log-to-stdout",
    is_flag=True,
    help="Display logs in stdout.",
)
@click.option(
    "--log-file-dir",
    type=str,
    help="The directory to write log files to.",
)
@click.option(
    "--dotenv",
    type=click.Path(exists=True, path_type=Path),
    help="Path to a custom .env file to load environment variables.",
    envvar="VULCAN_DOTENV_PATH",
)
@click.pass_context
@error_handler
def cli(
    ctx: click.Context,
    paths: t.List[str],
    config: t.Optional[str] = None,
    gateway: t.Optional[str] = None,
    ignore_warnings: bool = False,
    debug: bool = False,
    log_to_stdout: bool = True,
    log_file_dir: t.Optional[str] = None,
    dotenv: t.Optional[Path] = None,
) -> None:
    """Vulcan command line tool."""
    if "--help" in sys.argv:
        return

    configure_logging(
        debug,
        log_to_stdout,
        log_file_dir=log_file_dir,
        ignore_warnings=ignore_warnings,
    )
    configure_console(ignore_warnings=ignore_warnings)
    try:
        from vulcan.core.observability.hooks import register_observability_hooks

        register_observability_hooks()
    except Exception:
        logger.debug("Observability hooks not registered", exc_info=True)

    load = True

    if len(paths) == 1:
        path = os.path.abspath(paths[0])
        if ctx.invoked_subcommand in SKIP_CONTEXT_COMMANDS:
            ctx.obj = path
            return
        if ctx.invoked_subcommand in SKIP_LOAD_COMMANDS:
            load = False

    configs = load_configs(config, Context.CONFIG_TYPE, paths, dotenv_path=dotenv)
    log_limit = list(configs.values())[0].log_limit

    remove_excess_logs(log_file_dir, log_limit)

    try:
        context = Context(
            paths=paths,
            config=configs,
            gateway=gateway,
            load=load,
        )
    except Exception:
        if debug:
            logger.exception("Failed to initialize Vulcan context")
        raise

    if load and not context.models:
        raise click.ClickException(
            f"`{paths}` doesn't seem to have any models... cd into the proper directory or specify the path(s) with -p."
        )

    ctx.obj = context

@cli.command("init")
@click.argument("engine", required=False)
@click.option(
    "-t",
    "--template",
    type=str,
    help="Project template. Supported values: default, empty.",
)
@click.option("--tenant", type=str, help="Project tenant to write into config.yaml.")
@click.option("--name", "project_name", type=str, help="Project name to write into config.yaml.")
@click.option("--description", type=str, help="Project description to write into config.yaml.")
@click.pass_context
@error_handler
@cli_analytics
def init(
    ctx: click.Context,
    engine: t.Optional[str] = None,
    template: t.Optional[str] = None,
    tenant: t.Optional[str] = None,
    project_name: t.Optional[str] = None,
    description: t.Optional[str] = None,
) -> None:
    """Create a new Vulcan repository."""
    project_template = None
    if template:
        try:
            project_template = ProjectTemplate(template.lower())
        except ValueError:
            template_strings = "', '".join([template.value for template in ProjectTemplate])
            raise click.ClickException(
                f"Invalid project template '{template}'. Please specify one of '{template_strings}'."
            )

    if engine:
        init_example_project(
            path=ctx.obj,
            template=project_template or ProjectTemplate.DEFAULT,
            engine_type=engine,
            tenant=tenant,
            name=project_name,
            description=description,
        )
        return

    import vulcan.utils.rich as srich

    console = srich.console

    project_template, engine_type, cli_mode = interactive_init(ctx.obj, console, project_template)

    config_path = init_example_project(
        path=ctx.obj,
        template=project_template,
        engine_type=engine_type,
        cli_mode=cli_mode or InitCliMode.DEFAULT,
        tenant=tenant,
        name=project_name,
        description=description,
    )

    engine_install_text = ""
    if engine_type and engine_type not in ("duckdb", "motherduck"):
        install_text = (
            "pyspark" if engine_type == "spark" else f"vulcan\\[{engine_type.replace('_', '')}]"
        )
        # engine_install_text = f'• Run command in CLI to install your SQL engine\'s Python dependencies: pip install "{install_text}"\n'
    
    next_step_text = f"{engine_install_text}• Update your gateway connection settings (e.g., username/password) in the project configuration file:\n    {config_path}"

    console.print(f"""──────────────────────────────

Your Vulcan project is ready!

Next steps:
{next_step_text}
• Run command in CLI: vulcan plan
• (Optional) Explain a plan: vulcan plan --explain

Guide: https://tmdc-io.github.io/vulcan-book/guides

""")


@cli.command("render")
@click.argument("model")
@opt.start_time
@opt.end_time
@opt.execution_time
@opt.expand
@click.option(
    "--dialect",
    type=str,
    help="The SQL dialect to render the query as.",
)
@click.option("--no-format", is_flag=True, help="Disable fancy formatting of the query.")
@opt.format_options
@click.pass_context
@error_handler
@cli_analytics
def render(
    ctx: click.Context,
    model: str,
    start: TimeLike,
    end: TimeLike,
    execution_time: t.Optional[TimeLike] = None,
    expand: t.Optional[t.Union[bool, t.Iterable[str]]] = None,
    dialect: t.Optional[str] = None,
    no_format: bool = False,
    **format_kwargs: t.Any,
) -> None:
    """Render a model's query, optionally expanding referenced models."""
    model = ctx.obj.get_model(model, raise_if_missing=True)

    rendered = ctx.obj.render(
        model,
        start=start,
        end=end,
        execution_time=execution_time,
        expand=expand,
    )

    format_config = ctx.obj.config_for_node(model).format
    format_kwargs = {
        **format_config.generator_options,
        **{k: v for k, v in format_kwargs.items() if v is not None},
    }

    sql = rendered.sql(
        pretty=True,
        dialect=ctx.obj.config.dialect if dialect is None else dialect,
        **format_kwargs,
    )
    if no_format:
        print(sql)
    else:
        ctx.obj.console.show_sql(sql)


@cli.command("evaluate")
@click.argument("model")
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option(
    "--limit",
    type=int,
    help="The number of rows which the query should be limited to.",
)
@click.pass_context
@error_handler
@cli_analytics
def evaluate(
    ctx: click.Context,
    model: str,
    start: TimeLike,
    end: TimeLike,
    execution_time: t.Optional[TimeLike] = None,
    limit: t.Optional[int] = None,
) -> None:
    """Evaluate a model and return a dataframe with a default limit of 1000."""
    df = ctx.obj.evaluate(
        model,
        start=start,
        end=end,
        execution_time=execution_time,
        limit=limit,
    )
    if hasattr(df, "show"):
        df.show(limit)
    else:
        ctx.obj.console.log_success(df)


@cli.command("format")
@click.argument("paths", nargs=-1)
@click.option(
    "-t",
    "--transpile",
    type=str,
    help="Transpile project models to the specified dialect.",
)
@click.option(
    "--check",
    is_flag=True,
    help="Whether or not to check formatting (but not actually format anything).",
    default=None,
)
@click.option(
    "--rewrite-casts/--no-rewrite-casts",
    is_flag=True,
    help="Rewrite casts to use the :: syntax.",
    default=None,
)
@click.option(
    "--append-newline",
    is_flag=True,
    help="Include a newline at the end of each file.",
    default=None,
)
@opt.format_options
@click.pass_context
@error_handler
@cli_analytics
def format(
    ctx: click.Context, paths: t.Optional[t.Tuple[str, ...]] = None, **kwargs: t.Any
) -> None:
    """Format all SQL models and audits."""
    if not ctx.obj.format(**{k: v for k, v in kwargs.items() if v is not None}, paths=paths):
        ctx.exit(1)


@cli.command("diff")
@click.argument("environment")
@click.pass_context
@error_handler
@cli_analytics
def diff(ctx: click.Context, environment: t.Optional[str] = None) -> None:
    """Show the diff between the local state and the target environment."""
    if ctx.obj.diff(environment, detailed=True):
        exit(1)


@cli.command("plan")
@click.argument("environment", required=False)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option(
    "--create-from",
    type=str,
    help="The environment to create the target environment from if it doesn't exist. Default: prod.",
)
@click.option(
    "--skip-tests",
    is_flag=True,
    help="Skip tests prior to generating the plan if they are defined.",
    default=None,
)
@click.option(
    "--skip-linter",
    is_flag=True,
    help="Skip linting prior to generating the plan if the linter is enabled.",
    default=None,
)
@click.option(
    "--restate-model",
    "-r",
    type=str,
    multiple=True,
    help="Restate data for specified models and models downstream from the one specified. For production environment, all related model versions will have their intervals wiped, but only the current versions will be backfilled. For development environment, only the current model versions will be affected.",
)
@click.option(
    "--no-gaps",
    is_flag=True,
    help="Ensure that new snapshots have no data gaps when comparing to existing snapshots for matching models in the target environment.",
    default=None,
)
@click.option(
    "--skip-backfill",
    "--dry-run",
    is_flag=True,
    help="Skip the backfill step and only create a virtual update for the plan.",
    default=None,
)
@click.option(
    "--empty-backfill",
    is_flag=True,
    help="Produce empty backfill. Like --skip-backfill no models will be backfilled, unlike --skip-backfill missing intervals will be recorded as if they were backfilled.",
    default=None,
)
@click.option(
    "--forward-only",
    is_flag=True,
    help="Create a plan for forward-only changes.",
    default=None,
)
@click.option(
    "--allow-destructive-model",
    type=str,
    multiple=True,
    help="Allow destructive forward-only changes to models whose names match the expression.",
)
@click.option(
    "--allow-additive-model",
    type=str,
    multiple=True,
    help="Allow additive forward-only changes to models whose names match the expression.",
)
@click.option(
    "--effective-from",
    type=str,
    required=False,
    help="The effective date from which to apply forward-only changes on production.",
)
@click.option(
    "--no-prompts",
    is_flag=True,
    help="Disable interactive prompts for the backfill time range. Please note that if this flag is set and there are uncategorized changes, plan creation will fail.",
    default=None,
)
@click.option(
    "--auto-apply",
    is_flag=True,
    help="Automatically apply the new plan after creation.",
    default=None,
)
@click.option(
    "--no-auto-categorization",
    is_flag=True,
    help="Disable automatic change categorization.",
    default=None,
)
@click.option(
    "--include-unmodified",
    is_flag=True,
    help="Include unmodified models in the target environment.",
    default=None,
)
@click.option(
    "--select-model",
    type=str,
    multiple=True,
    help="Select specific model changes that should be included in the plan.",
)
@click.option(
    "--backfill-model",
    type=str,
    multiple=True,
    help="Backfill only the models whose names match the expression.",
)
@click.option(
    "--no-diff",
    is_flag=True,
    help="Hide text differences for changed models.",
    default=None,
)
@click.option(
    "--run",
    is_flag=True,
    help="Run latest intervals as part of the plan application (prod environment only).",
    default=None,
)
@click.option(
    "--enable-preview",
    is_flag=True,
    help="Enable preview for forward-only models when targeting a development environment.",
    default=None,
)
@click.option(
    "--diff-rendered",
    is_flag=True,
    help="Output text differences for the rendered versions of the models and standalone audits.",
    default=None,
)
@click.option(
    "--explain",
    is_flag=True,
    help="Explain the plan instead of applying it.",
    default=None,
)
@click.option(
    "--ignore-cron",
    is_flag=True,
    help="Run all missing intervals, ignoring individual cron schedules. Only applies if --run is set.",
    default=None,
)
@click.option(
    "--min-intervals",
    default=0,
    help="For every model, ensure at least this many intervals are covered by a missing intervals check regardless of the plan start date",
)
@click.option(
    "--migrate",
    is_flag=True,
    help="Run state migration before planning.",
)
@opt.verbose
@click.pass_context
@error_handler
@cli_analytics
def plan(
    ctx: click.Context,
    verbose: int,
    environment: t.Optional[str] = None,
    **kwargs: t.Any,
) -> None:
    """Apply local changes to the target environment."""
    context = ctx.obj
    restate_models = kwargs.pop("restate_model") or None
    select_models = kwargs.pop("select_model") or None
    allow_destructive_models = kwargs.pop("allow_destructive_model") or None
    allow_additive_models = kwargs.pop("allow_additive_model") or None
    backfill_models = kwargs.pop("backfill_model") or None
    ignore_cron = kwargs.pop("ignore_cron") or None
    setattr(get_console(), "verbosity", Verbosity(verbose))

    if kwargs.pop("migrate", False):
        context.migrate()

    context.plan(
        environment,
        restate_models=restate_models,
        select_models=select_models,
        allow_destructive_models=allow_destructive_models,
        allow_additive_models=allow_additive_models,
        backfill_models=backfill_models,
        ignore_cron=ignore_cron,
        **kwargs,
    )


@cli.command("run")
@click.argument("environment", required=False)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option("--skip-janitor", is_flag=True, help="Skip the janitor task.")
@click.option(
    "--ignore-cron",
    is_flag=True,
    help="Run for all missing intervals, ignoring individual cron schedules.",
)
@click.option(
    "--select-model",
    type=str,
    multiple=True,
    help="Select specific models to run. Note: this always includes upstream dependencies.",
)
@click.option(
    "--exit-on-env-update",
    type=int,
    help="If set, the command will exit with the specified code if the run is interrupted by an update to the target environment.",
)
@click.option(
    "--no-auto-upstream",
    is_flag=True,
    help="Do not automatically include upstream models. Only applicable when --select-model is used. Note: this may result in missing / invalid data for the selected models.",
)
@click.option(
    "--migrate",
    is_flag=True,
    help="Run state migration before run.",
)
@click.pass_context
@error_handler
@cli_analytics
def run(ctx: click.Context, environment: t.Optional[str] = None, **kwargs: t.Any) -> None:
    """Evaluate missing intervals for the target environment."""
    context = ctx.obj
    select_models = kwargs.pop("select_model") or None

    if kwargs.pop("migrate", False):
        context.migrate()

    completion_status = context.run(environment, select_models=select_models, **kwargs)
    if completion_status.is_failure:
        raise click.ClickException("Run failed.")

@cli.command("invalidate")
@click.argument("environment", required=True)
@click.option(
    "--sync",
    "-s",
    is_flag=True,
    help="Wait for the environment to be deleted before returning. If not specified, the environment will be deleted asynchronously by the janitor process. This option requires a connection to the data warehouse.",
)
@click.pass_context
@error_handler
@cli_analytics
def invalidate(ctx: click.Context, environment: str, **kwargs: t.Any) -> None:
    """Invalidate the target environment, forcing its removal during the next run of the janitor process."""
    context = ctx.obj
    context.invalidate_environment(environment, **kwargs)


@cli.command("janitor")
@click.option(
    "--ignore-ttl",
    is_flag=True,
    help="Cleanup snapshots that are not referenced in any environment, regardless of when they're set to expire",
)
@click.pass_context
@error_handler
@cli_analytics
def janitor(ctx: click.Context, ignore_ttl: bool, **kwargs: t.Any) -> None:
    """
    Run the janitor process on-demand.

    The janitor cleans up old environments and expired snapshots.
    """
    ctx.obj.run_janitor(ignore_ttl, **kwargs)


@cli.command("destroy")
@click.pass_context
@error_handler
@cli_analytics
def destroy(ctx: click.Context, **kwargs: t.Any) -> None:
    """
    The destroy command removes all project resources.

    This includes engine-managed objects, state tables, the Vulcan cache and any build artifacts.
    """
    ctx.obj.destroy(**kwargs)


@cli.group(invoke_without_command=True, no_args_is_help=False)
@click.pass_context
def graph(ctx: click.Context) -> None:
    """

    Write interactive HTML graph visualizations.

    Running this command alone is equivalent to running graph dag out.html.

    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(
            graph_dag,
            file=None,
            select_model=tuple(),
        )


@graph.command("dag")
@click.argument("file", required=False)
@click.option(
    "--select-model",
    type=str,
    multiple=True,
    help="Select specific models to include in the dag.",
)
@click.pass_obj
@error_handler
@cli_analytics
def graph_dag(
    obj: Context,
    file: t.Optional[str],
    select_model: t.Tuple[str, ...],
) -> None:
    """Render the lineage DAG as an HTML file."""

    outfile = file or "dag.html"
    rendered = obj.render_dag(outfile, select_model if select_model else None)
    if rendered:
        obj.console.log_success(f"Generated the dag to {rendered}")


@graph.command("joins")
@click.argument("file", required=False)
@click.pass_obj
@error_handler
@cli_analytics
def graph_join(obj: Context, file: t.Optional[str]) -> None:
    """Render semantic model joins declarations as an HTML graph."""

    outfile = file or "joins.html"
    out_path = obj.render_joins_graph(outfile)
    if out_path:
        obj.console.log_success(f"Generated the semantic joins graph to {out_path}")


@cli.command("create_test")
@click.argument("model")
@click.option(
    "-q",
    "--query",
    "queries",
    type=(str, str),
    multiple=True,
    default=[],
    help="Queries that will be used to generate data for the model's dependencies.",
)
@click.option(
    "-o",
    "--overwrite",
    "overwrite",
    is_flag=True,
    default=False,
    help="When true, the fixture file will be overwritten in case it already exists.",
)
@click.option(
    "-v",
    "--var",
    "variables",
    type=(str, str),
    multiple=True,
    help="Key-value pairs that will define variables needed by the model.",
)
@click.option(
    "-p",
    "--path",
    "path",
    help=(
        "The file path corresponding to the fixture, relative to the test directory. "
        "By default, the fixture will be created under the test directory and the file "
        "name will be inferred based on the test's name."
    ),
)
@click.option(
    "-n",
    "--name",
    "name",
    help="The name of the test that will be created. By default, it's inferred based on the model's name.",
)
@click.option(
    "--include-ctes",
    "include_ctes",
    is_flag=True,
    default=False,
    help="When true, CTE fixtures will also be generated.",
)
@click.pass_obj
@error_handler
@cli_analytics
def create_test(
    obj: Context,
    model: str,
    queries: t.List[t.Tuple[str, str]],
    overwrite: bool = False,
    variables: t.Optional[t.List[t.Tuple[str, str]]] = None,
    path: t.Optional[str] = None,
    name: t.Optional[str] = None,
    include_ctes: bool = False,
) -> None:
    """Generate a unit test fixture for a given model."""
    obj.create_test(
        model,
        input_queries=dict(queries),
        overwrite=overwrite,
        variables=dict(variables) if variables else None,
        path=path,
        name=name,
        include_ctes=include_ctes,
    )


@cli.command("test")
@opt.match_pattern
@opt.verbose
@click.option(
    "--preserve-fixtures",
    is_flag=True,
    default=False,
    help="Preserve the fixture tables in the testing database, useful for debugging.",
)
@click.argument("tests", nargs=-1)
@click.pass_obj
@error_handler
@cli_analytics
def test(
    obj: Context,
    k: t.List[str],
    verbose: int,
    preserve_fixtures: bool,
    tests: t.List[str],
) -> None:
    """Run model unit tests."""
    result = obj.test(
        match_patterns=k,
        tests=tests,
        verbosity=Verbosity(verbose),
        preserve_fixtures=preserve_fixtures,
    )
    if not result.wasSuccessful():
        exit(1)


@cli.command("audit")
@click.option(
    "--model",
    "models",
    multiple=True,
    help="A model to audit. Multiple models can be audited.",
)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.pass_obj
@error_handler
@cli_analytics
def audit(
    obj: Context,
    models: t.Iterator[str],
    start: TimeLike,
    end: TimeLike,
    execution_time: t.Optional[TimeLike] = None,
) -> None:
    """Run audits for the target model(s)."""
    if not obj.audit(models=models, start=start, end=end, execution_time=execution_time):
        exit(1)


@cli.command("check_intervals")
@click.option(
    "--no-signals",
    is_flag=True,
    help="Disable signal checks and only show missing intervals.",
    default=False,
)
@click.argument("environment", required=False)
@click.option(
    "--select-model",
    type=str,
    multiple=True,
    help="Select specific models to show missing intervals for.",
)
@opt.start_time
@opt.end_time
@click.pass_context
@error_handler
@cli_analytics
def check_intervals(
    ctx: click.Context,
    environment: t.Optional[str],
    no_signals: bool,
    select_model: t.List[str],
    start: TimeLike,
    end: TimeLike,
) -> None:
    """Show missing intervals in an environment, respecting signals."""
    context = ctx.obj
    context.console.show_intervals(
        context.check_intervals(
            environment,
            no_signals=no_signals,
            select_models=select_model,
            start=start,
            end=end,
        )
    )


@cli.command("fetchdf")
@click.argument("sql", required=False)
@click.option(
    "--file",
    "-f",
    type=click.File("r"),
    default=None,
    help="Read SQL from file. Use '-' to read from stdin.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "csv", "json", "raw"], case_sensitive=False),
    default="table",
    help="Output format: 'table' (formatted table), 'csv' (CSV), 'json' (JSON), 'raw' (simple table).",
)
@click.pass_context
@error_handler
@cli_analytics
def fetchdf(
    ctx: click.Context,
    sql: t.Optional[str],
    file: t.Optional[t.TextIO],
    output_format: str,
) -> None:
    """Run a SQL query and display the results."""
    import sys
    import pandas as pd
    
    context = ctx.obj
    
    # Determine SQL source: file > argument > stdin
    if file:
        sql_query = file.read()
    elif sql:
        sql_query = sql
    else:
        # Read from stdin if no argument provided
        sql_query = sys.stdin.read()
    
    if not sql_query or not sql_query.strip():
        raise click.ClickException("No SQL query provided. Provide SQL as argument, --file, or via stdin.")
    
    # Execute query
    df = context.fetchdf(sql_query)
    
    # Determine if output is piped
    is_piped = not sys.stdout.isatty()
    
    # Display results based on format
    if output_format.lower() == "csv":
        # CSV output (works well for piping)
        df.to_csv(sys.stdout, index=False)
    elif output_format.lower() == "json":
        # JSON output (works well for piping)
        df.to_json(sys.stdout, orient="records", indent=2, date_format="iso")
    elif output_format.lower() == "raw":
        # Raw output
        context.console.log_success(df)
    else:
        # Table format
        if is_piped:
            # Piped output - use CSV for better compatibility
            df.to_csv(sys.stdout, index=False)
        else:
            # Interactive terminal - use formatted table display
            from rich.table import Table as RichTable
            
            console = get_console()
            table = RichTable(show_header=True, header_style="bold magenta")
            
            # Add columns
            for col in df.columns:
                table.add_column(str(col))
            
            def _format_table_cell(val: t.Any) -> str:
                if val is None:
                    return "NULL"
                if pd.api.types.is_list_like(val) and not isinstance(val, (str, bytes, dict)):
                    return str(val)
                return str(val) if pd.notna(val) else "NULL"

            # Add rows (limit display for very large results)
            max_rows = 1000
            for idx, row in df.head(max_rows).iterrows():
                table.add_row(*[_format_table_cell(val) for val in row])
            
            console.console.print(table)
            
            if len(df) > max_rows:
                console.console.print(f"\n[dim]Showing {max_rows} of {len(df)} rows. Use --format raw|csv|json to export all rows.[/dim]")


@cli.command("info")
@click.option(
    "--skip-connection",
    is_flag=True,
    help="Skip the connection test.",
)
@opt.verbose
@click.pass_obj
@error_handler
@cli_analytics
def info(obj: Context, skip_connection: bool, verbose: int) -> None:
    """
    Print information about a Vulcan project.

    Includes counts of project models and macros and connection tests for the data warehouse.
    """
    obj.print_info(skip_connection=skip_connection, verbosity=Verbosity(verbose))


# TODO: We don't support ui. You should use api instead.
# @cli.command("ui")
# @click.option(
#     "--host",
#     type=str,
#     default="127.0.0.1",
#     help="Bind socket to this host. Default: 127.0.0.1",
# )
# @click.option(
#     "--port",
#     type=int,
#     default=8000,
#     help="Bind socket to this port. Default: 8000",
# )
# @click.option(
#     "--mode",
#     type=click.Choice(["ide", "catalog", "docs", "plan"], case_sensitive=False),
#     default="ide",
#     help="Mode to start the UI in. Default: ide",
# )
# @click.pass_context
# @error_handler
# @cli_analytics
# def ui(ctx: click.Context, host: str, port: int, mode: str) -> None:
#     """Start a browser-based Vulcan UI."""
#     from vulcan.core.console import get_console

#     get_console().log_warning(
#         "The UI is deprecated and will be removed in a future version. Please use the Vulcan VSCode extension instead. "
#         "Learn more at https://sqlmesh.readthedocs.io/en/stable/guides/vscode/"
#     )

#     try:
#         import uvicorn
#     except ModuleNotFoundError as e:
#         raise MissingDependencyError(
#             "Missing UI dependencies. Run `pip install 'vulcan[web]'` to install them."
#         ) from e

#     os.environ["PROJECT_PATH"] = ctx.obj
#     os.environ["UI_MODE"] = mode
#     if ctx.parent:
#         config = ctx.parent.params.get("config")
#         gateway = ctx.parent.params.get("gateway")
#         if config:
#             os.environ["CONFIG"] = config
#         if gateway:
#             os.environ["GATEWAY"] = gateway
#     uvicorn.run(
#         "web.server.app:app",
#         host=host,
#         port=port,
#         log_level="info",
#         timeout_keep_alive=300,
#     )

@cli.command("migrate")
@click.pass_context
@error_handler
@cli_analytics
def migrate(ctx: click.Context) -> None:
    """Migrate Vulcan to the current running version."""
    ctx.obj.migrate()


@cli.command("rollback")
@click.pass_obj
@error_handler
@cli_analytics
def rollback(obj: Context) -> None:
    """Rollback Vulcan to the previous migration."""
    obj.rollback()


@cli.command("create_external_models")
@click.option(
    "--strict",
    is_flag=True,
    help="Raise an error if the external model is missing in the database",
)
@click.pass_obj
@error_handler
@cli_analytics
def create_external_models(obj: Context, **kwargs: t.Any) -> None:
    """Create a schema file containing external model schemas."""
    obj.create_external_models(**kwargs)


@cli.command("table_diff")
@click.argument("source_to_target", required=True, metavar="SOURCE:TARGET")
@click.argument("model", required=False)
@click.option(
    "-o",
    "--on",
    type=str,
    multiple=True,
    help="The column to join on. Can be specified multiple times. The model grain will be used if not specified.",
)
@click.option(
    "-s",
    "--skip-columns",
    type=str,
    multiple=True,
    help="The column(s) to skip when comparing the source and target table.",
)
@click.option(
    "--where",
    type=str,
    help="An optional where statement to filter results.",
)
@click.option(
    "--limit",
    type=int,
    default=20,
    help="The limit of the sample dataframe.",
)
@click.option(
    "--show-sample",
    is_flag=True,
    help="Show a sample of the rows that differ. With many columns, the output can be very wide.",
)
@click.option(
    "-d",
    "--decimals",
    type=int,
    default=3,
    help="The number of decimal places to keep when comparing floating point columns. Default: 3",
)
@click.option(
    "--skip-grain-check",
    is_flag=True,
    help="Disable the check for a primary key (grain) that is missing or is not unique.",
)
@click.option(
    "--warn-grain-check",
    is_flag=True,
    help="Warn if any selected model is missing a grain, and compute diffs for the remaining models.",
)
@click.option(
    "--temp-schema",
    type=str,
    help="Schema used for temporary tables. It can be `CATALOG.SCHEMA` or `SCHEMA`. Default: `vulcan_temp`",
)
@click.option(
    "--select-model",
    "-m",
    type=str,
    multiple=True,
    help="Specify one or more models to data diff. Use wildcards to diff multiple models. Ex: '*' (all models with applied plan diffs), 'demo.model+' (this and downstream models), 'git:feature_branch' (models with direct modifications in this branch only)",
)
@click.option(
    "--schema-diff-ignore-case",
    is_flag=True,
    help="If set, when performing a schema diff the case of column names is ignored when matching between the two schemas. For example, 'col_a' in the source schema and 'COL_A' in the target schema will be treated as the same column.",
)
@click.pass_obj
@error_handler
@cli_analytics
def table_diff(
    obj: Context, source_to_target: str, model: t.Optional[str], **kwargs: t.Any
) -> None:
    """Show the diff between two tables or a selection of models when they are specified."""
    source, target = source_to_target.split(":")
    select_model = kwargs.pop("select_model", None)

    if model and select_model:
        raise VulcanError(
            "The --select-model option cannot be used together with a model argument. Please choose one of them."
        )

    select_models = {model} if model else select_model
    obj.table_diff(
        source=source,
        target=target,
        select_models=select_models,
        **kwargs,
    )

# TODO: We don't use Vulcan Metrics. Tie this to our semantics model.
# @cli.command("rewrite")
# @click.argument("sql")
# @click.option(
#     "--read",
#     type=str,
#     help="The input dialect of the sql string.",
# )
# @click.option(
#     "--write",
#     type=str,
#     help="The output dialect of the sql string.",
# )
# @click.pass_obj
# @error_handler
# @cli_analytics
# def rewrite(obj: Context, sql: str, read: str = "", write: str = "") -> None:
#     """Rewrite a SQL expression with semantic references into an executable query.

#     https://sqlmesh.readthedocs.io/en/latest/concepts/metrics/overview/
#     """
#     obj.console.show_sql(
#         obj.rewrite(sql, dialect=read).sql(pretty=True, dialect=write or obj.config.dialect),
#     )


@cli.command("clean")
@click.pass_obj
@error_handler
@cli_analytics
def clean(obj: Context) -> None:
    """Clears the Vulcan cache and any build artifacts."""
    obj.clear_caches()


@cli.command("table_name")
@click.argument("model_name", required=True)
@click.option(
    "--environment",
    "--env",
    help="The environment to source the model version from.",
)
@click.option(
    "--prod",
    is_flag=True,
    default=False,
    help="If set, return the name of the physical table that will be used in production for the model version promoted in the target environment.",
)
@click.pass_obj
@error_handler
@cli_analytics
def table_name(
    obj: Context,
    model_name: str,
    environment: t.Optional[str] = None,
    prod: bool = False,
) -> None:
    """Prints the name of the physical table for the given model."""
    print(obj.table_name(model_name, environment, prod))




@cli.command("environments")
@click.pass_obj
@error_handler
@cli_analytics
def environments(obj: Context) -> None:
    """Prints the list of Vulcan environments with its expiry datetime."""
    obj.print_environment_names()


@cli.command("snapshots")
@click.pass_obj
@error_handler
@cli_analytics
def snapshots_dump(obj: Context) -> None:
    """
    (TEMP) command
    
    Print each snapshot's :class:`~vulcan.core.model.Model` as pretty JSON (stdout).

    Keys are node names. Only snapshots that wrap a model are included (standalone audits are omitted).
    ``depends_on`` and ``columns`` are filled from inferred dependencies and column types when absent from SQL.
    """

    def _model_dump_json_with_derived(model: t.Any) -> t.Dict[str, t.Any]:
        data = model.model_dump(mode="json", by_alias=True)
        dialect = getattr(model, "dialect", None)
        try:
            deps = getattr(model, "depends_on", None)
            if deps is not None:
                data["depends_on"] = sorted(deps)
        except Exception as exc:
            logger.debug("Could not derive depends_on for model dump: %s", exc)
        try:
            ctt = getattr(model, "columns_to_types", None)
            if ctt is not None:
                data["columns"] = {
                    col: dtype.sql(dialect=dialect) if hasattr(dtype, "sql") else str(dtype)
                    for col, dtype in sorted(ctt.items())
                }
        except Exception as exc:
            logger.debug("Could not derive columns for model dump: %s", exc)

        return data



    payload = {
        name: _model_dump_json_with_derived(model)
        for name, snapshot in sorted(obj.snapshots.items())
        if (model := snapshot.model_or_none) is not None
    }
    click.echo(json.dumps(payload, indent=2, ensure_ascii=False))


@cli.command("lint")
@click.option(
    "--models",
    "--model",
    multiple=True,
    help="A model to lint. Multiple models can be linted. If no models are specified, every model will be linted.",
)
@click.pass_obj
@error_handler
@cli_analytics
def lint(
    obj: Context,
    models: t.Iterator[str],
) -> None:
    """Run the linter for the target model(s)."""
    obj.lint_models(models)


@cli.group(no_args_is_help=True)
def state() -> None:
    """Commands for interacting with state"""
    pass


@state.command("export")
@click.option(
    "-o",
    "--output-file",
    required=True,
    help="Path to write the state export to",
    type=click.Path(dir_okay=False, writable=True, path_type=Path),
)
@click.option(
    "--environment",
    multiple=True,
    help="Name of environment to export. Specify multiple --environment arguments to export multiple environments",
)
@click.option(
    "--local",
    is_flag=True,
    help="Export local state only. Note that the resulting file will not be importable",
)
@click.option(
    "--no-confirm",
    is_flag=True,
    help="Do not prompt for confirmation before exporting existing state",
)
@click.pass_obj
@error_handler
@cli_analytics
def state_export(
    obj: Context,
    output_file: Path,
    environment: t.Optional[t.Tuple[str]],
    local: bool,
    no_confirm: bool,
) -> None:
    """Export the state database to a file"""
    confirm = not no_confirm

    if environment and local:
        raise click.ClickException("Cannot specify both --environment and --local")

    environment_names = list(environment) if environment else None
    obj.export_state(
        output_file=output_file,
        environment_names=environment_names,
        local_only=local,
        confirm=confirm,
    )

@state.command("import")
@click.option(
    "-i",
    "--input-file",
    help="Path to the state file",
    required=True,
    type=click.Path(exists=True, dir_okay=False, readable=True, path_type=Path),
)
@click.option(
    "--replace",
    is_flag=True,
    help="Clear the remote state before loading the file. If omitted, a merge is performed instead",
)
@click.option(
    "--no-confirm",
    is_flag=True,
    help="Do not prompt for confirmation before updating existing state",
)
@click.pass_obj
@error_handler
@cli_analytics
def state_import(obj: Context, input_file: Path, replace: bool, no_confirm: bool) -> None:
    """Import a state export file back into the state database"""
    confirm = not no_confirm
    obj.import_state(input_file=input_file, clear=replace, confirm=confirm)

@cli.command("api")
@click.option(
    "--host",
    type=str,
    # default="127.0.0.1",
    default="0.0.0.0",
    help="Bind socket to this host. Default: 0.0.0.0",
)
@click.option(
    "--port",
    type=int,
    default=8000,
    help="Bind socket to this port. Default: 8000",
)
@click.option(
    "--reload",
    is_flag=True,
    default=False,
    help="Enable auto-reload on file changes. Default: False",
)
@click.option(
    "--workers",
    type=int,
    default=1,
    help="Number of worker processes. Default: 1",
)
@click.option(
    "--migrate",
    is_flag=True,
    default=False,
    help="Run state migration before starting the API server.",
)
@click.pass_context
@error_handler
@cli_analytics
def api(ctx: click.Context, host: str, port: int, reload: bool, workers: int, migrate: bool) -> None:
    """Start the Vulcan API server (models, metrics, lineage, telemetry)."""
    from vulcan.core.console import get_console

    try:
        import uvicorn
    except ModuleNotFoundError as e:
        raise MissingDependencyError(
            "Missing API dependencies. Run `pip install -e '.[api]'` to install them."
        ) from e

    # Set environment variables for API configuration
    # ctx.obj can be either a string path (if command is in SKIP_CONTEXT_COMMANDS)
    # or a Context object (otherwise). Extract path accordingly.
    if isinstance(ctx.obj, Context):
        project_path = str(ctx.obj.path)
        console = ctx.obj.console
    else:
        project_path = str(ctx.obj)
        console = get_console()
        
    # Get parent context parameters
    parent_params = ctx.parent.params if ctx.parent else {}
    config = parent_params.get("config")
    gateway = parent_params.get("gateway")
    log_level = "debug" if parent_params.get("debug", False) else "info"
    
    os.environ["PROJECT_PATH"] = project_path
    os.environ["LOG_LEVEL"] = log_level.upper()  # Convert to uppercase for logging module
    if config:
        os.environ["CONFIG"] = config
    if gateway:
        os.environ["GATEWAY"] = gateway

    # Run with reload for development, workers for production
    if reload and workers > 1:
        console.log_warning("--reload and --workers cannot be used together. Using --reload.")
        workers = 1

    if migrate:
        if not isinstance(ctx.obj, Context):
            raise click.ClickException("--migrate requires a fully initialized context.")
        ctx.obj.migrate()

    console.log_success(
        f"Starting API server on http://{host}:{port} \n" +
        f"OpenAPI docs available at http://{host}:{port}/redoc"
    )

    uvicorn.run(
        "api.app:app",
        host=host,
        port=port,
        log_level=log_level,
        reload=reload,
        workers=workers,
        timeout_keep_alive=300,
    )


def _run_compose_service(
    *,
    service_name: str,
    compose_rel_path: Path,
    subcommand: str,
    no_detach: bool,
    extra_env: t.Dict[str, str],
    build: bool = False,
) -> None:
    """Shared helper to run docker compose for local services (transpiler, graphql, etc.)."""
    console = get_console()

    # Detect docker compose command
    try:
        cmd_base = detect_docker_compose_command()
    except RuntimeError as e:
        raise click.ClickException(str(e))

    # Resolve compose file path relative to this CLI module's repository root.
    module_root = Path(__file__).resolve().parents[2]
    compose_path = module_root / compose_rel_path

    if not compose_path.exists():
        raise click.ClickException(
            f"{service_name} docker-compose file not found at '{compose_path}'."
        )

    env = os.environ.copy()
    env.update(extra_env)

    if subcommand == "up":
        cmd: t.List[str] = cmd_base + ["-f", str(compose_path), "up"]
        if not no_detach:
            cmd.append("-d")

        # Add --build and --force-recreate if build flag is set
        if build:
            cmd.append("--build")
            cmd.append("--force-recreate")
        
        console.log_success("Starting %s ..." % service_name) 
        # console.log_success("Starting %s using docker compose: %s" % (service_name, " ".join(cmd)))

        try:
            subprocess.run(cmd, env=env, check=True)
        except FileNotFoundError as e:
            raise click.ClickException(
                "Docker executable not found. Please install Docker and ensure it is on your PATH."
            ) from e
        except subprocess.CalledProcessError as e:
            raise click.ClickException(
                "Failed to start %s via docker compose (exit code %s)." % (service_name, e.returncode)
            ) from e

        console.log_success("%s started." % service_name)

    elif subcommand == "down":
        cmd = cmd_base + ["-f", str(compose_path), "down"]
        console.log_success("Stopping %s ..." % service_name) 
        # console.log_success("Stopping %s using docker compose: %s" % (service_name, " ".join(cmd)))

        try:
            subprocess.run(cmd, env=env, check=True)
        except FileNotFoundError as e:
            raise click.ClickException(
                "Docker executable not found. Please install Docker and ensure it is on your PATH."
            ) from e
        except subprocess.CalledProcessError as e:
            raise click.ClickException(
                "Failed to stop %s via docker compose (exit code %s)." % (service_name, e.returncode)
            ) from e

        console.log_success("%s stopped." % service_name)


@cli.command("graphql")
@click.argument("subcommand", type=click.Choice(["up", "down"]))
@click.option(
    "--no-detach",
    is_flag=True,
    default=False,
    help="Run docker compose in the foreground (omit -d).",
)
@click.option(
    "--build",
    is_flag=True,
    default=False,
    help="Build images before starting containers. Automatically adds --force-recreate.",
)
@click.pass_context
@error_handler
@cli_analytics
def graphql(
    ctx: click.Context,
    subcommand: str,
    no_detach: bool,
    build: bool,
) -> None:
    """Manage the GraphQL service (subcommands: up, down)."""
    host_ip = get_host_ip()
    extra_env = {
        "VULCAN_API_URL": f"http://{host_ip}:8000",
    }

    _run_compose_service(
        service_name="GraphQL",
        compose_rel_path=Path("docker") / "compose" / "docker-compose.graphql.yml",
        subcommand=subcommand,
        no_detach=no_detach,
        extra_env=extra_env,
        build=build,
    )

@cli.command("transpile")
@click.argument("query", required=False)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["sql", "rest"], case_sensitive=False),
    required=True,
    help="Input type: semantic SQL ('sql') or REST-style semantic payload ('rest').",
)
@click.option(
    "--file",
    "query_file",
    type=str,
    help="Read query or REST payload from file. Use '-' to read from stdin.",
)
@click.option(
    "--user",
    type=str,
    default=None,
    help="User id to propagate in the X-User header (defaults to 'cli').",
)
@click.option(
    "--disable-post-processing",
    is_flag=True,
    default=False,
    help="Disable post-processing in the Transpiler.",
)
@click.option(
    "--style",
    type=click.Choice(["pretty", "compact"], case_sensitive=False),
    help=(
        "SQL output style: "
        "'pretty' (formatted with indentation), "
        "'compact' (unformatted but processed), "
    ),
)
@click.option(
    "--environment",
    "--env",
    "-e",
    type=str,
    default=None,
    help="Environment to use (default: config's default_target_environment). Requires plan to have been run.",
)
@click.pass_obj
@error_handler
@cli_analytics
def transpile_command(
    context: Context,
    query: t.Optional[str],
    fmt: str,
    query_file: t.Optional[str],
    user: t.Optional[str],
    disable_post_processing: bool,
    style: t.Optional[str],
    environment: t.Optional[str],
) -> None:
    """Transpile a semantic SQL or REST-style semantic query to executable SQL.

    Requires plan to have been run for the target environment."""
    if query_file and query:
        raise click.ClickException("Provide either QUERY or --file, not both.")
    if not query_file and not query:
        raise click.ClickException("Provide either QUERY or --file/STDIN.")

    raw: t.Optional[str]
    if query_file:
        if query_file == "-":
            raw = sys.stdin.read()
        else:
            path = Path(query_file)
            if not path.exists():
                raise click.ClickException(f"File not found: {query_file}")
            raw = path.read_text(encoding="utf-8")
    else:
        raw = query

    if raw is None:
        raise click.ClickException("No input provided.")

    if fmt.lower() == "rest":
        try:
            payload_dict = t.cast(t.Dict[str, t.Any], json.loads(raw))
            rest_query = RestQuery(**payload_dict)
            query_obj: t.Union[RestQuery, str] = rest_query
        except Exception as e:
            raise click.ClickException(f"Invalid REST payload for --format rest: {e}") from e
    else:
        if not raw.strip():
            raise click.ClickException("Empty SQL query is not allowed.")
        query_obj = raw

    user_id = user or "cli"
    env = environment or context.config.default_target_environment

    async def _run() -> None:
        import uuid

        env_obj = context.state_sync.get_environment(env)
        if not env_obj:
            available = [e.name for e in context.state_sync.get_environments()]
            raise click.ClickException(
                f"Environment '{env}' not found. Run 'vulcan plan {env}' first. "
                f"Available: {', '.join(available) if available else 'none'}"
            )

        params = get_transpiler_params_from_snapshots(context, env)
        params["request_id"] = str(uuid.uuid4())

        token = os.environ.get("DATAOS_RUN_AS_APIKEY")
        client = make_transpiler_client(context.config, token=token)
        async with client:
            try:
                reply = await client.transpile(
                    query_obj,
                    disable_post_processing=disable_post_processing,
                    user=user_id,
                    schema=params["schema"],
                    tenant_id=params["tenant_id"],
                    request_id=params["request_id"],
                    db_type=params["db_type"],
                    name=params["name"],
                )
            except TranspilerError as e:
                if e.code == 503:
                    # Transpiler is likely down / unreachable – guide the user.
                    raise click.ClickException(
                        "Failed to connect to the Transpiler service (HTTP 503).\n"
                        "Make sure the Transpiler is reachable (check transpiler.base_url). "
                        "For local dev, run `make setup-up` from the docker/ directory."
                    ) from e

                if e.code == 401:
                    raise click.ClickException(
                        "Transpiler rejected request (HTTP 401). "
                        "Set DATAOS_RUN_AS_APIKEY env var for Transpiler auth."
                    ) from e

                # Check for post-processing errors
                if e.is_post_processing_error:
                    console = get_console()
                    console.log_warning(f"Query requires post-processing: {e}")
                    console.log_success(f"Use --disable-post-processing flag")
                    return

                # Generic error handling for other cases
                detail = f"TranspilerError (HTTP {e.code}): {e}"
                if getattr(e, "response_data", None):
                    detail += f"\nDetails: {e.response_data}"
                raise click.ClickException(detail)

        sql = reply.sql_statement
        params = getattr(reply, "sql_params", None)

        if style and style.lower() in ("pretty", "compact"):
            from vulcan.utils.sql import format_sql_for_display
            sql = format_sql_for_display(
                sql,
                dialect=context.config.dialect,
                pretty=(style.lower() == "pretty"),  # pretty=False prints compact SQL
            )
        
        # Check if stdout is a pipe (for shell piping)
        import sys
        try:
            if sys.stdout.isatty():
                # Interactive terminal - use formatted console output
                console = get_console()
                console.show_sql(sql)
                if params:
                    console.log_status_update(f"Parameters: {params}")
            else:
                # Piped output - write raw SQL to stdout
                print(sql, end="")
                if params:
                    print(f"\n-- Parameters: {params}", end="")
        except BrokenPipeError:
            # Handle broken pipe gracefully (e.g., when piped to head or another command that closes early)
            # Suppress the error by closing stdout
            sys.stdout.close()
            sys.exit(0)

    asyncio.run(_run())


def _write_to_file(context: Context, path_str: str, text: str) -> None:
    out = Path(path_str).expanduser()
    try:
        out.write_text(text, encoding="utf-8")
    except OSError as e:
        raise click.ClickException(str(e)) from e
    context.console.log_success(f"Wrote to {out}")


@cli.group("export")
def export_group() -> None:
    """Export cube, semantic, or metadata payloads for an environment (YAML written to FILE)."""


@export_group.command("cube")
@click.option(
    "-e",
    "--environment",
    "--env",
    type=str,
    default=None,
    help=(
        "Environment to export (defaults to config default_target_environment). "
        "Requires the environment to exist in state (after plan)."
    ),
)
@click.argument("file")
@click.pass_obj
@error_handler
@cli_analytics
def export_cube(
    context: Context,
    environment: t.Optional[str],
    file: str,
) -> None:
    """Export the cube schema for the target environment as YAML to FILE."""
    try:
        schema = context.cube_schema_for_environment(environment)
        _write_to_file(
            context,
            file,
            pydantic_to_yaml(schema, lean=True, omit_defaults=True),
        )
    except VulcanError as e:
        raise click.ClickException(str(e)) from e

    


@export_group.command("semantic")
@click.option(
    "-e",
    "--environment",
    "--env",
    type=str,
    default=None,
    help=(
        "Environment to export (defaults to config default_target_environment). "
        "Requires the environment to exist in state (after plan)."
    ),
)
@click.argument("file")
@click.pass_obj
@error_handler
@cli_analytics
def export_semantic(
    context: Context,
    environment: t.Optional[str],
    file: str,
) -> None:
    """Export the semantic schema (catalog) for the target environment as YAML to FILE."""
    try:
        schema = context.semantic_schema_for_environment(environment)
        _write_to_file(context, file, pydantic_to_yaml(schema, lean=True))
    except VulcanError as e:
        raise click.ClickException(str(e)) from e


@export_group.command("metadata")
@click.option(
    "-e",
    "--environment",
    "--env",
    type=str,
    default=None,
    help=(
        "Environment to export (defaults to config default_target_environment). "
        "Requires the environment to exist in state (after plan)."
    ),
)
@click.argument("file")
@click.pass_obj
@error_handler
@cli_analytics
def export_metadata(
    context: Context,
    environment: t.Optional[str],
    file: str,
) -> None:
    """Export environment metadata (models, semantics, product, gateway) as YAML to FILE."""
    try:
        schema = context.metadata_for_environment(environment=environment)
        _write_to_file(
            context,
            file,
            pydantic_to_yaml(schema, lean=True, json_dump=True),
        )
    except VulcanError as e:
        raise click.ClickException(str(e)) from e


@cli.command("create_deploy_yaml")
@click.option(
    "--output",
    "-o",
    type=str,
    default=None,
    help=(
        "Output path for the generated DataOS Vulcan resource YAML. "
        "Defaults to '<project_name>-deploy.yaml' in the project root."
    ),
)
@click.option("--overwrite", is_flag=True, help="Overwrite the output file if it already exists.")
@click.pass_obj
@error_handler
@cli_analytics
def create_deploy_yaml(context: t.Union[Context, str], output: t.Optional[str], overwrite: bool) -> None:
    """Generate a DataOS Vulcan resource deploy YAML for the current project."""
    from pathlib import Path
    import re
    from vulcan.core.config.loader import load_config_from_yaml

    project_root = Path(context.path).absolute() if isinstance(context, Context) else Path(str(context)).absolute()
    raw_config = load_config_from_yaml(project_root / "config.yaml")
    out_path = Path(output).expanduser() if output else (project_root / f"{raw_config.get('name')}-deploy.yaml")
    if not out_path.is_absolute():
        out_path = project_root / out_path

    if out_path.exists() and not overwrite:
        raise click.ClickException(
            f"Output file already exists: {out_path}. Use --overwrite to replace it."
        )

    def _yaml_quote_scalar(value: t.Optional[str]) -> str:
        s = (value or "").replace("\\", "\\\\").replace('"', '\\"')
        return f'"{s}"'

    def _to_k8s_cron(expr: str) -> str:
        """
        Convert common cron nicknames to Kubernetes CronJob-compatible 5-field cron expressions.

        Kubernetes does NOT support nicknames like '@daily'.
        """
        e = (expr or "").strip().lower()
        mapping = {
            "@hourly": "0 * * * *",
            "@daily": "0 0 * * *",
            "@midnight": "0 0 * * *",
            "@weekly": "0 0 * * 0",
            "@monthly": "0 0 1 * *",
            "@yearly": "0 0 1 1 *",
            "@annually": "0 0 1 1 *",
        }
        return mapping.get(e, expr)

    crons: t.Set[str] = set()
    models_dir = project_root / "models"
    if models_dir.exists():
        for path in models_dir.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".sql", ".py"}:
                continue
            text = path.read_text(encoding="utf-8")
            for match in re.finditer(r"cron\s*\(?\s*['\"]([^'\"]+)['\"]", text):
                crons.add(_to_k8s_cron(match.group(1)))
    if not crons and (raw_config.get("model_defaults") or {}).get("cron"):
        crons.add(_to_k8s_cron(str((raw_config.get("model_defaults") or {}).get("cron"))))
    if not crons:
        crons.add("0 0 * * *")
    cron_list = sorted(crons)

    tags = [str(tag) for tag in (raw_config.get("tags") or [])]
    tags_yaml = "\n".join([f"  - {t}" for t in tags]) if tags else "  -"

    crons_yaml = "\n".join([f"        - '{c}'" for c in cron_list])
    tenant = str(raw_config.get("tenant") or "<tenant>")
    gateways = raw_config.get("gateways") or {}
    default_gateway_name = str(raw_config.get("default_gateway") or "default")
    default_gateway = gateways.get(default_gateway_name) if isinstance(gateways, dict) else {}
    connection = default_gateway.get("connection") if isinstance(default_gateway, dict) else {}
    depot_address = ""
    if isinstance(connection, dict) and connection.get("type") == "depot":
        from urllib.parse import urlparse

        raw_depot_address = str(connection.get("address") or "").strip()
        parsed_depot_address = urlparse(raw_depot_address)
        if parsed_depot_address.scheme and parsed_depot_address.netloc:
            depot_address = raw_depot_address if parsed_depot_address.query else (
                f"{parsed_depot_address.scheme}://{parsed_depot_address.netloc}?purpose=<purpose>"
            )
        else:
            depot_address = raw_depot_address
    depot_section = (
        "  depots: # Use this if you are using depot for the type depot in config.yaml\n"
        f"    - {depot_address or '<dataos://<depot-name>?purpose=rw>'}\n"
        if depot_address
        else ""
    )
    connection_type = str(connection.get("type") or "").strip() if isinstance(connection, dict) else ""
    dialect = str((raw_config.get("model_defaults") or {}).get("dialect") or "").strip()
    if dialect.startswith("spark") or connection_type == "spark":
        engine = "spark"
    else:
        engine = connection_type if connection_type and connection_type != "depot" else dialect
    spark_workflow_resource_yaml = """    resource: #optional
      driver:
        coreLimit: "<core-limit>" # '1'
        cores: "<cores>"
        memory: "<memory>"
      executor:
        coreLimit: "<core-limit>" # '1'
        cores: "<cores>"
        memory: "<memory>"
        instances: "<instances>"

    sparkConf:
      spark.sql.shuffle.partitions: "16"
      spark.sql.adaptive.coalescePartitions.enabled: "true"
"""
    spark_api_resource_yaml = """    resource: #optional
      driver:
        coreLimit: "<core-limit>" # '1'
        cores: "<cores>"
        memory: "<memory>"
      executor:
        coreLimit: "<core-limit>" # '1'
        cores: "<cores>"
        memory: "<memory>"
        instances: "<instances>"

    sparkConf:
      spark.sql.shuffle.partitions: "16"
      spark.sql.adaptive.coalescePartitions.enabled: "true"
"""
    generic_workflow_resource_yaml = """    resource: #optional
      request:
        cpu: "<cpu-request>" # '200m'
        memory: "<memory-request>" # '512Mi'
      limit:
        cpu: "<cpu-limit>" # '1000m'
        memory: "<memory-limit>" # '1Gi'
"""
    generic_api_resource_yaml = """    resource:
      request:
        cpu: "<cpu-request>" # '200m'
        memory: "<memory-request>" # '512Mi'
      limit:
        cpu: "<cpu-limit>" # '1000m'
        memory: "<memory-limit>" # '1Gi'
"""
    workflow_resource_yaml = spark_workflow_resource_yaml if engine == "spark" else generic_workflow_resource_yaml
    api_resource_yaml = spark_api_resource_yaml if engine == "spark" else generic_api_resource_yaml
    resource_name = str(raw_config.get("name") or "").strip()
    poros_entity_name_fmt = r"^[a-z]([-a-z0-9]*[a-z0-9])?$"
    if len(resource_name) > 60 or not re.fullmatch(poros_entity_name_fmt, resource_name):
        raise click.ClickException(
            "Invalid DataOS resource name derived from config.yaml `name`.\n"
            f"Got: {resource_name!r}\n"
            "Rule: must be <= 60 chars, lowercase, start with a letter, and only contain "
            "letters/digits plus '-'; must end with a letter or digit.\n"
            f"Regex: {poros_entity_name_fmt}\n"
            "Action: Correct `name` in config.yaml and re-run `vulcan create_deploy_yaml`."
        )

    payload = f"""version: v1alpha
type: vulcan
name: {resource_name}
description: {_yaml_quote_scalar(str(raw_config.get("description") or ""))}
tags:
{tags_yaml}
spec:
  runAsUser: <Optional> # only add if you want to run as a specific user
  compute: general-purpose-shared # check available computes using dataos CLI
  engine: {engine or '<based on the project config.yaml>'}
  repo:
    url: <git repo url>
    syncFlags:
      - '--ref=main' # change to the branch you want to deploy
      - '--submodules=off' # change if you want to sync submodules
    baseDir: <repo-name>/<path-to-the-project>
    secret: {tenant}.<secret-name> # optional: if repo is private, create tenant secret and use it here
{depot_section}  use: # Use this section if you are using the connection of source type without depot
    projection:
      secrets:
        - id: {tenant}.<secret-name>
          contextAlias: <secret-alias>
      projections:
        envVars:
          - key: <PROJECT_ENV_VAR_NAME>
            template: "{{{{ secrets[<secret-alias>].<SECRET_KEY> | base64_decode }}}}"

  workflow:
    schedule:
      crons:
{crons_yaml}
      endOn: '<end-date-in-ISO-8601-format>' # '2027-01-01T00:00:00-00:00'
      timezone: '<timezone>' # 'US/Pacific'
      concurrencyPolicy: Forbid

    logLevel: INFO #default
{workflow_resource_yaml}

    #NOTE: - refer document for vulcan commands - https://tmdc-io.github.io/vulcan-book/cli-commands/cli/
    plan:
      command:
        - vulcan
      arguments:
        - plan
        - --auto-apply
    run:
      command:
        - vulcan
      arguments:
        - run

  api:
    replicas: 1
    logLevel: INFO
{api_resource_yaml}
"""

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(payload, encoding="utf-8")
    click.echo(f"Generated deploy YAML: {out_path}")
