"""Add check suite tables for Soda integration.

This migration creates 6 tables for comprehensive data quality management:
1. _check_runs: Scan execution metadata
2. _check_results: Individual check outcomes with full diagnostics (includes embedded samples)
3. _checks_definitions: Distinct check catalog for fast list_checks (no scan of _check_results)
4. _check_metrics: Typed metric measurements (text, number, JSON)
5. _profiles: Column profiling statistics
6. _check_feedbacks: User feedback for ML training and investigations

Note: samples now embedded directly in check diagnostics.

Design inspired by Cola (Soda's reference implementation) with Vulcan-specific enhancements.
"""

from sqlglot import exp

from vulcan.utils.migration import blob_text_type, index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create all check-related tables for data quality monitoring."""
    check_results_table = "_check_results"
    checks_definitions_table = "_checks_definitions"
    check_metrics_table = "_check_metrics"
    profiles_table = "_profiles"
    check_feedbacks_table = "_check_feedbacks"
    
    if schema:
        check_results_table = f"{schema}.{check_results_table}"
        checks_definitions_table = f"{schema}.{checks_definitions_table}"
        check_metrics_table = f"{schema}.{check_metrics_table}"
        profiles_table = f"{schema}.{profiles_table}"
        check_feedbacks_table = f"{schema}.{check_feedbacks_table}"

    index_type = index_text_type(engine_adapter.dialect)
    blob_type = blob_text_type(engine_adapter.dialect)

    # =========================================================================
    # Table 1: _check_results
    # =========================================================================
    # Note: _check_runs table removed - quality data now in _activity_run_executions

    # All check metadata lives in _checks_definitions; _check_results stores only run-specific
    # outcome data (outcome, outcome_reasons, diagnostics).
    check_results_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "start_ts": exp.DataType.build("bigint"),
        "end_ts": exp.DataType.build("bigint"),
        "check_identity": exp.DataType.build(index_type),
        "outcome": exp.DataType.build("text"),
        "outcome_reasons": exp.DataType.build("text"),
        "diagnostics": exp.DataType.build("text"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        check_results_table,
        check_results_columns_to_types,
        primary_key=("id",),
        table_description="Individual check outcomes with full diagnostics",
        column_descriptions={
            "id": "Unique check result UUID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "start_ts": "Scan start time (Unix ms)",
            "end_ts": "Scan end time (Unix ms)",
            "check_identity": "Soda check identity hash (links to _checks_definitions)",
            "outcome": "Check result: pass, warn, fail, error",
            "outcome_reasons": "JSON array of outcome reasons",
            "diagnostics": "Complete diagnostics JSON",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    # run_id: list_runs (quality_checks CTE)
    engine_adapter.create_index(
        check_results_table,
        "_check_results_run_idx",
        ("run_id",),
    )
    # check_identity: get_historic_check_results (single-check lookup)
    engine_adapter.create_index(
        check_results_table,
        "_check_results_identity_idx",
        ("check_identity",),
    )
    # list_checks ranked CTE: filter (environment, check_identity) + start_ts range, ORDER BY start_ts DESC
    engine_adapter.create_index(
        check_results_table,
        "_check_results_list_checks_idx",
        ("environment", "check_identity", "start_ts"),
    )
    
    # Add NOT NULL constraint to check_identity (required - Soda always provides it)
    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {check_results_table} ALTER COLUMN check_identity SET NOT NULL"
        )

    # =========================================================================
    # Table 2: _checks_definitions
    # =========================================================================
    # Distinct check catalog for fast list_checks. Maintained in app layer when
    # writing to _check_results. PK (check_identity, environment).

    checks_definitions_columns_to_types = {
        "check_identity": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "check_name": exp.DataType.build("text"),
        "check_type": exp.DataType.build("text"),
        "column_name": exp.DataType.build("text"),
        "dimension": exp.DataType.build("text"),
        "definition": exp.DataType.build("text"),
        "model_name": exp.DataType.build(index_type),
        "resource_attributes": exp.DataType.build("text"),
        "location": exp.DataType.build("text"),
        "group_by": exp.DataType.build("text"),
        "filter": exp.DataType.build("text"),
        "metrics": exp.DataType.build("text"),
        "archetype": exp.DataType.build("text"),
        "updated_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        checks_definitions_table,
        checks_definitions_columns_to_types,
        primary_key=("check_identity", "environment"),
        table_description="Distinct check catalog for fast list_checks",
        column_descriptions={
            "check_identity": "Soda check identity hash (stable across runs)",
            "environment": "Vulcan environment name",
            "check_name": "Human-readable check name",
            "check_type": "Check type (anomaly_detection, missing_count, etc.)",
            "column_name": "Column name for column-level checks",
            "dimension": "ODCS dimension (completeness, validity, etc.)",
            "definition": "Original SodaCL check definition",
            "model_name": "Logical model name (e.g., b2b_saas.users)",
            "resource_attributes": "JSON metadata (dimension, team, tags)",
            "location": "JSON file location (filePath, line, col)",
            "group_by": "JSON GROUP BY clauses",
            "filter": "Partition/WHERE clause filter",
            "metrics": "JSON array of metric identities",
            "archetype": "Automated monitoring archetype",
            "updated_ts": "Last update time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        checks_definitions_table,
        "_checks_definitions_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        checks_definitions_table,
        "_checks_definitions_list_idx",
        ("environment", "model_name", "column_name", "check_name"),
    )
    # Unique: check_name unique within (environment, model_name, dimension) per loader
    if engine_adapter.SUPPORTS_INDEXES:
        engine_adapter.execute(
            exp.Create(
                this=exp.Index(
                    this=exp.to_identifier("_checks_definitions_check_name_unique_idx"),
                    table=exp.to_table(checks_definitions_table),
                    params=exp.IndexParameters(
                        columns=[
                            exp.to_column("environment"),
                            exp.to_column("model_name"),
                            exp.to_column("dimension"),
                            exp.to_column("check_name"),
                        ]
                    ),
                ),
                kind="UNIQUE INDEX",
                exists=True,
            )
        )

    # =========================================================================
    # Table 3: _check_metrics
    # =========================================================================

    check_metrics_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "check_id": exp.DataType.build(index_type),
        "check_identity": exp.DataType.build(index_type),
        "metric_identity": exp.DataType.build(index_type),
        "metric_name": exp.DataType.build(index_type),
        "model_name": exp.DataType.build(index_type),
        "column_name": exp.DataType.build("text"),
        "partition_name": exp.DataType.build("text"),
        "value_text": exp.DataType.build("text"),
        "value_number": exp.DataType.build("numeric"),
        "value_json": exp.DataType.build("text"),
        "value_type": exp.DataType.build("text"),
        "measured_at": exp.DataType.build("bigint"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        check_metrics_table,
        check_metrics_columns_to_types,
        primary_key=("id",),
        table_description="Metric measurements with typed storage for time-series analysis",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "check_id": "Links to _check_results.id (NULL for standalone metrics)",
            "check_identity": "Soda check identity hash",
            "metric_identity": "Soda metric identity",
            "metric_name": "Metric name (row_count, missing_count, avg, etc.)",
            "model_name": "Logical model name",
            "column_name": "Column name for column-level metrics",
            "partition_name": "Partition identifier",
            "value_text": "String metric value",
            "value_number": "Numeric metric value (most common)",
            "value_json": "Complex metric value (histograms, arrays)",
            "value_type": "Type discriminator: text, number, or json",
            "measured_at": "Measurement time (Unix ms)",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_check_idx",
        ("check_id",),
    )
    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_identity_idx",
        ("check_identity", "measured_at"),
    )
    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_metric_identity_idx",
        ("metric_identity", "measured_at"),
    )
    engine_adapter.create_index(
        check_metrics_table,
        "_check_metrics_name_idx",
        ("metric_name", "model_name", "measured_at"),
    )
    
    # Add NOT NULL constraint to check_identity (required - Soda always provides it)
    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {check_metrics_table} ALTER COLUMN check_identity SET NOT NULL"
        )

    # =========================================================================
    # Table 4: _profiles
    # =========================================================================

    check_profiles_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "model_name": exp.DataType.build(index_type),
        "column_name": exp.DataType.build("text"),
        "profile_type": exp.DataType.build("text"),
        "value_text": exp.DataType.build("text"),
        "value_number": exp.DataType.build("numeric"),
        "value_json": exp.DataType.build("text"),
        "value_type": exp.DataType.build("text"),
        "profiled_at": exp.DataType.build("bigint"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        profiles_table,
        check_profiles_columns_to_types,
        primary_key=("id",),
        table_description="Column profiling statistics for automatic check generation",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "model_name": "Logical model name being profiled",
            "column_name": "Column name (NULL for table-level profiles)",
            "profile_type": "Statistic type (min, max, avg, distinct_count, etc.)",
            "value_text": "String profile values",
            "value_number": "Numeric profile values",
            "value_json": "Complex profile values (histograms, frequencies)",
            "value_type": "Type discriminator: text, number, or json",
            "profiled_at": "Profiling time (Unix ms)",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        profiles_table,
        "_profiles_table_column_idx",
        ("model_name", "column_name", "profiled_at"),
    )
    engine_adapter.create_index(
        profiles_table,
        "_profiles_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        profiles_table,
        "_profiles_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        profiles_table,
        "_profiles_type_idx",
        ("profile_type",),
    )

    # =========================================================================
    # Table 5: _check_feedbacks
    # =========================================================================

    check_feedbacks_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "check_id": exp.DataType.build(index_type),
        "check_identity": exp.DataType.build(index_type),
        "measurement_id": exp.DataType.build(index_type),
        "feedback_type": exp.DataType.build("text"),
        "feedback_category": exp.DataType.build("text"),
        "is_correctly_classified": exp.DataType.build("boolean"),
        "is_anomaly": exp.DataType.build("boolean"),
        "seasonality_reason": exp.DataType.build("text"),
        "skip_measurements": exp.DataType.build("text"),
        "feedback_text": exp.DataType.build("text"),
        "metadata_json": exp.DataType.build("text"),
        "user_id": exp.DataType.build("text"),
        "created_ts": exp.DataType.build("bigint"),
        "updated_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        check_feedbacks_table,
        check_feedbacks_columns_to_types,
        primary_key=("id",),
        table_description="User feedback on checks for ML training and suppression",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "check_id": "Links to _check_results.id",
            "check_identity": "Soda check identity hash",
            "measurement_id": "Links to _check_metrics.id (optional)",
            "feedback_type": "Specific feedback type (anomaly_false_positive, etc.)",
            "feedback_category": "High-level category (ml_training, investigation)",
            "is_correctly_classified": "Was anomaly detection correct?",
            "is_anomaly": "Is this truly an anomaly?",
            "seasonality_reason": "Structured seasonality type for ML training",
            "skip_measurements": "Measurements to exclude (this, previous, previousAndThis)",
            "feedback_text": "Free-form comment from user",
            "metadata_json": "Extensible JSON (ticket refs, thresholds)",
            "user_id": "Who provided feedback (email, username, user ID)",
            "created_ts": "Feedback creation time (Unix ms)",
            "updated_ts": "Last update time (Unix ms, allows editing)",
        },
    )

    engine_adapter.create_index(
        check_feedbacks_table,
        "_feedback_check_idx",
        ("check_id",),
    )
    engine_adapter.create_index(
        check_feedbacks_table,
        "_feedback_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        check_feedbacks_table,
        "_feedback_identity_idx",
        ("check_identity",),
    )
    engine_adapter.create_index(
        check_feedbacks_table,
        "_feedback_type_idx",
        ("feedback_type", "created_ts"),
    )
    engine_adapter.create_index(
        check_feedbacks_table,
        "_feedback_category_idx",
        ("feedback_category",),
    )
    
    # Add NOT NULL constraint to check_identity (required - Soda always provides it)
    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {check_feedbacks_table} ALTER COLUMN check_identity SET NOT NULL"
        )


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new tables."""
    pass
