"""API middleware module.

Provides middleware components for request processing.

Components:
- auth: Authorization middleware using Heimdall service
- metrics: Prometheus metrics middleware for semantic query endpoints
"""

from api.middleware.auth import AuthorizationMiddleware
from api.middleware.metrics import VulcanMetricsMiddleware

__all__ = [
    "AuthorizationMiddleware",
    "VulcanMetricsMiddleware",
]

