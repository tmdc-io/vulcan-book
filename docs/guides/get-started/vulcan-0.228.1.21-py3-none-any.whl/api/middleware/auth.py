"""Authorization middleware using Heimdall service.

This middleware intercepts all incoming requests (except excluded paths),
extracts the Bearer token from the Authorization header, and validates it
via the Heimdall authorization service.

The shared ``HeimdallClient`` is owned by the FastAPI lifespan and stored
on ``app.state.heimdall_client``; this middleware reads it per request so
we never construct an ``httpx.AsyncClient`` on the hot path and never risk
concurrent first-requests racing client creation.

Usage:
    from api.middleware import AuthorizationMiddleware

    app.add_middleware(
        AuthorizationMiddleware,
        enabled=True,  # Set False for local dev
    )

Environment Variables:
    HEIMDALL_BASE_URL: Heimdall service base URL (read by lifespan)
    HEIMDALL_TIMEOUT: Request timeout in seconds (read by lifespan)
    HEIMDALL_ENABLED: Enable/disable auth (default: true, set "false" for local dev)
"""

from __future__ import annotations

import logging
from typing import Optional, Set

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from api.clients.heimdall.client import HeimdallException

from vulcan.core.observability.facade import emit_policy_evaluation

logger = logging.getLogger(__name__)


class AuthorizationMiddleware(BaseHTTPMiddleware):
    """Middleware to authorize requests via Heimdall service.

    Validates Bearer tokens in the Authorization header against Heimdall.
    Requests without valid tokens are rejected with 401 Unauthorized.
    Requests with valid but not allowed tokens are rejected with 403 Forbidden.

    On successful authentication, stores user info in request.state:
    - request.state.user_id: User identifier (e.g., "akshayjaintmdcio")
    - request.state.user_tags: List of roles/permissions (e.g., ["roles:id:operator"])

    The Heimdall client lifecycle is owned by the FastAPI lifespan, which
    stores the shared client on ``app.state.heimdall_client``.  This
    middleware is stateless with respect to that client and reads it on
    each request.

    Attributes:
        enabled: Whether authorization is enabled
        excluded_paths: Paths to skip authorization (health checks, docs)
        excluded_prefixes: Path prefixes to skip authorization
    """

    # Paths that don't require authorization (health checks, docs, OpenAPI)
    DEFAULT_EXCLUDED_PATHS: Set[str] = {
        "/livez",
        "/readyz",
        "/docs",
        "/redoc",
        "/openapi.json",
    }

    # Path prefixes that don't require authorization (internal service-to-service endpoints).
    # These are used by Transpiler, MySQL server, etc. for internal communication; they
    # MUST NOT accept Heimdall tokens because:
    #   * ``/api/v1/_internal`` — diagnostic + runtime debug endpoints; must stay
    #     reachable even when Heimdall is down to support incident response.
    #   * ``/api/v1/queue``     — PGQ queue control plane used by the Vulcan worker;
    #     the worker ships internal service credentials, not Heimdall tokens.
    #   * ``/api/v1/files``     — presigned-URL proxy; auth is enforced at the object
    #     store layer, not Heimdall, so a Heimdall check here is dead weight that
    #     doubles the auth round-trip per presigned download.
    DEFAULT_EXCLUDED_PREFIXES: Set[str] = {
        "/api/v1/_internal",
        "/api/v1/queue",
        "/api/v1/files",
    }

    def __init__(
        self,
        app: ASGIApp,
        enabled: bool = True,
        excluded_paths: Optional[Set[str]] = None,
    ):
        """Initialize authorization middleware.

        Args:
            app: ASGI application
            enabled: Whether to enable authorization (set False for local dev)
            excluded_paths: Additional paths to exclude from authorization
        """
        super().__init__(app)
        self.enabled = enabled
        self.excluded_paths = self.DEFAULT_EXCLUDED_PATHS.copy()
        self.excluded_prefixes = self.DEFAULT_EXCLUDED_PREFIXES.copy()
        if excluded_paths:
            self.excluded_paths.update(excluded_paths)

        if self.enabled:
            logger.info(
                "Authorization middleware enabled (excluded paths: %s, excluded prefixes: %s)",
                self.excluded_paths, self.excluded_prefixes
            )
        else:
            logger.warning(
                "Authorization middleware DISABLED (HEIMDALL_ENABLED=false) - "
                "all requests allowed without authentication"
            )

    async def dispatch(self, request: Request, call_next):
        """Process request through authorization.

        Args:
            request: Incoming request
            call_next: Next middleware/handler

        Returns:
            Response from handler or error response
        """
        # Skip authorization if disabled
        if not self.enabled:
            return await call_next(request)

        # Skip excluded paths (health checks, docs)
        if request.url.path in self.excluded_paths:
            return await call_next(request)

        # Skip excluded prefixes (internal service-to-service endpoints)
        for prefix in self.excluded_prefixes:
            if request.url.path.startswith(prefix):
                return await call_next(request)

        # Extract Authorization header
        auth_header = request.headers.get("Authorization")

        if not auth_header:
            logger.debug("Missing Authorization header for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=401,
                content={
                    "status": 401,
                    "error": {
                        "code": "COMMON.AUTH.UNAUTHORIZED",
                        "message": "Missing Authorization header. Expected: Bearer <token>",
                    },
                },
            )

        # Validate Bearer token format
        if not auth_header.lower().startswith("bearer "):
            logger.debug("Invalid Authorization format for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=401,
                content={
                    "status": 401,
                    "error": {
                        "code": "COMMON.AUTH.UNAUTHORIZED",
                        "message": "Invalid Authorization format. Expected: Bearer <token>",
                    },
                },
            )

        # The lifespan is responsible for constructing the shared client and
        # placing it on ``app.state``.  A missing client with auth enabled is
        # a bootstrap / configuration bug: fail closed with 503 rather than
        # silently allowing traffic or constructing a new client on the hot
        # path.
        client = getattr(request.app.state, "heimdall_client", None)
        if client is None:
            logger.critical(
                "Heimdall client missing from app.state while authorization is enabled; "
                "refusing %s %s",
                request.method, request.url.path,
            )
            return JSONResponse(
                status_code=503,
                content={
                    "status": 503,
                    "error": {
                        "code": "COMMON.INTERNAL.ERROR",
                        "message": "Authorization service unavailable",
                    },
                },
            )

        import time as _time
        _auth_start = _time.perf_counter()
        try:
            auth_response = await client.authorize(auth_header)
            _auth_duration = _time.perf_counter() - _auth_start

            # Check if token is valid
            if not auth_response.valid:
                logger.warning(
                    "Invalid token for %s %s: %s",
                    request.method, request.url.path, auth_response.error_message
                )
                emit_policy_evaluation(_auth_duration, denied=True, reason="invalid_token")
                return JSONResponse(
                    status_code=401,
                    content={
                        "status": 401,
                        "error": {
                            "code": "COMMON.AUTH.INVALID_TOKEN",
                            "message": auth_response.error_message or "Invalid token",
                        },
                    },
                )

            # Check if operation is allowed
            if not auth_response.allow:
                logger.warning(
                    "Access denied for user %s on %s %s",
                    auth_response.user_id, request.method, request.url.path
                )
                emit_policy_evaluation(_auth_duration, denied=True, reason="access_denied")
                return JSONResponse(
                    status_code=403,
                    content={
                        "status": 403,
                        "error": {
                            "code": "COMMON.AUTH.FORBIDDEN",
                            "message": "Access denied",
                        },
                    },
                )

            # Store user info in request state for downstream handlers
            # This replaces the dummy X-User header approach
            request.state.user_id = auth_response.user_id
            request.state.user_tags = auth_response.user_tags

            emit_policy_evaluation(_auth_duration)

            logger.debug(
                "Authorized user %s for %s %s",
                auth_response.user_id, request.method, request.url.path
            )

            # Proceed to next handler
            return await call_next(request)
        except HeimdallException as e:
            _auth_duration = _time.perf_counter() - _auth_start
            logger.error(
                "Heimdall authorization failed for %s %s: %s",
                request.method,
                request.url.path,
                e,
                exc_info=True,
            )
            emit_policy_evaluation(_auth_duration, denied=True, reason=e.error_code)
            return JSONResponse(
                status_code=e.status_code,
                content={
                    "status": 503,
                    "error": {
                        "code": "COMMON.INTERNAL.ERROR",
                        "message": "Authorization service unavailable",
                    },
                },
            )
        except Exception:
            raise
