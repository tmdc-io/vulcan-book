"""Prometheus metrics middleware for the Vulcan API server.

Records request-level metrics (semantic query duration, cache hits, etc.)
into the shared push registry.  A background pusher thread flushes these
to the Pushgateway periodically — individual requests do NOT push.

Usage:
    from api.middleware.metrics import VulcanMetricsMiddleware

    app.add_middleware(VulcanMetricsMiddleware, tenant="acme", data_product="b2b_saas")
"""

from __future__ import annotations

import logging
import time
import typing as t

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger(__name__)

_METRICS_LOADED = False
_metrics: t.Dict[str, t.Any] = {}


def _load_metrics() -> bool:
    global _METRICS_LOADED, _metrics
    if _METRICS_LOADED:
        return True
    try:
        from vulcan.core.observability.metrics import (
            vulcan_semantic_query_duration_seconds,
            vulcan_semantic_query_total,
            vulcan_semantic_query_overhead_seconds,
            vulcan_cache_hit_total,
            vulcan_cache_miss_total,
        )
        _metrics = dict(
            query_duration=vulcan_semantic_query_duration_seconds,
            query_total=vulcan_semantic_query_total,
            query_overhead=vulcan_semantic_query_overhead_seconds,
            cache_hit=vulcan_cache_hit_total,
            cache_miss=vulcan_cache_miss_total,
        )
        _METRICS_LOADED = True
        return True
    except Exception:
        return False


class VulcanMetricsMiddleware(BaseHTTPMiddleware):
    """Record per-request Prometheus metrics for semantic query endpoints.

    Metrics are accumulated in-memory; the background pusher (started in
    lifespan) flushes them to Pushgateway every N seconds.
    """

    QUERY_PATH_PREFIXES = (
        "/api/v1/query",
        "/api/v1/perspectives",
    )

    def __init__(
        self,
        app: ASGIApp,
        tenant: str,
        data_product: str,
    ):
        super().__init__(app)
        self.tenant = tenant
        self.data_product = data_product

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        if not _load_metrics():
            return await call_next(request)

        path = request.url.path
        is_query = any(path.startswith(p) for p in self.QUERY_PATH_PREFIXES)
        if not is_query:
            return await call_next(request)

        api = "rest"
        if "/graphql" in path:
            api = "graphql"

        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start

        engine = "unknown"
        status = "success" if response.status_code < 400 else "error"
        base = dict(tenant=self.tenant, data_product=self.data_product)

        _metrics["query_duration"].labels(**base, engine=engine, api=api).observe(elapsed)
        _metrics["query_total"].labels(**base, engine=engine, api=api, status=status).inc()
        _metrics["query_overhead"].labels(**base, api=api).observe(elapsed)

        cache_status = getattr(request.state, "cache_status", None)
        if cache_status == "HIT":
            _metrics["cache_hit"].labels(**base, api=api).inc()
        elif cache_status == "MISS":
            _metrics["cache_miss"].labels(**base, api=api).inc()

        return response
