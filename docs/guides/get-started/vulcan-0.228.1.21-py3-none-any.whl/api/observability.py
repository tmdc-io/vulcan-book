from __future__ import annotations

import asyncio
import typing as t

from vulcan.core.observability.push_gateway import (
    get_base_labels,
    is_enabled,
    set_base_labels,
    set_job,
    start_metrics_pusher,
    start_queue_depth_poller,
)


async def init_api_observability(
    tenant: str,
    data_product: str,
    queue_manager: t.Any,
) -> t.Optional[t.Any]:
    if not is_enabled():
        return None

    set_job("vulcan-api")
    set_base_labels(tenant, data_product)
    start_metrics_pusher(interval=10)
    bl = get_base_labels()
    return asyncio.create_task(
        start_queue_depth_poller(
            queue_manager=queue_manager,
            tenant=bl["tenant"],
            data_product=bl["data_product"],
        )
    )
