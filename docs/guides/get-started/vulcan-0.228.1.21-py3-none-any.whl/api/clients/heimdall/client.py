"""Heimdall authorization client.

Provides HTTP client for communicating with the Heimdall authorization service.
Used by the authorization middleware to validate Bearer tokens.

Usage:
    from api.clients.heimdall import HeimdallClient
    
    async with HeimdallClient(base_url="https://example.dataos.app/heimdall") as client:
        response = await client.authorize(token="Bearer xxx")
        if response.valid and response.allow:
            user_id = response.user_id
            user_tags = response.user_tags
"""

from __future__ import annotations

import logging
from typing import Optional

import httpx
from pydantic import ValidationError

from api.clients.heimdall.models import AuthorizeResponse
from api.utils.env import (
    parse_optional_positive_int_env,
    parse_positive_float_env,
)

logger = logging.getLogger(__name__)


class HeimdallException(Exception):
    """Heimdall authorization failure which should surface as a 503 to callers."""

    def __init__(
        self,
        *,
        status_code: int = 503,
        error_code: str = "AUTH_SERVICE_UNAVAILABLE",
        msg: str = "Authorization service unavailable",
        details: dict | None = None,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        self.msg = msg
        self.details = details or {}
        super().__init__(msg)


class HeimdallClient:
    """HTTP client for Heimdall authorization service.
    
    Attributes:
        base_url: Heimdall service base URL (e.g., "https://glacier-121525.dataos.app/heimdall")
        timeout: Request timeout in seconds (default: 10)
    """
    
    def __init__(
        self,
        base_url: str,
        timeout: float = 10.0,
    ):
        """Initialize Heimdall client.
        
        Args:
            base_url: Heimdall service base URL
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self) -> "HeimdallClient":
        """Async context manager entry.

        ``httpx.Limits`` is wired through env vars so ops can size the pool
        per environment without touching code.  Defaults intentionally match
        httpx's built-in behaviour (no explicit caps, 5 s keepalive expiry)
        to preserve pre-DATAOS-1031 semantics; operators opt in to bounded
        pools by setting ``VULCAN_HEIMDALL_POOL_*``.  All three knobs fall
        back to their default on malformed input (see :mod:`api.utils.env`).
        """
        max_connections = parse_optional_positive_int_env(
            "VULCAN_HEIMDALL_POOL_MAX", default=None, floor=10, ceiling=1000
        )
        max_keepalive = parse_optional_positive_int_env(
            "VULCAN_HEIMDALL_POOL_KEEPALIVE", default=None, floor=1, ceiling=500
        )
        keepalive_expiry = parse_positive_float_env(
            "VULCAN_HEIMDALL_POOL_KEEPALIVE_EXPIRY_S",
            default=5.0,
            floor=1.0,
            ceiling=300.0,
        )
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            limits=httpx.Limits(
                max_connections=max_connections,
                max_keepalive_connections=max_keepalive,
                keepalive_expiry=keepalive_expiry,
            ),
            headers={"Content-Type": "application/json"},
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    def _extract_token(self, authorization: str) -> str:
        """Extract token from Authorization header.
        
        Args:
            authorization: Full Authorization header value (e.g., "Bearer xxx")
        
        Returns:
            Token string without "Bearer " prefix
        """
        if authorization.lower().startswith("bearer "):
            return authorization[7:]  # Remove "Bearer " prefix
        return authorization
    
    async def authorize(self, authorization: str) -> AuthorizeResponse:
        """Authorize a token via Heimdall service.
        
        Args:
            authorization: Authorization header value (e.g., "Bearer <token>")
        
        Returns:
            AuthorizeResponse with allow, valid, and user info
        
        Raises:
            httpx.RequestError: On network errors
            httpx.TimeoutException: On timeout
        """
        if not self._client:
            raise RuntimeError("Client not initialized. Use async context manager.")
        
        token = self._extract_token(authorization)
        
        url = f"{self.base_url}/api/v1/authorize"
        payload = {"token": token}
        
        logger.debug("Authorizing token via Heimdall: %s", url)
        
        try:
            response = await self._client.post(url, json=payload)
            
            # Heimdall returns different HTTP status codes:
            # - 200 OK: Valid token, check allow/valid flags in body
            # - 400 Bad Request: Invalid token format (body has allow=false, valid=false)
            # - 401/403: Authentication/authorization failure
            # - 5xx: Server errors
            #
            # We parse the response body for all 2xx/4xx responses since
            # Heimdall includes useful error details in the JSON body.
            
            data = response.json()
            auth_response = AuthorizeResponse.model_validate(data)
            
            # Store Heimdall's HTTP status for downstream context
            auth_response.heimdall_status = response.status_code
            
            if auth_response.valid and auth_response.allow:
                logger.debug("Authorization successful for user: %s", auth_response.user_id)
            else:
                logger.debug(
                    "Authorization failed (Heimdall HTTP %d): valid=%s, allow=%s, error=%s",
                    auth_response.heimdall_status, auth_response.valid, auth_response.allow, 
                    auth_response.error_message
                )
            
            return auth_response
            
        except httpx.TimeoutException as e:
            raise HeimdallException(
                error_code="AUTH_HEIMDALL_TIMEOUT",
                msg="Authorization service timed out",
                details={
                    "service": "heimdall",
                    "url": url,
                    "timeout_seconds": self.timeout,
                },
            ) from e
        except httpx.RequestError as e:
            raise HeimdallException(
                error_code="AUTH_HEIMDALL_REQUEST_ERROR",
                msg="Authorization service request failed",
                details={
                    "service": "heimdall",
                    "url": url,
                    "exception_type": type(e).__name__,
                },
            ) from e
        except ValueError as e:
            # response.json() can raise JSON decoding errors (ValueError/JSONDecodeError)
            raise HeimdallException(
                error_code="AUTH_HEIMDALL_INVALID_JSON",
                msg="Authorization service returned invalid JSON",
                details={
                    "service": "heimdall",
                    "url": url,
                },
            ) from e
        except ValidationError as e:
            raise HeimdallException(
                error_code="AUTH_HEIMDALL_INVALID_RESPONSE",
                msg="Authorization service returned unexpected response",
                details={
                    "service": "heimdall",
                    "url": url,
                },
            ) from e
        except Exception as e:
            raise HeimdallException(
                error_code="AUTH_HEIMDALL_ERROR",
                msg="Authorization service error",
                details={
                    "service": "heimdall",
                    "url": url,
                    "exception_type": type(e).__name__,
                },
            ) from e
