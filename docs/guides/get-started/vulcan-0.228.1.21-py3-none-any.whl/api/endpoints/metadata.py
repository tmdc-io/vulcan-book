import logging
import typing as t
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import Field
from starlette.status import HTTP_404_NOT_FOUND

from vulcan.core import constants as c
from schema import _PydanticModel
from schema.metadata import Metadata
from schema.semantic import SemanticSchema

from api.context import EnvContext
from api.settings import get_env_context
from api.utils.cache import cached, CachePolicy
from vulcan.utils.date import now, to_datetime

logger = logging.getLogger(__name__)

router = APIRouter()


class ModelLag(_PydanticModel):
    model: str
    as_of: datetime
    nominal_prev: t.Optional[datetime] = None
    nominal_next: t.Optional[datetime] = None
    most_recent_run: t.Optional[datetime] = None
    is_pending: bool = False


class MetadataWithModelLag(Metadata):
    status: t.List[ModelLag] = Field(default_factory=list)


def build_model_lag(ctx: EnvContext) -> t.List[ModelLag]:
    if not ctx.metadata.models:
        return []

    current_time = now()
    freshness = ctx.model_freshness_ts
    status: t.List[ModelLag] = []

    for entry in ctx.metadata.models:
        model_name = entry.name
        model = ctx.get_model(model_name)
        if not model:
            continue

        nominal_prev = to_datetime(model.cron_prev(value=current_time))
        nominal_next = to_datetime(model.cron_next(value=current_time))

        last_run_ts = freshness.get(model_name)
        most_recent_run = None
        if last_run_ts:
            most_recent_run = datetime.fromtimestamp(last_run_ts / 1000, tz=timezone.utc)

        is_pending = (
            nominal_prev is not None
            and current_time >= nominal_prev
            and (most_recent_run is None or most_recent_run < nominal_prev)
        )

        if model.kind.is_seed:
            is_pending = False

        status.append(
            ModelLag(
                model=model_name,
                as_of=current_time,
                nominal_prev=nominal_prev,
                nominal_next=nominal_next,
                most_recent_run=most_recent_run,
                is_pending=is_pending,
            )
        )

    return status


def metadata_with_model_lag(ctx: EnvContext) -> MetadataWithModelLag:
    base = ctx.metadata
    return MetadataWithModelLag.model_construct(
        **{k: getattr(base, k) for k in base.model_fields},
        status=build_model_lag(ctx),
    )


@router.get(
    "",
    summary="Get metadata",
    response_model=MetadataWithModelLag,
)
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_metadata(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> MetadataWithModelLag:
    """
    Export environment-scoped metadata document (models, product, gateway, graph).

    Response is ``Metadata`` plus a ``status`` array (``ModelLag``): nominal cron
    boundaries, last run time, and ``is_pending``. The static portion comes from
    ``build_metadata`` in ``EnvContext._load``.
    Use ``GET /metadata/semantic`` for the minimal semantic/metric schema consumed by
    GraphQL and MySQL.
    """
    # ``ctx.metadata`` is built in ``EnvContext._load``; lag is computed per request.
    # Async handler keeps FastAPI from pinning the anyio threadpool for this path.
    return metadata_with_model_lag(ctx)


@router.get(
    "/semantic",
    summary="Get semantic schema",
    response_model=SemanticSchema,
)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_semantic_schema(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> SemanticSchema:
    """
    Return the environment-scoped semantic schema (semantic models + metrics).

    The payload mirrors ``semantic_meta.json``: top-level ``name``/``tenant``/
    ``fingerprint`` plus a ``models[]`` list discriminated by ``kind`` (``"semantic"``
    or ``"metric"``). Use ``fingerprint`` to detect plan-changes without diffing the body.

    The wire is intentionally minimal — only the fields catalog/UI/GraphQL/MySQL consumers
    actually read. SQL-native types, warehouse-side ``physical_table`` resolution, joins,
    and segments are not emitted here; those live on the cube wire (see :mod:`schema.cube`)
    which the transpiler / Cube.js consumes.
    """
    return ctx.semantic_schema


@router.get(
    "/exports/powerbi",
    summary="Download Power BI artifact",
    responses={
        200: {"content": {"application/zip": {}}},
        404: {"description": "Artifact not found"},
    },
)
async def download_powerbi_artifact(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
):
    if ctx.metadata.env != c.PROD:
        raise HTTPException(
            status_code=HTTP_404_NOT_FOUND,
            detail={
                "error": "POWERBI_ARTIFACT_NOT_FOUND",
                "message": "Power BI artifacts are only generated for prod.",
                "environment": ctx.environment,
                "plan_id": ctx.plan_id,
            },
        )

    path_raw = (ctx.export_artifacts.get("powerbi") or {}).get("path")
    if not path_raw:
        raise HTTPException(
            status_code=HTTP_404_NOT_FOUND,
            detail={
                "error": "POWERBI_ARTIFACT_NOT_FOUND",
                "message": "Power BI artifact path not available on EnvContext.",
                "environment": ctx.environment,
                "plan_id": ctx.plan_id,
            },
        )

    path = Path(path_raw)
    if path.exists():
        return FileResponse(path, media_type="application/zip", filename=path.name)

    raise HTTPException(
        status_code=HTTP_404_NOT_FOUND,
        detail={
            "error": "POWERBI_ARTIFACT_NOT_FOUND",
            "message": "Power BI artifact not found at EnvContext path.",
            "expected_local_path": str(path),
            "environment": ctx.environment,
            "plan_id": ctx.plan_id,
        },
    )


@router.get(
    "/exports/tableau",
    summary="Download Tableau artifact",
    responses={
        200: {"content": {"application/zip": {}}},
        404: {"description": "Artifact not found"},
    },
)
async def download_tableau_artifact(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
):
    if ctx.metadata.env != c.PROD:
        raise HTTPException(
            status_code=HTTP_404_NOT_FOUND,
            detail={
                "error": "TABLEAU_ARTIFACT_NOT_FOUND",
                "message": "Tableau artifacts are only generated for prod.",
                "environment": ctx.environment,
                "plan_id": ctx.plan_id,
            },
        )

    path_raw = (ctx.export_artifacts.get("tableau") or {}).get("path")
    if not path_raw:
        raise HTTPException(
            status_code=HTTP_404_NOT_FOUND,
            detail={
                "error": "TABLEAU_ARTIFACT_NOT_FOUND",
                "message": "Tableau artifact path not available on EnvContext.",
                "environment": ctx.environment,
                "plan_id": ctx.plan_id,
            },
        )

    path = Path(path_raw)
    if path.exists():
        return FileResponse(path, media_type="application/zip", filename=path.name)

    raise HTTPException(
        status_code=HTTP_404_NOT_FOUND,
        detail={
            "error": "TABLEAU_ARTIFACT_NOT_FOUND",
            "message": "Tableau artifact not found at EnvContext path.",
            "expected_local_path": str(path),
            "environment": ctx.environment,
            "plan_id": ctx.plan_id,
        },
    )
