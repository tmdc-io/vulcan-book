from __future__ import annotations

import asyncio
import logging
import re
import time
import typing as t

from fastapi import APIRouter, HTTPException, Response, Query, Depends, Header
from fastapi.responses import JSONResponse
from pgqueuer import QueueManager
from starlette.requests import Request

from vulcan.core.query import ObjectStoreClient
from vulcan.core import constants as c
from vulcan.core.query.definitions import QueryStatus, Perspective, QueryRequest
from vulcan.core.state_sync.db.query import QueryState
from vulcan.utils import random_id

from api.context import EnvContext
from api.definitions import Link, Pagination
from api.endpoints.query import (
    is_request_stale,
    submit_perspective_refresh_by_id,
    timestamp_to_iso,
)
from api.endpoints.query.statement import get_statement_result
from api.settings import (
    get_env_context,
    get_object_store,
    get_query_state,
    get_queue_manager,
    get_user,
)
from api.utils.async_blocking import run_blocking
from api.utils.urls import urls

logger = logging.getLogger(__name__)


async def _fire_hera_perspective_delete(
    qm: QueueManager,
    slug: str,
    environment: str,
) -> None:
    """Fire-and-forget Hera delete for a perspective. Errors are logged, never raised."""
    try:
        from api.worker.hera_jobs import enqueue_hera_perspective_delete

        await enqueue_hera_perspective_delete(qm, environment, slug)
    except Exception as exc:
        logger.warning("Hera perspective delete failed (slug=%s): %s", slug, exc)


router = APIRouter()

# Import models from models.py
from api.endpoints.query.models import (
    PerspectiveCreateRequest,
    PerspectiveUpdateRequest,
    PerspectiveLinks,
    PerspectiveDetailView,
    PerspectiveListView,
    PerspectivesListResponse,
)


def _slugify(name: str) -> str:
    """Convert perspective name to URL-friendly slug."""
    slug = name.lower()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)  # Replace non-alphanumeric with -
    slug = re.sub(r"^-+|-+$", "", slug)  # Remove leading/trailing dashes
    slug = slug[:100]  # Limit length
    return slug or "perspective"  # Fallback if empty


def _generate_slug_suggestions(base_slug: str, user_id: str) -> t.List[str]:
    """Generate alternative slug suggestions when a slug conflict occurs."""
    return [
        f"{base_slug}-{user_id[:8]}",
        f"{base_slug}-{random_id()[:8]}",
        f"{base_slug}-{int(time.time())}",
    ]


def _make_perspective_links(
    slug: str,
    request_id: str,
    refresh_request_id: t.Optional[str] = None,
) -> PerspectiveLinks:
    """Build HATEOAS links for perspective resources."""
    links = PerspectiveLinks(
        self=Link(href=urls.perspective_detail(slug)),
        statement_detail=Link(href=urls.query_statement_detail(request_id)),
        result=Link(href=urls.perspective_result(slug)),
    )

    if refresh_request_id:
        links.refresh_statement = Link(href=urls.query_statement_detail(refresh_request_id))

    return links


def _can_access_perspective(user_id: str, perspective: Perspective) -> bool:
    """Check if a user has access to a perspective."""
    if perspective.is_public:
        return True

    if perspective.owner == user_id:
        return True

    allowed_user_ids = perspective.allowed_user_ids or []
    if user_id in allowed_user_ids:
        return True

    return False


async def _validate_and_resolve_result_id(statement_id: str, query_state: QueryState) -> str:
    """Validate statement and resolve result_id based on execution strategy."""
    query_request = await run_blocking(query_state.get_request_by_id, statement_id)
    if not query_request:
        raise HTTPException(status_code=404, detail=f"Statement '{statement_id}' not found")

    result_id = None

    if query_request.strategy == "from_cache":
        if not query_request.result_id:
            raise HTTPException(status_code=400, detail="Cache result not found")
        result_id = query_request.result_id

    elif query_request.strategy == "await_primary":
        if not query_request.primary_request_id:
            raise HTTPException(status_code=400, detail="Primary request ID not found")

        primary_req = await run_blocking(
            query_state.get_request_by_id, query_request.primary_request_id
        )
        if not primary_req:
            raise HTTPException(
                status_code=404,
                detail=f"Primary request '{query_request.primary_request_id}' not found",
            )

        if primary_req.execution_status != QueryStatus.SUCCESS:
            raise HTTPException(
                status_code=400,
                detail=f"Primary statement must be SUCCESS (current: {primary_req.execution_status})",
            )

        if not primary_req.result_id:
            raise HTTPException(status_code=400, detail="Primary statement has no result")

        result_id = primary_req.result_id

    else:  # strategy == "execute"
        if query_request.execution_status != QueryStatus.SUCCESS:
            raise HTTPException(
                status_code=400,
                detail=f"Statement must be SUCCESS (current: {query_request.execution_status})",
            )

        if not query_request.result_id:
            raise HTTPException(status_code=400, detail="Statement has no result")

        result_id = query_request.result_id

    return result_id


async def _trigger_auto_refresh_if_needed(
    perspective: Perspective,
    query_state: QueryState,
    env_context: EnvContext,
    qm: QueueManager,
    force_refresh: bool = False,
) -> t.Optional[QueryRequest]:
    """Trigger perspective refresh if stale or force_refresh is True."""
    if not perspective.request_id:
        return None

    is_stale, query_request = await is_request_stale(
        request_id=perspective.request_id,
        query_state=query_state,
        env_context=env_context,
    )

    if not query_request:
        return None

    should_refresh = (is_stale and perspective.auto_refresh) or force_refresh

    if should_refresh:
        accepted = await submit_perspective_refresh_by_id(
            perspective_id=perspective.perspective_id,
            env_context=env_context,
            query_state=query_state,
            qm=qm,
        )
        return await run_blocking(query_state.get_request_by_id, accepted.id)

    return None


@router.head(
    "/{slug}",
    summary="Check perspective slug availability",
    operation_id="check_perspective_availability",
    responses={
        200: {
            "description": "Slug exists (perspective metadata in X-Perspective-* headers)",
            "headers": {
                "X-Perspective-Id": {"schema": {"type": "string"}, "description": "Perspective ID"},
                "X-Perspective-Owner": {
                    "schema": {"type": "string"},
                    "description": "Owner user ID",
                },
                "X-Perspective-Name": {
                    "schema": {"type": "string"},
                    "description": "Perspective name",
                },
            },
        },
        404: {"description": "Slug is available (not taken)"},
        422: {"description": "Slug format validation error"},
    },
)
async def check_perspective_availability(
    slug: str,
    query_state: QueryState = Depends(get_query_state),
) -> Response:
    """Check if a perspective slug is available."""
    perspective = await run_blocking(query_state.get_perspective_by_slug, slug)

    if perspective:
        return Response(
            status_code=200,
            headers={
                "X-Perspective-Id": perspective.perspective_id,
                "X-Perspective-Owner": perspective.owner,
                "X-Perspective-Name": perspective.name,
            },
        )
    else:
        return Response(status_code=404)


@router.post(
    "",
    summary="Create perspective",
    operation_id="create_perspective",
    status_code=201,
    responses={
        201: {"description": "Perspective created successfully"},
        400: {"description": "Statement has no result or invalid status"},
        404: {"description": "Statement not found"},
        409: {"description": "Slug already taken (includes alternative suggestions)"},
        422: {"description": "Request body validation error"},
    },
)
async def create_perspective(
    body: PerspectiveCreateRequest,
    ctx: EnvContext = Depends(get_env_context),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """Create a new perspective from a successful query execution."""
    current_user_id = user["user_id"]

    slug = body.slug or _slugify(body.name)
    existing = await run_blocking(query_state.get_perspective_by_slug, slug)
    if existing:
        raise HTTPException(
            status_code=409,
            detail={
                "error": "SLUG_CONFLICT",
                "message": f"Slug '{slug}' is already taken",
                "suggestions": _generate_slug_suggestions(slug, current_user_id),
            },
        )

    statement = await run_blocking(query_state.get_request_by_id, body.statement_id)
    if not statement:
        raise HTTPException(status_code=404, detail="Statement not found")

    await _validate_and_resolve_result_id(body.statement_id, query_state)

    sql_query = statement.sql_query
    normalized_sql = statement.normalized_sql
    params = statement.params
    gateway = statement.gateway or "default"
    ttl = statement.ttl
    meta = statement.meta
    query_type = statement.query_type
    semantic_query = statement.semantic_query
    rest_query = statement.rest_query
    graphql_query = statement.graphql_query
    depends_on = statement.depends_on
    fingerprint = statement.fingerprint

    perspective_id = random_id()
    await run_blocking(
        query_state.create_perspective,
        perspective_id=perspective_id,
        slug=slug,
        request_id=body.statement_id,
        fingerprint=fingerprint,
        sql_query=sql_query,
        normalized_sql=normalized_sql,
        params=params,
        gateway=gateway,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query,
        graphql_query=graphql_query,
        depends_on=depends_on,
        name=body.name,
        description=body.description,
        tags=body.tags,
        terms=body.terms,
        owner=current_user_id,
        auto_refresh=body.auto_refresh,
        is_public=body.is_public,
        allowed_user_ids=body.allowed_user_ids if not body.is_public else [],
        created_by=current_user_id,
    )

    await submit_perspective_refresh_by_id(
        perspective_id=perspective_id,
        env_context=ctx,
        query_state=query_state,
        qm=qm,
    )

    return Response(status_code=201)


@router.put(
    "/{slug}",
    summary="Update perspective",
    operation_id="update_perspective",
    status_code=201,
    responses={
        201: {"description": "Perspective updated successfully"},
        400: {"description": "New statement_id has no result or invalid status"},
        403: {"description": "User is not the owner"},
        404: {"description": "Perspective not found or statement not found"},
        422: {"description": "Request body validation error"},
    },
)
async def update_perspective(
    slug: str,
    body: PerspectiveUpdateRequest,
    ctx: EnvContext = Depends(get_env_context),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """Update perspective metadata and optionally change the underlying query."""
    current_user_id = user["user_id"]

    perspective = await run_blocking(query_state.get_perspective_by_slug, slug)
    if not perspective:
        raise HTTPException(status_code=404, detail=f"Perspective '{slug}' not found")

    if perspective.owner != current_user_id:
        raise HTTPException(status_code=403, detail="Only owner can update perspective")

    if body.statement_id:
        statement = await run_blocking(query_state.get_request_by_id, body.statement_id)
        if not statement:
            raise HTTPException(status_code=404, detail="Statement not found")

        await _validate_and_resolve_result_id(body.statement_id, query_state)

        sql_query = statement.sql_query
        normalized_sql = statement.normalized_sql
        params = statement.params
        gateway = statement.gateway or "default"
        ttl = statement.ttl
        meta = statement.meta
        query_type = statement.query_type
        semantic_query = statement.semantic_query
        rest_query = statement.rest_query
        graphql_query = statement.graphql_query
        depends_on = statement.depends_on
        fingerprint = statement.fingerprint

        await run_blocking(
            query_state.update_perspective,
            perspective_id=perspective.perspective_id,
            fingerprint=fingerprint,
            sql_query=sql_query,
            normalized_sql=normalized_sql,
            params=params,
            gateway=gateway,
            ttl=ttl,
            meta=meta,
            query_type=query_type,
            semantic_query=semantic_query,
            rest_query=rest_query,
            graphql_query=graphql_query,
            depends_on=depends_on,
            updated_by=current_user_id,
        )

        await submit_perspective_refresh_by_id(
            perspective_id=perspective.perspective_id,
            env_context=ctx,
            query_state=query_state,
            qm=qm,
        )

    update_kwargs = {}
    if body.name is not None:
        update_kwargs["name"] = body.name
    if body.description is not None:
        update_kwargs["description"] = body.description
    if body.tags is not None:
        update_kwargs["tags"] = body.tags
    if body.terms is not None:
        update_kwargs["terms"] = body.terms
    if body.auto_refresh is not None:
        update_kwargs["auto_refresh"] = body.auto_refresh
    if body.is_public is not None:
        update_kwargs["is_public"] = body.is_public
        if body.is_public and body.allowed_user_ids is not None:
            update_kwargs["allowed_user_ids"] = []
        elif body.allowed_user_ids is not None:
            update_kwargs["allowed_user_ids"] = body.allowed_user_ids

    # Apply metadata updates if any fields were provided
    if update_kwargs:
        await run_blocking(
            query_state.update_perspective,
            perspective_id=perspective.perspective_id,
            updated_by=current_user_id,
            **update_kwargs,
        )

    return Response(status_code=201)


@router.get(
    "",
    summary="List perspectives",
    operation_id="list_perspectives",
    response_model=PerspectivesListResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Paginated list of accessible perspectives"},
        422: {"description": "Query parameter validation error"},
    },
)
async def list_perspectives(
    is_public: t.Optional[bool] = Query(default=None, description="Filter by public/private"),
    limit: int = Query(default=50, ge=1, le=100, description="Maximum number of results"),
    offset: int = Query(default=0, ge=0, description="Offset for pagination"),
    query_state: QueryState = Depends(get_query_state),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """List perspectives accessible to the current user."""
    current_user_id = user["user_id"]

    perspectives, has_more = await run_blocking(
        query_state.list_perspectives,
        current_user_id=current_user_id,
        is_public=is_public,
        limit=limit,
        offset=offset,
    )

    items = []
    for p in perspectives:
        items.append(
            PerspectiveListView.from_perspective(
                perspective=p,
                links=_make_perspective_links(
                    slug=p.slug,
                    request_id=p.request_id or "",
                ),
            )
        )

    pagination = Pagination(
        limit=limit,
        offset=offset,
        has_more=has_more,
        order_by="updated_at",
        order_direction="desc",
    )

    return PerspectivesListResponse(
        items=items,
        pagination=pagination,
    )


@router.get(
    "/{slug}",
    summary="Get perspective details",
    operation_id="get_perspective",
    response_model=PerspectiveDetailView,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {
            "description": "Perspective details with HATEOAS links",
            "headers": {
                "X-Refresh-Statement-Id": {
                    "schema": {"type": "string"},
                    "description": "Refresh request ID (present if refresh was triggered)",
                },
            },
        },
        403: {"description": "Access denied"},
        404: {"description": "Perspective not found"},
        422: {"description": "Query parameter validation error"},
    },
)
async def get_perspective(
    slug: str,
    refresh: bool = Query(
        default=False,
        description="Force refresh perspective (triggers refresh even if not stale or auto_refresh disabled)",
    ),
    query_state: QueryState = Depends(get_query_state),
    env_context: EnvContext = Depends(get_env_context),
    qm: QueueManager = Depends(get_queue_manager),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """Get perspective details by slug."""
    current_user_id = user["user_id"]

    perspective = await run_blocking(query_state.get_perspective_by_slug, slug)
    if not perspective:
        raise HTTPException(status_code=404, detail=f"Perspective '{slug}' not found")

    if not _can_access_perspective(current_user_id, perspective):
        raise HTTPException(status_code=403, detail="Access denied")

    refresh_query_request = await _trigger_auto_refresh_if_needed(
        perspective=perspective,
        query_state=query_state,
        env_context=env_context,
        qm=qm,
        force_refresh=refresh,
    )

    refresh_request_id = None
    if refresh_query_request:
        refresh_request_id = refresh_query_request.request_id

    response_data = PerspectiveDetailView(
        id=perspective.perspective_id,
        slug=perspective.slug,
        name=perspective.name,
        description=perspective.description,
        tags=perspective.tags or [],
        terms=perspective.terms or [],
        owner=perspective.owner,
        request_id=perspective.request_id,
        auto_refresh=perspective.auto_refresh,
        is_public=perspective.is_public,
        allowed_user_ids=perspective.allowed_user_ids or [],
        created_at=timestamp_to_iso(perspective.created_at),
        updated_at=timestamp_to_iso(perspective.updated_at),
        created_by=perspective.created_by,
        updated_by=perspective.updated_by,
        # Query fields directly from perspective (denormalized)
        sql_query=perspective.sql_query,
        normalized_sql=perspective.normalized_sql,
        params=perspective.params,
        depends_on=perspective.depends_on,
        gateway=perspective.gateway,
        query_type=perspective.query_type,
        semantic_query=perspective.semantic_query,
        rest_query=perspective.rest_query,
        graphql_query=perspective.graphql_query,
        meta=perspective.meta,
        ttl=perspective.ttl,
        links=_make_perspective_links(
            slug=perspective.slug,
            request_id=perspective.request_id,
            refresh_request_id=refresh_request_id,
        ),
    )

    headers = {}
    if refresh_request_id:
        headers["X-Refresh-Statement-Id"] = refresh_request_id

    return JSONResponse(
        content=response_data.model_dump(by_alias=True, exclude_unset=True, exclude_none=True),
        headers=headers,
    )


@router.get(
    "/{slug}/result",
    summary="Get perspective result",
    operation_id="get_perspective_result",
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    responses={
        200: {
            "description": "Result in requested text format (json/yaml/csv)",
            "headers": {
                "X-Refresh-Statement-Id": {
                    "schema": {"type": "string"},
                    "description": "Refresh request ID (present if refresh was triggered)",
                },
                "Is-Stale": {
                    "schema": {"type": "string"},
                    "description": "Present if result is stale (value: 'true')",
                },
            },
        },
        307: {
            "description": "Redirect to presigned Parquet URL (format=parquet)",
            "headers": {
                "Location": {
                    "schema": {"type": "string"},
                    "description": "Presigned URL for Parquet file",
                },
                "X-Refresh-Statement-Id": {
                    "schema": {"type": "string"},
                    "description": "Refresh request ID (present if refresh was triggered)",
                },
            },
        },
        400: {"description": "Perspective has no request_id or invalid columns requested"},
        403: {"description": "Access denied"},
        404: {"description": "Perspective not found, statement not found, or result not available"},
        406: {"description": "Unsupported format"},
        422: {"description": "Query parameter validation error"},
        500: {"description": "Internal server error (e.g., object store access failure)"},
    },
)
async def get_perspective_result(
    request: Request,
    slug: str,
    refresh: bool = Query(
        default=False,
        description="Force refresh perspective (triggers refresh even if not stale or auto_refresh disabled)",
    ),
    format: t.Optional[str] = Query(
        default=None, description="Result format: json, yaml, csv, parquet"
    ),
    limit: t.Optional[int] = Query(
        default=None,
        ge=1,
        description="Maximum rows to return",
    ),
    offset: t.Optional[int] = Query(default=None, ge=0, description="Row offset"),
    columns: t.Optional[str] = Query(default=None, description="Comma-separated column names"),
    accept: str = Header(default="application/octet-stream"),
    query_state: QueryState = Depends(get_query_state),
    ctx: EnvContext = Depends(get_env_context),
    object_store: ObjectStoreClient = Depends(get_object_store),
    qm: QueueManager = Depends(get_queue_manager),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """Get perspective result data in multiple formats."""
    current_user_id = user["user_id"]

    perspective = await run_blocking(query_state.get_perspective_by_slug, slug)
    if not perspective:
        raise HTTPException(status_code=404, detail=f"Perspective '{slug}' not found")

    if not _can_access_perspective(current_user_id, perspective):
        raise HTTPException(status_code=403, detail="Access denied")

    if not perspective.request_id:
        raise HTTPException(status_code=400, detail="Perspective has no request_id")

    refresh_query_request = await _trigger_auto_refresh_if_needed(
        perspective=perspective,
        query_state=query_state,
        env_context=ctx,
        qm=qm,
        force_refresh=refresh,
    )

    result_response = await get_statement_result(
        id=perspective.request_id,
        format=format,
        limit=limit,
        offset=offset,
        columns=columns,
        accept=accept,
        ctx=ctx,
        object_store=object_store,
        request=request,
    )

    if refresh_query_request:
        result_response.headers["X-Refresh-Statement-Id"] = refresh_query_request.request_id

    return result_response


@router.delete(
    "/{slug}",
    summary="Delete perspective",
    operation_id="delete_perspective",
    status_code=204,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    responses={
        204: {"description": "Perspective deleted successfully"},
        403: {"description": "User is not the owner"},
        404: {"description": "Perspective not found"},
        422: {"description": "Path parameter validation error"},
    },
)
async def delete_perspective(
    slug: str,
    ctx: EnvContext = Depends(get_env_context),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """Delete a perspective (requires ownership)."""
    current_user_id = user["user_id"]

    perspective = await run_blocking(query_state.get_perspective_by_slug, slug)
    if not perspective:
        raise HTTPException(status_code=404, detail=f"Perspective '{slug}' not found")

    if perspective.owner != current_user_id:
        raise HTTPException(status_code=403, detail="Only owner can delete perspective")
    await run_blocking(query_state.delete_perspective, perspective.perspective_id)

    if ctx.environment == c.PROD:
        asyncio.create_task(
            _fire_hera_perspective_delete(qm, perspective.slug, ctx.environment)
        )
    return Response(status_code=204)
