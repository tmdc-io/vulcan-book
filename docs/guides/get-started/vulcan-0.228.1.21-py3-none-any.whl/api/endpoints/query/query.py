from __future__ import annotations

import json
import logging
import time
import typing as t
import uuid
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from vulcan.core.query.definitions import QueryRequest
    from api.endpoints.query import QueryExecutionResult

from fastapi import APIRouter, HTTPException, Request, Response, Query, Depends, status
from urllib.parse import urljoin
from pgqueuer import QueueManager
from vulcan.core.state_sync.db.query import QueryState
from vulcan.core.query.definitions import QueryStatus

from api.context import EnvContext
from api.settings import (
    get_env_context,
    get_graphql_client,
    get_transpiler,
    get_query_state,
    get_query_validator,
    get_queue_manager,
    get_default_gateway,
    get_user,
)
from api.utils.urls import urls
from api.exceptions import QueryExecutionError
from api.endpoints.query import submit_sql_via_flow
from api.endpoints.query import (
    build_statement_accepted,
    make_statement_links,
    timestamp_to_iso,
)
from api.endpoints.query.models import (
    StatementAccepted,
    StatementRequest,
    RestQueryRequest,
    SqlQueryRequest,
)
from api.endpoints.query.types import QueryType
from vulcan.core.query.transpiler import (
    RestQuery,
    TranspilerClient,
    TranspilerReply,
    get_transpiler_params_from_snapshots,
)
from vulcan.utils.errors import VulcanError, TranspilerError
from vulcan.core.observability.facade import emit_semantic_compilation_metric, emit_transpiler_error_metric


logger = logging.getLogger(__name__)
router = APIRouter()

API_QUERY_POST_PROCESSING_REQUIRED = "API.QUERY.POST_PROCESSING_REQUIRED"


async def _transpile_or_http_error(
    query: RestQuery | str,
    *,
    invalid_msg: str,
    disable_post_processing: bool,
    user: str,
    transpiler: TranspilerClient,
    dialect: t.Optional[str] = None,
    ctx: "EnvContext",
    auth_headers: t.Optional[t.Dict[str, str]] = None,
) -> "TranspilerReply":
    """
    Call Transpiler service and map errors to appropriate HTTP exceptions.
    
    Handles Transpiler errors and converts them to user-friendly HTTP exceptions:
    - Post-processing errors: Provides guidance on enabling post-processing
    - 4xx errors: Treated as user query errors (400 Bad Request)
    - 5xx errors: Preserved as-is (500, 502, etc.)
    - Unexpected errors: Mapped to 502 Bad Gateway
    
    Args:
        query: REST query object or SQL string to transpile
        invalid_msg: Error message prefix for user-facing errors
        disable_post_processing: Whether post-processing is disabled
        user: Optional user ID for transpiler context
        transpiler: TranspilerClient instance
        dialect: Optional SQL dialect for wrapping query with alias mapping
        ctx: EnvContext for central transpiler (required; uses get_transpiler_params_from_snapshots)
        
    Returns:
        TranspilerReply with generated SQL and metadata
        
    Raises:
        TranspilerError: Re-raised for non-post-processing errors; the global
            handle_transpiler_error handler in api/main.py maps these to
            4xx (pass-through), 502 (upstream failure), or 503 (unreachable).
    """
    params = get_transpiler_params_from_snapshots(ctx.context, ctx.environment)
    params["request_id"] = str(uuid.uuid4())

    _compile_start = time.perf_counter()
    try:
        result = await transpiler.transpile(
            query,
            user=user,
            disable_post_processing=disable_post_processing,
            dialect=dialect,
            schema=params["schema"],
            tenant_id=params["tenant_id"],
            request_id=params["request_id"],
            db_type=params["db_type"],
            name=params["name"],
            headers=auth_headers,
        )
        emit_semantic_compilation_metric(dialect, "success", time.perf_counter() - _compile_start)
        return result
    except TranspilerError as e:
        logger.error("Transpiler error: %s", e)

        _api = "rest" if not isinstance(query, str) else "sql"
        emit_transpiler_error_metric(dialect, _api, e)
        emit_semantic_compilation_metric(dialect, "error", time.perf_counter() - _compile_start)

        if e.is_post_processing_error:
            if disable_post_processing:
                msg = (
                    "Query requires post-processing, but post-processing is currently disabled. "
                    "Set query parameter `disable_post_processing=false` to enable post-processing. "
                    f"Error: {e}"
                )
            else:
                msg = f"Query requires post-processing, but enabling it failed. Error: {e}"
            raise TranspilerError(
                message=msg,
                code=400,
                response_data={
                    "status": 400,
                    "error": {
                        "code": API_QUERY_POST_PROCESSING_REQUIRED,
                        "message": msg,
                    },
                },
            )

        raise


@router.get(
    "/usage-metrics",
    summary="Get query usage metrics",
    operation_id="get_usage_metrics",
    responses={
        200: {"description": "Usage metrics for the requested week"},
        400: {"description": "Invalid week_start parameter"},
    },
)
def usage_metrics(
    week_start: str | None = Query(
        default=None,
        description="Monday of the week in UTC (YYYY-MM-DD). Default: current week.",
    ),
    query_state: QueryState = Depends(get_query_state),
) -> dict[str, t.Any]:
    """
    Return usage metrics (active users, new users, queries, median time, % savings)
    for a given week from the statestore. No cache; each request runs the aggregation.
    """
    from datetime import datetime, timezone

    week_start_dt: datetime | None
    if week_start is None:
        week_start_dt = None
    else:
        try:
            week_start_dt = datetime.strptime(week_start, "%Y-%m-%d").replace(
                tzinfo=timezone.utc
            )
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail="week_start must be YYYY-MM-DD (e.g. 2025-02-10)",
            )

    try:
        return query_state.get_usage_metrics(week_start=week_start_dt)
    except VulcanError as e:
        # Misconfiguration / unsupported statestore dialect: surface a clear error.
        raise HTTPException(status_code=501, detail=str(e))


@router.post(
    "/statement",
    summary="Submit raw SQL query",
    operation_id="submit_statement",
    status_code=202,
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    responses={
        202: {
            "description": (
                "Statement accepted; use `_links` to poll status and fetch results "
                "via `GET /statement/{id}`."
            )
        },
        400: {"description": "Invalid SQL or validation error"},
        422: {"description": "Request validation error"},
    },
)
async def source_query(
    body: StatementRequest,
    response: Response,
    ctx: EnvContext = Depends(get_env_context),
    gateway: str = Query(
        default=None,
        description="Execution gateway (e.g., 'duckdb', 'postgres')",
    ),
    retry_on_recent_failure: bool = Query(
        default=False,
        description="Retry even if an identical query failed recently.",
    ),
    qv=Depends(get_query_validator),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
):
    """
    Submit source SQL query for execution.
    
    Accepts raw SQL queries and submits them for asynchronous execution via the
    statement flow. Returns immediately with a statement ID for polling. Validates SQL,
    checks cache, and submits to queue. Always returns `202 Accepted` with statement ID.
    Use `_links` to poll `GET /statement/{id}` for status and results.
    """
    exec_gateway = gateway or default_gateway

    # Step 1: Validate meta size (max 10KB) for direct SQL submissions only
    # This prevents abuse and ensures reasonable payload sizes
    if body.meta:
        meta_size = len(json.dumps(body.meta))
        if meta_size > 10 * 1024:
            raise HTTPException(
                400,
                f"meta field exceeds 10KB limit (got {meta_size} bytes)",
            )

    # Step 2: Submit query through execution flow
    # This handles caching, deduplication, and execution strategies
    try:
        accepted = await submit_sql_via_flow(
            sql=body.sql,
            params=body.params,
            ttl=body.ttl,
            meta=body.meta,
            gateway=exec_gateway,
            qv=qv,
            qm=qm,
            query_state=ctx.context.state_sync.query_state,
            env_context=ctx,
            retry_on_recent_failure=retry_on_recent_failure,
            query_type=QueryType.RAW_SQL.value,
            submitted_by=user["user_id"],
        )
    except QueryExecutionError as e:
        # Translate query execution error to HTTP exception
        raise HTTPException(e.status_code, e.detail)

    # Step 3: Set Location header for polling
    # Clients can use this header to poll for status updates
    # Status code 202 is set by the route decorator
    response.headers["Location"] = urls.query_statement_detail(accepted.id)

    # Return StatementAccepted response with request ID and status
    return accepted


@router.post(
    "/semantic/rest",
    summary="Submit semantic REST query",
    operation_id="submit_semantic_rest_query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    status_code=202,
    responses={
        202: {
            "description": (
                "Statement accepted; use `_links` to poll status and fetch results "
                "via `GET /statement/{id}`."
            )
        },
        400: {
            "description": "Invalid REST semantic query or SQL generation failed",
        },
        502: {"description": "Transpiler error"},
        503: {"description": "Transpiler unavailable"},
    },
)
async def rest_query(
    request: Request,
    response: Response,
    rest_request: RestQueryRequest,
    ctx: EnvContext = Depends(get_env_context),
    gateway: str = Query(
        default=None,
        description="Execution gateway (e.g., 'duckdb', 'postgres')",
    ),
    # Public REST semantic queries also default to disabling Cube post-processing.
    disable_post_processing: bool = Query(
        default=True,
        description=("Disable post-processing in the Transpiler."),
    ),
    retry_on_recent_failure: bool = Query(
        default=False,
        description="Retry even if an identical query failed recently.",
    ),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
    transpiler: TranspilerClient = Depends(get_transpiler),
):
    """
    Submit REST semantic query for execution.
    
    Accepts REST Query format (measures, dimensions, filters) and converts it to
    SQL before submitting for execution via the statement flow. Converts REST query
    to SQL, then executes via statement flow. Always returns `202 Accepted`. Use `_links`
    to poll `GET /statement/{id}` for status and results.
    """

    exec_gateway = gateway or default_gateway

    # Extract dialect for SQL wrapping
    dialect = ctx.get_dialect(exec_gateway)

    # Step 1: Transpile REST query to SQL
    # The transpiler converts REST query format (measures, dimensions, filters) to executable SQL
    auth_headers = {"Authorization": auth} if (auth := request.headers.get("Authorization")) else None
    transpiler_response = await _transpile_or_http_error(
        rest_request.query,
        invalid_msg="Invalid REST semantic query",
        disable_post_processing=disable_post_processing,
        user=user["user_id"],
        transpiler=transpiler,
        dialect=dialect,
        ctx=ctx,
        auth_headers=auth_headers,
    )

    generated_sql = transpiler_response.wrapped_sql_statement
    sql_params = transpiler_response.sql_params

    logger.info("Executing generated SQL via statement flow")

    meta = rest_request.meta.copy() if rest_request.meta else {}
    
    # Step 2: Determine query type
    # GraphQL service acts as a proxy that translates GraphQL queries to REST queries
    # and calls this endpoint. When graphql_body is present, it indicates the original
    # request was GraphQL, so we store both the translated REST query and the original
    # GraphQL query for traceability and analysis.
    if rest_request.graphql_body:
        query_type = QueryType.SEMANTIC_GRAPHQL.value
        rest_query = rest_request.query.model_dump(exclude_none=True)
        graphql_query = rest_request.graphql_body
    else:
        query_type = QueryType.SEMANTIC_REST.value
        rest_query = rest_request.query.model_dump(exclude_none=True)
        graphql_query = None

    # Step 3: Submit generated SQL through execution flow
    # This handles caching, deduplication, and execution strategies
    try:
        accepted = await submit_sql_via_flow(
            sql=generated_sql,
            params=sql_params,
            ttl=rest_request.ttl,
            meta=meta,
            gateway=exec_gateway,
            qv=qv,
            qm=qm,
            query_state=query_state,
            env_context=ctx,
            retry_on_recent_failure=retry_on_recent_failure,
            query_type=query_type,
            rest_query=rest_query,
            graphql_query=graphql_query,
            submitted_by=user["user_id"],
        )
    except QueryExecutionError as e:
        raise HTTPException(e.status_code, e.detail)
    
    # Step 4: Set Location header for polling
    response.headers["Location"] = urls.query_statement_detail(accepted.id)
    return accepted


@router.post(
    "/semantic/sql",
    summary="Submit semantic SQL query",
    operation_id="submit_semantic_sql_query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    status_code=202,
    responses={
        202: {
            "description": (
                "Statement accepted; use `_links` to poll status and fetch results "
                "via `GET /statement/{id}`."
            )
        },
        400: {
            "description": "Invalid semantic SQL query or compilation failed",
        },
        502: {"description": "Transpiler error"},
        503: {"description": "Transpiler unavailable"},
    },
)
async def sql_query(
    request: Request,
    response: Response,
    sql_request: SqlQueryRequest,
    ctx: EnvContext = Depends(get_env_context),
    gateway: str = Query(
        default=None,
        description="Execution gateway (e.g., 'duckdb', 'postgres')",
    ),
    # Public semantic SQL queries also default to disabling Cube post-processing.
    disable_post_processing: bool = Query(
        default=True,
        description=("Disable post-processing in the Transpiler."),
    ),
    retry_on_recent_failure: bool = Query(
        default=False,
        description="Retry even if an identical query failed recently.",
    ),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
    transpiler: TranspilerClient = Depends(get_transpiler),
):
    """
    Submit semantic SQL query for execution.
    
    Accepts semantic SQL (SQL with metric/dimension references) and converts it to
    executable SQL before submitting for execution via the statement flow. Converts
    semantic SQL to executable SQL, then executes via statement flow. Always returns
    202 Accepted. Use `_links` to poll `GET /statement/{id}` for status and results.
    
    For MySQL client dialect transpilation, use the internal endpoint `/_internal/query/semantic/sql`.
    """
    exec_gateway = gateway or default_gateway

    # Extract dialect for SQL wrapping
    dialect = ctx.get_dialect(exec_gateway)

    # Step 1: Transpile semantic SQL to executable SQL
    # The transpiler converts semantic SQL (with metric/dimension references) to executable SQL
    auth_headers = {"Authorization": auth} if (auth := request.headers.get("Authorization")) else None
    transpiler_response = await _transpile_or_http_error(
        sql_request.sql,
        invalid_msg="Invalid semantic SQL query",
        disable_post_processing=disable_post_processing,
        user=user["user_id"],
        transpiler=transpiler,
        dialect=dialect,
        ctx=ctx,
        auth_headers=auth_headers,
    )

    generated_sql = transpiler_response.wrapped_sql_statement
    sql_params = transpiler_response.sql_params

    logger.info("Executing compiled SQL via statement flow")

    meta = sql_request.meta.copy() if sql_request.meta else {}

    # Step 2: Submit generated SQL through execution flow
    # Store original semantic SQL for traceability (query_type="SEMANTIC_SQL")
    # This handles caching, deduplication, and execution strategies
    try:
        accepted = await submit_sql_via_flow(
            sql=generated_sql,
            params=sql_params,
            ttl=sql_request.ttl,
            meta=meta,
            gateway=exec_gateway,
            qv=qv,
            qm=qm,
            query_state=query_state,
            env_context=ctx,
            retry_on_recent_failure=retry_on_recent_failure,
            query_type=QueryType.SEMANTIC_SQL.value,
            semantic_query=sql_request.sql,
            submitted_by=user["user_id"],
        )
    except QueryExecutionError as e:
        raise HTTPException(e.status_code, e.detail)
    
    # Step 3: Set Location header for polling
    response.headers["Location"] = urls.query_statement_detail(accepted.id)
    return accepted


@router.api_route(
    "/semantic/graphql",
    methods=["POST"],
    summary="Execute semantic GraphQL query",
    response_class=Response,
    responses={
        200: {"description": "GraphQL query executed successfully"},
        503: {"description": "GraphQL service unavailable"},
        504: {"description": "GraphQL service request timed out"},
        500: {"description": "Internal proxy error"},
    },
)
async def graphql(
    request: Request,
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
    client: httpx.AsyncClient = Depends(get_graphql_client),
) -> Response:
    """
    Execute GraphQL queries against the data product.
    
    Accepts GraphQL queries and executes them against the semantic layer, returning
    results in GraphQL format. Processes GraphQL queries and returns results in standard
    GraphQL response format. Returns GraphQL-compatible error responses on connection or
    timeout errors.
    """
    # Step 1: Build upstream GraphQL endpoint URL from Vulcan config
    base = ctx.context.config.graphql.base_url
    base = base if base.endswith("/") else base + "/"
    graphql_endpoint = urljoin(base, "graphql")

    try:
        # Step 2: Prepare request for forwarding
        body = await request.body()

        headers = dict(request.headers)
        headers.pop("host", None)  # Remove host header (will be set by httpx)
        headers.pop("accept-encoding", None)  # Don't let Express compress — httpx decodes it but we can't re-encode for the client

        # Inject X-User header from authenticated user context
        # GraphQL service reads this for request context and Vulcan API for authorization
        headers["X-User"] = user["user_id"]

        # Step 3: Forward request to GraphQL service with all original context.
        # ``client`` is the shared ``httpx.AsyncClient`` built in lifespan and
        # injected via ``Depends(get_graphql_client)`` - reusing it keeps the
        # TCP + TLS handshake off the request hot path and prevents TIME_WAIT
        # accumulation under burst traffic (audit §5.4).
        response = await client.request(
            method=request.method,
            url=graphql_endpoint,
            content=body,
            headers=headers,
            params=request.query_params,
        )

        # Step 4: Return response with safe headers only.
        # Do NOT forward Content-Length, Transfer-Encoding, or Date — Starlette sets these
        # from content=bytes, and forwarding them causes RFC 7230 violations (502 at Kong).
        # content-encoding is not forwarded because we strip Accept-Encoding on the request
        # side, so Express never compresses. If it did, httpx auto-decodes but we can't
        # signal the encoding to the client without re-compressing.
        _SAFE_FORWARD_HEADERS = frozenset({"retry-after"})
        forwarded_headers = {
            k: v for k, v in response.headers.items()
            if k in _SAFE_FORWARD_HEADERS
        }
        return Response(
            content=response.content,
            status_code=response.status_code,
            headers=forwarded_headers,
            media_type=response.headers.get("content-type", "application/json"),
        )

    except httpx.ConnectError as e:
        # Connection error: GraphQL service is unavailable
        logger.error(
            "Failed to connect to GraphQL service at %s: %s",
            graphql_endpoint,
            e,
        )

        # Return GraphQL-compatible error response (follows GraphQL error format)
        error_response = {
            "errors": [
                {
                    "message": "GraphQL unavailable",
                    "extensions": {
                        "code": "SERVICE_UNAVAILABLE",
                    },
                }
            ]
        }

        return Response(
            content=json.dumps(error_response),
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            media_type="application/json",
        )

    except httpx.TimeoutException as e:
        # Timeout error: GraphQL service didn't respond in time
        logger.error("GraphQL service request timed out: %s", e)

        # Return GraphQL-compatible timeout error
        error_response = {
            "errors": [
                {
                    "message": "GraphQL service request timed out",
                    "extensions": {
                        "code": "GATEWAY_TIMEOUT",
                    },
                }
            ]
        }

        return Response(
            content=json.dumps(error_response),
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            media_type="application/json",
        )

    except Exception as e:  # pragma: no cover - defensive logging
        # Unexpected error: log and return GraphQL-compatible error
        logger.exception("Unexpected error in GraphQL proxy: %s", e)

        # Return GraphQL-compatible internal error
        error_response = {
            "errors": [
                {
                    "message": f"Internal proxy error: {str(e)}",
                    "extensions": {
                        "code": "INTERNAL_SERVER_ERROR",
                    },
                }
            ]
        }

        return Response(
            content=json.dumps(error_response),
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            media_type="application/json",
        )
