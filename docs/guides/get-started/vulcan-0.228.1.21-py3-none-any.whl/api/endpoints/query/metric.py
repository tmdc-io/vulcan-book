"""Metric query endpoint.

This repo previously exposed a dedicated metric route which accepted a metric name plus
optional slice/filters and executed it by translating to the existing semantic REST query
shape (Cube-compatible) and submitting through the shared statement flow.

The original implementation lived on branches which still had the legacy semantic catalog
types. In the OSI-merged codebase, metric definitions are loaded from the Vulcan Context's
semantic metric models, so this endpoint is implemented as a thin adapter over
`POST /api/v1/query/semantic/rest`.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from pydantic import Field
from pydantic import model_validator
from pgqueuer import QueueManager
from vulcan.core.query.transpiler import RestQuery, TranspilerClient
from vulcan.core.state_sync.db.query import QueryState
from vulcan.utils.pydantic import PydanticModel

from schema._semantic_types import MetricGranularityValue
from schema.metadata import ModelEntry as MetadataModelEntry

from api.context import EnvContext
from api.endpoints.query import submit_sql_via_flow
from api.endpoints.query.models import StatementAccepted
from api.endpoints.query.query import _transpile_or_http_error
from api.endpoints.query.types import QueryType
from api.settings import (
    get_default_gateway,
    get_env_context,
    get_query_state,
    get_query_validator,
    get_queue_manager,
    get_transpiler,
    get_user,
)
from api.utils.urls import urls

logger = logging.getLogger(__name__)
router = APIRouter()


class MetricFilterItem(PydanticModel):
    member: str = Field(min_length=1)

    model_config = {"extra": "allow"}


class MetricFilterGroup(PydanticModel):
    and_: t.Optional[t.List["MetricFilterExpression"]] = Field(default=None, alias="and")
    or_: t.Optional[t.List["MetricFilterExpression"]] = Field(default=None, alias="or")

    model_config = {"extra": "allow", "populate_by_name": True}

    @model_validator(mode="after")
    def _validate_non_empty(self) -> "MetricFilterGroup":
        if not self.and_ and not self.or_:
            raise ValueError("Metric filter group requires 'and' or 'or'")
        return self


MetricFilterExpression = t.Union[MetricFilterItem, MetricFilterGroup]


@dataclass(frozen=True, slots=True)
class MetricQueryPlan:
    metric_name: str
    measure_ref: str
    time_ref: str
    slice_map: dict[str, str]
    segments: t.Optional[t.List[str]]
    default_granularity: MetricGranularityValue

    @classmethod
    def from_metadata(cls, entry: MetadataModelEntry) -> "MetricQueryPlan":
        measure_ref: t.Optional[str] = None
        time_ref: t.Optional[str] = None
        slice_map: dict[str, str] = {}
        segments: t.List[str] = []

        for col in entry.columns or []:
            deps = col.depends_on or []
            dep0 = deps[0] if deps else None
            ref = ""
            if dep0 is not None and dep0.model and dep0.column:
                ref = f"{dep0.model}.{dep0.column}"

            if col.name == "measure":
                measure_ref = ref or None
            elif col.name == "ts":
                time_ref = ref or None
            elif col.kind == "dimension":
                slice_map[col.name] = ref
            elif col.kind == "segment" and ref:
                segments.append(ref)

        if not measure_ref or not time_ref:
            raise HTTPException(
                status_code=500,
                detail=f"Metric '{entry.name}' missing measure/ts in metadata export",
            )
        if entry.default_granularity is None:
            raise HTTPException(
                status_code=500,
                detail=f"Metric '{entry.name}' missing default_granularity in metadata export",
            )

        return cls(
            metric_name=entry.name,
            measure_ref=measure_ref,
            time_ref=time_ref,
            slice_map=slice_map,
            segments=segments or None,
            default_granularity=entry.default_granularity,
        )


MetricFilterGroup.model_rebuild()


class MetricQueryRequest(PydanticModel):
    """POST body for metric queries with dimensions ("slices") and ad-hoc filters.

    Both dimensions and filter members may use dimension alias names (e.g. 'plan_type')
    which are resolved to qualified refs (e.g. 'subscriptions.plan_type') from the
    metric definition.
    """

    slices: t.Optional[t.List[str]] = None
    granularity: t.Optional[MetricGranularityValue] = None
    timezone: t.Optional[str] = None
    filters: t.Optional[t.List[MetricFilterExpression]] = None
    limit: int = Field(default=10000, ge=1, le=50000)
    offset: int = Field(default=0, ge=0)

    model_config = {"extra": "ignore"}


def _metric_from_context(ctx: EnvContext, metric_name: str) -> t.Optional[MetadataModelEntry]:
    return ctx.metrics_by_name.get(metric_name)


def _resolve_filter_tree(filter_obj: t.Any, alias_map: dict[str, str]) -> t.Any:
    if hasattr(filter_obj, "model_dump"):
        filter_obj = filter_obj.model_dump(exclude_none=True, by_alias=True)

    if isinstance(filter_obj, list):
        return [_resolve_filter_tree(item, alias_map) for item in filter_obj]

    if isinstance(filter_obj, dict):
        member = filter_obj.get("member")
        if isinstance(member, str) and member in alias_map:
            filter_obj = {**filter_obj, "member": alias_map[member]}
        return {key: _resolve_filter_tree(value, alias_map) for key, value in filter_obj.items()}

    return filter_obj


def _resolve_filters(
    filters: t.List[t.Any],
    alias_map: dict[str, str],
) -> t.List[t.Dict[str, t.Any]]:
    return [t.cast(t.Dict[str, t.Any], _resolve_filter_tree(f, alias_map)) for f in filters]


def _effective_metric_granularity(
    metric_default: t.Any,
    requested: t.Optional[MetricGranularityValue],
) -> MetricGranularityValue:
    allowed = t.get_args(MetricGranularityValue)
    if requested is not None:
        if requested not in allowed:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid granularity '{requested}'. Allowed values: {sorted(allowed)}",
            )
        return requested

    if not isinstance(metric_default, str):
        raise HTTPException(
            status_code=500,
            detail="Metric default granularity is missing metric model.",
        )

    if isinstance(metric_default, str):
        candidate = metric_default.strip().lower()
        if candidate in allowed:
            return t.cast(MetricGranularityValue, candidate)

    raise HTTPException(
        status_code=500,
        detail=(
            f"Metric default granularity '{metric_default}' is invalid. "
            f"Allowed values: {sorted(allowed)}"
        ),
    )


def build_rest_query(
    plan: MetricQueryPlan,
    *,
    granularity: MetricGranularityValue,
    slices: t.Optional[t.List[str]] = None,
    filters: t.Optional[t.List[t.Dict[str, t.Any]]] = None,
    timezone: str = "UTC",
    timezone_name: t.Optional[str] = None,
    limit: int = 10000,
    offset: int = 0,
) -> RestQuery:
    if timezone_name is not None:
        timezone = timezone_name

    measure = plan.measure_ref
    ts = plan.time_ref
    alias_map = plan.slice_map
    segments = plan.segments

    dimensions: t.Optional[t.List[str]] = None
    if slices:
        requested = [s.strip() for s in slices if isinstance(s, str) and s.strip()]
        requested = list(dict.fromkeys(requested))
        available = set(alias_map.keys())
        unknown = sorted(set(requested) - available)
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=(f"Unknown slice(s) for metric '{plan.metric_name}': {unknown}. "
                        f"Available slices: {sorted(available)}"),
            )
        dimensions = []
        for slice_name in requested:
            ref = alias_map.get(slice_name, "")
            if not ref:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Metric is misconfigured for metric '{plan.metric_name}': "
                        f"slice '{slice_name}.ref' is missing"
                    ),
                )
            dimensions.append(ref)
        if not dimensions:
            dimensions = None

    time_dimensions = [{"dimension": ts, "granularity": granularity}]

    kwargs: dict[str, t.Any] = dict(
        measures=[measure],
        dimensions=dimensions,
        segments=segments,
        timeDimensions=time_dimensions,
        filters=filters,
        limit=limit,
        offset=offset,
    )
    kwargs["timezone"] = timezone

    return RestQuery(**kwargs)


def derive_cols_mapping(plan: MetricQueryPlan, rest_query: RestQuery) -> dict[str, str]:
    cols: dict[str, str] = {}
    measure = plan.measure_ref
    ts = plan.time_ref
    alias_map = plan.slice_map

    cols[measure] = "measure"
    gran = None
    if rest_query.timeDimensions:
        gran = rest_query.timeDimensions[0].get("granularity")
    cols[f"{ts}.{gran}" if gran else ts] = "time"

    ref_to_alias = {ref: alias for alias, ref in alias_map.items()}
    for dim in rest_query.dimensions or []:
        if dim in ref_to_alias:
            cols[dim] = ref_to_alias[dim]
    return cols


def _attach_cols_mapping(accepted: StatementAccepted, cols_mapping: dict[str, str]) -> StatementAccepted:
    return accepted.model_copy(update={"cols_mapping": cols_mapping})


async def _transpile_and_submit(
    *,
    metric_name: str,
    rest_query: RestQuery,
    request: Request,
    response: Response,
    ctx: EnvContext,
    transpiler: TranspilerClient,
    qv,
    query_state: QueryState,
    qm: QueueManager,
    default_gateway: str,
    user: t.Dict[str, t.Any],
) -> StatementAccepted:
    dialect = ctx.get_dialect(default_gateway)
    auth_headers = {"Authorization": auth} if (auth := request.headers.get("Authorization")) else None

    transpiler_response = await _transpile_or_http_error(
        rest_query,
        invalid_msg="Invalid metric query",
        disable_post_processing=True,
        user=user.get("user_id", ""),
        transpiler=transpiler,
        dialect=dialect,
        ctx=ctx,
        auth_headers=auth_headers,
    )

    accepted = await submit_sql_via_flow(
        sql=transpiler_response.wrapped_sql_statement,
        params=transpiler_response.sql_params,
        ttl=0,
        meta={"metric_name": metric_name},
        gateway=default_gateway,
        qv=qv,
        qm=qm,
        query_state=query_state,
        env_context=ctx,
        query_type=QueryType.SEMANTIC_METRIC.value,
        rest_query=rest_query.model_dump(exclude_none=True),
        submitted_by=user.get("user_id", ""),
    )

    response.headers["Location"] = urls.query_statement_detail(accepted.id)
    return accepted


@router.get(
    "/{metric_name}",
    summary="Submit metric query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    status_code=202,
    responses={
        202: {"description": "Statement accepted; use `_links` to poll status and fetch results."},
        400: {"description": "Invalid metric query or SQL generation failed"},
        404: {"description": "Metric not found"},
        502: {"description": "Transpiler error"},
    },
)
async def get_metric(
    request: Request,
    response: Response,
    metric_name: str,
    slices: t.Optional[str] = Query(
        default=None,
        description="Comma-separated slice dimensions (aliases defined on the metric)",
    ),
    granularity: t.Optional[MetricGranularityValue] = Query(
        default=None,
        description="Time-series granularity (second, minute, hour, day, week, month, quarter, year)",
    ),
    timezone: t.Optional[str] = Query(default=None, description="Timezone for time dimensions"),
    limit: int = Query(default=10000, ge=1, le=50000, description="Max rows"),
    offset: int = Query(default=0, ge=0, description="Rows to skip"),
    ctx: EnvContext = Depends(get_env_context),
    transpiler: TranspilerClient = Depends(get_transpiler),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> StatementAccepted:
    metric = _metric_from_context(ctx, metric_name)
    if not metric:
        raise HTTPException(status_code=404, detail=f"Metric '{metric_name}' not found")

    plan = MetricQueryPlan.from_metadata(metric)
    effective_granularity = _effective_metric_granularity(plan.default_granularity, granularity)

    slices_list = [s.strip() for s in slices.split(",") if s.strip()] if slices else None

    rest_query = build_rest_query(
        plan,
        slices=slices_list,
        granularity=effective_granularity,
        timezone=timezone or "UTC",
        limit=limit,
        offset=offset,
    )

    cols_mapping = derive_cols_mapping(plan, rest_query)
    accepted = await _transpile_and_submit(
        metric_name=metric_name,
        rest_query=rest_query,
        request=request,
        response=response,
        ctx=ctx,
        transpiler=transpiler,
        qv=qv,
        query_state=query_state,
        qm=qm,
        default_gateway=default_gateway,
        user=user,
    )
    return _attach_cols_mapping(accepted, cols_mapping)


@router.post(
    "/{metric_name}",
    summary="Submit customizable metric query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    status_code=202,
    responses={
        202: {"description": "Statement accepted; use `_links` to poll status and fetch results."},
        400: {"description": "Invalid metric query or SQL generation failed"},
        404: {"description": "Metric not found"},
        502: {"description": "Transpiler error"},
    },
)
async def post_metric(
    request: Request,
    response: Response,
    metric_name: str,
    body: MetricQueryRequest,
    ctx: EnvContext = Depends(get_env_context),
    transpiler: TranspilerClient = Depends(get_transpiler),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> StatementAccepted:
    metric = _metric_from_context(ctx, metric_name)
    if not metric:
        raise HTTPException(status_code=404, detail=f"Metric '{metric_name}' not found")

    plan = MetricQueryPlan.from_metadata(metric)
    effective_granularity = _effective_metric_granularity(plan.default_granularity, body.granularity)

    resolved_filters = (
        _resolve_filters(
            [f.model_dump(exclude_none=True) for f in body.filters],
            plan.slice_map,
        )
        if body.filters
        else None
    )

    rest_query = build_rest_query(
        plan,
        slices=body.slices,
        granularity=effective_granularity,
        filters=resolved_filters,
        timezone=body.timezone or "UTC",
        limit=body.limit,
        offset=body.offset,
    )

    cols_mapping = derive_cols_mapping(plan, rest_query)
    accepted = await _transpile_and_submit(
        metric_name=metric_name,
        rest_query=rest_query,
        request=request,
        response=response,
        ctx=ctx,
        transpiler=transpiler,
        qv=qv,
        query_state=query_state,
        qm=qm,
        default_gateway=default_gateway,
        user=user,
    )
    return _attach_cols_mapping(accepted, cols_mapping)
