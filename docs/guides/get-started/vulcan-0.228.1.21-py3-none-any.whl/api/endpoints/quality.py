"""Quality endpoints: product summary and checks."""

from __future__ import annotations

import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field as PydanticField, ConfigDict

from api.context import EnvContext
from api.definitions import Link, SelfLink
from api.settings import get_env_context
from api.utils.async_blocking import run_blocking
from api.utils.cache import cached, CachePolicy
from api.utils.urls import urls
from vulcan.core.soda3.spec import (
    CheckRuns,
    CheckResultWithRunId as CoreCheckRun,
    CheckOutcome,
    ProductQualitySummary,
)
from vulcan.utils.pydantic import PydanticModel

router = APIRouter()


class CheckRunLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    run: Link


class CheckRun(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    outcome: CheckOutcome
    outcome_reasons: t.Optional[t.Dict[str, t.Any]] = None
    diagnostics: t.Dict[str, t.Any] = PydanticField(default_factory=dict)
    run_id: str
    start_ts: int
    end_ts: t.Optional[int] = None
    links: CheckRunLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class CheckDefLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    self_link: Link = PydanticField(
        alias="self", serialization_alias="self", description="Link to check detail page"
    )


class CheckDef(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    check_identity: str
    check_name: t.Optional[str] = None
    check_type: t.Optional[str] = None
    column_name: t.Optional[str] = None
    dimension: t.Optional[str] = None
    definition: t.Optional[str] = None
    model_name: t.Optional[str] = None

    runs: t.List[CheckRun] = PydanticField(default_factory=list)
    links: CheckDefLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class ChecksResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    checks: t.List[CheckDef]
    total: int
    links: SelfLink = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class CheckRunsLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    self_link: Link = PydanticField(
        alias="self", serialization_alias="self", description="Self reference link"
    )
    checks: Link


class CheckRunsResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    check: CheckDef
    links: CheckRunsLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


def _extract_run(core_check_run: CoreCheckRun) -> CheckRun:
    """Extract run-only data from core CheckRun, removing metadata redundancy."""
    return CheckRun(
        outcome=core_check_run.outcome,
        outcome_reasons=core_check_run.outcome_reasons,
        diagnostics=core_check_run.diagnostics,
        run_id=core_check_run.run_id,
        start_ts=core_check_run.start_ts,
        end_ts=core_check_run.end_ts,
        links=CheckRunLinks(run=Link(href=urls.run(core_check_run.run_id))),
    )


def _check_runs_to_def(check_runs: CheckRuns) -> CheckDef:
    runs = [_extract_run(run) for run in check_runs.runs]

    return CheckDef(
        check_identity=check_runs.check_identity,
        check_name=check_runs.check_name,
        check_type=check_runs.check_type,
        column_name=check_runs.column_name,
        dimension=check_runs.dimension,
        definition=check_runs.definition,
        model_name=check_runs.model_name,
        runs=runs,
        links=CheckDefLinks(
            self_link=Link(href=urls.quality_check_runs(check_runs.check_identity))
        ),
    )


@router.get(
    "",
    summary="Get quality summary",
    response_model=ProductQualitySummary,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Product quality summary returned successfully"},
        404: {"description": "No quality data for environment"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_summary(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> ProductQualitySummary:
    """
    Get product-level quality summary for the current environment.

    Returns aggregated quality metrics using the latest evaluation per check.
    No run_id required. Metrics are grouped by dimension (e.g., completeness,
    accuracy, timeliness) and include pass/fail/warn/error counts and pass rates.
    """
    environment = ctx.environment
    summary = await run_blocking(
        ctx.context.state_sync.get_quality_summary, environment=environment
    )

    if not summary:
        raise HTTPException(
            status_code=404,
            detail=f"No quality data found for environment '{environment}'",
        )

    return summary


@router.get(
    "/checks",
    summary="List checks",
    response_model=ChecksResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Quality checks returned successfully"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_checks(
    model_name: t.Optional[str] = Query(
        None, description="Comma-separated model names. Omit for all."
    ),
    column_name: t.Optional[str] = Query(None, description="Filter by column name. Omit for all."),
    dimension: t.Optional[str] = Query(None, description="Filter by dimension. Omit for all."),
    runs_per_check: int = Query(
        default=10, ge=1, le=100, description="Runs per check (default 10)"
    ),
    limit: int = Query(default=100, ge=1, le=1000, description="Max checks to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> ChecksResponse:
    """
    List all quality checks with their latest execution status.

    Returns a catalog of all unique quality checks that have been executed, including check metadata
    (identity, name, type, dimension, definition) and the most recent execution results. Each check's
    `runs` array contains up to `runs_per_check` executions (default 10), ordered by most recent first.

    Use query parameters to filter checks by `model_name` (comma-separated), `column_name`, or
    `dimension`. Use `limit` and `offset` to paginate checks. Use `start_ts` and `end_ts` to filter
    by check evaluation time (when the check ran).

    To see full execution history for a specific check, use the `/quality/checks/{check_identity}` endpoint.
    """
    model_names = None
    if model_name:
        model_names = [m.strip() for m in model_name.split(",") if m.strip()]

    check_runs_list = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        model_names=model_names,
        column_name=column_name,
        dimension=dimension,
        runs_per_check=runs_per_check,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    check_runs_list = check_runs_list or []
    check_defs = [_check_runs_to_def(cr) for cr in check_runs_list]

    query_params = []
    if model_name:
        query_params.append(f"model_name={model_name}")
    if column_name:
        query_params.append(f"column_name={column_name}")
    if dimension:
        query_params.append(f"dimension={dimension}")
    if runs_per_check != 10:
        query_params.append(f"runs_per_check={runs_per_check}")
    if limit != 100:
        query_params.append(f"limit={limit}")
    if offset:
        query_params.append(f"offset={offset}")
    if start_ts is not None:
        query_params.append(f"start_ts={start_ts}")
    if end_ts is not None:
        query_params.append(f"end_ts={end_ts}")
    query_string = "&".join(query_params) if query_params else ""

    return ChecksResponse(
        checks=check_defs,
        total=len(check_defs),
        links=SelfLink(
            self_link=Link(
                href=f"/api/v1/quality/checks?{query_string}"
                if query_string
                else "/api/v1/quality/checks"
            )
        ),
    )


@router.get(
    "/checks/by-name/{model_name}/{dimension}/{check_name:path}",
    summary="Get check by name",
    response_model=CheckRunsResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Quality check runs returned successfully"},
        404: {"description": "Check not found or has no runs"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_check_by_name(
    model_name: str,
    dimension: str,
    check_name: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Max runs to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> CheckRunsResponse:
    """
    Get execution history for a specific quality check by natural key.

    Lookup by (model_name, dimension, check_name) instead of check_identity hash.
    Supports check_name with slashes via path:path (e.g. users/has/rows).
    Same response as GET /checks/{check_identity}.
    """
    check_identity = await run_blocking(
        ctx.context.state_sync.get_check_identity_by_natural_key,
        environment=ctx.environment,
        model_name=model_name,
        dimension=dimension,
        check_name=check_name,
    )
    if not check_identity:
        raise HTTPException(
            status_code=404,
            detail=f"Check not found: {model_name}/{dimension}/{check_name} for environment '{ctx.environment}'",
        )

    result = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        check_identity=check_identity,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail=f"Check '{check_name}' has no runs for environment '{ctx.environment}'",
        )

    query_params = []
    if limit != 20:
        query_params.append(f"limit={limit}")
    if offset:
        query_params.append(f"offset={offset}")
    if start_ts is not None:
        query_params.append(f"start_ts={start_ts}")
    if end_ts is not None:
        query_params.append(f"end_ts={end_ts}")
    query_string = "&".join(query_params) if query_params else ""

    check_def = _check_runs_to_def(result[0])

    links = CheckRunsLinks(
        self_link=Link(
            href=urls.quality_check_runs_by_name(
                model_name=model_name,
                dimension=dimension,
                check_name=check_name,
                limit=limit if limit != 20 else None,
                offset=offset or None,
                start_ts=start_ts,
                end_ts=end_ts,
            )
        ),
        checks=Link(href=urls.quality_checks()),
    )

    return CheckRunsResponse(
        check=check_def,
        links=links,
    )


@router.get(
    "/checks/{check_identity}",
    summary="Get check",
    response_model=CheckRunsResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Quality check runs returned successfully"},
        404: {"description": "Check not found or has no runs"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_check(
    check_identity: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Max runs to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: check evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> CheckRunsResponse:
    """
    Get execution history for a specific quality check.

    Returns the execution history of a check across multiple runs, showing how its outcome
    changed over time. The `runs` array contains executions ordered by most recent first, with
    each entry including run metadata (`run_id`, `start_ts`, `end_ts`) and check outcome (`pass`/`fail`/`warn`/`error`).

    Use `limit` and `offset` to paginate runs. Use `start_ts` and `end_ts` to filter by check evaluation time.

    To list all checks with their latest status, use the `/quality/checks` endpoint.
    """
    result = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        check_identity=check_identity,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail=f"Check '{check_identity}' not found or has no runs for environment '{ctx.environment}'",
        )

    query_params = []
    if limit != 20:
        query_params.append(f"limit={limit}")
    if offset:
        query_params.append(f"offset={offset}")
    if start_ts is not None:
        query_params.append(f"start_ts={start_ts}")
    if end_ts is not None:
        query_params.append(f"end_ts={end_ts}")
    query_string = "&".join(query_params) if query_params else ""

    check_def = _check_runs_to_def(result[0])

    links = CheckRunsLinks(
        self_link=Link(
            href=f"/api/v1/quality/checks/{check_identity}?{query_string}"
            if query_string
            else f"/api/v1/quality/checks/{check_identity}"
        ),
        checks=Link(href=urls.quality_checks()),
    )

    return CheckRunsResponse(
        check=check_def,
        links=links,
    )
