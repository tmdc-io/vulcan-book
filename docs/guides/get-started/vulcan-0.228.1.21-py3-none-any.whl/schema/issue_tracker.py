from __future__ import annotations

import typing as t

from pydantic import AnyHttpUrl

from schema import _PydanticModel

IssueTrackerProviderValue = t.Literal[
    "jira",
    "github",
    "gitlab",
    "linear",
    "asana",
    "azure_devops",
    "other",
]


class IssueTracker(_PydanticModel):
    provider: IssueTrackerProviderValue
    url: AnyHttpUrl
