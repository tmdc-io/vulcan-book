"""
Wire-only vocabulary shared by ``schema.cube`` and ``schema.metadata``.

This module is the single source of truth for the slim wire's semantic vocabulary
(logical type names, join cardinalities, measure aggregations, time grains,
rolling-window and time-granularity Pydantic shapes, etc.). It deliberately
depends only on ``pydantic`` and the standard library so the ``schema`` package
can be vendored into minimal consumers (e.g. the transpiler container) without
pulling in ``vulcan`` or ``sqlglot``.

The engine (``vulcan.core.model.semantic``) re-exports the Literal aliases
from here and either re-exports or subclasses the Pydantic specs to add
producer-side methods (hashing, render-to-sqlglot expression, etc.).
"""

from __future__ import annotations

import re
import typing as t
from enum import Enum

import pydantic
from pydantic import ConfigDict, Field, field_validator
from typing_extensions import Literal


_WIRE_CONFIG = ConfigDict(extra="forbid", protected_namespaces=())


LogicalTypeValue = Literal["number", "string", "time", "boolean"]
JoinRelationshipValue = Literal["one_to_one", "one_to_many", "many_to_one"]
MeasureTypeValue = Literal[
    "count",
    "count_distinct",
    "count_distinct_approx",
    "sum",
    "avg",
    "min",
    "max",
    "number",
    "string",
    "time",
    "boolean",
]
MetricGranularityValue = Literal[
    "second",
    "minute",
    "hour",
    "day",
    "week",
    "month",
    "quarter",
    "year",
]


VALID_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


class NamingError(ValueError):
    """
    Invalid semantic identifier (vendored from the engine for wire-side validators).
    """


def _validate_name(value: str, *, context: str = "name") -> str:
    """
    Enforce the lowercase semantic identifier rule used across the wire vocabulary.

    Args:
        value: Candidate identifier.
        context: Human-readable label included in the error message.

    Returns:
        ``value`` unchanged when it satisfies ``VALID_NAME_PATTERN``.

    Raises:
        NamingError: If ``value`` is empty or does not match the pattern.
    """
    if not value:
        raise NamingError(f"{context} must not be empty")
    if not VALID_NAME_PATTERN.match(value):
        raise NamingError(
            f"{context} must match {VALID_NAME_PATTERN.pattern}, got {value!r}"
        )
    return value


AiContextExampleFormat = Literal["sql", "graphql", "rest"]


class AiContextExampleSpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    description: str
    format: AiContextExampleFormat = "sql"
    query: str

    @field_validator("description", "query")
    @classmethod
    def _strip_non_empty(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("must not be empty")
        return stripped


class AiContextSpec(pydantic.BaseModel):
    """
    Structured ``ai_context`` for AI/BI tools (OSI core metadata: AI context structure).

    Mirrored from the engine spec; carried on the wire so consumers can surface it
    without round-tripping through the engine.
    """

    model_config = _WIRE_CONFIG

    instructions: t.Optional[str] = None
    synonyms: t.List[str] = Field(default_factory=list)
    examples: t.List[AiContextExampleSpec] = Field(default_factory=list)


class RollingWindowSpec(pydantic.BaseModel):
    """
    Rolling window on a measure: how far the window reaches and where it anchors.

    Wire-only fields and validators. Producer-side helpers (rendering to a sqlglot
    expression, hashing for fingerprints, etc.) live on engine code paths because
    the wire never executes them.
    """

    model_config = _WIRE_CONFIG

    _ROLLING_WINDOW_RE: t.ClassVar[re.Pattern[str]] = re.compile(
        r"^-?\d+\s+(minute|hour|day|week|month|year)s?$", re.IGNORECASE
    )

    trailing: t.Optional[str] = None
    leading: t.Optional[str] = None
    offset: str = "end"

    @field_validator("trailing", "leading")
    @classmethod
    def validate_window_size(cls, v: t.Optional[str]) -> t.Optional[str]:
        if v is None or str(v).lower() == "unbounded":
            return v
        if not cls._ROLLING_WINDOW_RE.match(str(v).strip()):
            raise ValueError(
                f"Invalid window size {v!r}. Use e.g. '1 day', '30 days', or 'unbounded'"
            )
        return str(v).strip()

    @field_validator("offset")
    @classmethod
    def validate_offset(cls, v: str) -> str:
        if v not in ("start", "end"):
            raise ValueError(f"offset must be 'start' or 'end', got {v!r}")
        return v


class TimeGranularitySpec(pydantic.BaseModel):
    """
    Named time grain for an object dimension (e.g. finer buckets on a timestamp column).

    Wire-only fields and validators. The engine subclass adds ``data_hash`` /
    ``metadata_hash`` / ``render_exp`` for producer-side use.
    """

    model_config = _WIRE_CONFIG

    _INTERVAL_RE: t.ClassVar[re.Pattern[str]] = re.compile(
        r"^\d+\s+(minute|hour|day|week|month|year)s?$", re.IGNORECASE
    )

    name: str
    interval: str
    offset: t.Optional[str] = None
    origin: t.Optional[str] = None
    description: t.Optional[str] = None
    ai_context: t.Optional[AiContextSpec] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return _validate_name(v, context="granularity name")

    @field_validator("interval")
    @classmethod
    def validate_interval(cls, v: str) -> str:
        if not cls._INTERVAL_RE.match(v.strip()):
            raise ValueError(
                f"Invalid interval {v!r}. Use a positive duration like '1 day' or '15 minutes'"
            )
        return v.strip()


DQDimension = Literal[
    "accuracy",
    "completeness",
    "conformity",
    "consistency",
    "coverage",
    "timeliness",
    "validity",
    "uniqueness",
]


class IntervalUnit(str, Enum):
    """
    Wire-only granularity enum carried on ``ColumnEntry`` / ``Metadata`` payloads.

    Mirrors the 7 members of :class:`vulcan.core.node.IntervalUnit`. Producer-side
    helpers (``from_cron``, cron expression rendering, second counts, etc.) live on
    the engine class because they pull in cron utilities the wire deliberately
    avoids. Drift risk is bounded: the string values are wire contract and changing
    them on either side is a breaking change.
    """

    YEAR = "year"
    MONTH = "month"
    DAY = "day"
    HOUR = "hour"
    HALF_HOUR = "half_hour"
    QUARTER_HOUR = "quarter_hour"
    FIVE_MINUTE = "five_minute"

    @property
    def is_date_granularity(self) -> bool:
        return self in (IntervalUnit.YEAR, IntervalUnit.MONTH, IntervalUnit.DAY)

    @property
    def is_year(self) -> bool:
        return self == IntervalUnit.YEAR

    @property
    def is_month(self) -> bool:
        return self == IntervalUnit.MONTH

    @property
    def is_day(self) -> bool:
        return self == IntervalUnit.DAY

    @property
    def is_hour(self) -> bool:
        return self == IntervalUnit.HOUR

    @property
    def is_minute(self) -> bool:
        return self in (
            IntervalUnit.FIVE_MINUTE,
            IntervalUnit.QUARTER_HOUR,
            IntervalUnit.HALF_HOUR,
        )
