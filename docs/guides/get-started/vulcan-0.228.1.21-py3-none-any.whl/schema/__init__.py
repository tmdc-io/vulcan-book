from __future__ import annotations

import pydantic


class _PydanticModel(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(
        extra="forbid",
        protected_namespaces=(),
        arbitrary_types_allowed=True,
        populate_by_name=True,
    )


from schema.cube import (
    Cube,
    CubeDimension,
    CubeJoin,
    CubeMeasure,
    CubeRef,
    CubeSchema,
    CubeSegment,
    Include,
    View,
)
