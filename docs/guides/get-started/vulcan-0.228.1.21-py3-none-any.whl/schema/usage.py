from __future__ import annotations

import typing as t

from pydantic import model_validator

from schema import _PydanticModel

UsageReferenceType = t.Literal["doc", "design", "dashboard", "runbook", "other"]
CaveatSeverity = t.Literal["low", "medium", "high"]


def _coerce_title_string(data: t.Any) -> t.Any:
    if isinstance(data, str):
        return {"title": data}
    return data


class UsageItem(_PydanticModel):
    title: str
    details: t.Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def _accept_title_string(cls, data: t.Any) -> t.Any:
        return _coerce_title_string(data)


class Caveat(_PydanticModel):
    title: str
    details: t.Optional[str] = None
    severity: CaveatSeverity = "medium"

    @model_validator(mode="before")
    @classmethod
    def _accept_title_string(cls, data: t.Any) -> t.Any:
        return _coerce_title_string(data)


class Reference(_PydanticModel):
    title: str
    url: str
    type: UsageReferenceType = "doc"


class Usage(_PydanticModel):
    good_for: t.List[UsageItem] = []
    not_for: t.List[UsageItem] = []
    caveats: t.List[Caveat] = []
    references: t.List[Reference] = []
