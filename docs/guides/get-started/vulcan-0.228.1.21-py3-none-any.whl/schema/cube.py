from __future__ import annotations

import typing as t

import pydantic

from schema._semantic_types import (
    JoinRelationshipValue,
    LogicalTypeValue,
    MeasureTypeValue,
    RollingWindowSpec,
    TimeGranularitySpec,
)


class _PydanticModel(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="forbid", protected_namespaces=())


class CubeMeasure(_PydanticModel):
    name: str
    type: MeasureTypeValue
    sql: str
    filters: t.List[dict] = []
    rolling_window: t.Optional[RollingWindowSpec] = None
    public: bool = True


class CubeDimension(_PydanticModel):
    name: str
    sql: str
    type: LogicalTypeValue
    primary_key: bool = False
    public: bool = True
    format: t.Optional[str] = None
    granularities: t.Optional[t.List[TimeGranularitySpec]] = None


class CubeSegment(_PydanticModel):
    name: str
    sql: str
    public: bool = True


class CubeJoin(_PydanticModel):
    name: str
    relationship: JoinRelationshipValue
    sql: str


class Cube(_PydanticModel):
    name: str
    sql_table: str
    measures: t.List[CubeMeasure]
    dimensions: t.List[CubeDimension]
    segments: t.List[CubeSegment]
    joins: t.List[CubeJoin]


class Include(_PydanticModel):
    name: str
    alias: str


class CubeRef(_PydanticModel):
    join_path: str
    includes: t.List[t.Union[str, Include]]


class View(_PydanticModel):
    name: str
    cubes: t.List[CubeRef]


class CubeSchema(_PydanticModel):
    cubes: t.List[Cube]
    views: t.List[View]
