from __future__ import annotations

import pydantic


class PydanticModel(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(
        extra="forbid",
        protected_namespaces=(),
        arbitrary_types_allowed=True,
        populate_by_name=True,
    )
