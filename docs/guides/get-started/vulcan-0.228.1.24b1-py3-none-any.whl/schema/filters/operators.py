from __future__ import annotations

import re
import typing as t
from enum import Enum


MEMBER_PATTERN = re.compile(r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$")
DIMENSION_PATTERN = re.compile(r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)?$")
POLICY_FIELD_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")
GROUP_PATTERN = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


class FilterOperator(str, Enum):
    EQUALS = "equals"
    NOT_EQUALS = "notEquals"
    CONTAINS = "contains"
    NOT_CONTAINS = "notContains"
    STARTS_WITH = "startsWith"
    NOT_STARTS_WITH = "notStartsWith"
    ENDS_WITH = "endsWith"
    NOT_ENDS_WITH = "notEndsWith"
    IN = "in"
    NOT_IN = "notIn"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    SET = "set"
    NOT_SET = "notSet"
    IN_DATE_RANGE = "inDateRange"
    NOT_IN_DATE_RANGE = "notInDateRange"
    ON_THE_DATE = "onTheDate"
    BEFORE_DATE = "beforeDate"
    BEFORE_OR_ON_DATE = "beforeOrOnDate"
    AFTER_DATE = "afterDate"
    AFTER_OR_ON_DATE = "afterOrOnDate"
    MEASURE_FILTER = "measureFilter"


RestFilterOperator = FilterOperator

_OPERATORS_WITHOUT_VALUES = frozenset(
    {
        FilterOperator.SET,
        FilterOperator.NOT_SET,
        FilterOperator.MEASURE_FILTER,
    }
)

POLICY_FILTER_OPERATORS = frozenset(FilterOperator) - {
    FilterOperator.MEASURE_FILTER,
}

FilterValue = t.Union[str, int, float, bool, None]
RestFilterValue = FilterValue


def validate_qualified_member(value: str) -> str:
    if not MEMBER_PATTERN.match(value):
        raise ValueError(f"invalid member format: {value!r}")
    return value


def validate_qualified_dimension(value: str) -> str:
    if not DIMENSION_PATTERN.match(value):
        raise ValueError(f"invalid dimension format: {value!r}")
    return value


def validate_policy_field(value: str) -> str:
    if not POLICY_FIELD_PATTERN.match(value):
        raise ValueError(f"invalid policy filter field: {value!r}")
    return value


def validate_policy_group(value: str) -> str:
    group = value.strip()
    if not GROUP_PATTERN.match(group):
        raise ValueError(f"invalid policy group: {group!r}")
    return group


def validate_operator_values(*, operator: FilterOperator, values: list[FilterValue] | None) -> None:
    if operator in _OPERATORS_WITHOUT_VALUES:
        if values is not None:
            raise ValueError(f"operator '{operator.value}' must not include values")
    elif not values:
        raise ValueError(f"operator '{operator.value}' requires values")
