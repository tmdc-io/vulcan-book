from __future__ import annotations

import typing as t

from pydantic import Field, model_serializer, model_validator
from typing_extensions import Literal

from schema import _PydanticModel


class SemanticColumn(_PydanticModel):
    kind: Literal["dimension", "measure"]
    name: str
    ltype: str
    dtype: str
    public: bool = True
    primary_key: bool = False
    description: t.Optional[str] = None
    tags: t.List[str] = Field(default_factory=list)
    terms: t.List[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _primary_key_only_for_dimensions(self) -> SemanticColumn:
        if self.kind == "measure" and self.primary_key:
            raise ValueError("semantic measure rows cannot use primary_key=True")
        return self

    @model_serializer(mode="wrap")
    def _semantic_column_wire(
        self,
        handler: t.Callable[..., t.Dict[str, t.Any]],
    ) -> t.Dict[str, t.Any]:
        data = dict(handler(self))
        if self.kind == "measure":
            data.pop("primary_key", None)
        else:
            data["primary_key"] = bool(self.primary_key)
        return data


class SemanticEntry(_PydanticModel):
    name: str
    kind: Literal["SEMANTIC", "METRIC"]
    description: t.Optional[str] = None
    tags: t.List[str] = Field(default_factory=list)
    terms: t.List[str] = Field(default_factory=list)
    columns: t.List[SemanticColumn] = Field(default_factory=list)


class SemanticSchema(_PydanticModel):
    name: str
    tenant: str
    fingerprint: str
    models: t.List[SemanticEntry] = Field(default_factory=list)
