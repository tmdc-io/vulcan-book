from __future__ import annotations

import typing as t

from pydantic import ConfigDict, Field, model_serializer

from schema import _PydanticModel
from schema.product import IssueTracker, Usage
from schema.filters import PolicyEntry
from schema.types import (
    AiContextSpec,
    ColumnSemanticConfig,
    DQDimension,
    IntervalUnit,
    JoinRelationshipValue,
    LogicalTypeValue,
    MeasureTypeValue,
    MetricGranularityValue,
    RollingWindowSpec,
    TimeGranularitySpec,
)


ModelKindValue = t.Literal[
    "FULL",
    "VIEW",
    "INCREMENTAL_BY_TIME_RANGE",
    "INCREMENTAL_BY_UNIQUE_KEY",
    "INCREMENTAL_BY_PARTITION",
    "INCREMENTAL_UNMANAGED",
    "SCD_TYPE_2",
    "SCD_TYPE_2_BY_TIME",
    "SCD_TYPE_2_BY_COLUMN",
    "EMBEDDED",
    "SEED",
    "EXTERNAL",
    "CUSTOM",
    "MANAGED",
    "DBT_CUSTOM",
    "SEMANTIC",
    "METRIC",
]
ModelSourceType = t.Literal["sql", "seed", "python", "external", "semantic", "metric"]
CheckDimensionValue = DQDimension
ColumnKind = t.Literal["physical", "dimension", "measure", "segment"]
ProductAlignmentValue = t.Literal["source_aligned", "consumer_aligned"]


class TableDetail(_PydanticModel):
    connection_uri: str
    name: str


class Table(_PydanticModel):
    physical: TableDetail
    virtual: t.Optional[TableDetail] = None


class DependsOn(_PydanticModel):
    model_config = ConfigDict(frozen=True)

    model: str
    column: t.Optional[str] = None


class JoinDetail(_PydanticModel):
    model: str
    relationship: JoinRelationshipValue
    expression: str
    ai_context: t.Optional[AiContextSpec] = None


class LineageUpstream(_PydanticModel):
    node: str
    columns: t.List[str] = Field(default_factory=list)


# `from` is a reserved keyword; Python field is `from_`, wire key is "from" (Field alias).
class ColumnLineage(_PydanticModel):
    to: str
    from_: t.List[LineageUpstream] = Field(
        alias="from",
        default_factory=list,
    )


class GraphEdge(_PydanticModel):
    from_: str = Field(alias="from")
    to: str


class JoinEdge(_PydanticModel):
    from_: str = Field(alias="from")
    to: str
    type_: JoinRelationshipValue = Field(alias="type")


class GraphColumn(_PydanticModel):
    name: str
    ltype: LogicalTypeValue
    kind: ColumnKind


class GraphNode(_PydanticModel):
    name: str
    kind: ModelKindValue
    source_type: ModelSourceType
    columns: t.List[GraphColumn] = Field(default_factory=list)
    parents: t.List[str] = Field(default_factory=list)
    children: t.List[str] = Field(default_factory=list)
    column_lineage: t.List[ColumnLineage] = Field(default_factory=list)


class Graph(_PydanticModel):
    nodes: t.List[GraphNode] = Field(default_factory=list)
    edges: t.List[GraphEdge] = Field(default_factory=list)
    relationships: t.List[JoinEdge] = Field(default_factory=list)
    parent_map: t.Dict[str, t.List[str]] = Field(default_factory=dict)
    child_map: t.Dict[str, t.List[str]] = Field(default_factory=dict)


MaskExpression = t.Union[str, int, float, bool]


class DimensionDetails(_PydanticModel):
    time_format: t.Optional[str] = None
    time_granularities: t.Optional[t.List[TimeGranularitySpec]] = None
    mask_expression: t.Optional[MaskExpression] = None


class MeasureDetails(_PydanticModel):
    expression: t.Optional[str] = None
    measure_type: MeasureTypeValue
    filters: t.List[str] = []
    rolling_window: t.Optional[RollingWindowSpec] = None


class SegmentDetails(_PydanticModel):
    expression: t.Optional[str] = None


ColumnDetails = t.Union[DimensionDetails, MeasureDetails, SegmentDetails]


class ColumnEntry(_PydanticModel):
    name: str
    kind: ColumnKind = "physical"
    ltype: LogicalTypeValue
    dtype: str
    primary_key: bool = False
    public: bool = True
    description: t.Optional[str] = None
    tags: t.List[str] = []
    terms: t.List[str] = []
    depends_on: t.List[DependsOn] = []
    details: t.Optional[ColumnDetails] = None
    semantic_config: t.Optional[ColumnSemanticConfig] = None
    ai_context: t.Optional[AiContextSpec] = None


class DqRuleEntry(_PydanticModel):
    name: str
    expression: str
    dimension: CheckDimensionValue
    description: t.Optional[str] = None
    extra: t.Dict[str, t.Any] = Field(default_factory=dict)

    @model_serializer(mode="wrap")
    def _flatten_extra_for_json(
        self,
        handler: t.Callable[..., t.Dict[str, t.Any]],
    ) -> t.Dict[str, t.Any]:
        data = handler(self)
        loose = data.pop("extra", None) or {}
        return {**loose, **data}


class ModelDataQuality(_PydanticModel):
    filter: t.Optional[str] = None
    profiles: t.List[str] = Field(default_factory=list)
    rules: t.List[DqRuleEntry] = Field(default_factory=list)


class AuditEntry(_PydanticModel):
    name: str
    columns: t.Optional[t.List[str]] = None
    args: t.Dict[str, str] = {}


class GatewayInfo(_PydanticModel):
    name: str
    connection_type: str
    dialect: str
    connection_uri: t.Optional[str] = None


class ProductInfo(_PydanticModel):
    display_name: t.Optional[str] = None
    description: t.Optional[str] = None
    readme: t.Optional[str] = None
    tags: t.List[str] = []
    terms: t.List[str] = []
    users: t.List[t.Dict[str, t.Any]] = []
    domain: t.Optional[str] = None
    usage: Usage = Field(default_factory=Usage)
    repository: t.Optional[str] = None
    issue_tracker: t.Optional[IssueTracker] = None


class ModelEntry(_PydanticModel):
    name: str
    fqn: str
    kind: ModelKindValue
    source_type: ModelSourceType
    table: t.Optional[Table] = None
    display_name: t.Optional[str] = None
    description: t.Optional[str] = None
    tags: t.List[str] = []
    terms: t.List[str] = []
    owner: t.Optional[str] = None
    dialect: str = Field(default="")
    cron: str = Field(default="")
    interval_unit: t.Optional[IntervalUnit] = None
    depends_on: t.List[str] = []
    columns: t.List[ColumnEntry] = []
    grains: t.List[str] = Field(default_factory=list)
    dq: t.Optional[ModelDataQuality] = None
    audits: t.List[AuditEntry] = []
    partitioned_by: t.Optional[str] = None
    clustered_by: t.Optional[str] = None
    table_format: t.Optional[str] = None
    storage_format: t.Optional[str] = None
    batch_size: t.Optional[int] = None
    lookback: t.Optional[int] = None
    model_name: t.Optional[str] = None
    joins: t.List[JoinDetail] = []
    default_granularity: t.Optional[MetricGranularityValue] = None
    ai_context: t.Optional[AiContextSpec] = None
    policies: t.List[PolicyEntry] = Field(default_factory=list)


class Metadata(_PydanticModel):
    tenant: str
    name: str
    discoverable: bool = True
    version: str = "0.0.0"
    alignment: ProductAlignmentValue = "consumer_aligned"
    fingerprint: str
    product: ProductInfo
    gateway: t.Optional[GatewayInfo] = None
    models: t.List[ModelEntry] = Field(default_factory=list)
    graph: Graph
    env: str

    def to_json_dict(self) -> t.Dict[str, t.Any]:
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)
