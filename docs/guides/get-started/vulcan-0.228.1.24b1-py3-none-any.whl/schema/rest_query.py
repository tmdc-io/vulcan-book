from __future__ import annotations

import re
import typing as t

import pydantic
from pydantic import Field, field_validator, model_validator
from typing_extensions import Literal

from schema import _PydanticModel
from schema.filters import (
    RestFilterExpression,
    validate_qualified_dimension,
    validate_qualified_member,
)

ORDER_MEMBER_PATTERN = re.compile(
    r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$|^[a-zA-Z0-9_]+$|^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$"
)

RestOrderDirection = Literal["asc", "desc"]
RestDateRange = t.Union[str, t.List[str]]
RestOrderDict = t.Dict[str, RestOrderDirection]
RestOrderList = t.List[t.Tuple[str, RestOrderDirection]]
RestOrder = t.Union[RestOrderDict, RestOrderList]


class RestTimeDimension(_PydanticModel):
    dimension: str
    granularity: t.Optional[str] = Field(default=None, max_length=128)
    dateRange: t.Optional[RestDateRange] = None
    compareDateRange: t.Optional[t.List[t.Any]] = None

    @field_validator("dimension")
    @classmethod
    def _validate_dimension_member(cls, value: str) -> str:
        return validate_qualified_member(value)

    @field_validator("dateRange")
    @classmethod
    def _validate_date_range(cls, value: t.Optional[RestDateRange]) -> t.Optional[RestDateRange]:
        if isinstance(value, list) and not (1 <= len(value) <= 2):
            raise ValueError("dateRange array must contain 1 or 2 values")
        return value

    @model_validator(mode="after")
    def _date_range_xor_compare(self) -> RestTimeDimension:
        if self.dateRange is not None and self.compareDateRange is not None:
            raise ValueError("provide dateRange or compareDateRange, not both")
        return self


class RestQuery(_PydanticModel):
    measures: t.Optional[t.List[str]] = None
    dimensions: t.Optional[t.List[str]] = None
    segments: t.Optional[t.List[str]] = None
    filters: t.Optional[t.List[RestFilterExpression]] = None
    timeDimensions: t.Optional[t.List[RestTimeDimension]] = None
    order: t.Optional[RestOrder] = None
    limit: t.Optional[int] = Field(default=10000, ge=1, le=50000)
    offset: t.Optional[int] = Field(default=None, ge=0)
    timezone: t.Optional[str] = "UTC"
    total: t.Optional[bool] = None
    ungrouped: t.Optional[bool] = None

    model_config = pydantic.ConfigDict(extra="ignore", populate_by_name=True)

    @field_validator("measures", "segments")
    @classmethod
    def _validate_members(cls, value: t.Optional[t.List[str]]) -> t.Optional[t.List[str]]:
        if value is None:
            return value
        for item in value:
            validate_qualified_member(item)
        return value

    @field_validator("dimensions")
    @classmethod
    def _validate_dimensions(cls, value: t.Optional[t.List[str]]) -> t.Optional[t.List[str]]:
        if value is None:
            return value
        for item in value:
            validate_qualified_dimension(item)
        return value

    @field_validator("order")
    @classmethod
    def _validate_order(cls, value: t.Optional[RestOrder]) -> t.Optional[RestOrder]:
        if value is None:
            return value
        if isinstance(value, dict):
            for key in value:
                if not ORDER_MEMBER_PATTERN.match(key):
                    raise ValueError(f"invalid order member: {key!r}")
            return value
        for item in value:
            if len(item) != 2:
                raise ValueError("order tuple must be [member, direction]")
            member, direction = item
            if not ORDER_MEMBER_PATTERN.match(member):
                raise ValueError(f"invalid order member: {member!r}")
            if direction not in ("asc", "desc"):
                raise ValueError(f"invalid order direction: {direction!r}")
        return value

    @model_validator(mode="after")
    def _at_least_one_query_member(self) -> RestQuery:
        if not any([self.measures, self.dimensions, self.timeDimensions]):
            raise ValueError(
                "query requires at least one of measures, dimensions, or timeDimensions"
            )
        return self

    @classmethod
    def from_storage(
        cls,
        raw: t.Mapping[str, t.Any] | str | None,
    ) -> RestQuery | None:
        """
        Parse a REST query from JSONB or a perspective denormalized field.

        Args:
            raw: Parsed JSON object, JSON string, or ``None`` when unset.

        Returns:
            Valid ``RestQuery``, or ``None`` when ``raw`` is missing.

        Raises:
            pydantic.ValidationError: If ``raw`` is present but not a valid query.
        """
        if raw is None:
            return None
        if isinstance(raw, str):
            if not raw.strip():
                return None
            return cls.model_validate_json(raw)
        return cls.model_validate(raw)
