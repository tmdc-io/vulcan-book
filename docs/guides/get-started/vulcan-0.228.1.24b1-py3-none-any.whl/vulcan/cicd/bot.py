from __future__ import annotations

import typing as t

import click

from vulcan import configure_logging
from vulcan.cli import error_handler
from vulcan.cli import options as opt
from vulcan.integrations.github.cicd.command import github


@click.group(no_args_is_help=True)
@opt.paths
@opt.config
@click.pass_context
@error_handler
def bot(
    ctx: click.Context,
    paths: t.List[str],
    config: t.Optional[str] = None,
) -> None:
    """Vulcan CI/CD Bot. Currently only Github Actions is supported. See https://sqlmesh.readthedocs.io/en/stable/integrations/github/ for details"""
    configure_logging(write_to_stdout=True, write_to_file=False)

    ctx.obj = {
        "paths": paths,
        "config": config,
    }


bot.add_command(github)
