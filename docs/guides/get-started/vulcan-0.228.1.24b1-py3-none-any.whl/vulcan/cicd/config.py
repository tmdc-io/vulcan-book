from vulcan.integrations.github.cicd.config import GithubCICDBotConfig

CICDBotConfig = GithubCICDBotConfig
