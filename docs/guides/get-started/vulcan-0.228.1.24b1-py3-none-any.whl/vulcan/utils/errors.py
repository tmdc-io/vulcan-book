from __future__ import annotations

import typing as t
from collections import defaultdict
from enum import auto
from pathlib import Path

from sqlglot import exp
from sqlglot.helper import AutoName

if t.TYPE_CHECKING:
    from requests.models import Response

    from vulcan.core.model import Model
    from vulcan.core.schema_diff import TableAlterOperation


class ErrorLevel(AutoName):
    IGNORE = auto()
    WARN = auto()
    RAISE = auto()


class VulcanError(Exception):
    pass


class ConfigError(VulcanError):
    location: t.Optional[Path] = None

    def __init__(self, message: str | Exception, location: t.Optional[Path] = None) -> None:
        super().__init__(message)
        if location:
            self.location = Path(location) if isinstance(location, str) else location


class BaseMissingReferenceError(ConfigError):
    def __init__(self, ref: str) -> None:
        self.ref = ref


class MissingModelError(BaseMissingReferenceError):
    """Raised when a model that is referenced is missing."""


class MissingSourceError(BaseMissingReferenceError):
    """Raised when a source that is referenced is missing."""


class MissingDependencyError(VulcanError):
    """Local environment is missing a required dependency for the given operation"""


class MacroEvalError(VulcanError):
    pass


class PlanError(VulcanError):
    pass


class NoChangesPlanError(PlanError):
    pass


class UncategorizedPlanError(PlanError):
    pass


class ConflictingPlanError(PlanError):
    pass


class MissingContextException(Exception):
    pass


class SnapshotVersionError(VulcanError):
    pass


class MagicError(VulcanError):
    pass


class AuditConfigError(ConfigError):
    pass


class StateMigrationError(VulcanError):
    pass


class AuditError(VulcanError):
    def __init__(
        self,
        audit_name: str,
        audit_args: t.Dict[t.Any, t.Any],
        count: int,
        query: exp.Query,
        model: t.Optional[Model] = None,
        # the dialect of the engine adapter that evaluated the audit query
        adapter_dialect: t.Optional[str] = None,
    ) -> None:
        self.audit_name = audit_name
        self.audit_args = audit_args
        self.model = model
        self.count = count
        self.query = query
        self.adapter_dialect = adapter_dialect

        super().__init__(
            f"'{self.audit_name}' audit error: {self.count} {'row' if self.count == 1 else 'rows'} failed on model '{self.model.name if self.model else 'unknown'}'"
        )

    @property
    def model_name(self) -> t.Optional[str]:
        return self.model.name if self.model else None

    def sql(self, dialect: t.Optional[str] = None, **opts: t.Any) -> str:
        """
        Returns the rendered audit query that failed.

        Args:
            dialect: the dialect of the output SQL string, by default,
                     this will use the dialect of the engine adapter that ran the query.
            opts: other `sqlglot.generator.Generator` options.

        Returns:
            The SQL string.
        """
        return self.query.sql(dialect=dialect or self.adapter_dialect, **opts)


class NodeAuditsErrors(VulcanError):
    def __init__(self, errors: t.List[AuditError]) -> None:
        self.errors = errors

        super().__init__(f"Audits failed: {', '.join([e.audit_name for e in errors])}")


class TestError(VulcanError):
    __test__ = False  # prevent pytest trying to collect this as a test class
    pass


class DestructiveChangeError(VulcanError):
    pass


class AdditiveChangeError(VulcanError):
    pass


class MigrationNotSupportedError(VulcanError):
    pass


class NotificationTargetError(VulcanError):
    pass


class ApiError(VulcanError):
    def __init__(self, message: str, code: int) -> None:
        super().__init__(message)
        self.code = code


class ApiClientError(ApiError):
    pass


class ApiServerError(ApiError):
    pass


class NotFoundError(ApiClientError):
    def __init__(self, message: str) -> None:
        super().__init__(message, 404)


class CICDBotError(VulcanError):
    pass


class ParsetimeAdapterCallError(VulcanError):
    pass


class EngineAdapterError(VulcanError):
    pass


class UnsupportedCatalogOperationError(EngineAdapterError):
    pass


class CircuitBreakerError(VulcanError):
    def __init__(self) -> None:
        super().__init__("Circuit breaker triggered.")


class PythonModelEvalError(VulcanError):
    pass


class MissingDefaultCatalogError(VulcanError):
    pass


class LinterError(VulcanError):
    pass


class SignalEvalError(VulcanError):
    """Errors when evaluating a signal that is because of a user mistake and not a Vulcan bug."""

    pass


def raise_config_error(
    msg: str,
    location: t.Optional[Path] = None,
    error_type: t.Type[ConfigError] = ConfigError,
) -> None:
    if location:
        raise error_type(f"{msg} at '{location}'", location)
    raise error_type(msg, location=location)


def raise_for_status(response: Response) -> None:
    if response.status_code == 404:
        raise NotFoundError(response.text)
    if 400 <= response.status_code < 500:
        raise ApiClientError(response.text, response.status_code)
    if 500 <= response.status_code < 600:
        raise ApiServerError(response.text, response.status_code)


def _format_schema_change_msg(
    snapshot_name: str,
    is_destructive: bool,
    alter_operations: t.List[TableAlterOperation],
    dialect: str,
    error: bool = True,
) -> str:
    """
    Common function to format schema change messages.

    Args:
        snapshot_name: Name of the model/snapshot
        is_destructive: if change is destructive else it would be additive
        alter_operations: List of table alter operations
        dialect: SQL dialect for formatting
        error: Whether this is an error or warning
    """
    from vulcan.core.schema_diff import get_dropped_column_names, get_additive_column_names

    change_type = "destructive" if is_destructive else "additive"
    setting_name = "on_destructive_change" if is_destructive else "on_additive_change"
    action_verb = "drops" if is_destructive else "adds"
    cli_flag = "--allow-destructive-model" if is_destructive else "--allow-additive-model"

    column_names = (
        get_dropped_column_names(alter_operations)
        if is_destructive
        else get_additive_column_names(alter_operations)
    )
    column_str = "', '".join(column_names)
    column_msg = (
        f" that {action_verb} column{'s' if column_names and len(column_names) > 1 else ''} '{column_str}'"
        if column_str
        else ""
    )

    # Format ALTER expressions
    alter_expr_msg = "\n\nSchema changes:\n  " + "\n  ".join(
        [alter.expression.sql(dialect) for alter in alter_operations]
    )

    # Main warning message
    warning_msg = (
        f"Plan requires {change_type} change to forward-only model '{snapshot_name}'s schema"
    )

    if error:
        permissive_values = "`warn`, `allow`, or `ignore`"
        cli_part = f" or include the model in the plan's `{cli_flag}` option"
        err_msg = f"\n\nTo allow the {change_type} change, set the model's `{setting_name}` setting to {permissive_values}{cli_part}.\n"
    else:
        err_msg = ""

    return f"\n{warning_msg}{column_msg}.{alter_expr_msg}{err_msg}"


def format_destructive_change_msg(
    snapshot_name: str,
    alter_expressions: t.List[TableAlterOperation],
    dialect: str,
    error: bool = True,
) -> str:
    return _format_schema_change_msg(
        snapshot_name=snapshot_name,
        is_destructive=True,
        alter_operations=alter_expressions,
        dialect=dialect,
        error=error,
    )


def format_additive_change_msg(
    snapshot_name: str,
    alter_operations: t.List[TableAlterOperation],
    dialect: str,
    error: bool = True,
) -> str:
    return _format_schema_change_msg(
        snapshot_name=snapshot_name,
        is_destructive=False,
        alter_operations=alter_operations,
        dialect=dialect,
        error=error,
    )


class SemanticError(ConfigError):
    def __init__(self, message: str, location: t.Optional[str | Path] = None):
        super().__init__(message, location)
        self.message = message
        self.location = location


def format_semantic_errors(errors: t.List[SemanticError]) -> str:
    """Format semantic errors, grouping by location when available."""
    if not errors:
        return ""
    
    grouped = defaultdict(list)
    for error in errors:
        grouped[error.location].append(error.message)
    
    # Format
    sections = [
        ([f"{loc}:"] + [f"  - {msg}" for msg in msgs]) if loc 
        else [f"- {msg}" for msg in msgs]
        for loc, msgs in grouped.items()
    ]
    
    # Flatten and join
    return "\n".join([line for section in sections for line in section])


class CheckError(ConfigError):
    def __init__(self, message: str, location: t.Optional[str | Path] = None):
        super().__init__(message, location)
        self.message = message
        self.location = location


def format_check_errors(errors: t.List[CheckError]) -> str:
    """Format check errors, grouping by location when available."""
    if not errors:
        return ""

    # Group by location
    by_location: t.Dict[t.Optional[str], t.List[str]] = {}
    for error in errors:
        loc = str(error.location) if error.location else None
        if loc not in by_location:
            by_location[loc] = []
        by_location[loc].append(error.message)

    # Format output
    lines = []
    for location, messages in by_location.items():
        if location:
            lines.append(f"\n{location}:")
            for msg in messages:
                lines.append(f"  - {msg}")
        else:
            for msg in messages:
                lines.append(f"- {msg}")

    return "\n".join(lines)


class QueryValidationError(VulcanError):
    """Raised when query validation fails."""

    def __init__(self, error_type: str, message: str):
        self.error_type = error_type
        self.message = message
        super().__init__(f"[{error_type}] {message}")


class ObjectStoreError(VulcanError):
    """Exception raised for object store operations."""

    pass


class TranspilerError(ApiError):
    """Error raised when the Transpiler API call fails."""

    def __init__(
        self,
        message: str,
        code: int,
        response_data: t.Optional[t.Dict[str, t.Any]] = None,
        query_type: t.Optional[str] = None,
        is_connection_error: bool = False,
    ) -> None:
        super().__init__(message, code)
        self.response_data = response_data
        self.query_type = query_type
        self._is_connection_error = is_connection_error

    @property
    def is_connection_error(self) -> bool:
        """Check if this error is due to a connection/network failure."""
        return self._is_connection_error

    @property
    def is_post_processing_error(self) -> bool:
        """Check if this error is related to post-processing requirements."""
        if self.code != 400:
            return False
        return "post_processing" == self.query_type

    @property
    def user_message(self) -> str:
        """Return a user-friendly error message extracted from the error."""
        msg = str(self)
        # Extract meaningful error from SQLCompilationError format
        if "SQLCompilationError:" in msg:
            # e.g., "Error: SQLCompilationError: Internal: Initial planning error: Error during planning: <actual issue>"
            if "Error during planning:" in msg:
                return msg.split("Error during planning:")[-1].strip()
            # Fallback: get everything after SQLCompilationError:
            return msg.split("SQLCompilationError:")[-1].strip()
        return msg


def rebrand(text: t.Any) -> t.Any:
    """Replace Vulcan branding with Vulcan in user-facing text."""
    if not isinstance(text, str):
        return text
    # Order matters: handle proper case first.
    replacements = {
        "https://sqlmesh.readthedocs.io/en/stable/": "https://tmdc-io.github.io/vulcan-book/",
        "SQLMESH": "VULCAN",
        "Vulcan": "Vulcan",
        "vulcan": "vulcan",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text

