from __future__ import annotations

import subprocess
import typing as t
from functools import cached_property
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit


@dataclass(frozen=True)
class GitCommit:
    sha: str
    message: str
    author_name: str
    author_email: str
    authored_at: str


@dataclass(frozen=True)
class GitCommitInfo:
    sha: t.Optional[str]
    url: t.Optional[str]


class GitClient:
    def __init__(self, repo: str | Path):
        self._work_dir = Path(repo)
        if self._work_dir.is_file():
            self._work_dir = self._work_dir.parent

    def list_untracked_files(self) -> t.List[Path]:
        return self._execute_list_output(
            ["ls-files", "--others", "--exclude-standard"], self._work_dir
        )

    def list_uncommitted_changed_files(self) -> t.List[Path]:
        return self._execute_list_output(
            ["diff", "--name-only", "--diff-filter=d", "HEAD"], self._git_root
        )

    def list_committed_changed_files(self, target_branch: str = "main") -> t.List[Path]:
        return self._execute_list_output(
            ["diff", "--name-only", "--diff-filter=d", f"{target_branch}..."], self._git_root
        )

    def _execute_list_output(self, commands: t.List[str], base_path: Path) -> t.List[Path]:
        return [(base_path / o).absolute() for o in self._execute(commands).split("\n") if o]

    def _execute(self, commands: t.List[str]) -> str:
        result = subprocess.run(
            ["git"] + commands,
            cwd=self._work_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

        # If the Git command failed, extract and raise the error message in the console
        if result.returncode != 0:
            stderr_output = result.stderr.decode("utf-8").strip()
            error_message = next(
                (line for line in stderr_output.splitlines() if line.lower().startswith("fatal:")),
                stderr_output,
            )
            raise RuntimeError(f"Git error: {error_message}")

        return result.stdout.decode("utf-8").strip()

    @cached_property
    def _git_root(self) -> Path:
        return Path(self._execute(["rev-parse", "--show-toplevel"]))

    @cached_property
    def commit_sha(self) -> str:
        """Get the current commit SHA (HEAD)."""
        return self._execute(["rev-parse", "HEAD"])

    def remote_url(self, remote: str) -> str:
        """Get a git remote URL normalized to HTTPS form.

        Args:
            remote: The remote name.

        Returns:
            The normalized remote URL (for example, "https://github.com/owner/repo").
        """
        url = self._execute(["config", "--get", f"remote.{remote}.url"])
        return self.convert_url_to_https(url)

    @cached_property
    def origin_url(self) -> str:
        """Get the origin remote URL normalized to HTTPS form.

        Returns:
            The normalized origin remote URL (for example, "https://github.com/owner/repo").
        """
        return self.remote_url("origin")

    def diff(self, old_commit_sha: str, new_commit_sha: str) -> str:
        """Return the unified git diff between two commits."""
        return self._execute(["diff", old_commit_sha, new_commit_sha])

    def list_commits(self, old_commit_sha: str, new_commit_sha: str) -> t.List[GitCommit]:
        """Return commits between two SHAs, oldest first."""
        output = self._execute(
            [
                "log",
                "--reverse",
                "--date=iso-strict",
                "--format=%H%x1f%s%x1f%an%x1f%ae%x1f%ad",
                f"{old_commit_sha}..{new_commit_sha}",
            ]
        )
        commits = []
        for line in output.splitlines():
            if not line:
                continue
            sha, message, author_name, author_email, authored_at = line.split("\x1f", 4)
            commits.append(
                GitCommit(
                    sha=sha,
                    message=message,
                    author_name=author_name,
                    author_email=author_email,
                    authored_at=authored_at,
                )
            )
        return commits

    def commit_url(self, commit_sha: t.Optional[str] = None) -> t.Optional[str]:
        # Default to the current HEAD so callers can omit the SHA.
        sha = commit_sha or self.commit_sha
        if not sha:
            return None

        try:
            repo_url = self.origin_url
        except RuntimeError:
            return None
        if not repo_url:
            return None

        host = urlsplit(repo_url).hostname or ""

        if "gitlab" in host:
            return f"{repo_url}/-/commit/{sha}"
        if "bitbucket" in host:
            return f"{repo_url}/commits/{sha}"
        if "github" in host:
            return f"{repo_url}/commit/{sha}"

        return None

    def folder_url(
        self, folder_path: str, ref: t.Optional[str] = None
    ) -> t.Optional[str]:
        ref = ref or self.commit_sha
        try:
            repo_url = self.origin_url
        except RuntimeError:
            return None
        if not repo_url:
            return None

        host = urlsplit(repo_url).hostname or ""
        suffix = f"/{folder_path}" if folder_path else ""

        if "gitlab" in host:
            return f"{repo_url}/-/tree/{ref}{suffix}"
        if "bitbucket" in host:
            return f"{repo_url}/src/{ref}{suffix}"
        if "github" in host:
            return f"{repo_url}/tree/{ref}{suffix}"

        return None

    def commit_info(self) -> GitCommitInfo:
        try:
            commit_sha = self.commit_sha
            return GitCommitInfo(sha=commit_sha, url=self.commit_url(commit_sha))
        except Exception:
            return GitCommitInfo(sha=None, url=None)

    def project_folder_url(self) -> t.Optional[str]:
        try:
            project_dir = self._work_dir
            project_dir = project_dir.resolve()
            folder_path = project_dir.relative_to(self._git_root).as_posix()
            if folder_path == ".":
                folder_path = ""
            return self.folder_url(folder_path, self.commit_sha)
        except Exception:
            return None

    @staticmethod
    def convert_url_to_https(url: str) -> str:
        """Convert git remote URL to HTTPS format.
        
        Handles:
        - SSH: git@github.com:owner/repo.git -> https://github.com/owner/repo
        - SSH: ssh://git@github.com/owner/repo.git -> https://github.com/owner/repo
        - HTTP: http://github.com/owner/repo.git -> https://github.com/owner/repo
        - HTTPS: https://github.com/owner/repo.git -> https://github.com/owner/repo
        """
        if not url:
            return url

        # Already HTTPS.
        if url.startswith("https://"):
            result = url
        # Promote plain HTTP to HTTPS.
        elif url.startswith("http://"):
            result = "https://" + url[len("http://") :]
        # SSH scp-like format: git@host:path
        elif url.startswith("git@"):
            part = url.split("git@", 1)[1]
            part = part.replace(":", "/", 1)
            result = f"https://{part}"
        # SSH URL format: ssh://git@host/path or ssh://git@host:port/path
        elif url.startswith("ssh://git@"):
            parsed = urlsplit(url)
            if not parsed.hostname:
                return url
            result = f"https://{parsed.hostname}{parsed.path}"
        else:
            return url

        # Remove .git suffix if present.
        if result.endswith(".git"):
            result = result[:-4]

        return result
