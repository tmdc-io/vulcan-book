# mypy: disable-error-code=no-untyped-def

from concurrent.futures import Future, ProcessPoolExecutor
import socket
import subprocess
import typing as t
import multiprocessing as mp
from vulcan.utils.windows import IS_WINDOWS


class SynchronousPoolExecutor:
    """A mock implementation of the ProcessPoolExecutor for synchronous use.

    This executor runs functions synchronously in the same process, avoiding the issues
    with forking in test environments or when forking isn't possible (non-posix).
    """

    def __init__(self, max_workers=None, mp_context=None, initializer=None, initargs=()):
        if initializer is not None:
            try:
                initializer(*initargs)
            except BaseException as ex:
                raise RuntimeError(f"Exception in initializer: {ex}")

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.shutdown(wait=True)
        return False

    def shutdown(self, wait=True, cancel_futures=False):
        """No-op method to match ProcessPoolExecutor API.

        Since this executor runs synchronously, there are no background processes
        or resources to shut down and all futures will have completed already.
        """
        pass

    def submit(self, fn, *args, **kwargs):
        """Execute the function synchronously and return a Future with the result."""
        future = Future()
        try:
            result = fn(*args, **kwargs)
            future.set_result(result)
        except Exception as e:
            future.set_exception(e)
        return future

    def map(self, fn, *iterables, timeout=None, chunksize=1):
        """Synchronous implementation of ProcessPoolExecutor.map.

        This executes the function for each set of inputs from the iterables in the
        current process using Python's built-in map, rather than distributing work.
        """
        return map(fn, *iterables)


PoolExecutor = t.Union[SynchronousPoolExecutor, ProcessPoolExecutor]


def create_process_pool_executor(
    initializer: t.Callable, initargs: t.Tuple, max_workers: t.Optional[int]
) -> PoolExecutor:
    if max_workers == 1 or IS_WINDOWS:
        return SynchronousPoolExecutor(
            initializer=initializer,
            initargs=initargs,
        )
    return ProcessPoolExecutor(
        mp_context=mp.get_context("fork"),
        initializer=initializer,
        initargs=initargs,
        max_workers=max_workers,
    )


def _is_private_ipv4(ip: str) -> bool:
    """Return True if ip is an RFC1918-style private IPv4 address."""
    try:
        parts = [int(p) for p in ip.split(".")]
        if len(parts) != 4:
            return False
    except ValueError:
        return False

    if parts[0] == 10:
        return True
    if parts[0] == 192 and parts[1] == 168:
        return True
    if parts[0] == 172 and 16 <= parts[1] <= 31:
        return True
    return False


def get_host_ip(default: str = "127.0.0.1") -> str:
    """Best-effort detection of this machine's LAN IP, with a safe default.

    Preference order:
    1. RFC1918 private IPv4 addresses (e.g. 192.168.x.x, 10.x.x.x, 172.16-31.x.x),
       which are typically what we want for local Docker access.
    2. Previous heuristic: outbound interface IP when routing to 8.8.8.8.
    3. Supplied default (127.0.0.1).
    """
    # First, try to pick a private IPv4 bound to the hostname.
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, family=socket.AF_INET)
        for *_, sockaddr in infos:
            ip = sockaddr[0]
            if _is_private_ipv4(ip):
                return ip
    except Exception:
        # Fall back to the old heuristic below.
        pass

    # Fallback: "connect to 8.8.8.8" heuristic.
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        return ip
    except Exception:
        return default


def detect_docker_compose_command() -> t.List[str]:
    """Return the docker compose command as a list, or raise RuntimeError if not available."""
    candidates = [
        ["docker", "compose"],
        ["docker-compose"],
    ]
    for cmd in candidates:
        try:
            subprocess.run(
                cmd + ["version"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
            )
            return cmd
        except (FileNotFoundError, subprocess.CalledProcessError):
            continue

    raise RuntimeError(
        "Neither 'docker compose' nor 'docker-compose' is available. "
        "Please install Docker and Docker Compose."
    )
