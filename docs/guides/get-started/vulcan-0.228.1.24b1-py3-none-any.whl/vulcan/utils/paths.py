"""Filesystem path helpers (project layout, diff labels, etc.)."""

from __future__ import annotations

import typing as t
from pathlib import Path

from vulcan.core.config.common import ALL_CONFIG_FILENAMES


def relative_to_project_config(path: t.Optional[Path]) -> str:
    """
    Return a path string for unified diff headers (e.g. ``fromfile`` / ``tofile`` labels).

    Discovers a *project root* by walking upward from the input path: starting at the
    parent of a file path (paths with a ``suffix``), or at the path itself when it has
    no suffix (treated as a directory). The first ancestor directory that contains any
    regular file named in :data:`~vulcan.core.config.common.ALL_CONFIG_FILENAMES` is
    taken as the root.

    Returns that root-relative path (e.g. ``models/m.sql``). If ``path`` is ``None``,
    returns ``""``. If resolution fails, no config directory is found, or
    ``relative_to`` cannot be applied, returns only the final path component
    (:meth:`pathlib.PurePath.name`).

    This is display-only metadata for diffs; it does not affect loading or hashing.
    """
    if path is None:
        return ""
    p = Path(path)
    try:
        abs_path = p.resolve()
    except OSError:
        return str(p)
    origin = abs_path.parent if abs_path.suffix else abs_path
    for root in [origin, *origin.parents]:
        if any((root / name).is_file() for name in ALL_CONFIG_FILENAMES):
            try:
                return str(abs_path.relative_to(root))
            except ValueError:
                break
    return p.name
