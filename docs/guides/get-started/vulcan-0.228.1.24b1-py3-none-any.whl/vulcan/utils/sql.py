from __future__ import annotations

import re
import typing as t
from sqlglot import exp
from sqlglot.dialects.dialect import DialectType


def format_sql_for_display(
    sql: str | exp.Expression,
    dialect: DialectType = None,
    pretty: bool = True,
    max_text_width: int = 100,
) -> str:
    """Format SQL for user-facing display with proper indentation and comment handling."""
    try:
        # Parse if it's a string
        if isinstance(sql, str):
            parsed = exp.maybe_parse(sql, dialect=dialect)
            if not parsed:
                return sql
        else:
            parsed = sql
            
        # Format with pretty printing
        formatted = parsed.sql(dialect=dialect, pretty=pretty, max_text_width=max_text_width)
        
        # Normalize block comments for readability
        formatted = _normalize_block_comments(formatted)
            
        return formatted
        
    except Exception:
        # Fallback to original SQL if anything fails
        return sql if isinstance(sql, str) else sql.sql(dialect=dialect)


def _normalize_block_comments(sql: str) -> str:
    """
    Separate consecutive block comments onto individual lines.
    
    Transforms: /* comment1 */ /* comment2 */
    Into:       /* comment1 */
                /* comment2 */
    
    This preserves line breaks between consecutive comments that SQLGlot
    may have combined onto a single line when converting from -- style comments.
    """
    # Pattern to match consecutive block comments on the same line
    # Matches: */ followed by optional whitespace and another /*
    # We replace with */\n/* to put each comment on its own line
    return re.sub(r'\*/\s*/\*', '*/\n/*', sql)

