"""Add data quality (DQ) state tables for Soda integration.

This migration creates five tables for data quality management:
1. _dq_results: Individual rule outcomes with full diagnostics (includes embedded samples)
2. _dq_definitions: Distinct rule catalog for fast list_checks (no scan of _dq_results)
3. _dq_metrics: Typed metric measurements (text, number, JSON)
4. _dq_profiles: Column profiling statistics
5. _dq_feedbacks: User feedback for ML training and investigations

Scan execution metadata lives in _activity_run_executions (not a separate runs table).
Samples are embedded directly in rule diagnostics.

Column names use Soda's ``check_*`` vocabulary (``check_identity``, ``check_name``,
``check_type``). In product terms and the ``/dq`` API these are **rules** defined
via ``kind: dq`` YAML—the same entity, different layer names.

Design inspired by Cola (Soda's reference implementation) with Vulcan-specific enhancements.
"""

from sqlglot import exp

from vulcan.utils.migration import blob_text_type, index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create all DQ-related tables for data quality monitoring."""
    dq_results_table = "_dq_results"
    dq_definitions_table = "_dq_definitions"
    dq_metrics_table = "_dq_metrics"
    dq_profiles_table = "_dq_profiles"
    dq_feedbacks_table = "_dq_feedbacks"

    if schema:
        dq_results_table = f"{schema}.{dq_results_table}"
        dq_definitions_table = f"{schema}.{dq_definitions_table}"
        dq_metrics_table = f"{schema}.{dq_metrics_table}"
        dq_profiles_table = f"{schema}.{dq_profiles_table}"
        dq_feedbacks_table = f"{schema}.{dq_feedbacks_table}"

    index_type = index_text_type(engine_adapter.dialect)
    blob_type = blob_text_type(engine_adapter.dialect)

    # =========================================================================
    # Table 1: _dq_results
    # =========================================================================

    # All rule metadata lives in _dq_definitions; _dq_results stores only run-specific
    # outcome data (outcome, outcome_reasons, diagnostics).
    dq_results_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "start_ts": exp.DataType.build("bigint"),
        "end_ts": exp.DataType.build("bigint"),
        "check_identity": exp.DataType.build(index_type),
        "outcome": exp.DataType.build("text"),
        "outcome_reasons": exp.DataType.build("text"),
        "diagnostics": exp.DataType.build("text"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        dq_results_table,
        dq_results_columns_to_types,
        primary_key=("id",),
        table_description="Individual rule outcomes with full diagnostics",
        column_descriptions={
            "id": "Unique rule result UUID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "start_ts": "Scan start time (Unix ms)",
            "end_ts": "Scan end time (Unix ms)",
            "check_identity": "Soda check identity hash (links to _dq_definitions)",
            "outcome": "Rule result: pass, warn, fail, error",
            "outcome_reasons": "JSON array of outcome reasons",
            "diagnostics": "Complete diagnostics JSON",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        dq_results_table,
        "_dq_results_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        dq_results_table,
        "_dq_results_identity_idx",
        ("check_identity",),
    )
    engine_adapter.create_index(
        dq_results_table,
        "_dq_results_list_checks_idx",
        ("environment", "check_identity", "start_ts"),
    )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {dq_results_table} ALTER COLUMN check_identity SET NOT NULL"
        )

    # =========================================================================
    # Table 2: _dq_definitions
    # =========================================================================

    dq_definitions_columns_to_types = {
        "check_identity": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "check_name": exp.DataType.build("text"),
        "check_type": exp.DataType.build("text"),
        "column_name": exp.DataType.build("text"),
        "dimension": exp.DataType.build("text"),
        "definition": exp.DataType.build("text"),
        "model_name": exp.DataType.build(index_type),
        "resource_attributes": exp.DataType.build("text"),
        "location": exp.DataType.build("text"),
        "group_by": exp.DataType.build("text"),
        "filter": exp.DataType.build("text"),
        "metrics": exp.DataType.build("text"),
        "archetype": exp.DataType.build("text"),
        "updated_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        dq_definitions_table,
        dq_definitions_columns_to_types,
        primary_key=("check_identity", "environment"),
        table_description="Distinct rule catalog for fast list_checks",
        column_descriptions={
            "check_identity": "Soda check identity hash (stable across runs)",
            "environment": "Vulcan environment name",
            "check_name": "Human-readable rule name",
            "check_type": "Rule type (anomaly_detection, missing_count, etc.)",
            "column_name": "Column name for column-level rules",
            "dimension": "Required ODPS dimension (completeness, validity, etc.)",
            "definition": "Original SodaCL rule definition",
            "model_name": "Logical model name (e.g., b2b_saas.users)",
            "resource_attributes": "JSON metadata (dimension, team, tags)",
            "location": "JSON file location (filePath, line, col)",
            "group_by": "JSON GROUP BY clauses",
            "filter": "Partition/WHERE clause filter",
            "metrics": "JSON array of metric identities",
            "archetype": "Automated monitoring archetype",
            "updated_ts": "Last update time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        dq_definitions_table,
        "_dq_definitions_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        dq_definitions_table,
        "_dq_definitions_list_idx",
        ("environment", "model_name", "column_name", "check_name"),
    )
    if engine_adapter.SUPPORTS_INDEXES:
        engine_adapter.execute(
            exp.Create(
                this=exp.Index(
                    this=exp.to_identifier("_dq_definitions_check_name_unique_idx"),
                    table=exp.to_table(dq_definitions_table),
                    params=exp.IndexParameters(
                        columns=[
                            exp.to_column("environment"),
                            exp.to_column("model_name"),
                            exp.to_column("dimension"),
                            exp.to_column("check_name"),
                        ]
                    ),
                ),
                kind="UNIQUE INDEX",
                exists=True,
            )
        )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {dq_definitions_table} ALTER COLUMN dimension SET NOT NULL"
        )

    # =========================================================================
    # Table 3: _dq_metrics
    # =========================================================================

    dq_metrics_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "check_id": exp.DataType.build(index_type),
        "check_identity": exp.DataType.build(index_type),
        "metric_identity": exp.DataType.build(index_type),
        "metric_name": exp.DataType.build(index_type),
        "model_name": exp.DataType.build(index_type),
        "column_name": exp.DataType.build("text"),
        "partition_name": exp.DataType.build("text"),
        "value_text": exp.DataType.build("text"),
        "value_number": exp.DataType.build("numeric"),
        "value_json": exp.DataType.build("text"),
        "value_type": exp.DataType.build("text"),
        "measured_at": exp.DataType.build("bigint"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        dq_metrics_table,
        dq_metrics_columns_to_types,
        primary_key=("id",),
        table_description="Metric measurements with typed storage for time-series analysis",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "check_id": "Links to _dq_results.id (NULL for standalone metrics)",
            "check_identity": "Soda check identity hash",
            "metric_identity": "Soda metric identity",
            "metric_name": "Metric name (row_count, missing_count, avg, etc.)",
            "model_name": "Logical model name",
            "column_name": "Column name for column-level metrics",
            "partition_name": "Partition identifier",
            "value_text": "String metric value",
            "value_number": "Numeric metric value (most common)",
            "value_json": "Complex metric value (histograms, arrays)",
            "value_type": "Type discriminator: text, number, or json",
            "measured_at": "Measurement time (Unix ms)",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_check_idx",
        ("check_id",),
    )
    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_identity_idx",
        ("check_identity", "measured_at"),
    )
    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_metric_identity_idx",
        ("metric_identity", "measured_at"),
    )
    engine_adapter.create_index(
        dq_metrics_table,
        "_dq_metrics_name_idx",
        ("metric_name", "model_name", "measured_at"),
    )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {dq_metrics_table} ALTER COLUMN check_identity SET NOT NULL"
        )

    # =========================================================================
    # Table 4: _dq_profiles
    # =========================================================================

    dq_profiles_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "model_name": exp.DataType.build(index_type),
        "column_name": exp.DataType.build("text"),
        "profile_type": exp.DataType.build("text"),
        "value_text": exp.DataType.build("text"),
        "value_number": exp.DataType.build("numeric"),
        "value_json": exp.DataType.build("text"),
        "value_type": exp.DataType.build("text"),
        "profiled_at": exp.DataType.build("bigint"),
        "created_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        dq_profiles_table,
        dq_profiles_columns_to_types,
        primary_key=("id",),
        table_description="Column profiling statistics for automatic rule generation",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "environment": "Vulcan environment name",
            "model_name": "Logical model name being profiled",
            "column_name": "Column name (NULL for table-level profiles)",
            "profile_type": "Statistic type (min, max, avg, distinct_count, etc.)",
            "value_text": "String profile values",
            "value_number": "Numeric profile values",
            "value_json": "Complex profile values (histograms, frequencies)",
            "value_type": "Type discriminator: text, number, or json",
            "profiled_at": "Profiling time (Unix ms)",
            "created_ts": "Record creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        dq_profiles_table,
        "_dq_profiles_table_column_idx",
        ("model_name", "column_name", "profiled_at"),
    )
    engine_adapter.create_index(
        dq_profiles_table,
        "_dq_profiles_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        dq_profiles_table,
        "_dq_profiles_env_idx",
        ("environment",),
    )
    engine_adapter.create_index(
        dq_profiles_table,
        "_dq_profiles_type_idx",
        ("profile_type",),
    )

    # =========================================================================
    # Table 5: _dq_feedbacks
    # =========================================================================

    dq_feedbacks_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "run_id": exp.DataType.build(index_type),
        "check_id": exp.DataType.build(index_type),
        "check_identity": exp.DataType.build(index_type),
        "measurement_id": exp.DataType.build(index_type),
        "feedback_type": exp.DataType.build("text"),
        "feedback_category": exp.DataType.build("text"),
        "is_correctly_classified": exp.DataType.build("boolean"),
        "is_anomaly": exp.DataType.build("boolean"),
        "seasonality_reason": exp.DataType.build("text"),
        "skip_measurements": exp.DataType.build("text"),
        "feedback_text": exp.DataType.build("text"),
        "metadata_json": exp.DataType.build("text"),
        "user_id": exp.DataType.build("text"),
        "created_ts": exp.DataType.build("bigint"),
        "updated_ts": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        dq_feedbacks_table,
        dq_feedbacks_columns_to_types,
        primary_key=("id",),
        table_description="User feedback on rules for ML training and suppression",
        column_descriptions={
            "id": "Auto-generated random ID",
            "run_id": "Links to _activity_run_executions.run_id",
            "check_id": "Links to _dq_results.id",
            "check_identity": "Soda check identity hash",
            "measurement_id": "Links to _dq_metrics.id (optional)",
            "feedback_type": "Specific feedback type (anomaly_false_positive, etc.)",
            "feedback_category": "High-level category (ml_training, investigation)",
            "is_correctly_classified": "Was anomaly detection correct?",
            "is_anomaly": "Is this truly an anomaly?",
            "seasonality_reason": "Structured seasonality type for ML training",
            "skip_measurements": "Measurements to exclude (this, previous, previousAndThis)",
            "feedback_text": "Free-form comment from user",
            "metadata_json": "Extensible JSON (ticket refs, thresholds)",
            "user_id": "Who provided feedback (email, username, user ID)",
            "created_ts": "Feedback creation time (Unix ms)",
            "updated_ts": "Last update time (Unix ms, allows editing)",
        },
    )

    engine_adapter.create_index(
        dq_feedbacks_table,
        "_dq_feedbacks_check_idx",
        ("check_id",),
    )
    engine_adapter.create_index(
        dq_feedbacks_table,
        "_dq_feedbacks_run_idx",
        ("run_id",),
    )
    engine_adapter.create_index(
        dq_feedbacks_table,
        "_dq_feedbacks_identity_idx",
        ("check_identity",),
    )
    engine_adapter.create_index(
        dq_feedbacks_table,
        "_dq_feedbacks_type_idx",
        ("feedback_type", "created_ts"),
    )
    engine_adapter.create_index(
        dq_feedbacks_table,
        "_dq_feedbacks_category_idx",
        ("feedback_category",),
    )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"ALTER TABLE {dq_feedbacks_table} ALTER COLUMN check_identity SET NOT NULL"
        )


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new tables."""
    pass
