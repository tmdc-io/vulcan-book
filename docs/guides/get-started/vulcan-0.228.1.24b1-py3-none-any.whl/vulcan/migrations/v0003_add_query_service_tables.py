"""Add query service tables for ad-hoc query execution.

This migration creates 3 tables for query caching and execution tracking:
1. _query_results: Result metadata (parquet paths in object store)
2. _query_fingerprints: Fingerprint → result mapping with TTL and model dependencies
3. _query_requests: Comprehensive audit log of all requests with strategy tracking

Design optimized for high-volume reads/writes with PostgreSQL as job queue.
"""

from sqlglot import exp

from vulcan.utils.migration import blob_text_type, index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create all query service tables."""
    results_table = "_query_results"
    fingerprints_table = "_query_fingerprints"
    requests_table = "_query_requests"
    
    if schema:
        results_table = f"{schema}.{results_table}"
        fingerprints_table = f"{schema}.{fingerprints_table}"
        requests_table = f"{schema}.{requests_table}"
    
    index_type = index_text_type(engine_adapter.dialect)
    blob_type = blob_text_type(engine_adapter.dialect)
    
    # =========================================================================
    # Table 1: _query_results
    # =========================================================================

    results_columns_to_types = {
        "result_id": exp.DataType.build(index_type),
        "object_store_path": exp.DataType.build("text"),
        "row_count": exp.DataType.build("bigint"),
        "size_bytes": exp.DataType.build("bigint"),
        "columns": exp.DataType.build("jsonb"),
        "sql": exp.DataType.build("text"),
        "references": exp.DataType.build("jsonb"),
        "created_ts": exp.DataType.build("bigint"),
    }
    
    engine_adapter.create_state_table(
        results_table,
        results_columns_to_types,
        primary_key=("result_id",),
        table_description="Query result metadata with Parquet references in object store",
        column_descriptions={
            "result_id": "Unique result identifier (primary key)",
            "object_store_path": "Relative Parquet file path in object store",
            "row_count": "Number of rows in result",
            "size_bytes": "Parquet file size in bytes",
            "columns": "Column schema as JSON (name, type pairs)",
            "sql": "SQL query that was executed (transpiled for REST/SEMANTIC_SQL, original for RAW_SQL)",
            "references": "Field-level lineage mapping {column_name: [[model_name, field_name], ...]}",
            "created_ts": "Creation time (Unix ms)",
        },
    )

    engine_adapter.create_index(
        results_table,
        "_query_results_created_idx",
        ("created_ts",),
    )
    
    # =========================================================================
    # Table 2: _query_fingerprints
    # =========================================================================

    fingerprints_columns_to_types = {
        "fingerprint": exp.DataType.build(index_type),
        "result_id": exp.DataType.build(index_type),
        "depends_on": exp.DataType.build("text[]"),
        "created_ts": exp.DataType.build("bigint"),
        "expires_ts": exp.DataType.build("bigint"),
        "invalidated_by_run_id": exp.DataType.build(index_type),
        "invalidated_ts": exp.DataType.build("bigint"),
    }
    
    engine_adapter.create_state_table(
        fingerprints_table,
        fingerprints_columns_to_types,
        primary_key=("fingerprint",),
        table_description="Query fingerprint registry mapping fingerprints to results with TTL and run-based invalidation",
        column_descriptions={
            "fingerprint": "SHA-256 hash of normalized SQL + params (primary key)",
            "result_id": "Links to _query_results.result_id",
            "depends_on": "Array of model names for invalidation",
            "created_ts": "Fingerprint entry creation time (Unix ms)",
            "expires_ts": "Expiration time (NULL = never)",
            "invalidated_by_run_id": "Run ID that triggered invalidation (NULL if not invalidated)",
            "invalidated_ts": "Invalidation timestamp (Unix ms, NULL if not invalidated)",
        },
    )

    engine_adapter.create_index(
        fingerprints_table,
        "_query_fingerprints_expires_idx",
        ("expires_ts",),
    )
    
    engine_adapter.create_index(
        fingerprints_table,
        "_query_fingerprints_invalidated_by_run_idx",
        ("invalidated_by_run_id",),
    )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(
            f"""
            CREATE INDEX IF NOT EXISTS _query_fingerprints_depends_on_gin_idx
            ON {fingerprints_table} USING GIN (depends_on)
            """
        )
    
    # =========================================================================
    # Table 3: _query_requests
    # =========================================================================

    requests_columns_to_types = {
        "request_id": exp.DataType.build(index_type),
        "strategy": exp.DataType.build("text"),
        "execution_status": exp.DataType.build("text"),
        "primary_request_id": exp.DataType.build(index_type),
        "fingerprint": exp.DataType.build(index_type),
        "params": exp.DataType.build("jsonb"),
        "depends_on": exp.DataType.build("text[]"),
        "gateway": exp.DataType.build(index_type),
        "submitted_by": exp.DataType.build("text"),
        "submitted_ts": exp.DataType.build("bigint"),
        "ttl": exp.DataType.build("int"),
        "meta": exp.DataType.build("jsonb"),
        "query_type": exp.DataType.build("text"),
        "semantic_query": exp.DataType.build("text"),
        "rest_query": exp.DataType.build("jsonb"),
        "graphql_query": exp.DataType.build("text"),
        "sql_query": exp.DataType.build("text"),
        "normalized_sql": exp.DataType.build("text"),
        "perspective_id": exp.DataType.build(index_type),
        "pgq_job_id": exp.DataType.build("bigint"),
        "execution_start_ts": exp.DataType.build("bigint"),
        "execution_end_ts": exp.DataType.build("bigint"),
        "cached_at_ts": exp.DataType.build("bigint"),
        "result_id": exp.DataType.build(index_type),
        "error_message": exp.DataType.build("text"),
    }
    
    engine_adapter.create_state_table(
        requests_table,
        requests_columns_to_types,
        primary_key=("request_id",),
        table_description="Audit log of query requests with strategy and execution tracking",
        column_descriptions={
            "request_id": "Unique request identifier (primary key)",
            "strategy": "Resolution strategy (from_cache, await_primary, execute)",
            "execution_status": "Execution status for strategy=execute",
            "primary_request_id": "Primary execution link for strategy=await_primary",
            "fingerprint": "SHA-256 hash for cache lookup/deduplication",
            "params": "Query parameters as JSON",
            "depends_on": "Array of model names referenced",
            "gateway": "Execution gateway name",
            "submitted_by": "User who submitted query",
            "submitted_ts": "Submission time (Unix ms)",
            "ttl": "Cache TTL in minutes (5-43200) or 0",
            "meta": "Client metadata as JSONB",
            "query_type": "Query type: RAW_SQL, SEMANTIC_SQL, SEMANTIC_REST, SEMANTIC_GRAPHQL, or SEMANTIC_METRIC",
            "semantic_query": "Semantic SQL query (for SEMANTIC_SQL type)",
            "rest_query": "REST Query object (for REST and GRAPHQL types)",
            "graphql_query": "GraphQL query string (for GRAPHQL type)",
            "sql_query": "SQL query that was executed (transpiled for REST/SEMANTIC_SQL, original for RAW_SQL)",
            "normalized_sql": "Normalized SQL for execution",
            "perspective_id": "Perspective ID that triggered this refresh (NULL for regular queries)",
            "pgq_job_id": "PGQueuer job ID for strategy=execute",
            "execution_start_ts": "Execution start (Unix ms)",
            "execution_end_ts": "Execution end (Unix ms)",
            "cached_at_ts": "Cache time for strategy=from_cache (Unix ms)",
            "result_id": "Links to _query_results.result_id",
            "error_message": "Error for execution_status=FAILED",
        },
    )
    
    engine_adapter.create_index(
        requests_table,
        "_query_requests_fingerprint_idx",
        ("fingerprint", "submitted_ts"),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_strategy_idx",
        ("strategy", "submitted_ts"),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_execution_status_idx",
        ("execution_status", "submitted_ts"),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_primary_request_idx",
        ("primary_request_id",),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_perspective_id_idx",
        ("perspective_id", "submitted_ts"),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_submitted_idx",
        ("submitted_ts",),
    )
    engine_adapter.create_index(
        requests_table,
        "_query_requests_query_type_idx",
        ("query_type",),
    )

    if engine_adapter.dialect == "postgres":
        engine_adapter.execute(f"""
            ALTER TABLE {requests_table}
            ADD CONSTRAINT check_strategy
            CHECK (strategy IN ('from_cache', 'await_primary', 'execute'))
        """)
        engine_adapter.execute(f"""
            ALTER TABLE {requests_table}
            ADD CONSTRAINT check_ttl_range
            CHECK (ttl = 0 OR (ttl >= 5 AND ttl <= 43200))
        """)
        engine_adapter.execute(f"""
            ALTER TABLE {requests_table}
            ADD CONSTRAINT check_primary_for_await
            CHECK (strategy != 'await_primary' OR primary_request_id IS NOT NULL)
        """)
        engine_adapter.execute(f"""
            ALTER TABLE {requests_table}
            ADD CONSTRAINT check_status_for_execute
            CHECK (strategy != 'execute' OR execution_status IS NOT NULL)
        """)


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new tables."""
    pass
