"""Add query perspective table for saved queries with auto-refresh.

This migration creates the _query_perspective table for storing saved queries
that automatically refresh when underlying models change.
"""

from sqlglot import exp

from vulcan.utils.migration import index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create _query_perspective table."""
    perspectives_table = "_query_perspective"
    
    if schema:
        perspectives_table = f"{schema}.{perspectives_table}"
    
    index_type = index_text_type(engine_adapter.dialect)
    
    # Column types for _perspectives
    perspectives_columns_to_types = {
        # Perspective Identity
        "perspective_id": exp.DataType.build(index_type),
        "slug": exp.DataType.build("text"),
        
        # Perspective Metadata
        "name": exp.DataType.build("text"),
        "description": exp.DataType.build("text"),
        "tags": exp.DataType.build("text[]"),
        "terms": exp.DataType.build("text[]"),
        "owner": exp.DataType.build("text"),
        
        # Execution Lifecycle (link to QueryRequest)
        "request_id": exp.DataType.build(index_type), # Lastest Query Request ID
        "fingerprint": exp.DataType.build(index_type),  # Fingerprint of original query (denormalized for performance)
        
        # Denormalized Query Definition Fields
        "params": exp.DataType.build("jsonb"),
        "gateway": exp.DataType.build("text"),
        "ttl": exp.DataType.build("int"),
        "meta": exp.DataType.build("jsonb"),
        "query_type": exp.DataType.build("text"),
        "semantic_query": exp.DataType.build("text"),
        "rest_query": exp.DataType.build("jsonb"),
        "graphql_query": exp.DataType.build("text"),
        "sql_query": exp.DataType.build("text"),
        "normalized_sql": exp.DataType.build("text"),
        "depends_on": exp.DataType.build("text[]"),
        
        # Settings
        "auto_refresh": exp.DataType.build("boolean"),
        
        # Permissions
        "is_public": exp.DataType.build("boolean"),
        "allowed_user_ids": exp.DataType.build("text[]"),
        
        # Timestamps
        "created_at": exp.DataType.build("bigint"),
        "updated_at": exp.DataType.build("bigint"),
        "created_by": exp.DataType.build("text"),
        "updated_by": exp.DataType.build("text"),
    }
    
    engine_adapter.create_state_table(
        perspectives_table,
        perspectives_columns_to_types,
        primary_key=("perspective_id",),
        table_description="Saved queries with auto-refresh capabilities",
        column_descriptions={
            "perspective_id": "Unique perspective identifier (primary key)",
            "slug": "User-friendly identifier (globally unique)",
            "name": "Perspective name",
            "description": "Perspective description",
            "tags": "Array of tags",
            "terms": "Array of glossary terms",
            "owner": "User who created the perspective",
            "request_id": "Links to _query_requests.request_id (current execution, for result link)",
            "fingerprint": "Fingerprint of original query (denormalized for performance, used for invalidation checks)",
            "params": "Query parameters as JSON",
            "gateway": "Execution gateway name",
            "ttl": "Cache TTL hint in minutes (0 = never expires)",
            "meta": "Client metadata as JSONB",
            "query_type": "Query type: RAW_SQL, SEMANTIC_SQL, SEMANTIC_REST, SEMANTIC_GRAPHQL, or SEMANTIC_METRIC",
            "semantic_query": "Semantic SQL query (for SEMANTIC_SQL type)",
            "rest_query": "REST Query object (for REST and GRAPHQL types)",
            "graphql_query": "GraphQL query string (for GRAPHQL type)",
            "sql_query": "SQL query that was executed (transpiled for REST/SEMANTIC_SQL, original for RAW_SQL)",
            "normalized_sql": "Normalized SQL query definition",
            "depends_on": "Array of model names referenced",
            "auto_refresh": "Whether perspective should auto-refresh on model changes (default: true)",
            "is_public": "Whether perspective is publicly accessible",
            "allowed_user_ids": "Array of user IDs allowed to access (if private)",
            "created_at": "Creation time (Unix ms)",
            "updated_at": "Last update time (Unix ms)",
            "created_by": "User who created the perspective",
            "updated_by": "User who last updated the perspective",
        },
    )
    
    # Create indexes
    engine_adapter.create_index(
        perspectives_table,
        "_query_perspective_slug_idx",
        ("slug",),
    )
    engine_adapter.create_index(
        perspectives_table,
        "_query_perspective_owner_idx",
        ("owner",),
    )
    engine_adapter.create_index(
        perspectives_table,
        "_query_perspective_request_id_idx",
        ("request_id",),
    )
    engine_adapter.create_index(
        perspectives_table,
        "_query_perspective_fingerprint_idx",
        ("fingerprint",),
    )
    engine_adapter.create_index(
        perspectives_table,
        "_query_perspective_public_idx",
        ("is_public",),
    )
    
    if engine_adapter.dialect == "postgres":
        # GIN index for array columns
        engine_adapter.execute(
            f"""
            CREATE INDEX IF NOT EXISTS _query_perspective_tags_gin_idx
            ON {perspectives_table} USING GIN (tags)
            """
        )
        engine_adapter.execute(
            f"""
            CREATE INDEX IF NOT EXISTS _query_perspective_allowed_user_ids_gin_idx
            ON {perspectives_table} USING GIN (allowed_user_ids)
            """
        )
        
        # Constraints
        engine_adapter.execute(f"""
            ALTER TABLE {perspectives_table}
            ADD CONSTRAINT check_slug_not_empty_query_perspective
            CHECK (slug IS NOT NULL AND length(slug) > 0)
        """)
        engine_adapter.execute(f"""
            ALTER TABLE {perspectives_table}
            ALTER COLUMN auto_refresh SET DEFAULT TRUE
        """)


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new table."""
    pass
