"""Add _followers table for data product follower subscriptions."""

from sqlglot import exp

from vulcan.utils.migration import index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create _followers table."""
    followers_table = "_followers"

    if schema:
        followers_table = f"{schema}.{followers_table}"

    index_type = index_text_type(engine_adapter.dialect)

    followers_columns_to_types = {
        "user_id": exp.DataType.build(index_type),
        "active": exp.DataType.build("boolean"),
        "followed_at": exp.DataType.build("bigint"),
        "updated_at": exp.DataType.build("bigint"),
        "metadata": exp.DataType.build("jsonb"),
    }

    engine_adapter.create_state_table(
        followers_table,
        followers_columns_to_types,
        primary_key=("user_id",),
        table_description="Users following this data product",
        column_descriptions={
            "user_id": "Heimdall user identifier (primary key)",
            "active": "Whether the user is currently following",
            "followed_at": "Unix timestamp (seconds) when the user first followed",
            "updated_at": "Unix timestamp (seconds) of the last follow/unfollow mutation",
            "metadata": "Optional JSON metadata for future extensions",
        },
    )

    engine_adapter.create_index(
        followers_table,
        "idx_followers_active_followed_at",
        ("active", "followed_at"),
    )


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new table."""
    pass
