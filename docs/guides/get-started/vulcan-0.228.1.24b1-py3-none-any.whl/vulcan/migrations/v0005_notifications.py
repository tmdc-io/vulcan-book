"""Add _notifications table for persisted notification events."""

from sqlglot import exp

from vulcan.utils.migration import index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create _notifications table."""
    notifications_table = "_notifications"

    if schema:
        notifications_table = f"{schema}.{notifications_table}"

    index_type = index_text_type(engine_adapter.dialect)

    notifications_columns_to_types = {
        "id": exp.DataType.build(index_type),
        "created_ts_ns": exp.DataType.build("bigint"),
        "event": exp.DataType.build(index_type),
        "status": exp.DataType.build("text"),
        "environment": exp.DataType.build(index_type, nullable=True),
        "run_id": exp.DataType.build(index_type, nullable=True),
        "plan_id": exp.DataType.build(index_type, nullable=True),
        "username": exp.DataType.build("text", nullable=True),
        "summary": exp.DataType.build("text"),
        "payload": exp.DataType.build("jsonb"),
    }

    engine_adapter.create_state_table(
        notifications_table,
        notifications_columns_to_types,
        primary_key=("id",),
        table_description="Persisted notification events for in-app feed",
        column_descriptions={
            "id": "Unique notification identifier (UUID)",
            "created_ts_ns": "Insertion timestamp (nanoseconds) for ordering and cursor pagination",
            "event": "Notification event name (e.g. run_start, audit_failure)",
            "status": "Notification status (info, success, failure, warning)",
            "environment": "Target environment when applicable",
            "run_id": "Associated run identifier when applicable",
            "plan_id": "Associated plan identifier when applicable",
            "username": "User recipient for per-user notification deliveries",
            "summary": "Short text summary for list views",
            "payload": "Structured event payload as JSON",
        },
    )

    engine_adapter.create_index(
        notifications_table,
        "idx_notifications_environment_created",
        ("environment", "created_ts_ns"),
    )
    engine_adapter.create_index(
        notifications_table,
        "idx_notifications_run_id_created",
        ("run_id", "created_ts_ns"),
    )
    engine_adapter.create_index(
        notifications_table,
        "idx_notifications_plan_id_created",
        ("plan_id", "created_ts_ns"),
    )


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new table."""
    pass
