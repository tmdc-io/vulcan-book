from sqlglot import exp

from vulcan.utils.migration import blob_text_type, index_text_type


def migrate_schemas(engine_adapter, schema, **kwargs):  # type: ignore
    """Create activity tracking tables."""
    plans_table = "_plans"
    runs_table = "_runs"

    if schema:
        plans_table = f"{schema}.{plans_table}"
        runs_table = f"{schema}.{runs_table}"

    index_type = index_text_type(engine_adapter.dialect)
    blob_type = blob_text_type(engine_adapter.dialect)

    # =========================================================================
    # Table 1: _plans
    # =========================================================================

    plans_columns_to_types = {
        "plan_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "start_ts": exp.DataType.build("bigint"),
        "end_ts": exp.DataType.build("bigint"),
        "created_ts_ns": exp.DataType.build("bigint"),
        "executor": exp.DataType.build("text"),
        "git_commit_sha": exp.DataType.build("text"),
        "prev_plan_id": exp.DataType.build("text"),
        "version": exp.DataType.build("text"),
        "models_affected_directly": exp.DataType.build("ARRAY<TEXT>"),
        "models_affected_indirectly": exp.DataType.build("ARRAY<TEXT>"),
        "plan_diff": exp.DataType.build("jsonb"),
        "has_changes": exp.DataType.build("boolean"),
        "has_backfills": exp.DataType.build("boolean"),
        "success": exp.DataType.build("boolean"),
        "plan_seq": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        plans_table,
        plans_columns_to_types,
        primary_key=("plan_id",),
        table_description="Plan application history with change tracking",
        column_descriptions={
            "plan_id": "Unique plan identifier",
            "environment": "Target environment",
            "start_ts": "Plan start time (Unix milliseconds)",
            "end_ts": "Plan end time (Unix milliseconds)",
            "created_ts_ns": "Insertion timestamp (nanoseconds)",
            "executor": "User who executed the plan",
            "git_commit_sha": "Associated Git commit SHA",
            "prev_plan_id": "Previous plan ID",
            "version": "Data product SemVer at plan apply",
            "models_affected_directly": "List of model FQNs directly affected (added/modified/removed)",
            "models_affected_indirectly": "List of model FQNs indirectly affected (downstream)",
            "plan_diff": "Complete plan diff as JSON (PlanDiff model)",
            "has_changes": "Plan contains changes",
            "has_backfills": "Plan requires backfills",
            "success": "Plan applied successfully",
            "plan_seq": "Sequential number per environment (1, 2, 3...)",
        },
    )

    engine_adapter.create_index(
        plans_table,
        "idx_plans_environment_created",
        ("environment", "created_ts_ns"),
    )
    engine_adapter.create_index(
        plans_table,
        "idx_plans_plan_id",
        ("plan_id",),
    )
    engine_adapter.create_index(
        plans_table,
        "idx_plans_start_ts",
        ("start_ts",),
    )
    engine_adapter.create_index(
        plans_table,
        "idx_plans_prev_plan_id",
        ("prev_plan_id",),
    )
    
    # GIN indexes for array queries
    try:
        engine_adapter.create_index(
            plans_table,
            "idx_plans_models_directly_gin",
            ("models_affected_directly",),
            index_type="GIN",
        )
        engine_adapter.create_index(
            plans_table,
            "idx_plans_models_indirectly_gin",
            ("models_affected_indirectly",),
            index_type="GIN",
        )
    except Exception:
        pass

    # =========================================================================
    # Table 2: _runs
    # =========================================================================

    runs_columns_to_types = {
        "run_id": exp.DataType.build(index_type),
        "plan_id": exp.DataType.build(index_type),
        "environment": exp.DataType.build(index_type),
        "start_ts": exp.DataType.build("bigint"),
        "end_ts": exp.DataType.build("bigint"),
        "created_ts_ns": exp.DataType.build("bigint"),
        "executor": exp.DataType.build("text"),
        "success": exp.DataType.build("boolean"),
        "models_affected": exp.DataType.build("ARRAY<TEXT>"),
        "rows_affected": exp.DataType.build("bigint"),
        "bytes_processed": exp.DataType.build("bigint"),
        "total_evaluation_ms": exp.DataType.build("bigint"),
        "run_data": exp.DataType.build("jsonb"),
        "run_seq": exp.DataType.build("bigint"),
    }

    engine_adapter.create_state_table(
        runs_table,
        runs_columns_to_types,
        primary_key=("run_id",),
        table_description="Model execution runs with performance metrics",
        column_descriptions={
            "run_id": "Unique run identifier",
            "plan_id": "Plan that triggered this run",
            "environment": "Execution environment",
            "start_ts": "Run start time (Unix milliseconds)",
            "end_ts": "Run end time (Unix milliseconds)",
            "created_ts_ns": "Insertion timestamp (nanoseconds)",
            "executor": "User who executed the run",
            "success": "Run completed successfully",
            "models_affected": "List of model names executed",
            "rows_affected": "Total rows processed",
            "bytes_processed": "Total bytes processed",
            "total_evaluation_ms": "Total SQL evaluation duration in milliseconds (sum of all models)",
            "run_data": "Complete run details (RunExecution model without quality fields)",
            "run_seq": "Sequential number per environment (1, 2, 3...)",
        },
    )

    engine_adapter.create_index(
        runs_table,
        "idx_runs_environment_created",
        ("environment", "created_ts_ns"),
    )
    engine_adapter.create_index(
        runs_table,
        "idx_runs_plan_id",
        ("plan_id",),
    )
    engine_adapter.create_index(
        runs_table,
        "idx_runs_start_ts",
        ("start_ts",),
    )
    
    # GIN index for array queries
    try:
        engine_adapter.create_index(
            runs_table,
            "idx_runs_models_gin",
            ("models_affected",),
            index_type="GIN",
        )
    except Exception:
        pass


def migrate_rows(engine_adapter, schema, **kwargs):  # type: ignore
    """No data migration needed for new tables."""
    pass
