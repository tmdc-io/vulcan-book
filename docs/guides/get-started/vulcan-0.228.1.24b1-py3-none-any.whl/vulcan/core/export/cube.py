from __future__ import annotations

import typing as t
from collections import defaultdict, deque

from sqlglot import ParseError, parse_one
from sqlglot import expressions as exp

from vulcan.core.model.definition import _METRIC_COL_MEASURE, _METRIC_COL_TS
from vulcan.core.model.semantic import LogicalTypeValue
from vulcan.utils.dag import DAG

from schema.cube import (
    Cube,
    CubeAccessPolicyEntry,
    CubeDimension,
    CubeJoin,
    CubeMaskValue,
    CubeMemberLevelExcludes,
    CubeMemberLevelIncludesAll,
    CubeMemberLevelIncludesNone,
    CubeMemberMaskingIncludes,
    CubeMemberMaskingIncludesAll,
    CubeMeasure,
    CubeRef,
    CubeRowLevelAllowAll,
    CubeRowLevelFilters,
    CubeSchema,
    CubeSegment,
    CubeSqlMask,
    Include,
    View,
)
from schema.filters import PolicyEntry
from schema.metadata import (
    ColumnEntry,
    DimensionDetails,
    MaskExpression,
    MeasureDetails,
    Metadata,
    ModelEntry,
    SegmentDetails,
    Table,
)

class Graph:
    """
    Join graph from semantic YAML: each declarer maps to declared join targets
    (:class:`~vulcan.utils.dag.DAG`). :meth:`join_path` traverses immediate joins as **undirected**
    edges and uses shortest-hop BFS (neighbors scanned in sorted order for deterministic ties).

    Cube metric export uses this to stitch join paths between semantics (YAML joins, not warehouse
    lineage).
    """

    __slots__ = ("_dag",)

    def __init__(self, dag: DAG[str]) -> None:
        self._dag = dag

    @classmethod
    def from_metadata(cls, metadata: Metadata) -> Graph:
        semantics_by_name: t.Dict[str, ModelEntry] = {
            m.name: m for m in metadata.models if m.kind == "SEMANTIC"
        }
        known = frozenset(semantics_by_name)
        dag: DAG[str] = DAG[str]()
        for name, sem in semantics_by_name.items():
            dag.add(name, [j.model for j in sem.joins if j.model in known])
        return cls(dag)

    def _semantic_join_adjacency(self) -> t.Mapping[str, t.AbstractSet[str]]:
        """
        Build undirected neighbors: declarer declares a join to target ⇒ one edge declarer↔target.
        """

        adj: t.Dict[str, t.Set[str]] = defaultdict(set)
        for declarer, targets in self._dag.graph.items():
            for tgt in targets:
                adj[declarer].add(tgt)
                adj[tgt].add(declarer)
        return adj

    def join_path(self, start: str, end: str) -> t.Optional[str]:
        """
        Shortest ``join_path`` from ``start`` to ``end`` over immediate YAML join edges only.

        Args:
            start: Anchor semantic model name (typically the metric's primary cube).
            end: Target semantic model for bundled view fields.

        Returns:
            Dot-separated Cube path inclusive of both endpoints, or ``None`` if disconnected.
        """

        if start == end:
            return start

        adj = self._semantic_join_adjacency()
        queue: t.Deque[str] = deque([start])
        visited: t.Set[str] = {start}
        parent: t.Dict[str, str] = {}

        while queue:
            curr = queue.popleft()
            if curr == end:
                break
            for nb in sorted(adj.get(curr, ())):
                if nb not in visited:
                    visited.add(nb)
                    parent[nb] = curr
                    queue.append(nb)
        else:
            return None

        path: t.List[str] = []
        at = end
        while True:
            path.append(at)
            if at == start:
                break
            pn = parent.get(at)
            if pn is None:
                return None
            at = pn
        path.reverse()
        return ".".join(path)


def _mask(
    mask_expression: MaskExpression | None,
    *,
    dialect: str = "postgres",
) -> CubeMaskValue | None:
    if mask_expression is None:
        return None
    if not isinstance(mask_expression, str):
        return mask_expression

    expression = mask_expression.strip()
    try:
        parsed = parse_one(expression, dialect=dialect)
    except ParseError:
        return mask_expression

    is_scalar_sql_literal = isinstance(parsed, (exp.Literal, exp.Null, exp.Boolean)) or (
        isinstance(parsed, exp.Neg)
        and isinstance(parsed.this, (exp.Literal, exp.Null, exp.Boolean))
    )
    if is_scalar_sql_literal:
        return mask_expression

    return CubeSqlMask(sql=mask_expression)


def _access_policy(policy: PolicyEntry) -> CubeAccessPolicyEntry:
    if policy.filter:
        # Row-level WHERE: restrict which rows this group can see.
        row_level = CubeRowLevelFilters(filters=list(policy.filter))
    else:
        # No row filter: all rows allowed (subject to user REST filters).
        row_level = CubeRowLevelAllowAll(allow_all=True)

    member_masking: CubeMemberMaskingIncludesAll | CubeMemberMaskingIncludes | None
    if policy.mask == "*":
        # Redact every dimension; member_level lists none as directly visible.
        member_level = CubeMemberLevelIncludesNone(includes=[])
        member_masking = CubeMemberMaskingIncludesAll(includes="*")
    elif policy.mask:
        # Redact only listed dimensions; others stay cleartext.
        member_level = CubeMemberLevelExcludes(excludes=list(policy.mask))
        member_masking = CubeMemberMaskingIncludes(includes=list(policy.mask))
    else:
        # No masking: all dimensions cleartext for this group.
        member_level = CubeMemberLevelIncludesAll(includes="*")
        member_masking = None

    return CubeAccessPolicyEntry(
        group=policy.group,
        row_level=row_level,
        member_level=member_level,
        member_masking=member_masking,
    )


def _measure(col: ColumnEntry, *, semantic_name: str) -> CubeMeasure:
    assert isinstance(col.details, MeasureDetails)
    m = col.details
    return CubeMeasure(
        name=col.name,
        type=m.measure_type,
        sql=m.expression or "",
        filters=[{"sql": f"({expr})"} for expr in (m.filters or [])],
        rolling_window=m.rolling_window,
        public=col.public,
    )


def _dimension(col: ColumnEntry, *, dialect: str) -> CubeDimension:
    assert isinstance(col.details, DimensionDetails)
    d = col.details
    sem_type: LogicalTypeValue = col.ltype
    time_fmt = str(d.time_format) if d.time_format and sem_type == "time" else None
    granularities = (
        sorted(
            [g.model_copy(update={"ai_context": None, "description": None}) for g in d.time_granularities],
            key=lambda x: x.name,
        )
        if d.time_granularities
        else None
    )
    return CubeDimension(
        name=col.name,
        sql=col.name,
        type=sem_type,
        primary_key=col.primary_key,
        public=col.public,
        format=time_fmt,
        granularities=granularities,
        mask=_mask(d.mask_expression, dialect=dialect),
    )


def _sql_table(table: t.Optional[Table]) -> str:
    assert table is not None
    phys = table.physical.name
    if table.virtual is not None and table.virtual.name != phys:
        return table.virtual.name
    return phys


def _cube(sem: ModelEntry, physical: ModelEntry) -> Cube:
    assert physical.table is not None
    sql_tbl = _sql_table(physical.table)

    dim_cols = sorted(
        (x for x in sem.columns if x.kind == "dimension"),
        key=lambda x: x.name,
    )
    dimensions = [_dimension(c, dialect=sem.dialect or "postgres") for c in dim_cols]

    measures = [
        _measure(c, semantic_name=sem.name)
        for c in sorted(
            (x for x in sem.columns if x.kind == "measure"),
            key=lambda x: x.name,
        )
    ]
    segments = [
        CubeSegment(
            name=c.name,
            sql=t.cast(SegmentDetails, c.details).expression or "",
            public=c.public,
        )
        for c in sorted(
            (x for x in sem.columns if x.kind == "segment"),
            key=lambda x: x.name,
        )
    ]
    joins = [
        CubeJoin(
            name=j.model,
            relationship=j.relationship,
            sql=j.expression,
        )
        for j in sorted(sem.joins, key=lambda x: x.model)
    ]

    access_policy = (
        [_access_policy(p) for p in sem.policies]
        if sem.policies
        else None
    )

    return Cube(
        name=sem.name,
        sql_table=sql_tbl,
        measures=measures,
        dimensions=dimensions,
        segments=segments,
        joins=joins,
        access_policy=access_policy,
    )


def _build_cubes(metadata: Metadata) -> t.List[Cube]:
    by_name = {m.name: m for m in metadata.models}
    semantics = [m for m in metadata.models if m.kind == "SEMANTIC"]
    cubes: t.List[Cube] = []
    for sem in sorted(semantics, key=lambda m: m.name):
        if not sem.depends_on:
            continue
        physical = by_name.get(sem.depends_on[0])
        if physical is None or physical.table is None:
            continue
        cubes.append(_cube(sem, physical))
    return cubes


def _metric_field_triples(metric_entry: ModelEntry) -> t.Iterator[t.Tuple[str, str, str]]:
    """
    Walk a metric ModelEntry and yield one triple per view field: semantic model name, column on
    that cube, and the label used in the exported view. Emit measure, then ts, then each
    dimension and segment that has a dependency, sorted by column name.

    Examples: subscriptions.arr for the measure body becomes (subscriptions, arr, measure);
    subscriptions.start_date for time becomes (subscriptions, start_date, ts); a dimension tied to
    users.plan_type becomes (users, plan_type, that dimension's name on the metric row). Segments
    reuse the same triple shape when they declare a dependency.

    If measure or ts is missing or has no depends_on pointing at a cube, yield nothing.
    """
    measure_column = next(
        (column for column in metric_entry.columns if column.name == _METRIC_COL_MEASURE),
        None,
    )
    ts_column = next(
        (column for column in metric_entry.columns if column.name == _METRIC_COL_TS),
        None,
    )
    if (
        measure_column is None
        or ts_column is None
        or not measure_column.depends_on
        or not ts_column.depends_on
        or not measure_column.depends_on[0].model
        or not ts_column.depends_on[0].model
    ):
        return
    yield measure_column.depends_on[0].model, measure_column.depends_on[0].column or "", "measure"
    yield ts_column.depends_on[0].model, ts_column.depends_on[0].column or "", "ts"
    for dimension_column in sorted(
        (
            column
            for column in metric_entry.columns
            if column.kind == "dimension"
            and column.name not in (_METRIC_COL_MEASURE, _METRIC_COL_TS)
        ),
        key=lambda column: column.name,
    ):
        if not dimension_column.depends_on:
            continue
        yield (
            dimension_column.depends_on[0].model,
            dimension_column.depends_on[0].column or "",
            dimension_column.name,
        )
    for segment_column in sorted(
        (column for column in metric_entry.columns if column.kind == "segment"),
        key=lambda column: column.name,
    ):
        if not segment_column.depends_on:
            continue
        yield (
            segment_column.depends_on[0].model,
            segment_column.depends_on[0].column or "",
            segment_column.name,
        )


def _view(metric_entry: ModelEntry, graph: Graph) -> View:
    measure_column = next(
        (column for column in metric_entry.columns if column.name == _METRIC_COL_MEASURE),
        None,
    )
    column_triples = tuple(_metric_field_triples(metric_entry))
    if measure_column is None or not column_triples or not measure_column.depends_on:
        return View(name=metric_entry.name, cubes=[])
    primary_model_name = measure_column.depends_on[0].model
    columns_by_cube: t.DefaultDict[str, t.Dict[str, str]] = defaultdict(dict)

    for cube_name, column_name, alias in column_triples:
        column_aliases = columns_by_cube[cube_name]
        if column_name not in column_aliases:
            column_aliases[column_name] = alias

    cube_refs: t.List[CubeRef] = []
    for cube_name, column_aliases in columns_by_cube.items():
        join_path = graph.join_path(primary_model_name, cube_name) or (
            f"{primary_model_name}.{cube_name}"
        )
        includes: t.List[t.Union[str, Include]] = [
            source_column
            if column_aliases[source_column] == source_column
            else Include(name=source_column, alias=column_aliases[source_column])
            for source_column in sorted(column_aliases)
        ]
        cube_refs.append(CubeRef(join_path=join_path, includes=includes))

    return View(name=metric_entry.name, cubes=cube_refs)


def _build_views(metadata: Metadata) -> t.List[View]:
    metrics = [m for m in metadata.models if m.kind == "METRIC"]
    if not metrics:
        return []
    graph = Graph.from_metadata(metadata)
    return [
        _view(metric_entry, graph)
        for metric_entry in sorted(metrics, key=lambda metric: metric.name)
    ]


def build_cube_schema(metadata: Metadata) -> CubeSchema:
    """
    Build a Cube.js-style schema object from environment :class:`~schema.metadata.Metadata`.

    Args:
        metadata: Output of :func:`~vulcan.core.export.metadata.build_metadata` for the target
            environment (same snapshot slice, logical/physical tables, joins, metric columns).

    Returns:
        A :class:`~schema.cube.CubeSchema` describing semantic cubes and metric-derived views when
        the metadata includes semantics; otherwise ``cubes`` and ``views`` are empty.
    """
    cubes = _build_cubes(metadata)
    if not cubes:
        return CubeSchema(cubes=[], views=[])
    views = _build_views(metadata)
    return CubeSchema(cubes=cubes, views=views)
