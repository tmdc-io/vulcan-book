from __future__ import annotations

import typing as t

from schema.metadata import Metadata
from schema.semantic import (
    SemanticColumn,
    SemanticEntry,
    SemanticSchema,
)


def build_semantic_schema(metadata: Metadata) -> SemanticSchema:
    models: t.List[SemanticEntry] = [
        SemanticEntry(
            name=m.name,
            kind=m.kind,
            description=m.description or None,
            tags=list(m.tags),
            terms=list(m.terms),
            columns=list(
                SemanticColumn(
                    kind=col.kind,
                    name=col.name,
                    ltype=str(col.ltype),
                    dtype=col.dtype,
                    public=col.public,
                    primary_key=col.primary_key,
                    description=col.description,
                    tags=list(col.tags),
                    terms=list(col.terms),
                )
                for col in m.columns
                if col.kind in ("measure", "dimension")
            ),
        )
        for m in metadata.models
        if m.kind in ("SEMANTIC", "METRIC")
    ]
    return SemanticSchema(
        name=metadata.name,
        tenant=metadata.tenant,
        fingerprint=metadata.fingerprint,
        models=models,
    )
