from __future__ import annotations

import typing as t

from schema.types import JoinRelationshipValue, LogicalTypeValue, MeasureTypeValue
from schema.metadata import Metadata, MeasureDetails
from vulcan.utils.pydantic import PydanticModel


class BiColumn(PydanticModel):
    name: str
    type: LogicalTypeValue
    public: bool = True
    agg_type: t.Optional[MeasureTypeValue] = None


class BiJoin(PydanticModel):
    name: str
    relationship: JoinRelationshipValue


class BiTable(PydanticModel):
    name: str
    type: t.Literal["table", "view"] = "table"
    public: bool = True
    dimensions: t.List[BiColumn] = []
    measures: t.List[BiColumn] = []
    joins: t.List[BiJoin] = []


def _is_public_by_tags(tags: t.Iterable[str]) -> bool:
    return "private" not in {tag.lower() for tag in tags}


def export_to_bi_tables(metadata: Metadata) -> t.List[BiTable]:
    model_by_name = {model.name: model for model in metadata.models}
    semantic_names = {model.name for model in metadata.models if model.kind == "SEMANTIC"}

    tables: t.List[BiTable] = []
    for entry in metadata.models:
        if entry.kind != "SEMANTIC":
            continue

        physical = model_by_name.get(entry.depends_on[0]) if entry.depends_on else None
        table_type: t.Literal["table", "view"] = (
            "view" if physical and physical.kind == "VIEW" else "table"
        )

        dimensions = [
            BiColumn(
                name=f"{entry.name}.{col.name}",
                type=col.ltype,
                public=col.public,
            )
            for col in entry.columns
            if col.kind == "dimension"
        ]
        measures = [
            BiColumn(
                name=f"{entry.name}.{col.name}",
                type="number",
                public=col.public,
                agg_type=(
                    t.cast(MeasureDetails, col.details).measure_type
                    if isinstance(col.details, MeasureDetails)
                    else None
                ),
            )
            for col in entry.columns
            if col.kind == "measure"
        ]
        joins = [
            BiJoin(name=join.model, relationship=join.relationship)
            for join in entry.joins
            if join.model in semantic_names
        ]

        tables.append(
            BiTable(
                name=entry.name,
                type=table_type,
                public=_is_public_by_tags(entry.tags),
                dimensions=dimensions,
                measures=measures,
                joins=joins,
            )
        )

    return tables
