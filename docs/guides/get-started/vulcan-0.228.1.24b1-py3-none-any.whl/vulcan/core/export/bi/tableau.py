from __future__ import annotations

import json
import logging
import typing as t
import xml.etree.ElementTree as ET
from xml.dom import minidom

from schema.metadata import Metadata

from vulcan.core.export.bi.adapter import BiColumn, BiTable, export_to_bi_tables
from vulcan.core.dataproduct_mysql import get_dataproduct_mysql_endpoint

logger = logging.getLogger(__name__)

_DATA_TYPE_MAPPINGS: dict[str, str] = {
    "number": "real",
    "string": "string",
    "time": "datetime",
    "boolean": "boolean",
}

_HIDDEN_MAPPING: dict[str, str] = {
    "true": "false",
    "false": "true",
}

_AGGREGATION_MAPPING: dict[str, str] = {
    "sum": "Sum",
    "boolean": "Max",
    "count": "Count",
    "avg": "Avg",
    "min": "Min",
    "max": "Max",
    "countDistinct": "CountD",
    "countDistinctApprox": "CountD",
    "count_distinct": "CountD",
    "count_distinct_approx": "CountD",
    "number": "Sum",
    "string": "Count",
    "time": "Min",
}

_CONNECTION_CUSTOMIZATIONS: dict[str, str] = {
    "CAP_CONNECT_CUSTOM_SQL_WITHOUT_SCHEMA": "no",
    "CAP_CREATE_TEMP_TABLES": "no",
    "CAP_CUSTOM_NOSQL": "no",
    "CAP_EXTRACT_ONLY": "no",
    "CAP_ISOLATION_LEVEL_READ_COMMITTED": "no",
    "CAP_ISOLATION_LEVEL_READ_UNCOMMITTED": "no",
    "CAP_ISOLATION_LEVEL_REPEATABLE_READS": "no",
    "CAP_ISOLATION_LEVEL_SERIALIZABLE": "no",
    "CAP_JDBC_BIND_DETECT_ALIAS_CASE_FOLDING": "no",
    "CAP_JDBC_SUPPRESS_EMPTY_CATALOG_NAME": "no",
    "CAP_JDBC_SUPPRESS_ENUMERATE_DATABASES": "no",
    "CAP_JDBC_SUPPRESS_ENUMERATE_SCHEMAS": "no",
    "CAP_JDBC_SUPPRESS_ENUMERATE_TABLES": "no",
    "CAP_QUERY_BOOLEXPR_TO_INTEXPR": "yes",
    "CAP_QUERY_FROM_REQUIRES_ALIAS": "no",
    "CAP_QUERY_GROUP_ALLOW_DUPLICATES": "yes",
    "CAP_QUERY_GROUP_BY_ALIAS": "no",
    "CAP_QUERY_GROUP_BY_DEGREE": "no",
    "CAP_QUERY_HAVING_REQUIRES_GROUP_BY": "no",
    "CAP_QUERY_HAVING_UNSUPPORTED": "no",
    "CAP_QUERY_JOIN_ACROSS_SCHEMAS": "no",
    "CAP_QUERY_JOIN_REQUIRES_SCOPE": "no",
    "CAP_QUERY_NULL_REQUIRES_CAST": "no",
    "CAP_QUERY_SELECT_ALIASES_SORTED": "yes",
    "CAP_QUERY_SORT_BY_DEGREE": "yes",
    "CAP_QUERY_SUBQUERIES": "no",
    "CAP_QUERY_SUBQUERIES_WITH_TOP": "no",
    "CAP_QUERY_SUBQUERY_QUERY_CONTEXT": "yes",
    "CAP_QUERY_TOPSTYLE_LIMIT": "no",
    "CAP_QUERY_TOPSTYLE_ROWNUM": "no",
    "CAP_QUERY_TOPSTYLE_TOP": "no",
    "CAP_QUERY_TOP_0_METADATA": "no",
    "CAP_QUERY_TOP_N": "no",
    "CAP_QUERY_WHERE_FALSE_METADATA": "no",
    "CAP_SELECT_INTO": "yes",
    "CAP_SELECT_TOP_INTO": "yes",
    "CAP_SET_ISOLATION_LEVEL_VIA_ODBC_API": "no",
    "CAP_SET_ISOLATION_LEVEL_VIA_SQL": "no",
    "CAP_SUPPRESS_CONNECTION_POOLING": "no",
    "CAP_SUPPRESS_DISCOVERY_QUERIES": "no",
}


def _short_name(col: BiColumn) -> str:
    return col.name.split(".", 1)[1] if "." in col.name else col.name


def _build_jdbc_url(host: str, port: str, dbname: str) -> str:
    host_or = host or "127.0.0.1"
    port_or = port or "3306"
    return (
        f"jdbc:mysql://{host_or}:{port_or}/{dbname}"
        "?useSSL=true&allowPublicKeyRetrieval=true&allowCleartextPasswords=true&verifyServerCertificate=false"
    )


def _build_genericjdbc_connection(
    root: ET.Element,
    jdbc_url: str,
    dbname: str,
    host: str,
    port: str,
    username: str | None,
) -> tuple[str, ET.Element]:
    connection_el = ET.SubElement(root, "connection", attrib={"class": "federated"})

    connection_name = f"genericjdbc.{(host or 'localhost')}"

    named_connections = ET.SubElement(connection_el, "named-connections")
    named_connection = ET.SubElement(
        named_connections,
        "named-connection",
        caption=jdbc_url,
        name=connection_name,
    )

    inner_conn = ET.SubElement(
        named_connection,
        "connection",
        attrib={"class": "genericjdbc"},
        dbname=dbname,
        dialect="mysql",
        jdbcproperties="",
        jdbcurl=jdbc_url,
        port=port or "",
        schema="",
        server=host or "",
        username=username or "",
        warehouse="",
    )

    customization = ET.SubElement(
        inner_conn,
        "connection-customization",
        attrib={"class": "genericjdbc"},
        enabled="false",
        version="18.1",
    )
    ET.SubElement(customization, "vendor", name="genericjdbc")
    ET.SubElement(customization, "driver", name="mysql")
    customizations_el = ET.SubElement(customization, "customizations")
    for name, value in _CONNECTION_CUSTOMIZATIONS.items():
        ET.SubElement(customizations_el, "customization", name=name, value=value)

    return connection_name, connection_el


def _build_tables_tds(tables: list[BiTable], host: str, port: int, product_db: str) -> str:
    port_str = str(port)
    columns_object: list[dict[str, object]] = []
    table_object: list[dict[str, object]] = []
    obj: list[dict[str, object]] = []
    connection_object: list[dict[str, object]] = []
    relationship_obj: list[dict[str, object]] = []
    cols_obj: list[dict[str, object]] = []

    for table in tables:
        if not table.public or table.type != "table":
            continue

        table_data = {
            "caption": table.name,
            "datatype": "table",
            "name": f"[__tableau_internal_object_id__].[{table.name}]",
            "role": "measure",
            "type": "quantitative",
        }
        obj_data = {"caption": table.name, "id": table.name}
        connection_data = {
            "connection": "",
            "name": table.name,
            "table": f"[public].[{table.name}]",
            "type": "table",
        }

        connection_object.append(connection_data)
        obj.append(obj_data)
        table_object.append(table_data)

        for dimension in table.dimensions:
            short = _short_name(dimension)
            columns_data = {
                "caption": short,
                "datatype": _DATA_TYPE_MAPPINGS.get(str(dimension.type), "string"),
                "hidden": _HIDDEN_MAPPING[str(dimension.public).lower()],
                "name": f"[{short} ({table.name})]",
                "role": "dimension",
                "type": "ordinal" if str(dimension.type) == "time" else "nominal",
            }
            columns_object.append(columns_data)

        for measure in table.measures:
            short = _short_name(measure)
            columns_data = {
                "caption": short,
                "datatype": _DATA_TYPE_MAPPINGS.get(str(measure.type), "real"),
                "aggregation": _AGGREGATION_MAPPING.get(str(measure.agg_type or ""), "Sum"),
                "hidden": _HIDDEN_MAPPING[str(measure.public).lower()],
                "name": f"[{short} ({table.name})]",
                "role": "measure",
                "type": "ordinal" if str(measure.type) == "time" else "quantitative",
            }
            if str(measure.type) not in ["time", "boolean", "string"]:
                columns_object.append(columns_data)
            else:
                columns_data.pop("aggregation", None)
                columns_data["role"] = "dimension"
                columns_data["type"] = "ordinal" if str(measure.type) == "time" else "nominal"
                columns_object.append(columns_data)

        columns_object.append(
            {
                "caption": "__user",
                "datatype": "string",
                "hidden": "true",
                "name": f"[__user ({table.name})]",
                "role": "dimension",
                "type": "nominal",
            }
        )
        columns_object.append(
            {
                "caption": "__joinField",
                "datatype": "string",
                "hidden": "true",
                "name": f"[__joinField ({table.name})]",
                "role": "dimension",
                "type": "nominal",
            }
        )

        for join in table.joins:
            relationship_obj.append(
                {"source": table.name, "dest": join.name, "cardinality": str(join.relationship)}
            )

    caption_to_id = {item["caption"]: item["id"] for item in obj}
    relationship_list: list[dict[str, object]] = []
    for relation in relationship_obj:
        source_caption = t.cast(str, relation["source"])
        dest_caption = t.cast(str, relation["dest"])
        cardinality = t.cast(str, relation["cardinality"])
        source_id = caption_to_id.get(source_caption)
        dest_id = caption_to_id.get(dest_caption)
        if source_id and dest_id:
            relationship_list.append(
                {
                    "source_caption": source_caption,
                    "source_id": source_id,
                    "destination_caption": dest_caption,
                    "destination_id": dest_id,
                    "cardinality": cardinality,
                }
            )

    for item in columns_object:
        key = t.cast(str, item["name"])
        caption = t.cast(str, item["caption"])
        cols_obj.append(
            {
                "key": key,
                "value": f"[{(key.split('(')[1]).split(')')[0]}].[{caption}]",
            }
        )

    root = ET.Element("datasource", inline="true", version="18.1")

    manifest_el = ET.SubElement(root, "document-format-change-manifest")
    ET.SubElement(
        manifest_el,
        "_.fcp.ObjectModelEncapsulateLegacy.true...ObjectModelEncapsulateLegacy",
    )
    ET.SubElement(manifest_el, "_.fcp.ObjectModelTableType.true...ObjectModelTableType")
    ET.SubElement(
        manifest_el, "_.fcp.SchemaViewerObjectModel.true...SchemaViewerObjectModel"
    )

    jdbc_url = _build_jdbc_url(host, port_str, product_db)
    connection_name, connection_el = _build_genericjdbc_connection(
        root, jdbc_url, product_db, host, port_str, None
    )

    for conn in connection_object:
        conn["connection"] = connection_name

    fcp_true_relation_string = ET.SubElement(
        connection_el,
        "_.fcp.ObjectModelEncapsulateLegacy.true...relation",
        type="collection",
    )
    for conn in connection_object:
        ET.SubElement(fcp_true_relation_string, "relation", **t.cast(dict[str, str], conn))

    cols = ET.SubElement(connection_el, "cols")
    for col in cols_obj:
        ET.SubElement(cols, "map", **t.cast(dict[str, str], col))

    ET.SubElement(root, "aliases", enabled="yes")
    for table in table_object:
        ET.SubElement(root, "_.fcp.ObjectModelTableType.true...column", **t.cast(dict[str, str], table))
    for column in columns_object:
        ET.SubElement(root, "column", **t.cast(dict[str, str], column))

    ET.SubElement(
        root,
        "layout",
        **{"_.fcp.SchemaViewerObjectModel.false...dim-percentage": "0.5"},
        **{"_.fcp.SchemaViewerObjectModel.false...measure-percentage": "0.4"},
        **{"dim-ordering": "alphabetic", "measure-ordering": "alphabetic", "show-structure": "true"},
    )

    object_graph = ET.SubElement(
        root, "_.fcp.ObjectModelEncapsulateLegacy.true...object-graph"
    )
    objects = ET.SubElement(object_graph, "objects")
    for x in obj:
        object_elem = ET.SubElement(objects, "object", **t.cast(dict[str, str], x))
        properties = ET.SubElement(object_elem, "properties", context="")
        ET.SubElement(
            properties,
            "relation",
            connection=connection_name,
            name=t.cast(str, x["caption"]),
            table=f"[public].[{t.cast(str, x['caption'])}]",
            type="table",
        )

    relationships = ET.SubElement(object_graph, "relationships")
    for relation in relationship_list:
        relationship = ET.SubElement(relationships, "relationship")
        expression = ET.SubElement(relationship, "expression", op="=")
        ET.SubElement(
            expression,
            "expression",
            op=f"[__joinField ({relation['source_caption']})]",
        )
        ET.SubElement(
            expression,
            "expression",
            op=f"[__joinField ({relation['destination_caption']})]",
        )

        unique_key = {"unique-key": "true"}
        card = str(relation["cardinality"]).lower()
        if "belongs" in card:
            first_end_point_id = {"object-id": relation["source_id"], **unique_key}
            second_end_point_id = {"object-id": relation["destination_id"], **unique_key}
        elif "hasmany" in card:
            first_end_point_id = {"object-id": relation["source_id"], **unique_key}
            second_end_point_id = {"object-id": relation["destination_id"]}
        elif "hasone" in card or "one_to_one" in card:
            first_end_point_id = {"object-id": relation["source_id"], **unique_key}
            second_end_point_id = {"object-id": relation["destination_id"], **unique_key}
        else:
            first_end_point_id = {"object-id": relation["source_id"], **unique_key}
            second_end_point_id = {"object-id": relation["destination_id"]}

        ET.SubElement(relationship, "first-end-point", **t.cast(dict[str, str], first_end_point_id))
        ET.SubElement(relationship, "second-end-point", **t.cast(dict[str, str], second_end_point_id))

    tds_xml = ET.tostring(root, encoding="utf-8", method="xml")
    return minidom.parseString(tds_xml).toprettyxml(indent="  ")


def _build_view_tds(table: BiTable, host: str, port: int, product_db: str) -> str:
    port_str = str(port)
    columns_object: list[dict[str, object]] = []
    table_object: list[dict[str, object]] = []
    obj: list[dict[str, object]] = []
    connection_object: list[dict[str, object]] = []

    table_data = {
        "caption": table.name,
        "datatype": "table",
        "name": f"[__tableau_internal_object_id__].[{table.name}]",
        "role": "measure",
        "type": "quantitative",
    }
    obj_data = {"caption": table.name, "id": table.name}
    connection_data = {
        "connection": "",
        "name": table.name,
        "table": f"[public].[{table.name}]",
        "type": "table",
    }

    connection_object.append(connection_data)
    obj.append(obj_data)
    table_object.append(table_data)

    for dimension in table.dimensions:
        short = _short_name(dimension)
        columns_object.append(
            {
                "caption": short,
                "datatype": _DATA_TYPE_MAPPINGS.get(str(dimension.type), "string"),
                "hidden": _HIDDEN_MAPPING[str(dimension.public).lower()],
                "name": f"[{short}]",
                "role": "dimension",
                "type": "ordinal" if str(dimension.type) == "time" else "nominal",
            }
        )

    for measure in table.measures:
        short = _short_name(measure)
        columns_data = {
            "caption": short,
            "datatype": _DATA_TYPE_MAPPINGS.get(str(measure.type), "real"),
            "aggregation": _AGGREGATION_MAPPING.get(str(measure.agg_type or ""), "Sum"),
            "hidden": _HIDDEN_MAPPING[str(measure.public).lower()],
            "name": f"[{short}]",
            "role": "measure",
            "type": "ordinal" if str(measure.type) == "time" else "quantitative",
        }
        if str(measure.type) not in ["time", "boolean", "string"]:
            columns_object.append(columns_data)
        else:
            columns_data.pop("aggregation", None)
            columns_data["role"] = "dimension"
            columns_data["type"] = "ordinal" if str(measure.type) == "time" else "nominal"
            columns_object.append(columns_data)

    columns_object.append(
        {
            "caption": "__user",
            "datatype": "string",
            "hidden": "true",
            "name": "[__user]",
            "role": "dimension",
            "type": "nominal",
        }
    )
    columns_object.append(
        {
            "caption": "__joinField",
            "datatype": "string",
            "hidden": "true",
            "name": "[__joinField]",
            "role": "dimension",
            "type": "nominal",
        }
    )

    root = ET.Element("datasource", inline="true", version="18.1")
    manifest_el = ET.SubElement(root, "document-format-change-manifest")
    ET.SubElement(
        manifest_el,
        "_.fcp.ObjectModelEncapsulateLegacy.true...ObjectModelEncapsulateLegacy",
    )
    ET.SubElement(manifest_el, "_.fcp.ObjectModelTableType.true...ObjectModelTableType")
    ET.SubElement(
        manifest_el, "_.fcp.SchemaViewerObjectModel.true...SchemaViewerObjectModel"
    )

    jdbc_url = _build_jdbc_url(host, port_str, product_db)
    connection_name, connection_el = _build_genericjdbc_connection(
        root, jdbc_url, product_db, host, port_str, None
    )

    for conn in connection_object:
        conn["connection"] = connection_name
        ET.SubElement(
            connection_el,
            "_.fcp.ObjectModelEncapsulateLegacy.true...relation",
            **t.cast(dict[str, str], conn),
        )

    ET.SubElement(root, "aliases", enabled="yes")
    for column in columns_object:
        ET.SubElement(root, "column", **t.cast(dict[str, str], column))
    for td in table_object:
        ET.SubElement(root, "_.fcp.ObjectModelTableType.true...column", **t.cast(dict[str, str], td))

    ET.SubElement(
        root,
        "layout",
        **{"_.fcp.SchemaViewerObjectModel.false...dim-percentage": "0.5"},
        **{"_.fcp.SchemaViewerObjectModel.false...measure-percentage": "0.4"},
        **{"dim-ordering": "alphabetic", "measure-ordering": "alphabetic", "show-structure": "true"},
    )

    object_graph = ET.SubElement(
        root, "_.fcp.ObjectModelEncapsulateLegacy.true...object-graph"
    )
    objects = ET.SubElement(object_graph, "objects")
    for x in obj:
        object_elem = ET.SubElement(objects, "object", **t.cast(dict[str, str], x))
        properties = ET.SubElement(object_elem, "properties", context="")
        ET.SubElement(
            properties,
            "relation",
            connection=connection_name,
            name=t.cast(str, x["caption"]),
            table=f"[public].[{t.cast(str, x['caption'])}]",
            type="table",
        )

    tds_xml = ET.tostring(root, encoding="utf-8", method="xml")
    return minidom.parseString(tds_xml).toprettyxml(indent="  ")


def build_tableau_entries(
    metadata: Metadata,
    *,
    tables: list[BiTable] | None = None,
) -> dict[str, str]:
    endpoint = get_dataproduct_mysql_endpoint()
    product_key = f"{metadata.tenant}_{metadata.name}" if metadata.tenant else metadata.name
    product_id = f"{metadata.tenant}/{metadata.name}"
    product_db = f"{metadata.tenant}.{metadata.name}"
    if tables is None:
        tables = export_to_bi_tables(metadata)

    entries: dict[str, str] = {
        "data_sources/manifest.json": json.dumps(
            {
                "product": product_id,
                "environment": metadata.env,
                "models": [table.name for table in tables],
            },
            indent=2,
        ),
        f"data_sources/tables/{product_key}_tables.tds": _build_tables_tds(
            tables, endpoint.host, endpoint.port, product_db
        ),
    }

    for table in tables:
        if table.type == "view" and table.public:
            entries[f"data_sources/views/{table.name}.tds"] = _build_view_tds(
                table, endpoint.host, endpoint.port, product_db
            )

    return entries
