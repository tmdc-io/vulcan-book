from __future__ import annotations

import json
import logging
import typing as t
import uuid

from schema.metadata import Metadata

from vulcan.core.export.bi.adapter import BiColumn, BiTable, export_to_bi_tables
from vulcan.core.dataproduct_mysql import get_dataproduct_mysql_endpoint

logger = logging.getLogger(__name__)

_DATA_TYPE_MAPPINGS: dict[str, str] = {
    "number": "double",
    "string": "string",
    "time": "dateTime",
    "boolean": "boolean",
}

_SOURCE_PROVIDER_MAPPINGS: dict[str, str] = {
    "string": "nvarchar(max)",
    "number": "decimal",
    "time": "datetime2",
    "boolean": "boolean",
    "double": "decimal",
}

_PROJECT_FILE_TEMPLATE: dict[str, object] = {
    "version": "1.0",
    "artifacts": [{"report": {"path": ""}}],
    "settings": {"enableAutoRecovery": False},
}

_REPORT_DEFINITION_PBIR_TEMPLATE: dict[str, object] = {
    "version": "4.0",
    "datasetReference": {"byPath": {"path": ""}, "byConnection": None},
}

_MODEL_DEFINITION_PBISM: dict[str, object] = {
    "version": "4.0",
    "settings": {},
}


def _short_name(col: BiColumn) -> str:
    return col.name.split(".", 1)[1] if "." in col.name else col.name


def _dimension_column(col: BiColumn) -> dict[str, object]:
    short_name = _short_name(col)
    data_type = _DATA_TYPE_MAPPINGS.get(str(col.type), "string")
    return {
        "name": short_name,
        "annotations": [{"name": "SummarizationSetBy", "value": "Automatic"}],
        "dataType": data_type,
        "isNullable": True,
        "lineageTag": str(uuid.uuid4()),
        "sourceColumn": short_name,
        "sourceProviderType": _SOURCE_PROVIDER_MAPPINGS.get(str(col.type), "nvarchar(max)"),
        "summarizeBy": "none",
    }


def _measure_column(col: BiColumn) -> dict[str, object]:
    short_name = _short_name(col)
    data_type = _DATA_TYPE_MAPPINGS.get(str(col.type), "double")
    return {
        "name": short_name,
        "annotations": [
            {"name": "SummarizationSetBy", "value": "Automatic"},
            {"name": "PBI_FormatHint", "value": '{"isGeneralNumber":true}'},
        ],
        "dataType": data_type,
        "formatString": "0",
        "lineageTag": str(uuid.uuid4()),
        "sourceColumn": short_name,
        "sourceProviderType": _SOURCE_PROVIDER_MAPPINGS.get(str(col.type), "decimal"),
        "summarizeBy": "sum",
        "isHidden": True,
    }


def _user_helper_column() -> dict[str, object]:
    return {
        "name": "__user",
        "annotations": [{"name": "SummarizationSetBy", "value": "Automatic"}],
        "dataType": "string",
        "lineageTag": str(uuid.uuid4()),
        "sourceColumn": "__user",
        "sourceProviderType": "nvarchar(max)",
        "summarizeBy": "none",
        "isHidden": True,
    }


def _join_helper_column() -> dict[str, object]:
    return {
        "name": "__joinField",
        "annotations": [{"name": "SummarizationSetBy", "value": "Automatic"}],
        "dataType": "string",
        "lineageTag": str(uuid.uuid4()),
        "sourceColumn": "__joinField",
        "sourceProviderType": "nvarchar(max)",
        "summarizeBy": "none",
        "isHidden": True,
    }


def _dax_measure(col: BiColumn, table_name: str) -> tuple[str, dict[str, object]]:
    short_name = _short_name(col)
    internal_measure_name = f"{table_name}_{short_name}"
    return internal_measure_name, {
        "name": internal_measure_name,
        "annotations": [{"name": "PBI_FormatHint", "value": '{"isGeneralNumber":true}'}],
        "expression": f"FIRSTNONBLANK('{table_name}'[{short_name}], 0)",
        "lineageTag": str(uuid.uuid4()),
    }


def _build_model_bim(tables: list[BiTable], hostport: str, product_db: str) -> dict[str, object]:
    start_json: dict[str, object] = {
        "compatibilityLevel": 1567,
        "model": {
            "annotations": [
                {"name": "PBI_QueryOrder", "value": []},
                {"name": "__PBI_TimeIntelligenceEnabled", "value": "1"},
                {"name": "PBIDesktopVersion", "value": "2.128.1380.0 (24.04)"},
                {"name": "PBI_ProTooling", "value": '["DevMode"]'},
            ],
            "culture": "en-IN",
            "cultures": [
                {
                    "name": "en-IN",
                    "linguisticMetadata": {
                        "content": {"Language": "en-US", "Version": "1.0.0"},
                        "contentType": "json",
                    },
                }
            ],
            "dataAccessOptions": {
                "legacyRedirects": True,
                "returnErrorValuesAsNull": True,
            },
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "relationships": [],
            "sourceQueryCulture": "en-IN",
        },
    }

    tables_info: list[dict[str, object]] = []
    is_public_tab = {table.name: table.public for table in tables}

    for table in tables:
        if not table.public:
            logger.info("Skipped non-public table '%s'", table.name)
            continue

        table_name = table.name
        table_object: dict[str, object] = {
            "name": table_name,
            "annotations": [{"name": "PBI_ResultType", "value": "Table"}],
            "columns": [],
            "lineageTag": str(uuid.uuid4()),
            "measures": [],
            "partitions": [],
        }

        for col in table.dimensions:
            if not col.public:
                logger.info("Skipped non-public dimension '%s'", col.name)
                continue
            table_object["columns"].append(_dimension_column(col))

        for join in table.joins:
            if not is_public_tab.get(join.name, False):
                logger.info(
                    "Skipped join from '%s' to non-public table '%s'",
                    table.name,
                    join.name,
                )
                continue

            join_data: dict[str, object] = {
                "name": str(uuid.uuid4()),
                "crossFilteringBehavior": "oneDirection",
                "fromColumn": "__joinField",
                "toColumn": "__joinField",
            }
            rel = (join.relationship or "").lower()
            if "one_to_many" in rel:
                join_data["fromTable"] = join.name
                join_data["fromCardinality"] = "many"
                join_data["toTable"] = table_name
                join_data["toCardinality"] = "one"
            elif "many_to_one" in rel:
                join_data["fromTable"] = table_name
                join_data["fromCardinality"] = "many"
                join_data["toTable"] = join.name
                join_data["toCardinality"] = "one"
            elif "one_to_one" in rel:
                join_data["crossFilteringBehavior"] = "bothDirections"
                join_data["toTable"] = table_name
                join_data["fromCardinality"] = "one"
                join_data["fromTable"] = join.name
                join_data["toCardinality"] = "one"
            else:
                join_data["fromTable"] = table_name
                join_data["fromCardinality"] = "many"
                join_data["toTable"] = join.name
                join_data["toCardinality"] = "one"
            start_json["model"]["relationships"].append(join_data)

        for col in table.measures:
            if not col.public:
                logger.info("Skipped non-public measure '%s'", col.name)
                continue
            table_object["columns"].append(_measure_column(col))

        table_object["columns"].append(_user_helper_column())
        table_object["columns"].append(_join_helper_column())

        for col in table.measures:
            if not col.public:
                continue
            _, measure_obj = _dax_measure(col, table_name)
            table_object["measures"].append(measure_obj)

        partition = {
            "name": table_name,
            "mode": "directQuery",
            "source": {
                "expression": [
                    "let",
                    f'    Source = DataOS.Contents("{hostport};{product_db}", null),',
                    f'    public_{table_name} = Source{{[Name="{table_name}" ]}}[Data]',
                    "in",
                    f"    public_{table_name}",
                ],
                "type": "m",
            },
        }
        table_object["partitions"].append(partition)
        tables_info.append(table_object)

    query_order_annotation = start_json["model"]["annotations"][0]
    try:
        query_order_annotation["value"] = json.dumps([table["name"] for table in tables_info])
    except Exception as exc:  # pragma: no cover - defensive parity with old branch
        logger.error("Could not update or serialize PBI_QueryOrder annotation: %s", exc)
        raise

    start_json["model"]["tables"] = tables_info
    return start_json


def build_powerbi_entries(
    metadata: Metadata,
    *,
    tables: list[BiTable] | None = None,
) -> dict[str, str]:
    endpoint = get_dataproduct_mysql_endpoint()
    product_key = f"{metadata.tenant}_{metadata.name}"
    product_db = f"{metadata.tenant}.{metadata.name}"
    if tables is None:
        tables = export_to_bi_tables(metadata)
    hostport = f"{endpoint.host}:{endpoint.port}"

    model_bim = _build_model_bim(tables, hostport, product_db)

    entries: dict[str, str] = {}
    entries[f"{product_key}.SemanticModel/model.bim"] = json.dumps(model_bim)
    entries[f"{product_key}.SemanticModel/definition.pbism"] = json.dumps(
        _MODEL_DEFINITION_PBISM
    )
    report_definition = json.loads(json.dumps(_REPORT_DEFINITION_PBIR_TEMPLATE))
    report_definition["datasetReference"]["byPath"]["path"] = f"../{product_key}.SemanticModel"
    entries[f"{product_key}.Report/definition.pbir"] = json.dumps(report_definition)

    project_file = json.loads(json.dumps(_PROJECT_FILE_TEMPLATE))
    project_file["artifacts"][0]["report"]["path"] = f"{product_key}.Report"
    entries[f"{product_key}.pbip"] = json.dumps(project_file)
    return entries
