from __future__ import annotations

from vulcan.core.config.base import BaseConfig


class MigrationConfig(BaseConfig):
    """Configuration for the Vulcan state migration.

    Args:
        promoted_snapshots_only: If True, only snapshots that are part of at least one environment will be migrated.
            Otherwise, all snapshots will be migrated.
    """

    promoted_snapshots_only: bool = True
