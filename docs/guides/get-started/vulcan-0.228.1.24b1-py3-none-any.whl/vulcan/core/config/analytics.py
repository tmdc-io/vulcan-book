from __future__ import annotations

import typing as t

from pydantic import Field
from vulcan.core.config.base import BaseConfig


class PrometheusConfig(BaseConfig):
    """Prometheus Pushgateway configuration (root-level ``prometheus:`` block).

    Independent of ``analytics.enabled`` — metrics push even when CloudEvents is off.

    Example::

        prometheus:
          enabled: true
          pushgateway_url: "{{ env_var('PUSHGATEWAY_URL', 'http://localhost:9091') }}"
          job: "vulcan-v2"
          push_interval_sec: 10
    """

    enabled: bool = Field(default=False)
    pushgateway_url: str = Field(default="")
    job: str = Field(default="vulcan-v2")
    push_interval_sec: int = Field(default=10, ge=1, le=300)
    push_timeout_sec: float = Field(default=2.0, ge=0.1, le=30.0)
    grouping_key: t.Dict[str, str] = Field(
        default_factory=dict,
        description="Explicit grouping_key override; auto-built from DATAOS_* env vars when empty",
    )


class AnalyticsConfig(BaseConfig):
    """CloudEvents-based analytics/telemetry configuration for Vulcan.

    Controls the CloudEvents collector that sends telemetry events (plan, apply,
    run, etc.) to a remote service.  Prometheus metrics are configured separately
    at the root level under ``prometheus:`` and are independent of ``enabled``.

    Design Decision (Dec 2025):
        ``analytics.enabled`` is the single source of truth for CloudEvents.
        Prometheus was previously nested here but has been promoted to a root-level
        config (``prometheus:``) so it can be enabled independently of CloudEvents.

    Example (config.yaml)::

        analytics:
          enabled: true
          base_url: "https://collector.example.com/api"
          api_key: "{{ env_var('ANALYTICS_API_KEY') }}"
          source_name: "vulcan"
          retention_days: 30
    """
    
    enabled: bool = Field(
        default=True,
        description="Whether analytics collection is enabled",
    )
    base_url: str = Field(
        default="",
        description="Base URL for the CloudEvents collector API (required when enabled)",
    )
    api_key: str = Field(
        default="",
        description="API key for authentication with the collector (required when enabled)",
    )
    source_name: str = Field(
        default="vulcan",
        description="Source identifier for events",
    )
    enable_search: bool = Field(
        default=True,
        description="Whether to enable search indexing on the collector",
    )
    retention_days: int = Field(
        default=30,
        ge=1,
        le=365,
        description="Number of days to retain analytics data",
    )
    timeout: int = Field(
        default=10,
        ge=1,
        le=300,
        description="HTTP timeout in seconds for collector requests",
    )

