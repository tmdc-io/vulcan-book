from __future__ import annotations

from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import model_validator
import typing as t


class PGQConfig(BaseConfig):
    """PGQ (PostgreSQL Queue) configuration for async job processing.

    https://pgqueuer.readthedocs.io/en/latest/index.html
    
    Args:
        concurrency_limit: Max concurrent jobs per queue (per-queue limit)
        batch_size: Number of jobs to fetch per DB query (efficiency)
        max_concurrent_tasks: Global concurrency limit across all queues (must be >= 2 * batch_size)
        requests_per_second: Rate limit for job starts per second (per-queue)
        dequeue_timeout: Polling timeout in seconds when LISTEN/NOTIFY fails (default: 30s)
    """
    concurrency_limit: int = 5
    batch_size: int = 10
    max_concurrent_tasks: int = 20
    requests_per_second: float = 10.0
    dequeue_timeout: int = 5  # Seconds - polling fallback timeout
    
    @model_validator(mode='after')
    def validate_max_concurrent_tasks(self) -> t.Any:
        if self.max_concurrent_tasks < 2 * self.batch_size:
            raise ValueError(
                f"max_concurrent_tasks ({self.max_concurrent_tasks}) must be >= 2 * batch_size ({2 * self.batch_size})"
            )
        return self

