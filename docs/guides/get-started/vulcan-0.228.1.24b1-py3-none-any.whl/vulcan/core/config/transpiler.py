from __future__ import annotations

from vulcan.core.config.base import BaseConfig
import typing as t


class TranspilerConfig(BaseConfig):
    """Transpiler service configuration."""

    # Base URL of the Transpiler API (client appends /v1/sql)
    base_url: str = "http://127.0.0.1:8100"
    # HTTP timeout in seconds for Transpiler requests
    timeout: int = 30
    # Bearer token for Transpiler auth (optional; set via config.yaml or VULCAN__TRANSPILER__TOKEN)
    token: t.Optional[str] = None


