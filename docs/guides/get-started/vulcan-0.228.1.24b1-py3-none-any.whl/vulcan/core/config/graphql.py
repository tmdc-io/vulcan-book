from __future__ import annotations

from vulcan.core.config.base import BaseConfig


class GraphQLConfig(BaseConfig):
    """GraphQL proxy service configuration."""

    # Base URL for upstream GraphQL service, e.g. "http://vulcan-graphql:3000"
    base_url: str = "http://127.0.0.1:3000"
    # HTTP timeout in seconds for GraphQL proxy requests
    timeout: int = 30


