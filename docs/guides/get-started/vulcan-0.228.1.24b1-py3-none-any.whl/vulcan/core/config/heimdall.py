from __future__ import annotations

import re
import typing as t

from pydantic import Field, field_validator, model_validator

from vulcan.core.config.base import BaseConfig

_HOOK_SPEC_PATTERN = re.compile(
    r"^[a-zA-Z_][a-zA-Z0-9_.]*:[a-zA-Z_][a-zA-Z0-9_]*$",
    re.ASCII,
)


class HeimdallConfig(BaseConfig):
    """
    Heimdall settings for the Vulcan API

    Attributes:
        base_url:
            Root URL of your Heimdall deployment (must be non-empty when ``enabled`` is true).
        timeout:
            Wall-clock deadline (seconds) for one ``asyncio.wait_for`` spanning Heimdall authorize plus the
            optional enrichment hook together.
        enabled:
            When true, Bearer tokens are enforced for protected routes; defaults to false for safe bootstrapping.
        after_authorize:
            Hook import path ``module:callable`` from the project root, or omit / leave blank when unused.
            The callable accepts :class:`schema.auth.AuthExtensionContext` and returns
            :class:`schema.auth.SecurityContext`.
        cache_timeout:
            In-process TTL (seconds) for caching successful Heimdall ``authorize`` responses keyed by
            Bearer token. ``0`` disables caching. Does not apply to ``after_authorize``.
    """

    base_url: str = ""
    timeout: float = Field(default=10.0, ge=0.05, le=300.0)
    enabled: bool = False
    after_authorize: t.Optional[str] = None
    cache_timeout: float = Field(default=30.0, ge=0.0, le=300.0)

    @field_validator("after_authorize")
    @classmethod
    def _normalize_and_validate_hook_spec(cls, v: t.Optional[str]) -> t.Optional[str]:
        stripped = None if v is None else str(v).strip()
        if not stripped:
            return None
        if not _HOOK_SPEC_PATTERN.fullmatch(stripped):
            raise ValueError(
                f"Invalid heimdall.after_authorize hook {stripped!r}; expected "
                "'<dotted_python_module>:<callable_name>' (ASCII; exactly one ':')."
            )
        return stripped

    @model_validator(mode="after")
    def validate_base_url_required_when_enabled(self) -> "HeimdallConfig":
        if self.enabled and not self.base_url:
            raise ValueError(
                "heimdall.base_url is required when heimdall.enabled=true. "
                "Either provide a valid Heimdall URL or set heimdall.enabled=false."
            )
        return self
