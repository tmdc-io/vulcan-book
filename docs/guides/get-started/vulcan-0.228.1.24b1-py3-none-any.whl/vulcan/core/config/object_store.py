from vulcan.core.config.base import BaseConfig
import typing as t


class ObjectStoreConfig(BaseConfig):
    """Object store configuration for query result storage.

    Supports multiple cloud providers:
    - S3: AWS S3
    - MinIO: Self-hosted S3-compatible storage
    - GCS: Google Cloud Storage
    - Azure: Azure Blob Storage / Data Lake Gen2

    Example (MinIO - Local Dev):
        ```yaml
        object_store:
          provider: minio
          bucket: warehouse
          base_path: queries
          compression: snappy
          presigned_url_expiry_mins: 60
          credentials:
            endpoint_url: http://localhost:9000
            access_key_id: admin
            secret_access_key: password
            region: us-east-1
        ```

    Example (AWS S3 - Production):
        ```yaml
        object_store:
          provider: s3
          bucket: my-query-results
          base_path: queries
          credentials:
            access_key_id: AKIAIOSFODNN7EXAMPLE
            secret_access_key: ${AWS_SECRET_ACCESS_KEY}
            region: us-west-2
        ```

    Example (GCS - Production):
        ```yaml
        object_store:
          provider: gcs
          bucket: my-query-results
          base_path: queries
          credentials:
            project_id: my-project
            credentials_file: /path/to/service-account.json
        ```
    """

    provider: t.Literal["s3", "gcs", "azure", "minio"] = "minio"
    bucket: str = "warehouse"  # Container name for Azure
    base_path: str = "queries"  # Prefix for all query result objects
    compression: t.Literal["snappy", "gzip", "zstd"] = "snappy"
    presigned_url_expiry_mins: int = 60  # URLs valid for 1 hour
    credentials: t.Dict[str, t.Any] = {}

