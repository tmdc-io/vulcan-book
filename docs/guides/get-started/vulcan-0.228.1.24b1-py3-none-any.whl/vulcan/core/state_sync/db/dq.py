from __future__ import annotations

import json
import typing as t
import logging
from collections import defaultdict

from sqlglot import exp
from decimal import Decimal
from datetime import date, datetime, timezone, timedelta

import pandas as pd

from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import (
    fetchall,
    fetchone,
    json_to_dict,
    json_to_list,
    raise_if_not_postgres,
)
from vulcan.utils.migration import index_text_type
from vulcan.utils.date import now_timestamp
from vulcan.utils import random_id, to_snake_case_keys

from vulcan.core.soda3 import _NAME_ATTR_KEY, _DIMENSION_ATTR_KEY
from vulcan.core.soda3.spec import (
    CheckResult,
    CheckOutcome,
    CheckRuns,
    CheckResultWithRunId,
    ModelProfile,
    FieldStatistics,
    ScanResults,
    QualitySummary,
    ProductQualitySummary,
    validate_dq_dimension,
)

if t.TYPE_CHECKING:
    from vulcan.core.activity import RunActivityWithChecksAndProfile

logger = logging.getLogger(__name__)

# Profile metric value discriminator: which column holds the value (value_text, value_number, value_json)
ProfileValueType = t.Literal["number", "json", "text"]


def _parse_metric_value(m: t.Dict[str, t.Any]) -> t.Any:
    """Extract value from profile metric row based on value_type.

    _dq_profiles uses EAV: value lives in one of value_text, value_number, value_json.
    value_type (ProfileValueType) selects which column to read.
    """
    vt: t.Optional[ProfileValueType] = m.get("value_type")
    if vt == "number":
        # value_number: DB may return Decimal; normalize to int when whole, else float
        v = m.get("value_number")
        if v is None:
            return None
        try:
            f = float(v)
            return int(f) if f.is_integer() else f
        except (ValueError, TypeError):
            return v
    if vt == "json":
        # value_json: stored as JSON string; parse to dict/list, fallback to raw on error
        raw = m.get("value_json")
        if not raw:
            return None
        try:
            return json.loads(raw) if isinstance(raw, str) else raw
        except (json.JSONDecodeError, TypeError):
            return raw
    # value_text (or unknown value_type): return as-is
    return m.get("value_text")


def _parse_outcome_reasons(outcome_reasons: t.Any) -> t.Optional[t.Dict[str, t.Any]]:
    if not outcome_reasons:
        return None

    try:
        if isinstance(outcome_reasons, str):
            parsed = json.loads(outcome_reasons)
        else:
            parsed = outcome_reasons

        if isinstance(parsed, list):
            messages = []
            for item in parsed:
                if isinstance(item, dict):
                    messages.append(item.get("message", str(item)))
                else:
                    messages.append(str(item))
            return {"messages": messages}

        return parsed if isinstance(parsed, dict) else {"message": str(parsed)}

    except (json.JSONDecodeError, Exception):
        return {"message": str(outcome_reasons)}


def _build_quality_list(checks: t.List[t.Any]) -> t.List[CheckResult]:
    """Build list of CheckResult from parsed quality checks list."""
    result: t.List[CheckResult] = []
    for d in checks:
        data = dict(d)
        data["outcome_reasons"] = _parse_outcome_reasons(data.get("outcome_reasons"))
        data["diagnostics"] = json_to_dict(data.get("diagnostics"))
        try:
            data["outcome"] = CheckOutcome(data.get("outcome") or "not_evaluated")
        except ValueError:
            data["outcome"] = CheckOutcome.NOT_EVALUATED
        result.append(CheckResult.model_validate(data))
    return result


def _build_profile_list(metrics: t.List[t.Any]) -> t.List[ModelProfile]:
    """Build list of ModelProfile from parsed profile metrics list."""
    if not metrics:
        return []
    by_model: t.Dict[str, t.Dict[str, t.Any]] = defaultdict(lambda: {"columns": defaultdict(dict)})
    for m in metrics:
        model_name = m["model_name"]
        col = m.get("column_name")
        ptype = m["profile_type"]
        value = _parse_metric_value(m)
        if col is None:
            # Table-level metric (row_count, table_labels, etc.)
            by_model[model_name][ptype] = value
        else:
            # Column-level metric (min, max, distinct_count, etc.)
            by_model[model_name]["columns"][col][ptype] = value
    return [
        ModelProfile(
            model_name=name,
            columns={c: FieldStatistics.model_validate(dict(d)) for c, d in data["columns"].items()},
            **{k: v for k, v in data.items() if k != "columns"},
        )
        for name, data in by_model.items()
    ]


def _timestamp_to_iso(timestamp: int) -> str:
    """Convert timestamp (ms) to ISO-8601 UTC string."""
    from datetime import datetime, timezone
    # now_timestamp() returns milliseconds, so convert to seconds
    dt = datetime.fromtimestamp(timestamp / 1000, tz=timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")

def format_data_time(value: t.Any) -> str:
    """Normalize various timestamp representations to ISO-8601 UTC."""
    # Milliseconds since epoch (our created_ts/measured_at convention).
    if isinstance(value, int):
        dt = datetime.fromtimestamp(value / 1000, tz=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")

    # Naive or aware datetime.
    if isinstance(value, datetime):
        dt = value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)
        dt = dt.astimezone(timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")

    # Date only → treat as midnight UTC.
    if isinstance(value, date):
        dt = datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")

    # Already an ISO timestamp string – return as-is.
    if isinstance(value, str):
        return value

    raise ValueError(f"Unsupported type for dataTime: {type(value)}")


def convert_value(value: t.Any, column_name: t.Optional[str] = None) -> t.Any:
    if isinstance(value, Decimal):
        return float(value)
    if column_name == "dataTime":
        return format_data_time(value)
    return value


def _parse_diagnostics(raw: t.Any) -> t.Dict[str, t.Any]:
    """Best-effort diagnostics parser supporting JSON strings and dicts."""
    return json_to_dict(raw)

class QualityState:
    """Manages data quality state: rule catalog, run outcomes, metrics, and profiles.

    Note:
        DB columns and Soda wire data use ``check_*`` names (``check_identity``,
        ``check_name``, ``check_type``). Product/API terminology calls the same
        things **rules** (``kind: dq``, ``/api/v1/dq/rules``). Check == rule.
    """
    
    def __init__(
        self,
        engine_adapter: EngineAdapter,
        schema: t.Optional[str] = None,
    ):
        self.engine_adapter = engine_adapter
        self.schema = schema
        
        # Table references
        self.check_results_table = exp.table_("_dq_results", db=schema)
        self.checks_definitions_table = exp.table_("_dq_definitions", db=schema)
        self.check_metrics_table = exp.table_("_dq_metrics", db=schema)
        self.profiles_table = exp.table_("_dq_profiles", db=schema)
        self.check_feedback_table = exp.table_("_dq_feedbacks", db=schema)
        
        # Reference to runs table for run verification
        self.runs_table = exp.table_("_runs", db=schema)

    def store_checks_and_profile_results(
        self,
        scan_results: t.Dict[str, t.Any],
        run_id: str,
        environment: str,
    ) -> str:
        """Store check and profile results (checks, metrics, failed rows, profiles) in a single transaction."""
        scan_id = scan_results["scanId"]
        
        try:
            # Phase 1: Prepare all DataFrames (CPU-bound, parallelizable)
            # Note: No longer preparing run_df - quality data now tracked in _activity_run_executions
            checks_df, check_id_map = self._prepare_checks_dataframe(
                scan_results, run_id, environment
            )
            metrics_df = self._prepare_metrics_dataframe(
                scan_results, run_id, environment, check_id_map
            )
            # Note: Failed rows are now embedded directly in check diagnostics
            profiles_df = self._prepare_profiles_dataframe(
                scan_results, run_id, environment
            )
            
            # Phase 2: Batch write to database (I/O-bound, transactional)
            # Using explicit transaction for atomicity
            with self.engine_adapter.transaction():
                # No longer writing run data - quality summary stored in _activity_run_executions
                
                if not checks_df.empty:
                    self._write_checks_batch(checks_df)
                    self._upsert_checks_definitions(checks_df)
                
                if not metrics_df.empty:
                    self._write_metrics_batch(metrics_df)
                
                if not profiles_df.empty:
                    self._write_profiles_batch(profiles_df)
            
            logger.info(
                f"Stored check scan {scan_id}, run {run_id}: "
                f"{len(checks_df)} checks, {len(metrics_df)} metrics, "
                f"{len(profiles_df)} profile metrics"
            )
            return scan_id
            
        except Exception as e:
            logger.error(f"Failed to store scan results for scan {scan_id}: {e}", exc_info=True)
            raise

    def _prepare_checks_dataframe(
        self,
        scan_results: ScanResults,
        run_id: str,
        environment: str,
    ) -> t.Tuple[pd.DataFrame, t.Dict[str, str]]:
        """Prepare all checks as a DataFrame and return check ID mapping."""
        all_checks = scan_results.get("checks", []) + scan_results.get("automatedMonitoringChecks", [])
        
        if not all_checks:
            return pd.DataFrame(), {}
        
        rows = []
        check_id_map = {}
        created_ts = now_timestamp()
        
        for check in all_checks:
            # Extract dimension from resourceAttributes using constants.
            # Soda converts attributes to list of {name, value} objects.
            resource_attrs = check.get("resourceAttributes", {})
            dimension = None
            if isinstance(resource_attrs, list):
                # List format: [{"name": "...", "value": "..."}]
                for attr in resource_attrs:
                    if not isinstance(attr, dict):
                        continue
                    name = attr.get(_NAME_ATTR_KEY)
                    if name == _DIMENSION_ATTR_KEY:
                        dimension = attr.get("value")
            elif isinstance(resource_attrs, dict):
                # Dict format: {dimension_key: "..."} (see ``_DIMENSION_ATTR_KEY``)
                dimension = resource_attrs.get(_DIMENSION_ATTR_KEY)

            check_id = random_id()
            check_identity = check.get("identity")
            if not check_identity:
                raise ValueError(
                    f"Check missing 'identity' field. Check name: '{check.get(_NAME_ATTR_KEY, 'unnamed')}', "
                    f"table: '{check.get('table', 'unknown')}'."
                )
            if not dimension or not str(dimension).strip():
                raise ValueError(
                    f"Check missing '{_DIMENSION_ATTR_KEY}' in resourceAttributes. "
                    f"Check name: '{check.get(_NAME_ATTR_KEY, 'unnamed')}', "
                    f"identity: '{check_identity}'."
                )
            dimension = validate_dq_dimension(dimension)
            metric_identities = check.get("metrics", [])

            # Map each metric identity to this check's ID
            for metric_id in metric_identities:
                check_id_map[metric_id] = (check_id, check_identity)

            # SodaStateSyncBackend._build_scan_results has already normalized the
            # check's `table` field to the Vulcan model name using table_model_map,
            # so we rely directly on that here as the logical model name.
            effective_model_name = check.get("table", "unknown")

            # Convert diagnostics keys from camelCase to snake_case before storing
            # This normalizes the data format in the database (diagnostics come from Soda in camelCase)
            diagnostics_json = None
            diagnostics = check.get("diagnostics")
            if diagnostics:
                diagnostics_json = json.dumps(to_snake_case_keys(diagnostics))

            rows.append({
                "id": check_id,
                "run_id": run_id,
                "environment": environment,
                "model_name": effective_model_name,
                "start_ts": scan_results["scanStartTimestamp"],
                "end_ts": scan_results["scanEndTimestamp"],
                "check_identity": check_identity,
                "check_name": check.get(_NAME_ATTR_KEY, "unnamed"),
                "check_type": check.get("type", "unknown"),
                "definition": check.get("definition"),
                "dimension": dimension,
                "resource_attributes": json.dumps(resource_attrs) if resource_attrs else None,
                "location": json.dumps(check.get("location")) if check.get("location") else None,
                "group_by": json.dumps(check.get("group")) if check.get("group") else None,
                "column_name": check.get("column"),
                "filter": check.get("filter"),
                "metrics": json.dumps(check.get("metrics")) if check.get("metrics") else None,
                "outcome": check.get("outcome") or CheckOutcome.NOT_EVALUATED.value,
                "outcome_reasons": json.dumps(check.get("outcomeReasons")) if check.get("outcomeReasons") else None,
                "archetype": check.get("archetype"),
                "diagnostics": diagnostics_json,
                "created_ts": created_ts,  # Timestamp when this check result was created (milliseconds)
            })
        
        return pd.DataFrame(rows), check_id_map

    def _prepare_metrics_dataframe(
        self,
        scan_results: ScanResults,
        run_id: str,
        environment: str,
        check_id_map: t.Dict[str, str],
    ) -> pd.DataFrame:
        """Prepare all metrics as a DataFrame."""
        metrics_list = scan_results.get("metrics", [])
        
        if not metrics_list:
            return pd.DataFrame()
        
        rows = []
        created_ts = now_timestamp()
        
        for metric in metrics_list:
            # Generate unique random ID
            metric_id = random_id()
            
            # Link to check using metric's identity
            metric_identity = metric.get("identity")
            check_mapping = check_id_map.get(metric_identity)
            if check_mapping:
                check_id, check_identity = check_mapping
            else:
                check_id, check_identity = None, None
            
            # Handle typed values
            value = metric.get("value")
            value_text, value_number, value_json, value_type = None, None, None, None
            
            if value is not None:
                if isinstance(value, (int, float)):
                    value_number = float(value)
                    value_type = "number"
                elif isinstance(value, str):
                    value_text = value
                    value_type = "text"
                elif isinstance(value, (dict, list)):
                    value_json = json.dumps(value)
                    value_type = "json"
                else:
                    value_json = json.dumps(value)
                    value_type = "json"
            
            rows.append({
                "id": metric_id,
                "run_id": run_id,
                "environment": environment,
                "check_id": check_id,
                "check_identity": check_identity or "",
                "metric_identity": metric.get("identity"),
                "metric_name": metric.get("metricName") or metric.get(_NAME_ATTR_KEY, "unknown"),
                "model_name": metric.get("table", "unknown"),
                "column_name": metric.get("columnName") or metric.get("column"),
                "partition_name": metric.get("partition"),
                "value_text": value_text,
                "value_number": value_number,
                "value_json": value_json,
                "value_type": value_type,
                "measured_at": metric.get("dataTime") or scan_results["scanEndTimestamp"],
                "created_ts": created_ts,
            })
        
        return pd.DataFrame(rows)

    def _prepare_profiles_dataframe(
        self,
        scan_results: ScanResults,
        run_id: str,
        environment: str,
    ) -> pd.DataFrame:
        """Prepare profile results as DataFrame (table-level and column-level metrics)."""
        profiling = scan_results.get("profiling", [])
        
        if not profiling:
            return pd.DataFrame()
        
        rows = []
        current_ts = now_timestamp()
        profiled_at = scan_results.get("scanStartTimestamp", current_ts)
        
        for profile_table in profiling:
            model_name = profile_table.get('table')
            if not model_name:
                continue
            
            # At this stage, SodaStateSyncBackend has already decided what the
            # `table` identifier should be for profiling results (based on the
            # SodaCL configuration), so we treat it as the final logical model
            # name to store.
            full_model_name = model_name
            
            # 1. Table-level: row_count
            row_count = profile_table.get('rowCount')
            if row_count is not None:
                rows.append({
                    'id': random_id(),
                    'run_id': run_id,
                    'environment': environment,
                    'model_name': full_model_name,
                    'column_name': None,
                    'profile_type': 'row_count',
                    'value_text': None,
                    'value_number': float(row_count),
                    'value_json': None,
                    'value_type': 'number',
                    'profiled_at': profiled_at,
                    'created_ts': current_ts,
                })
            
            # 2. Column-level profiles
            column_profiles = profile_table.get('columnProfiles', [])
            for col_profile in column_profiles:
                column_name = col_profile.get('columnName')
                profile_data = col_profile.get('profile', {})
                
                if not column_name or not profile_data:
                    continue
                
                # Iterate through all profile metrics for this column
                for metric_name, metric_value in profile_data.items():
                    # Skip None values - don't store them in database
                    if metric_value is None:
                        continue
                    
                    # Determine value type and store in appropriate column
                    value_text = None
                    value_number = None
                    value_json = None
                    value_type = None
                    
                    if isinstance(metric_value, (int, float)):
                        value_number = float(metric_value)
                        value_type = 'number'
                    elif isinstance(metric_value, str):
                        # Try to parse numeric strings (e.g., "0.0" -> 0.0)
                        try:
                            value_number = float(metric_value)
                            value_type = 'number'
                        except (ValueError, TypeError):
                            # Not a numeric string, store as text
                            value_text = metric_value
                            value_type = 'text'
                    elif isinstance(metric_value, (dict, list)):
                        value_json = json.dumps(metric_value)
                        value_type = 'json'
                    else:
                        # Fallback: convert to string (should rarely happen)
                        value_text = str(metric_value)
                        value_type = 'text'
                    
                    rows.append({
                        'id': random_id(),
                        'run_id': run_id,
                        'environment': environment,
                        'model_name': full_model_name,
                        'column_name': column_name,
                        'profile_type': metric_name,
                        'value_text': value_text,
                        'value_number': value_number,
                        'value_json': value_json,
                        'value_type': value_type,
                        'profiled_at': profiled_at,
                        'created_ts': current_ts,
                    })
            
            # 3. Table-level: table_labels (optional)
            table_profile = profile_table.get('tableProfile', {})
            if table_profile:
                table_labels = table_profile.get('tableLabels')
                if table_labels:
                    rows.append({
                        'id': random_id(),
                        'run_id': run_id,
                        'environment': environment,
                        'model_name': full_model_name,
                        'column_name': None,
                        'profile_type': 'table_labels',
                        'value_text': None,
                        'value_number': None,
                        'value_json': json.dumps(table_labels),
                        'value_type': 'json',
                        'profiled_at': profiled_at,
                        'created_ts': current_ts,
                    })
        
        if not rows:
            return pd.DataFrame()
        
        # ID already included in rows - no need to add separately
        return pd.DataFrame(rows)

    def _write_checks_batch(self, df: pd.DataFrame) -> None:
        """Write checks DataFrame to database. Check metadata lives in _dq_definitions."""
        index_type = index_text_type(self.engine_adapter.dialect)
        df_to_insert = df[
            [
                "id", 
                "run_id", 
                "environment", 
                "start_ts", 
                "end_ts", 
                "check_identity",
                "outcome", 
                "outcome_reasons", 
                "diagnostics", 
                "created_ts",
            ]
        ].copy()
        self.engine_adapter.insert_append(
            self.check_results_table,
            df_to_insert,
            target_columns_to_types={
                "id": exp.DataType.build(index_type),
                "run_id": exp.DataType.build(index_type),
                "environment": exp.DataType.build(index_type),
                "start_ts": exp.DataType.build("bigint"),
                "end_ts": exp.DataType.build("bigint"),
                "check_identity": exp.DataType.build(index_type),
                "outcome": exp.DataType.build("text"),
                "outcome_reasons": exp.DataType.build("text"),
                "diagnostics": exp.DataType.build("text"),
                "created_ts": exp.DataType.build("bigint"),
            },
            track_rows_processed=False,
        )

    def _upsert_checks_definitions(self, df: pd.DataFrame) -> None:
        """Upsert distinct check definitions from checks batch. PK: (check_identity, environment)."""
        if df.empty:
            return
        distinct = df.drop_duplicates(
            subset=["check_identity", "environment"], keep="last"
        )[
            [
                "check_identity",
                "environment",
                "check_name",
                "check_type",
                "column_name",
                "dimension",
                "definition",
                "model_name",
                "resource_attributes",
                "location",
                "group_by",
                "filter",
                "metrics",
                "archetype",
                "end_ts",
            ]
        ].copy()
        distinct = distinct.rename(columns={"end_ts": "updated_ts"})
        index_type = index_text_type(self.engine_adapter.dialect)
        target_columns_to_types = {
            "check_identity": exp.DataType.build(index_type),
            "environment": exp.DataType.build(index_type),
            "check_name": exp.DataType.build("text"),
            "check_type": exp.DataType.build("text"),
            "column_name": exp.DataType.build("text"),
            "dimension": exp.DataType.build("text"),
            "definition": exp.DataType.build("text"),
            "model_name": exp.DataType.build(index_type),
            "resource_attributes": exp.DataType.build("text"),
            "location": exp.DataType.build("text"),
            "group_by": exp.DataType.build("text"),
            "filter": exp.DataType.build("text"),
            "metrics": exp.DataType.build("text"),
            "archetype": exp.DataType.build("text"),
            "updated_ts": exp.DataType.build("bigint"),
        }
        self.engine_adapter.merge(
            self.checks_definitions_table,
            distinct,
            target_columns_to_types=target_columns_to_types,
            unique_key=(exp.column("check_identity"), exp.column("environment")),
        )

    def _write_metrics_batch(self, df: pd.DataFrame) -> None:
        """Write metrics DataFrame to database."""
        index_type = index_text_type(self.engine_adapter.dialect)
        
        self.engine_adapter.insert_append(
            self.check_metrics_table,
            df,
            target_columns_to_types={
                "id": exp.DataType.build(index_type),
                "run_id": exp.DataType.build(index_type),
                "environment": exp.DataType.build(index_type),
                "check_id": exp.DataType.build(index_type),
                "check_identity": exp.DataType.build(index_type),
                "metric_identity": exp.DataType.build(index_type),
                "metric_name": exp.DataType.build(index_type),
                "model_name": exp.DataType.build(index_type),
                "column_name": exp.DataType.build("text"),
                "partition_name": exp.DataType.build("text"),
                "value_text": exp.DataType.build("text"),
                "value_number": exp.DataType.build("numeric"),
                "value_json": exp.DataType.build("text"),
                "value_type": exp.DataType.build("text"),
                "measured_at": exp.DataType.build("bigint"),
                "created_ts": exp.DataType.build("bigint"),
            },
            track_rows_processed=False,
        )

    def _write_profiles_batch(self, df: pd.DataFrame) -> None:
        """Write profiles batch to database."""
        index_type = index_text_type(self.engine_adapter.dialect)
        
        # Ensure correct column order matching table schema
        column_order = [
            'id', 'run_id', 'environment', 'model_name', 'column_name', 'profile_type',
            'value_text', 'value_number', 'value_json', 'value_type',
            'profiled_at', 'created_ts'
        ]
        
        df = df[column_order]
        
        # Insert into database
        self.engine_adapter.insert_append(
            self.profiles_table,
            df,
            target_columns_to_types={
                "id": exp.DataType.build(index_type),
                "run_id": exp.DataType.build(index_type),
                "environment": exp.DataType.build(index_type),
                "model_name": exp.DataType.build(index_type),
                "column_name": exp.DataType.build("text"),
                "profile_type": exp.DataType.build("text"),
                "value_text": exp.DataType.build("text"),
                "value_number": exp.DataType.build("numeric"),
                "value_json": exp.DataType.build("text"),
                "value_type": exp.DataType.build("text"),
                "profiled_at": exp.DataType.build("bigint"),
                "created_ts": exp.DataType.build("bigint"),
            },
            track_rows_processed=False,
        )

    # ===== HISTORIC DATA QUERIES (For Anomaly Detection & Change-Over-Time) =====

    def get_historic_measurements(
        self,
        metric_identity: str,
        limit: int = 100,
    ) -> t.List[t.Dict[str, t.Any]]:
        """Fetch historic metric measurements for anomaly detection."""
        try:
            query = (
                exp.select(
                    exp.column("id"),
                    exp.column("metric_identity").as_("identity"),
                    exp.column("value_number").as_("value"),
                    exp.column("created_ts").as_("dataTime"),
                )
                .from_(self.check_metrics_table)
                .where(
                    exp.and_(
                        exp.EQ(
                            this=exp.column("metric_identity"),
                            expression=exp.Literal.string(metric_identity),
                        ),
                        exp.Is(this=exp.column("value_number"), expression=exp.Null()).not_(),
                    )
                )
                .order_by(exp.column("created_ts"), desc=True)
                .limit(limit)
            )
            
            rows = fetchall(self.engine_adapter, query)
            results: t.List[t.Dict[str, t.Any]] = []
            for row in rows:
                (
                    id_,
                    identity,
                    value_number,
                    created_ts
                ) = row

                # Soda requires "value" to be numeric — use value_number
                value = convert_value(value_number, "value")

                # Convert timestamp into ISO8601
                data_time = convert_value(created_ts, "dataTime")

                results.append({
                    "id": id_,
                    "identity": identity,
                    "value": value,
                    "dataTime": data_time,
                })
            
            logger.debug(
                f"Fetched {len(results)} historic measurements for metric '{metric_identity}'"
            )
            return results
            
        except Exception as e:
            logger.error(
                f"Failed to fetch historic measurements for '{metric_identity}': {e}",
                exc_info=True,
            )
            return []

    def get_historic_check_results(
        self,
        check_identity: str,
        limit: int = 100,
    ) -> t.List[t.Dict[str, t.Any]]:
        """Fetch historic check outcomes for anomaly detection (Soda format)."""
        try:
            c = exp.to_table(self.check_results_table).as_("c")
            m = exp.to_table(self.check_metrics_table).as_("m")
            cd = exp.to_table(self.checks_definitions_table).as_("cd")

            select_exprs = [
                exp.column("check_type", table="cd").as_("type"),
                exp.column("id", table="c").as_("testResultId"),
                exp.column("outcome", table="c"),
                exp.column("created_ts", table="c").as_("dataTime"),
                exp.column("diagnostics", table="c"),
                exp.column("id", table="m").as_("measurementId"),
            ]

            query = (
                exp.select(*select_exprs)
                .from_(c)
                .join(
                    cd,
                    on=exp.and_(
                        exp.EQ(
                            this=exp.column("check_identity", table="c"),
                            expression=exp.column("check_identity", table="cd"),
                        ),
                        exp.EQ(
                            this=exp.column("environment", table="c"),
                            expression=exp.column("environment", table="cd"),
                        ),
                    ),
                    join_type="inner",
                )
                .join(
                    m,
                    on=exp.EQ(
                        this=exp.column("id", table="c"),
                        expression=exp.column("check_id", table="m"),
                    ),
                    join_type="left",
                )
                .where(
                    exp.EQ(
                        this=exp.column("check_identity", table="c"),
                        expression=exp.Literal.string(check_identity),
                    )
                )
                .order_by(exp.Ordered(this=exp.column("created_ts", table="c"), desc=True))
                .limit(limit)
            )
            
            rows = fetchall(self.engine_adapter, query)
            results: t.List[t.Dict[str, t.Any]] = []
            for row in rows:
                (
                    type,
                    test_result_id,
                    outcome,
                    created_ts,
                    diagnostics_raw,
                    measurement_id,
                ) = row
                data_time = convert_value(created_ts, "dataTime")
                diagnostics = _parse_diagnostics(diagnostics_raw)
                results.append(
                    {
                        "type": type,
                        "testResultId": test_result_id,
                        "outcome": outcome,
                        "dataTime": data_time,
                        "diagnostics": diagnostics,
                        "measurementId": measurement_id,
                    }
                )
            
            logger.debug(
                f"Fetched {len(results)} historic check results for check '{check_identity}'"
            )
            return results
            
        except Exception as e:
            logger.error(
                f"Failed to fetch historic check results for '{check_identity}': {e}",
                exc_info=True,
            )
            return []

    def get_historic_metric_change_over_time(
        self,
        metric_identity: str,
        same_day_last_week: bool = False,
    ) -> t.List[t.Dict[str, t.Any]]:
        """Fetch historic metric changes over time for a given metric identity."""
        try:
            conditions: t.List[exp.Expression] = [
                exp.EQ(
                    this=exp.column("metric_identity"),
                    expression=exp.Literal.string(metric_identity),
                )
            ]

            previous_time_start = None
            previous_time_end = None
            today = date.today()

            if same_day_last_week:
                last_week = today - timedelta(days=7)
                previous_time_start = datetime(
                    year=last_week.year, month=last_week.month, day=last_week.day, tzinfo=timezone.utc
                )
                previous_time_end = datetime(
                    year=last_week.year,
                    month=last_week.month,
                    day=last_week.day,
                    hour=23,
                    minute=59,
                    second=59,
                    tzinfo=timezone.utc,
                )

            if previous_time_start and previous_time_end:
                # Convert datetime objects to string in the required format
                start_ms = int(previous_time_start.timestamp() * 1000)
                end_ms = int(previous_time_end.timestamp() * 1000)


                conditions.append(
                    exp.GT(
                        this=exp.column("created_ts"),
                        expression=exp.Literal.number(start_ms),
                    )
                )
                conditions.append(
                    exp.LTE(
                        this=exp.column("created_ts"),
                        expression=exp.Literal.number(end_ms),
                    )
                )

            query = (
                exp.select(
                    exp.column("id"),
                    exp.column("metric_identity"),
                    exp.column("value_number"),
                    exp.column("created_ts").as_("dataTime"),
                )
                .from_(self.check_metrics_table)
                .where(exp.and_(*conditions))
                .order_by(exp.column("created_ts"))
            )

            rows = fetchall(self.engine_adapter, query)

            results: t.List[t.Dict[str, t.Any]] = []
            for row in rows:
                (
                    measurement_id,
                    identity,
                    value_number,
                    data_time,
                ) = row

                results.append(
                    {
                        "id": measurement_id,
                        "identity": identity,
                        "value": convert_value(value_number, "value"),
                        "dataTime": convert_value(data_time, "dataTime"),
                    }
                )

            logger.debug(
                f"Fetched {len(results)} historic changes over time for '{metric_identity}'"
            )
            return results

        except Exception as e:
            logger.error(
                f"Failed to fetch change-over-time data for '{metric_identity}': {e}",
                exc_info=True,
            )
            return []

    # ======= API Queries =======
    
    def get_check_identity_by_natural_key(
        self,
        environment: str,
        model_name: str,
        dimension: str,
        check_name: str,
    ) -> t.Optional[str]:
        """
        Look up ``check_identity`` from the human-readable check key.

        Stored results and most quality APIs key off ``check_identity``—an opaque
        hash assigned when the check is first seen. Day to day, though, checks
        are referred to by ``(model_name, dimension, check_name)``. This method
        bridges the two: a single indexed lookup in ``_dq_definitions``.

        Returns ``None`` when no check matches that key in the environment.
        After you have the identity, pass it to ``list_checks`` for run history
        or use it anywhere else the catalog expects ``check_identity``.

        Args:
            environment: Environment the check belongs to.
            model_name: Model the check is defined on.
            dimension: DQ dimension (e.g. completeness, validity).
            check_name: Check name as stored in the catalog.

        Returns:
            The ``check_identity`` string, or ``None`` if the check is unknown.
        """
        where = exp.and_(
            exp.EQ(
                this=exp.column("environment"),
                expression=exp.Literal.string(environment),
            ),
            exp.EQ(
                this=exp.column("model_name"),
                expression=exp.Literal.string(model_name),
            ),
            exp.EQ(
                this=exp.column("dimension"),
                expression=exp.Literal.string(dimension),
            ),
            exp.EQ(
                this=exp.column("check_name"),
                expression=exp.Literal.string(check_name),
            ),
        )
        query = (
            exp.select(exp.column("check_identity"))
            .from_(self.checks_definitions_table)
            .where(where)
            .limit(1)
        )
        with self.engine_adapter.transaction():
            row = fetchone(self.engine_adapter, query)
        return row[0] if row else None

    def list_checks(
        self,
        environment: str,
        check_identity: t.Optional[str] = None,
        model_names: t.Optional[t.List[str]] = None,
        column_name: t.Optional[str] = None,
        dimension: t.Optional[str] = None,
        runs_per_check: int = 10,
        limit: int = 100,
        offset: int = 0,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
    ) -> t.List[CheckRuns]:
        """
        List quality checks with their recent run outcomes.

        Checks are defined once in ``_dq_definitions`` and evaluated on
        every run. This method reads from that catalog and attaches recent
        results from ``_dq_results``— either across many checks or deep into
        one check's history, depending on how you call it.

        Without ``check_identity`` (catalog mode), you get a paginated list of
        distinct checks, each bundled with up to ``runs_per_check`` of its most
        recent executions. Filters narrow the catalog by model, column, or
        dimension; ``start_ts``/``end_ts`` bound which run results are
        considered. Checks that match the catalog filters but have no runs in
        the window come back with an empty ``runs`` list.

        With ``check_identity`` set (single-check mode), pagination applies to
        run history instead: you get at most one ``CheckRuns`` row with a page
        of that check's executions. The ``model_names`` filter is ignored here.

        Unlike ``list_runs``, the primary axis is the check, not the run. Use
        this when browsing the check catalog or drilling into one check over
        time.

        Args:
            environment: Environment name. Required.
            check_identity: When set, single-check mode: returns 0 or 1 check
                with paginated runs. When None, catalog mode.
            model_names: Filter by model names. Catalog mode only.
            column_name: Filter by column name.
            dimension: Filter by dimension (e.g. completeness, validity).
            runs_per_check: Max runs per check in catalog mode. Default 10.
            limit: Catalog mode: max checks to return. Single-check: max runs.
            offset: Pagination offset.
            start_ts: Include runs with start_ts >= this (Unix seconds).
            end_ts: Include runs with start_ts <= this (Unix seconds).

        Returns:
            List of ``CheckRuns``. Empty when ``environment`` is empty or
            nothing matches.

        Raises:
            VulcanError: If the state store is not PostgreSQL.
        """
        raise_if_not_postgres(self.engine_adapter, feature="list_checks")

        if not environment:
            return []

        defs_tbl = self.checks_definitions_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        results_tbl = self.check_results_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        start_ms = start_ts * 1000 if start_ts is not None else None
        end_ms = end_ts * 1000 if end_ts is not None else None

        def _row_to_check_run(row: t.Dict[str, t.Any]) -> CheckResultWithRunId:
            try:
                outcome = CheckOutcome(row.get("outcome") or "not_evaluated")
            except ValueError:
                outcome = CheckOutcome.NOT_EVALUATED
            return CheckResultWithRunId(
                check_identity=row["check_identity"],
                check_name=row["check_name"],
                check_type=row["check_type"],
                column_name=row["column_name"],
                dimension=row["dimension"],
                definition=row["definition"],
                model_name=row["model_name"],
                outcome=outcome,
                outcome_reasons=_parse_outcome_reasons(row.get("outcome_reasons")),
                diagnostics=(
                    _parse_diagnostics(row.get("diagnostics"))
                    if outcome != CheckOutcome.PASS
                    else {}
                ),
                run_id=row["run_id"],
                start_ts=row["start_ts"],
                end_ts=row["end_ts"],
            )

        # Parameterize for catalog vs single-check mode.
        # rn_min/rn_max: row-number range for jsonb_agg FILTER (which runs to include per check).
        # out_limit/out_offset: outer query pagination (checks or single-check row).
        if check_identity:
            rn_min, rn_max = offset, offset + limit  # Paginate runs for single check
            out_limit, out_offset = 1, 0  # At most one CheckRuns row
        else:
            rn_min, rn_max = 0, runs_per_check  # Last N runs per check
            out_limit, out_offset = limit, offset  # Paginate checks

        # Query: checks_from_def from _dq_definitions (no time filter); ranked from
        # _dq_results (with time filter); outer SELECT joins and aggregates runs.
        sql = f"""
        WITH checks_from_def AS (
            SELECT check_identity, check_name, check_type, column_name, dimension, definition, model_name
            FROM {defs_tbl}
            WHERE environment = %s
              AND (%s IS NULL OR check_identity = %s)
              AND (%s IS NULL OR model_name = ANY(%s))
              AND (%s IS NULL OR column_name = %s)
              AND (%s IS NULL OR dimension = %s)
            ORDER BY model_name NULLS LAST, column_name NULLS LAST, check_name
            LIMIT %s OFFSET %s
        ),
        ranked AS (
            SELECT cr.*,
                ROW_NUMBER() OVER (PARTITION BY cr.check_identity ORDER BY cr.start_ts DESC) AS rn
            FROM {results_tbl} cr
            WHERE cr.environment = %s
              AND cr.check_identity IN (SELECT check_identity FROM checks_from_def)
              AND (%s IS NULL OR cr.start_ts >= %s)
              AND (%s IS NULL OR cr.start_ts <= %s)
        )
        SELECT
            d.check_identity,
            d.check_name,
            d.check_type,
            d.column_name,
            d.dimension,
            d.definition,
            d.model_name,
            COALESCE(
                jsonb_agg(
                    jsonb_build_object(
                        'run_id', r.run_id,
                        'start_ts', r.start_ts,
                        'end_ts', r.end_ts,
                        'check_identity', d.check_identity,
                        'check_name', d.check_name,
                        'check_type', d.check_type,
                        'model_name', d.model_name,
                        'column_name', d.column_name,
                        'dimension', d.dimension,
                        'definition', d.definition,
                        'outcome', r.outcome,
                        'outcome_reasons', r.outcome_reasons,
                        'diagnostics', r.diagnostics
                    ) ORDER BY r.start_ts DESC
                ) FILTER (WHERE r.rn > %s AND r.rn <= %s),
                '[]'::jsonb
            ) AS runs_json
        FROM checks_from_def d
        LEFT JOIN ranked r ON r.check_identity = d.check_identity
        GROUP BY d.check_identity, d.check_name, d.check_type, d.column_name, d.dimension, d.definition, d.model_name
        ORDER BY d.model_name NULLS LAST, d.column_name NULLS LAST, d.check_name
        """
        # Placeholder order: env, check_identity (x2), model_names (x2), column_name (x2),
        # dimension (x2), out_limit, out_offset, env, start_ms (x2), end_ms (x2), rn_min, rn_max
        params = (
            environment,
            check_identity,
            check_identity,
            model_names,
            model_names,
            column_name,
            column_name,
            dimension,
            dimension,
            out_limit,
            out_offset,
            environment,
            start_ms,
            start_ms,
            end_ms,
            end_ms,
            rn_min,
            rn_max,
        )

        try:
            with self.engine_adapter.transaction():
                self.engine_adapter.cursor.execute(sql, params)
                rows = self.engine_adapter.cursor.fetchall()

            if not rows:
                return []

            result = []
            for row in rows:
                (
                    check_identity_val,
                    check_name,
                    check_type,
                    column_name_val,
                    dimension_val,
                    definition,
                    model_name,
                    runs_json,
                ) = row
                metadata = {
                    "check_identity": check_identity_val,
                    "check_name": check_name,
                    "check_type": check_type,
                    "column_name": column_name_val,
                    "dimension": dimension_val,
                    "definition": definition,
                    "model_name": model_name,
                }
                runs_list = json_to_list(runs_json)
                runs = [
                    _row_to_check_run({**r, **metadata})
                    for r in runs_list
                    if isinstance(r, dict)
                ]
                result.append(CheckRuns(**metadata, runs=runs))
            return result

        except Exception as e:
            logger.error(f"Failed to fetch checks: {e}", exc_info=True)
            return []

    def list_runs(
        self,
        run_id: t.Optional[str] = None,
        environment: t.Optional[str] = None,
        model_names: t.Optional[t.List[str]] = None,
        success: t.Optional[bool] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> t.List[RunActivityWithChecksAndProfile]:
        """
        List pipeline runs with quality checks and profile data attached.

        This is the run-first view of activity history: each row is one
        execution, newest first, with every check outcome and profile metric
        recorded during that run folded into the payload.

        Pass ``run_id`` to fetch a single run—other filters are ignored.
        Otherwise ``environment`` is required and you can narrow the list by
        model overlap, success/failure, and time range. ``limit``/``offset``
        paginate runs, not checks or models.

        When ``model_names`` is set, run selection still uses array overlap on
        ``models_affected``, but the attached quality and profile data are
        also trimmed to those models.

        Unlike ``list_latest_runs_by_model``, this returns a flat run list
        where each entry may cover many models. Use this when browsing
        execution history or opening one run in full detail.

        Args:
            run_id: When set, return only this run. Mutually exclusive with
                filters.
            environment: When ``run_id`` is None, filter runs by environment.
                Required.
            model_names: Filter runs that executed any of these models (array
                overlap).
            success: Filter by success (True) or failure (False).
            start_ts: Filter runs with start_ts >= this (Unix seconds).
            end_ts: Filter runs with start_ts <= this (Unix seconds).
            limit: Max runs to return. Default 20.
            offset: Pagination offset.

        Returns:
            List of ``RunActivityWithChecksAndProfile``, newest first. Empty
            when ``environment`` is None (and ``run_id`` not set) or nothing
            matches.

        Raises:
            VulcanError: If the state store is not PostgreSQL.
        """
        raise_if_not_postgres(self.engine_adapter, feature="list_runs")

        from vulcan.core.activity import (
            RunActivity,
            RunActivityWithChecksAndProfile,
        )

        runs_tbl = self.runs_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        checks_tbl = self.check_results_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        defs_tbl = self.checks_definitions_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        profiles_tbl = self.profiles_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )

        start_ms = start_ts * 1000 if start_ts else None
        end_ms = end_ts * 1000 if end_ts else None

        where_sql = ""
        limit_sql = ""
        params: t.List[t.Any] = []

        if run_id:
            # Single run by ID; other filters are ignored and pagination is unnecessary.
            where_sql = "run_id = %s"
            params.append(run_id)
        else:
            if environment is None:
                return []  # list mode requires an environment scope
            where_parts = ["environment = %s"]
            params.append(environment)
            if model_names:
                where_parts.append("models_affected && %s")  # overlap with requested models
                params.append(model_names)
            if success is not None:
                where_parts.append("success = %s")  # optional pass/fail filter
                params.append(success)
            if start_ms is not None:
                where_parts.append("start_ts >= %s")  # inclusive lower bound (ms)
                params.append(start_ms)
            if end_ms is not None:
                where_parts.append("start_ts <= %s")  # inclusive upper bound (ms)
                params.append(end_ms)
            where_sql = " AND ".join(where_parts)
            limit_sql = "LIMIT %s OFFSET %s"  # paginate the run list
            params.extend([limit, offset])

        qc_model_filter = " AND cd.model_name = ANY(%s)" if model_names else ""
        pm_model_filter = " AND model_name = ANY(%s)" if model_names else ""
        if model_names:
            params.extend([model_names, model_names])

        # CTE 1: runs – target runs with optional filters
        # CTE 2: quality_checks – check results for those runs (optionally filtered by model)
        # CTE 3: profile_metrics – profile metrics for those runs (optionally filtered by model)
        # Final SELECT: per-run JSON aggregates for quality and profile
        query = f"""
        WITH runs AS (
            SELECT
                run_data,
                run_seq,
                run_id,
                start_ts
            FROM {runs_tbl}
            WHERE {where_sql}
            ORDER BY start_ts DESC
            {limit_sql}
        ),
        quality_checks AS (
            SELECT
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cr.check_identity,
                cd.check_name,
                cd.check_type,
                cd.column_name,
                cr.outcome,
                cr.outcome_reasons,
                cr.diagnostics,
                cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM runs){qc_model_filter}
            ORDER BY
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cd.check_name
        ),
        profile_metrics AS (
            SELECT
                run_id,
                model_name,
                column_name,
                profile_type,
                value_text,
                value_number,
                value_json,
                value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM runs){pm_model_filter}
            ORDER BY
                run_id,
                model_name,
                column_name,
                profile_type
        )
        SELECT
            r.run_data,
            r.run_seq,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', qc.model_name,
                            'dimension', qc.dimension,
                            'check_identity', qc.check_identity,
                            'check_name', qc.check_name,
                            'check_type', qc.check_type,
                            'column_name', qc.column_name,
                            'outcome', qc.outcome,
                            'outcome_reasons', qc.outcome_reasons,
                            'diagnostics', qc.diagnostics,
                            'definition', qc.definition
                        )
                        ORDER BY
                            qc.model_name,
                            qc.dimension,
                            qc.check_name
                    ),
                    '[]'::jsonb
                )
                FROM quality_checks qc
                WHERE qc.run_id = r.run_id
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', pm.model_name,
                            'column_name', pm.column_name,
                            'profile_type', pm.profile_type,
                            'value_text', pm.value_text,
                            'value_number', pm.value_number,
                            'value_json', pm.value_json,
                            'value_type', pm.value_type
                        )
                        ORDER BY
                            pm.model_name,
                            pm.column_name,
                            pm.profile_type
                    ),
                    '[]'::jsonb
                )
                FROM profile_metrics pm
                WHERE pm.run_id = r.run_id
            ) AS profile_metrics
        FROM runs r
        ORDER BY r.start_ts DESC
        """

        with self.engine_adapter.transaction():
            self.engine_adapter.cursor.execute(query, params)
            rows = self.engine_adapter.cursor.fetchall()

        if not rows:
            return []

        runs: t.List["RunActivityWithChecksAndProfile"] = []
        for row in rows:
            run_data, seq, quality_raw, profile_raw = row

            quality_data = json_to_list(quality_raw)
            profile_data = json_to_list(profile_raw)

            run = RunActivity.model_validate(run_data).model_copy(
                update={"run_seq": seq}
            )

            if model_names:
                models_set = set(model_names)
                run = run.model_copy(
                    update={
                        "models_affected": [
                            m for m in run.models_affected if m.name in models_set
                        ]
                    }
                )

            quality = _build_quality_list(quality_data)
            profile = _build_profile_list(profile_data)

            runs.append(
                RunActivityWithChecksAndProfile(
                    **run.model_dump(exclude_none=True),
                    quality=quality,
                    profile=profile,
                )
            )

        return runs

    def list_latest_runs_by_model(
        self,
        environment: str,
        model_names: t.List[str],
    ) -> t.Dict[str, RunActivityWithChecksAndProfile]:
        """
        Return the latest run for each model in ``model_names``, with quality and
        profile data scoped to that model.

        Runs often touch multiple models, so run history is naturally organized
        by run. When you need "what happened the last time we ran model X?"
        across the whole catalog, ``list_runs`` is the wrong abstraction—you
        would paginate runs and trim quality/profile payloads yourself. This
        method does that in one shot: for each model it picks the run with the
        latest ``start_ts`` that listed the model in ``models_affected``, then
        attaches only that model's checks and profile rows from that run.

        The result is a dict keyed by model name. Different models may point
        at different ``run_id`` values. Models with no matching runs are
        omitted.

        Args:
            environment: Vulcan environment name.
            model_names: Models to resolve; typically the full project catalog.

        Returns:
            Map of ``model_name`` → ``RunActivityWithChecksAndProfile`` where
            ``models_affected``, ``quality``, and ``profile`` are trimmed to
            the requested model only.

        Raises:
            VulcanError: If the state store is not PostgreSQL.
        """
        raise_if_not_postgres(self.engine_adapter, feature="list_latest_runs_by_model")

        from vulcan.core.activity import (
            RunActivity,
            RunActivityWithChecksAndProfile,
        )

        if not environment or not model_names:
            return {}

        runs_tbl = self.runs_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        checks_tbl = self.check_results_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        defs_tbl = self.checks_definitions_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )
        profiles_tbl = self.profiles_table.sql(
            dialect=self.engine_adapter.dialect, identify=True
        )

        # CTE 1: expand runs.models_affected → per-model rows, then rank per model
        # CTE 2: latest per model
        # CTE 3/4: quality + profile rows for those run_ids (later filtered by model_name during aggregation)
        query = f"""
        WITH expanded AS (
            SELECT
                r.run_data,
                r.run_seq,
                r.run_id,
                r.start_ts,
                model_name,
                ROW_NUMBER() OVER (
                    PARTITION BY model_name
                    ORDER BY r.start_ts DESC
                ) AS rn
            FROM {runs_tbl} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = %s
              AND r.models_affected IS NOT NULL
              AND model_name = ANY(%s)
        ),
        latest AS (
            SELECT
                run_data,
                run_seq,
                run_id,
                model_name
            FROM expanded
            WHERE rn = 1
        ),
        quality_checks AS (
            SELECT
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cr.check_identity,
                cd.check_name,
                cd.check_type,
                cd.column_name,
                cr.outcome,
                cr.outcome_reasons,
                cr.diagnostics,
                cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM latest)
              AND cd.model_name = ANY(%s)
            ORDER BY
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cd.check_name
        ),
        profile_metrics AS (
            SELECT
                run_id,
                model_name,
                column_name,
                profile_type,
                value_text,
                value_number,
                value_json,
                value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM latest)
              AND model_name = ANY(%s)
            ORDER BY
                run_id,
                model_name,
                column_name,
                profile_type
        )
        SELECT
            l.model_name,
            l.run_data,
            l.run_seq,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', qc.model_name,
                            'dimension', qc.dimension,
                            'check_identity', qc.check_identity,
                            'check_name', qc.check_name,
                            'check_type', qc.check_type,
                            'column_name', qc.column_name,
                            'outcome', qc.outcome,
                            'outcome_reasons', qc.outcome_reasons,
                            'diagnostics', qc.diagnostics,
                            'definition', qc.definition
                        )
                        ORDER BY
                            qc.dimension,
                            qc.check_name
                    ),
                    '[]'::jsonb
                )
                FROM quality_checks qc
                WHERE qc.run_id = l.run_id
                  AND qc.model_name = l.model_name
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', pm.model_name,
                            'column_name', pm.column_name,
                            'profile_type', pm.profile_type,
                            'value_text', pm.value_text,
                            'value_number', pm.value_number,
                            'value_json', pm.value_json,
                            'value_type', pm.value_type
                        )
                        ORDER BY
                            pm.column_name,
                            pm.profile_type
                    ),
                    '[]'::jsonb
                )
                FROM profile_metrics pm
                WHERE pm.run_id = l.run_id
                  AND pm.model_name = l.model_name
            ) AS profile_metrics
        FROM latest l
        """

        params: t.List[t.Any] = [environment, model_names, model_names, model_names]

        with self.engine_adapter.transaction():
            self.engine_adapter.cursor.execute(query, params)
            rows = self.engine_adapter.cursor.fetchall()

        if not rows:
            return {}

        result: t.Dict[str, "RunActivityWithChecksAndProfile"] = {}
        for model_name, run_data, seq, quality_raw, profile_raw in rows:
            quality_data = json_to_list(quality_raw)
            profile_data = json_to_list(profile_raw)

            run = RunActivity.model_validate(run_data).model_copy(update={"run_seq": seq})
            run = run.model_copy(
                update={
                    "models_affected": [
                        m for m in (run.models_affected or []) if m.name == model_name
                    ]
                }
            )

            result[model_name] = RunActivityWithChecksAndProfile(
                **run.model_dump(exclude_none=True),
                quality=_build_quality_list(quality_data),
                profile=_build_profile_list(profile_data),
            )

        return result

    def get_quality_summary(
        self,
        environment: str,
        as_of_ts: t.Optional[int] = None,
    ) -> t.Optional[ProductQualitySummary]:
        """
        Roll up quality health for an environment.

        This is the product-level scorecard: for every check in the catalog,
        take its most recent outcome, then count pass/fail/warn/error/
        ``not_evaluated`` overall and broken out by dimension (completeness,
        validity, and so on). Each check may come from a different run.

        With ``as_of_ts`` set (Unix seconds), only results with
        ``start_ts <= as_of_ts`` are considered—the latest outcome per check
        as of that moment. Omit ``as_of_ts`` for the current unbounded
        summary.

        Unlike ``list_runs`` or ``list_checks``, you are not paging history.
        Unlike ``list_latest_runs_by_model``, the unit is the check, not the
        model.

        Args:
            environment: Environment to summarize.
            as_of_ts: Optional Unix timestamp in seconds. When set, summarize
                using each check's latest outcome at or before this time.

        Returns:
            ``ProductQualitySummary`` with overall ``summary``, per-dimension
            counts and pass rates, ``checks_count``, and
            ``latest_evaluated_at`` (milliseconds). ``as_of_ts`` is echoed
            when provided; otherwise ``None``. Returns ``None`` when the
            environment has no matching check results.

        Raises:
            VulcanError: If the state store is not PostgreSQL.
        """
        raise_if_not_postgres(self.engine_adapter, feature="get_quality_summary")

        check_results_table_str = str(self.check_results_table)
        checks_definitions_table_str = str(self.checks_definitions_table)
        as_of_ms = as_of_ts * 1000 if as_of_ts is not None else None

        # Query structure:
        # 1. latest_with_dimension: Definitions on left (~100s rows) joined to results.
        #    DISTINCT ON keeps the latest result per check (by start_ts DESC). Index lookup
        #    per check is cheaper than scanning millions of result rows.
        #    Optional as_of_ms filters cr.start_ts <= as_of_ms for point-in-time summaries.
        # 2. stats: Single aggregation via GROUPING SETS ((dimension), ()) produces both
        #    per-dimension counts and overall totals (dimension IS NULL row).
        # 3. Final SELECT: Extract totals from the NULL-dimension row, build dimensions
        #    JSON from the per-dimension rows.
        sql = """
        WITH latest_with_dimension AS (
            SELECT DISTINCT ON (cd.check_identity, cd.environment)
                cd.check_identity,
                cr.outcome,
                cr.end_ts,
                cd.dimension
            FROM {checks_definitions_table} cd
            INNER JOIN {check_results_table} cr
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cd.environment = %s
              AND (%s IS NULL OR cr.start_ts <= %s)
            ORDER BY
                cd.check_identity,
                cd.environment,
                cr.start_ts DESC
        ),
        stats AS (
            SELECT
                dimension,
                COUNT(*) FILTER (WHERE outcome = 'pass') AS pass_count,
                COUNT(*) FILTER (WHERE outcome = 'fail') AS fail_count,
                COUNT(*) FILTER (WHERE outcome = 'warn') AS warn_count,
                COUNT(*) FILTER (WHERE outcome = 'error') AS error_count,
                COUNT(*) FILTER (WHERE outcome = 'not_evaluated') AS not_evaluated_count,
                COUNT(*) AS total_count,
                MAX(end_ts) AS latest_evaluated_at,
                COUNT(*) AS checks_count
            FROM latest_with_dimension
            GROUP BY GROUPING SETS ((dimension), ())
        )
        SELECT
            COALESCE(
                MAX(s.latest_evaluated_at) FILTER (WHERE s.dimension IS NULL),
                0
            ) AS latest_evaluated_at,
            COALESCE(
                MAX(s.checks_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS checks_count,
            COALESCE(
                jsonb_object_agg(
                    s.dimension,
                    jsonb_build_object(
                        'pass', s.pass_count,
                        'fail', s.fail_count,
                        'warn', s.warn_count,
                        'error', s.error_count,
                        'not_evaluated', s.not_evaluated_count,
                        'total', s.total_count,
                        'pass_rate', ROUND(
                            s.pass_count::NUMERIC
                            / NULLIF(s.total_count, 0) * 100,
                            1
                        )
                    )
                ) FILTER (WHERE s.dimension IS NOT NULL),
                '{{}}'::jsonb
            ) AS dimensions,
            COALESCE(
                SUM(s.pass_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_pass,
            COALESCE(
                SUM(s.fail_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_fail,
            COALESCE(
                SUM(s.warn_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_warn,
            COALESCE(
                SUM(s.error_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_error,
            COALESCE(
                SUM(s.not_evaluated_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_not_evaluated,
            COALESCE(
                SUM(s.total_count) FILTER (WHERE s.dimension IS NULL),
                0
            )::int AS total_checks
        FROM stats s
        """.format(
            check_results_table=check_results_table_str,
            checks_definitions_table=checks_definitions_table_str,
        )

        params = (environment, as_of_ms, as_of_ms)

        try:
            with self.engine_adapter.transaction():
                self.engine_adapter.cursor.execute(sql, params)
                row = self.engine_adapter.cursor.fetchone()
        except Exception as e:
            logger.error(f"Failed to execute get_quality_summary query: {e}")
            logger.debug(f"SQL query: {sql}")
            logger.debug(f"Params: {params}")
            raise

        if not row:
            return None

        try:
            (
                latest_evaluated_at,
                checks_count,
                dimensions_json,
                total_pass,
                total_fail,
                total_warn,
                total_error,
                total_not_evaluated,
                total_checks,
            ) = row
        except (ValueError, TypeError) as e:
            logger.error(f"Failed to unpack get_quality_summary result: {e}")
            logger.debug(f"Row: {row}")
            raise

        if checks_count == 0:
            return None

        # Parse dimensions JSONB
        dimensions = {}
        dim_dict = json_to_dict(dimensions_json)
        if dim_dict:
            try:
                dimensions = {
                    dim: QualitySummary(**stats)
                    for dim, stats in dim_dict.items()
                }
            except (TypeError, ValueError) as e:
                logger.warning(f"Failed to parse dimensions for get_quality_summary: {e}")

        pass_rate = (
            round(float(total_pass) / total_checks * 100, 1)
            if total_checks and total_checks > 0
            else 0.0
        )

        summary = QualitySummary(
            pass_=total_pass or 0,
            fail=total_fail or 0,
            warn=total_warn or 0,
            error=total_error or 0,
            not_evaluated=total_not_evaluated or 0,
            total=total_checks or 0,
            pass_rate=pass_rate,
        )

        return ProductQualitySummary(
            environment=environment,
            as_of_ts=as_of_ts,
            latest_evaluated_at=latest_evaluated_at or 0,
            checks_count=checks_count or 0,
            dimensions=dimensions,
            summary=summary,
        )
