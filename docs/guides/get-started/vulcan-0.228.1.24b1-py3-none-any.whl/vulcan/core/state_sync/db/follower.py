from __future__ import annotations

import json
import time
import typing as t
from calendar import monthrange
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import pandas as pd
from sqlglot import exp

from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.follower import (
    Follower,
    FollowerAnalytics,
    FollowerAnalyticsPagination,
    FollowerAnalyticsPeriod,
    FollowerGranularity,
)
from vulcan.core.state_sync.db.utils import fetchall, fetchone, json_to_dict
from vulcan.utils.migration import index_text_type

MAX_ANALYTICS_LIMIT = 365


@dataclass(frozen=True)
class FollowerBucketSpec:
    """One analytics bucket anchored relative to the present."""

    bucket_index: int
    period_start: int
    period_end: int


# ---------------------------------------------------------------------------
# Analytics: bucket planning (pure, no I/O)
# ---------------------------------------------------------------------------


def _ts_from_utc(dt: datetime) -> int:
    return int(dt.timestamp())


def _floor_day(dt: datetime) -> datetime:
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def _floor_week(dt: datetime) -> datetime:
    floored_day = _floor_day(dt)
    return floored_day - timedelta(days=floored_day.weekday())


def _floor_month(dt: datetime) -> datetime:
    return dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def _add_months(dt: datetime, months: int) -> datetime:
    month_index = dt.month - 1 + months
    year = dt.year + month_index // 12
    month = month_index % 12 + 1
    day = min(dt.day, monthrange(year, month)[1])
    return dt.replace(year=year, month=month, day=day)


def _bucket_bounds_for_index(
    bucket_index: int,
    granularity: FollowerGranularity,
    now: datetime,
) -> tuple[datetime, datetime]:
    """
    Return ``(period_start, period_end)`` for bucket ``bucket_index``.

    Bucket ``0`` is the current partial period ending at ``now``. Older buckets
    use calendar-aligned UTC boundaries.
    """
    if bucket_index < 0:
        raise ValueError("bucket_index must be non-negative")

    if granularity == FollowerGranularity.DAY:
        if bucket_index == 0:
            return _floor_day(now), now
        today_midnight = _floor_day(now)
        period_end = today_midnight - timedelta(days=bucket_index - 1)
        return period_end - timedelta(days=1), period_end

    if granularity == FollowerGranularity.WEEK:
        if bucket_index == 0:
            return _floor_week(now), now
        current_week_start = _floor_week(now)
        period_end = current_week_start - timedelta(weeks=bucket_index - 1)
        return period_end - timedelta(weeks=1), period_end

    if bucket_index == 0:
        return _floor_month(now), now
    current_month_start = _floor_month(now)
    period_end = _add_months(current_month_start, -(bucket_index - 1))
    period_start = _add_months(current_month_start, -bucket_index)
    return period_start, period_end


def _validate_analytics_pagination(*, limit: int, offset: int) -> None:
    if limit < 1 or limit > MAX_ANALYTICS_LIMIT:
        raise ValueError(f"limit must be between 1 and {MAX_ANALYTICS_LIMIT}")
    if offset < 0:
        raise ValueError("offset must be non-negative")


def _build_analytics_bucket_specs(
    *,
    granularity: FollowerGranularity,
    offset: int,
    limit: int,
    now: t.Optional[datetime] = None,
) -> t.List[FollowerBucketSpec]:
    """
    Build bucket specs for ``offset .. offset + limit - 1``, newest index first.

    Args:
        granularity: Bucket size.
        offset: Buckets to skip counting back from the present.
        limit: Number of buckets to include.
        now: Anchor time in UTC; defaults to the current time.

    Returns:
        Bucket definitions ordered newest-first.
    """
    _validate_analytics_pagination(limit=limit, offset=offset)
    anchor = now or datetime.now(timezone.utc)
    specs: t.List[FollowerBucketSpec] = []
    for bucket_index in range(offset, offset + limit):
        period_start, period_end = _bucket_bounds_for_index(bucket_index, granularity, anchor)
        specs.append(
            FollowerBucketSpec(
                bucket_index=bucket_index,
                period_start=_ts_from_utc(period_start),
                period_end=_ts_from_utc(period_end),
            )
        )
    return specs


# ---------------------------------------------------------------------------
# Analytics: SQL helpers
# ---------------------------------------------------------------------------


def _analytics_active_at_period_end_condition() -> exp.Expression:
    """Match followers active at ``buckets.period_end``."""
    return exp.and_(
        exp.LTE(
            this=exp.column("followed_at", "f"),
            expression=exp.column("period_end", "b"),
        ),
        exp.or_(
            exp.column("active", "f").eq(exp.true()),
            exp.GT(
                this=exp.column("updated_at", "f"),
                expression=exp.column("period_end", "b"),
            ),
        ),
    )


def _analytics_buckets_subquery(bucket_specs: t.Sequence[FollowerBucketSpec]) -> exp.Subquery:
    return (
        exp.select(
            exp.column("bucket_index"),
            exp.column("period_start"),
            exp.column("period_end"),
        )
        .from_(
            exp.values(
                [
                    (spec.bucket_index, spec.period_start, spec.period_end)
                    for spec in bucket_specs
                ],
                alias="buckets",
                columns=["bucket_index", "period_start", "period_end"],
            )
        )
        .subquery("b")
    )


# ---------------------------------------------------------------------------
# FollowerState
# ---------------------------------------------------------------------------


class FollowerState:
    """Manages data product follower subscriptions in ``_followers``."""

    def __init__(
        self,
        engine_adapter: EngineAdapter,
        schema: t.Optional[str] = None,
    ) -> None:
        self.engine_adapter = engine_adapter
        self.schema = schema
        self.followers_table = exp.table_("_followers", db=schema)

        index_type = index_text_type(engine_adapter.dialect)
        self._followers_columns_to_types = {
            "user_id": exp.DataType.build(index_type),
            "active": exp.DataType.build("boolean"),
            "followed_at": exp.DataType.build("bigint"),
            "updated_at": exp.DataType.build("bigint"),
            "metadata": exp.DataType.build("jsonb"),
        }

    def follow(
        self,
        user_id: str,
        metadata: t.Optional[t.Dict[str, t.Any]] = None,
    ) -> Follower:
        """
        Follow this data product for ``user_id``.

        Args:
            user_id: Authenticated Heimdall user id.
            metadata: Optional JSON metadata stored on first follow or merged on re-follow.

        Returns:
            The follower row after the operation.
        """
        existing = self.get_follower(user_id)
        now_ts = int(time.time())

        if existing is None:
            payload_metadata = metadata or {}
            df = pd.DataFrame([
                {
                    "user_id": user_id,
                    "active": True,
                    "followed_at": now_ts,
                    "updated_at": now_ts,
                    "metadata": json.dumps(payload_metadata),
                }
            ])
            self.engine_adapter.insert_append(
                self.followers_table,
                df,
                target_columns_to_types=self._followers_columns_to_types,
                track_rows_processed=False,
            )
            return Follower(
                user_id=user_id,
                active=True,
                followed_at=now_ts,
                updated_at=now_ts,
                metadata=payload_metadata,
            )

        if existing.active:
            return existing

        merged_metadata = existing.metadata
        if metadata:
            merged_metadata = {**existing.metadata, **metadata}

        self._update_follower(
            user_id,
            active=True,
            updated_at=now_ts,
            metadata=merged_metadata,
        )
        return Follower(
            user_id=user_id,
            active=True,
            followed_at=existing.followed_at,
            updated_at=now_ts,
            metadata=merged_metadata,
        )

    def unfollow(self, user_id: str) -> Follower:
        """
        Unfollow this data product for ``user_id``.

        Args:
            user_id: Authenticated Heimdall user id.

        Returns:
            The follower row after the operation.

        Raises:
            ValueError: If the user has never followed this product.
        """
        existing = self.get_follower(user_id)
        if existing is None:
            raise ValueError(f"User {user_id!r} is not a follower")

        if not existing.active:
            return existing

        now_ts = int(time.time())
        self._update_follower(user_id, active=False, updated_at=now_ts)
        return Follower(
            user_id=user_id,
            active=False,
            followed_at=existing.followed_at,
            updated_at=now_ts,
            metadata=existing.metadata,
        )

    def get_follower(self, user_id: str) -> t.Optional[Follower]:
        """
        Return the follower row for ``user_id``, if any.

        Args:
            user_id: Heimdall user id.

        Returns:
            Follower row or ``None`` when the user has never followed.
        """
        query = (
            exp.select(
                exp.column("user_id"),
                exp.column("active"),
                exp.column("followed_at"),
                exp.column("updated_at"),
                exp.column("metadata"),
            )
            .from_(self.followers_table)
            .where(exp.column("user_id").eq(user_id))
        )
        row = fetchone(self.engine_adapter, query)
        if row is None:
            return None
        return self._row_to_follower(row)

    def list_followers(
        self,
        *,
        active_only: bool = True,
        limit: int = 50,
        offset: int = 0,
    ) -> t.Tuple[t.List[Follower], bool]:
        """
        List followers ordered by ``followed_at`` descending.

        Args:
            active_only: When ``True``, return only active followers.
            limit: Maximum rows to return.
            offset: Number of rows to skip.

        Returns:
            Tuple of follower rows and whether more rows exist beyond this page.
        """
        conditions: t.List[exp.Expression] = []
        if active_only:
            conditions.append(exp.column("active").eq(exp.true()))

        query = (
            exp.select(
                exp.column("user_id"),
                exp.column("active"),
                exp.column("followed_at"),
                exp.column("updated_at"),
                exp.column("metadata"),
            )
            .from_(self.followers_table)
            .where(exp.and_(*conditions) if conditions else None)
            .order_by(exp.Ordered(this=exp.column("followed_at"), desc=True))
            .limit(limit + 1)
            .offset(offset)
        )

        rows = fetchall(self.engine_adapter, query)
        has_more = len(rows) > limit
        if has_more:
            rows = rows[:limit]

        return [self._row_to_follower(row) for row in rows], has_more

    def get_follower_analytics(
        self,
        *,
        granularity: t.Optional[FollowerGranularity] = None,
        limit: int = 30,
        offset: int = 0,
    ) -> FollowerAnalytics:
        """
        Return active follower count and optional bucket-based analytics.

        When ``granularity`` is omitted, only ``total_active`` is returned.
        Otherwise buckets are numbered from the present backward and paginated
        with ``offset`` and ``limit``. Each bucket reports how many users were
        actively following at ``period_end``.

        Args:
            granularity: Bucket size for analytics.
            limit: Number of buckets to return.
            offset: Buckets to skip counting back from the present.

        Returns:
            Follower analytics payload.

        Raises:
            ValueError: For invalid pagination parameters.
        """
        total_active = self._count_current_active_followers()
        if granularity is None:
            return FollowerAnalytics(total_active=total_active)

        bucket_specs = _build_analytics_bucket_specs(
            granularity=granularity,
            offset=offset,
            limit=limit,
        )
        series = self._query_active_followers_by_buckets(bucket_specs)
        return self._build_analytics_response(
            total_active=total_active,
            granularity=granularity,
            offset=offset,
            limit=limit,
            series=series,
        )

    def _count_current_active_followers(self) -> int:
        query = (
            exp.select(exp.Count(this=exp.Star()).as_("count"))
            .from_(self.followers_table)
            .where(exp.column("active").eq(exp.true()))
        )
        row = fetchone(self.engine_adapter, query)
        return int(row[0]) if row else 0

    def _query_active_followers_by_buckets(
        self,
        bucket_specs: t.Sequence[FollowerBucketSpec],
    ) -> t.List[FollowerAnalyticsPeriod]:
        """
        Count active followers at each bucket's ``period_end`` in one SQL query.

        Args:
            bucket_specs: Bucket definitions ordered newest-first.

        Returns:
            Analytics periods ordered newest-first.
        """
        if not bucket_specs:
            return []

        buckets = _analytics_buckets_subquery(bucket_specs)
        followers = self.followers_table.as_("f")

        query = (
            exp.select(
                exp.column("bucket_index", "b"),
                exp.column("period_start", "b"),
                exp.column("period_end", "b"),
                exp.Count(this=exp.column("user_id", "f")).as_("active_followers"),
            )
            .from_(buckets)
            .join(followers, on=_analytics_active_at_period_end_condition(), join_type="left")
            .group_by(
                exp.column("bucket_index", "b"),
                exp.column("period_start", "b"),
                exp.column("period_end", "b"),
            )
            .order_by(exp.column("bucket_index", "b"))
        )

        rows = fetchall(self.engine_adapter, query)
        counts_by_index = {int(row[0]): int(row[3]) for row in rows}
        return [
            FollowerAnalyticsPeriod(
                period_start=spec.period_start,
                period_end=spec.period_end,
                active_followers=counts_by_index.get(spec.bucket_index, 0),
            )
            for spec in bucket_specs
        ]

    def _build_analytics_response(
        self,
        *,
        total_active: int,
        granularity: FollowerGranularity,
        offset: int,
        limit: int,
        series: t.List[FollowerAnalyticsPeriod],
    ) -> FollowerAnalytics:
        return FollowerAnalytics(
            total_active=total_active,
            granularity=granularity,
            offset=offset,
            limit=limit,
            series=series,
            pagination=FollowerAnalyticsPagination(
                offset=offset,
                limit=limit,
                # TODO(DPS-356): Compute has_more from a bounded history window or
                # detect when offset+limit exceeds the earliest follower row so
                # chart clients know when to stop paging older buckets.
                has_more=True,
            ),
        )

    def _update_follower(
        self,
        user_id: str,
        *,
        active: bool,
        updated_at: int,
        metadata: t.Optional[t.Dict[str, t.Any]] = None,
    ) -> None:
        values: t.Dict[str, t.Any] = {
            "active": active,
            "updated_at": updated_at,
        }
        if metadata is not None:
            values["metadata"] = json.dumps(metadata)

        update_stmt = exp.update(
            self.followers_table,
            values,
            where=exp.column("user_id").eq(user_id),
        )
        self.engine_adapter.execute(update_stmt)

    def _row_to_follower(self, row: t.Tuple) -> Follower:
        return Follower(
            user_id=row[0],
            active=bool(row[1]),
            followed_at=int(row[2]),
            updated_at=int(row[3]),
            metadata=json_to_dict(row[4]),
        )
