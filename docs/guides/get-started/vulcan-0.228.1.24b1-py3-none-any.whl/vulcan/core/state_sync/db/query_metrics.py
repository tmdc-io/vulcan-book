"""Query usage metrics aggregation over the statestore.

This module is intentionally statestore-specific (currently Postgres).
It lives in the state-sync / query layer so it can be reused and tested
independently of the API.
"""

from __future__ import annotations

import typing as t
from decimal import Decimal
from datetime import datetime, timedelta, timezone

import pandas as pd

from vulcan.core.engine_adapter import EngineAdapter

# Single-scan variant: three-week window for this week, prev week, and new_users_prev.
# Placeholders: {schema}, :week_start_ms, :week_end_ms, :prev_week_start_ms, :prev_prev_week_start_ms.
USAGE_METRICS_SQL = """
WITH base AS (
  SELECT
    COALESCE(submitted_by, 'anonymous') AS submitted_by,
    strategy,
    execution_start_ts,
    execution_end_ts,
    (submitted_ts >= :week_start_ms AND submitted_ts < :week_end_ms) AS is_this_week,
    (submitted_ts >= :prev_week_start_ms AND submitted_ts < :week_start_ms) AS is_prev_week,
    (submitted_ts >= :prev_prev_week_start_ms AND submitted_ts < :prev_week_start_ms) AS is_prev_prev_week
  FROM {schema}._query_requests
  WHERE submitted_ts >= :prev_prev_week_start_ms
    AND submitted_ts < :week_end_ms
),
user_flags AS (
  SELECT
    submitted_by,
    BOOL_OR(is_this_week) AS in_this_week,
    BOOL_OR(is_prev_week) AS in_prev_week,
    BOOL_OR(is_prev_prev_week) AS in_prev_prev_week
  FROM base
  GROUP BY submitted_by
),
agg AS (
  SELECT
    COUNT(*) FILTER (WHERE is_this_week) AS total_requests,
    COUNT(*) FILTER (WHERE is_this_week AND strategy = 'from_cache') AS cache_requests,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_this_week) AS active_users,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_this_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms,
    COUNT(*) FILTER (WHERE is_prev_week) AS total_requests_prev,
    COUNT(*) FILTER (WHERE is_prev_week AND strategy = 'from_cache') AS cache_requests_prev,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_prev_week) AS active_users_prev,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_prev_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms_prev
  FROM base
),
new_user_count AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_this_week AND NOT in_prev_week
),
new_user_count_prev AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_prev_week AND NOT in_prev_prev_week
),
curr AS (
  SELECT
    a.active_users,
    n.n AS new_users,
    (a.active_users - n.n) AS repeat_users,
    a.total_requests AS queries,
    a.median_ms AS median_query_time_ms,
    (a.cache_requests * 100.0 / NULLIF(a.total_requests, 0)) AS pct_savings
  FROM agg a
  CROSS JOIN new_user_count n
),
prev AS (
  SELECT
    a.active_users_prev,
    np.n AS new_users_prev,
    (a.active_users_prev - np.n) AS repeat_users_prev,
    a.total_requests_prev AS queries_prev,
    a.median_ms_prev AS median_query_time_ms_prev,
    (a.cache_requests_prev * 100.0 / NULLIF(a.total_requests_prev, 0)) AS pct_savings_prev
  FROM agg a
  CROSS JOIN new_user_count_prev np
)
SELECT
  c.active_users,
  c.new_users,
  c.repeat_users,
  c.queries,
  c.median_query_time_ms,
  c.pct_savings,
  ((c.active_users - COALESCE(p.active_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.active_users_prev, 0), 0)) AS active_users_wow_pct,
  ((c.new_users - COALESCE(p.new_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.new_users_prev, 0), 0)) AS new_users_wow_pct,
  ((c.repeat_users - COALESCE(p.repeat_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.repeat_users_prev, 0), 0)) AS repeat_users_wow_pct,
  ((c.queries - COALESCE(p.queries_prev, 0)) * 100.0 / NULLIF(COALESCE(p.queries_prev, 0), 0)) AS queries_wow_pct,
  ((c.median_query_time_ms - COALESCE(p.median_query_time_ms_prev, 0)) * 100.0 / NULLIF(COALESCE(p.median_query_time_ms_prev, 0), 0)) AS median_query_time_wow_pct,
  (c.pct_savings - COALESCE(p.pct_savings_prev, 0)) AS pct_savings_wow_pct
FROM curr c
CROSS JOIN prev p
"""


def week_bounds_ms(week_start: datetime | None = None) -> tuple[int, int, int, int]:
    """Compute week bounds in epoch milliseconds (UTC).

    Args:
        week_start: Monday 00:00:00 UTC of the week. If None, uses current week.

    Returns:
        (week_start_ms, week_end_ms, prev_week_start_ms, prev_prev_week_start_ms).
    """
    if week_start is None:
        now = datetime.now(timezone.utc)
        week_start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(
            days=now.weekday()
        )

    if week_start.tzinfo is None:
        week_start = week_start.replace(tzinfo=timezone.utc)
    else:
        week_start = week_start.astimezone(timezone.utc)

    week_start_ms = int(week_start.timestamp() * 1000)
    week_end_ms = int((week_start + timedelta(days=7)).timestamp() * 1000)
    prev_week_start_ms = week_start_ms - (7 * 24 * 60 * 60 * 1000)
    prev_prev_week_start_ms = prev_week_start_ms - (7 * 24 * 60 * 60 * 1000)
    return week_start_ms, week_end_ms, prev_week_start_ms, prev_prev_week_start_ms


def _json_safe_number(x: t.Any) -> int | float | None:
    # Covers None, NaN, NaT, pandas NA scalars, numpy scalars, etc.
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass

    if hasattr(x, "item"):
        try:
            x = x.item()
        except Exception:
            pass

    if isinstance(x, bool):
        return int(x)
    if isinstance(x, Decimal):
        return float(x)
    if isinstance(x, (int, float)):
        return x
    return None


def usage_metrics_defaults() -> dict[str, t.Any]:
    return {
        "active_users": 0,
        "active_users_wow_pct": None,
        "new_users": 0,
        "new_users_wow_pct": None,
        "repeat_users": 0,
        "repeat_users_wow_pct": None,
        "queries": 0,
        "queries_wow_pct": None,
        "median_query_time_ms": None,
        "median_query_time_wow_pct": None,
        "pct_savings": None,
        "pct_savings_wow_pct": None,
    }


def fetch_usage_metrics(
    engine_adapter: EngineAdapter,
    *,
    schema: str,
    week_start_ms: int,
    week_end_ms: int,
    prev_week_start_ms: int,
    prev_prev_week_start_ms: int,
) -> dict[str, t.Any]:
    """Run the usage metrics aggregation and return one JSON-safe dict."""
    sql = USAGE_METRICS_SQL.replace("{schema}", schema)
    params = {
        "week_start_ms": week_start_ms,
        "week_end_ms": week_end_ms,
        "prev_week_start_ms": prev_week_start_ms,
        "prev_prev_week_start_ms": prev_prev_week_start_ms,
    }

    df = engine_adapter.fetchdf_with_params(sql, params)  # type: ignore[attr-defined]
    if df is None or len(df) == 0:
        return usage_metrics_defaults()

    row = df.iloc[0].to_dict()

    def _int(key: str) -> int:
        v = _json_safe_number(row.get(key))
        return int(v or 0)

    def _num(key: str) -> int | float | None:
        return _json_safe_number(row.get(key))

    out: dict[str, t.Any] = {
        "active_users": _int("active_users"),
        "active_users_wow_pct": _num("active_users_wow_pct"),
        "new_users": _int("new_users"),
        "new_users_wow_pct": _num("new_users_wow_pct"),
        "repeat_users": _int("repeat_users"),
        "repeat_users_wow_pct": _num("repeat_users_wow_pct"),
        "queries": _int("queries"),
        "queries_wow_pct": _num("queries_wow_pct"),
        "median_query_time_ms": _num("median_query_time_ms"),
        "median_query_time_wow_pct": _num("median_query_time_wow_pct"),
        "pct_savings": _num("pct_savings"),
        "pct_savings_wow_pct": _num("pct_savings_wow_pct"),
    }
    return out

