from __future__ import annotations

import typing as t
import json
import logging
import uuid
from sqlglot import exp

import pandas as pd

from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import fetchall, fetchone, raise_if_not_postgres, is_postgres
from vulcan.utils.migration import index_text_type, blob_text_type
from vulcan.utils.date import now_timestamp, to_timestamp, TimeLike
from vulcan.utils import random_id
from datetime import datetime

from vulcan.core.activity import (
    PlanActivity,
    RunActivity,
    EnvironmentChange,
)

logger = logging.getLogger(__name__)


class ActivityState:
    """Manages plan diffs, run executions, and activity log."""

    def __init__(
        self,
        engine_adapter: EngineAdapter,
        schema: t.Optional[str] = None,
    ):
        self.engine_adapter = engine_adapter
        self.schema = schema

        # Table references
        self.plans_table = exp.table_("_plans", db=schema)
        self.runs_table = exp.table_("_runs", db=schema)
        self.query_fingerprints = exp.table_("_query_fingerprints", db=schema)

        index_type = index_text_type(engine_adapter.dialect)
        blob_type = blob_text_type(engine_adapter.dialect)

        # Plans column types
        self._plan_columns_to_types = {
            "plan_id": exp.DataType.build(index_type),
            "environment": exp.DataType.build(index_type),
            "start_ts": exp.DataType.build("bigint"),
            "end_ts": exp.DataType.build("bigint"),
            "created_ts_ns": exp.DataType.build("bigint"),
            "executor": exp.DataType.build("text"),
            "git_commit_sha": exp.DataType.build("text"),
            "prev_plan_id": exp.DataType.build("text"),
            "version": exp.DataType.build("text"),
            "models_affected_directly": exp.DataType.build("ARRAY<TEXT>"),
            "models_affected_indirectly": exp.DataType.build("ARRAY<TEXT>"),
            "plan_diff": exp.DataType.build("jsonb"),
            "has_changes": exp.DataType.build("boolean"),
            "has_backfills": exp.DataType.build("boolean"),
            "success": exp.DataType.build("boolean"),
            "plan_seq": exp.DataType.build("bigint"),
        }

        # Runs column types
        self._run_columns_to_types = {
            "run_id": exp.DataType.build(index_type),
            "plan_id": exp.DataType.build(index_type),
            "environment": exp.DataType.build(index_type),
            "start_ts": exp.DataType.build("bigint"),
            "end_ts": exp.DataType.build("bigint"),
            "created_ts_ns": exp.DataType.build("bigint"),
            "executor": exp.DataType.build("text"),
            "success": exp.DataType.build("boolean"),
            "models_affected": exp.DataType.build("ARRAY<TEXT>"),
            "rows_affected": exp.DataType.build("bigint"),
            "bytes_processed": exp.DataType.build("bigint"),
            "total_evaluation_ms": exp.DataType.build("bigint"),
            "run_data": exp.DataType.build("jsonb"),
            "run_seq": exp.DataType.build("bigint"),
        }

        # Activity log column types
        self._activity_log_columns_to_types = {
            "id": exp.DataType.build("text"),
            "environment": exp.DataType.build(index_type),
            "model_name": exp.DataType.build(index_type, nullable=True),
            "event_type": exp.DataType.build(index_type),
            "event_ts": exp.DataType.build("bigint"),  # Nanoseconds
            "event_data": exp.DataType.build("text"),
        }

    def store_plan_activity(self, plan_activity: PlanActivity) -> None:
        """Store a plan activity."""
        import pandas as pd
        import time

        updated_ts_ns = time.time_ns()

        with self.engine_adapter.transaction():
            # Delete existing record if present
            # TODO If exists, why delete? why not raise an error?
            self.engine_adapter.delete_from(
                self.plans_table,
                where=exp.EQ(
                    this=exp.column("plan_id"),
                    expression=exp.Literal.string(plan_activity.plan_id),
                ),
            )

            # Compute next plan_seq for this environment (sequential per env)
            next_seq_result = fetchone(
                self.engine_adapter,
                exp.select(
                    exp.func("COALESCE", exp.func("MAX", exp.column("plan_seq")), 0).as_(
                        "max_seq"
                    )
                )
                .from_(self.plans_table)
                .where(
                    exp.EQ(
                        this=exp.column("environment"),
                        expression=exp.Literal.string(plan_activity.environment),
                    )
                ),
            )
            plan_seq = (next_seq_result[0] or 0) + 1 if next_seq_result else 1

            # Serialize plan activity to JSONB
            # Pydantic handles nested object serialization automatically
            diff_json = plan_activity.json()

            # Use properties from PlanActivity
            # Convert empty lists to None
            # for PostgreSQL compatibility (can't infer type of empty array)
            models_directly = None
            models_indirectly = None

            if plan_activity.models_affected_directly:
                models_directly = plan_activity.models_affected_directly
            if plan_activity.models_affected_indirectly:
                models_indirectly = plan_activity.models_affected_indirectly

            # Prepare row
            df = pd.DataFrame([
                {
                        "plan_id": plan_activity.plan_id,
                        "environment": plan_activity.environment,
                        "start_ts": int(plan_activity.start_ts),
                        "end_ts": int(plan_activity.end_ts),
                        "created_ts_ns": updated_ts_ns,
                        "executor": plan_activity.executor,
                        "git_commit_sha": plan_activity.git_commit_sha,
                        "prev_plan_id": plan_activity.prev_plan_id,
                        "version": plan_activity.version,
                        "models_affected_directly": models_directly,
                        "models_affected_indirectly": models_indirectly,
                        "plan_diff": diff_json,
                        "has_changes": plan_activity.has_changes,
                        "has_backfills": bool(plan_activity.backfills),
                        "success": plan_activity.success,
                        "plan_seq": plan_seq,
                }
            ])

            self.engine_adapter.insert_append(
                self.plans_table,
                df,
                target_columns_to_types=self._plan_columns_to_types,
                track_rows_processed=False,
            )

    def store_run_activity(self, run_activity: RunActivity) -> str:
        import pandas as pd
        import time
        import os

        run_id = run_activity.run_id
        executor = os.environ.get("VULCAN_USER", os.environ.get("USER", "unknown"))
        updated_ts_ns = time.time_ns()

        with self.engine_adapter.transaction():
            # Delete existing record if present (for idempotency)
            # TODO If exists, why delete? why not raise an error?
            self.engine_adapter.delete_from(
                self.runs_table,
                where=exp.EQ(
                    this=exp.column("run_id"),
                    expression=exp.Literal.string(run_id),
                ),
            )

            # Compute next run_seq for this environment (sequential per env)
            next_seq_result = fetchone(
                self.engine_adapter,
                exp.select(
                    exp.func("COALESCE", exp.func("MAX", exp.column("run_seq")), 0).as_(
                        "max_seq"
                    )
                )
                .from_(self.runs_table)
                .where(
                    exp.EQ(
                        this=exp.column("environment"),
                        expression=exp.Literal.string(run_activity.environment),
                    )
                ),
            )
            run_seq = (next_seq_result[0] or 0) + 1 if next_seq_result else 1

            execution_json = run_activity.model_dump_json()
            df = pd.DataFrame([
                {
                    "run_id": run_id,
                    "plan_id": run_activity.plan_id,
                    "environment": run_activity.environment,
                    "start_ts": int(run_activity.start_ts),      # Already milliseconds
                    "end_ts": int(run_activity.end_ts),          # Already milliseconds
                    "created_ts_ns": updated_ts_ns,               # Insertion timestamp
                    "executor": executor,
                    "success": run_activity.success,
                    "models_affected": [m.name for m in run_activity.models_affected] if run_activity.models_affected else None,  # Extract model names, None for empty list
                    "rows_affected": run_activity.rows_affected,         # Use property
                    "bytes_processed": run_activity.bytes_processed,     # Use property
                    "total_evaluation_ms": run_activity.total_evaluation_ms, # Use property
                    "run_data": execution_json,
                    "run_seq": run_seq,
                }
            ])

            self.engine_adapter.insert_append(
                self.runs_table,
                df,
                target_columns_to_types=self._run_columns_to_types,
                track_rows_processed=False,
            )

            # After successful storage, expire query results for affected models (within transaction)
            if run_activity.models_affected and is_postgres(self.engine_adapter):
                model_names = [m.name for m in run_activity.models_affected]
                self._expire_query_fingerprints_by_models(
                    model_names=model_names,
                    run_id=run_id,
                )

        return run_id

    def list_plans(
        self,
        plan_id: t.Optional[str] = None,
        environment: t.Optional[str] = None,
        plan_seq: t.Optional[int] = None,
        model_names: t.Optional[t.List[str]] = None,
        success: t.Optional[bool] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> t.List[PlanActivity]:
        """List plan activities. Single plan when plan_id set, else filtered list.

        Either plan_id (single plan) or environment (filtered list) must be provided.
        When plan_id is set, other filters are ignored.

        Args:
            plan_id: When set, return only this plan. Mutually exclusive with filters.
            environment: When plan_id is None, filter plans by environment. Required.
            plan_seq: Filter plans by sequence within the environment. Ignored when plan_id is set.
            model_names: Filter plans where models_affected_directly overlaps (array &&).
            success: Filter by success (True) or failure (False).
            start_ts: Filter plans with start_ts >= this (Unix seconds).
            end_ts: Filter plans with start_ts <= this (Unix seconds).
            limit: Max plans to return. Default 20.
            offset: Pagination offset.

        Returns:
            List of PlanActivity, newest first. Empty when environment is None
            (and plan_id not set) or no matches.
        """
        start_ms = start_ts * 1000 if start_ts is not None else None
        end_ms = end_ts * 1000 if end_ts is not None else None

        order = exp.Ordered(this=exp.column("start_ts"), desc=True)

        if plan_id:
            where = exp.EQ(
                this=exp.column("plan_id"),
                expression=exp.Literal.string(plan_id),
            )
            query = (
                exp.select(exp.column("plan_diff"), exp.column("plan_seq"))
                .from_(self.plans_table)
                .where(where)
                .order_by(order)
            )
        else:
            if environment is None:
                return []
            conditions: t.List[exp.Expression] = [
                exp.EQ(
                    this=exp.column("environment"),
                    expression=exp.Literal.string(environment),
                )
            ]
            if plan_seq is not None:
                conditions.append(
                    exp.EQ(
                        this=exp.column("plan_seq"),
                        expression=exp.Literal.number(plan_seq),
                    )
                )
            if model_names:
                conditions.append(
                    exp.ArrayOverlaps(
                        this=exp.column("models_affected_directly"),
                        expression=exp.Array(
                            expressions=[exp.Literal.string(m) for m in model_names]
                        ),
                    )
                )
            if success is not None:
                conditions.append(
                    exp.column("success").eq(exp.true() if success else exp.false())
                )
            if start_ms is not None:
                conditions.append(
                    exp.GTE(
                        this=exp.column("start_ts"),
                        expression=exp.Literal.number(start_ms),
                    )
                )
            if end_ms is not None:
                conditions.append(
                    exp.LTE(
                        this=exp.column("start_ts"),
                        expression=exp.Literal.number(end_ms),
                    )
                )
            where = exp.and_(*conditions)
            query = (
                exp.select(exp.column("plan_diff"), exp.column("plan_seq"))
                .from_(self.plans_table)
                .where(where)
                .order_by(order)
                .limit(limit)
                .offset(offset)
            )

        with self.engine_adapter.transaction():
            results = fetchall(self.engine_adapter, query)

        plans = []
        for plan_diff_json, plan_seq in results or []:
            if not plan_diff_json:
                continue
            if isinstance(plan_diff_json, str):
                plan_activity = PlanActivity.parse_raw(plan_diff_json)
            else:
                plan_activity = PlanActivity.model_validate(plan_diff_json)
            plans.append(plan_activity.model_copy(update={"plan_seq": plan_seq}))
        return plans

    def get_last_successful_run_end_ts_by_model(
        self,
        environment: str,
    ) -> t.Dict[str, int]:
        """
        Resolve each model's latest successful run completion time for one environment.

        Lets the API compare cached query metadata to when each model last finished in a
        successful run. For every model name in models_affected, returns the maximum end_ts in
        milliseconds. Uses PostgreSQL-specific SQL (lateral unnest of the array column and %s
        parameters) and requires a PostgreSQL state store. Yields an empty map when nothing matches.
        """
        raise_if_not_postgres(
            self.engine_adapter,
            feature="get_last_successful_run_end_ts_by_model",
        )

        runs_table_str = self.runs_table.sql(
            dialect=self.engine_adapter.dialect,
            identify=True,
        )

        sql = f"""
            SELECT 
                model_name,
                MAX(end_ts) AS ts
            FROM {runs_table_str} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = %s
                AND r.success = true
                AND r.models_affected IS NOT NULL
            GROUP BY model_name
        """

        with self.engine_adapter.transaction():
            cursor = self.engine_adapter.cursor
            cursor.execute(sql, (environment,))
            rows = cursor.fetchall()

        if not rows:
            return {}

        df = pd.DataFrame(rows, columns=["model_name", "ts"])
        return dict(zip(df["model_name"], df["ts"]))

    def fetch_plan_run_activity_since(self, since_ts_ns: int = 0) -> t.Tuple[t.List[EnvironmentChange], int]:
        """
        Surface new plan and run activity after a nanosecond watermark for background tasks.

        Unions _plans and _runs rows with created_ts_ns strictly after the watermark, groups by
        environment, and sets has_plan and has_run on each EnvironmentChange. Returns those
        changes plus the largest created_ts_ns seen so callers can advance their cursor; if
        nothing matched, returns an empty list and the same watermark. Built with SQLGlot and
        requires PostgreSQL state for consistency with the query API.
        """
        raise_if_not_postgres(
            self.engine_adapter,
            feature="fetch_plan_run_activity_since",
        )

        # _plans rows newer than the watermark
        plans_query = (
            exp.select("environment", exp.Literal.string("plan").as_("action_type"), "created_ts_ns")
            .from_(self.plans_table)
            .where(exp.GT(this=exp.column("created_ts_ns"), expression=exp.Literal.number(since_ts_ns)))
        )

        # _runs rows newer than the watermark
        runs_query = (
            exp.select("environment", exp.Literal.string("run").as_("action_type"), "created_ts_ns")
            .from_(self.runs_table)
            .where(exp.GT(this=exp.column("created_ts_ns"), expression=exp.Literal.number(since_ts_ns)))
        )

        combined_query = exp.union(plans_query, runs_query, distinct=False)
        combined_query = combined_query.order_by(
            exp.Ordered(this=exp.column("created_ts_ns"), desc=True)
        )

        results = fetchall(self.engine_adapter, combined_query)

        if not results:
            return [], since_ts_ns

        changes_dict: t.Dict[str, EnvironmentChange] = {}
        max_overall_ts_ns = since_ts_ns

        for env_name, action_type, created_ts_ns in results:
            change = changes_dict.setdefault(env_name, EnvironmentChange(environment=env_name))
            setattr(change, f'has_{action_type}', True)
            max_overall_ts_ns = max(max_overall_ts_ns, created_ts_ns)

        return list(changes_dict.values()), max_overall_ts_ns

    def _expire_query_fingerprints_by_models(
        self,
        model_names: t.Union[str, t.List[str]],
        run_id: str,
    ) -> None:
        """
        Invalidate cached query fingerprint rows after a run touches their dependency models.

        Invoked from run storage so the query API does not keep serving fingerprints whose
        depends_on lists overlap models that just executed. Targets still-valid rows not yet
        tied to another run, stamps expiry and invalidation metadata with this run_id, and logs
        affected row count when the driver reports it. Requires a PostgreSQL state store.
        """
        raise_if_not_postgres(
            self.engine_adapter,
            feature="_expire_query_fingerprints_by_models",
        )

        if isinstance(model_names, str):
            model_names = [model_names]

        if not model_names:
            return

        run_info = f" (run_id={run_id})" if run_id else ""
        logger.info(
            f"Expiring query fingerprint entries for {len(model_names)} model(s): "
            f"{model_names}{run_info}"
        )

        now_ts = to_timestamp(datetime.utcnow())

        where_clause = exp.and_(
            # depends_on overlaps model_names (unnest + IN); SQLGlot-friendly vs raw &&
            exp.Exists(
                this=exp.select(exp.Literal.number(1))
                .from_(
                    exp.Unnest(
                        expressions=[exp.column("depends_on")],
                        alias=exp.TableAlias(this=exp.to_identifier("_model")),
                    )
                )
                .where(
                    exp.column("_model").isin(*[exp.Literal.string(m) for m in model_names])
                )
            ),
            # Row still valid (unexpired or future expiry)
            exp.or_(
                exp.column("expires_ts").is_(exp.null()),
                exp.column("expires_ts") > now_ts,
            ),
            exp.column("invalidated_by_run_id").is_(exp.null())
        )

        update_props = {
            "expires_ts": now_ts,
            "invalidated_ts": now_ts,
            "invalidated_by_run_id": run_id,
        }

        self.engine_adapter.execute(
            exp.update(
                self.query_fingerprints,
                update_props,
                where=where_clause,
            )
        )

        # PEP 249: rowcount may be unknown on some drivers
        rowcount = getattr(self.engine_adapter.cursor, "rowcount", None)
        if rowcount is not None and rowcount >= 0:
            logger.info(f"Expired {rowcount} query fingerprint entries {run_info}")
            return

        logger.info(
            f"Expired query fingerprint entries (row count not reported by {self.engine_adapter.dialect} driver){run_info}"
        )

