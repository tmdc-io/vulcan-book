from __future__ import annotations

import json
import logging
import time
import typing as t
import uuid

import pandas as pd
from sqlglot import exp

from vulcan.core import constants as c
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.notification import Notification, NotificationEvent, NotificationStatus
from vulcan.core.state_sync.db.utils import fetchall
from vulcan.utils.migration import index_text_type

logger = logging.getLogger(__name__)

_NS_PER_SECOND = 1_000_000_000


def _col_eq(column: str, value: str) -> exp.EQ:
    return exp.EQ(this=exp.column(column), expression=exp.Literal.string(value))


class NotificationState:
    """Manages persisted notification events in ``_notifications``."""

    def __init__(
        self,
        engine_adapter: EngineAdapter,
        schema: t.Optional[str] = None,
    ) -> None:
        self.engine_adapter = engine_adapter
        self.schema = schema
        self.notifications_table = exp.table_("_notifications", db=schema)

        index_type = index_text_type(engine_adapter.dialect)
        self._notification_columns_to_types = {
            "id": exp.DataType.build(index_type),
            "created_ts_ns": exp.DataType.build("bigint"),
            "event": exp.DataType.build(index_type),
            "status": exp.DataType.build("text"),
            "environment": exp.DataType.build(index_type, nullable=True),
            "run_id": exp.DataType.build(index_type, nullable=True),
            "plan_id": exp.DataType.build(index_type, nullable=True),
            "username": exp.DataType.build("text", nullable=True),
            "summary": exp.DataType.build("text"),
            "payload": exp.DataType.build("jsonb"),
        }

    def store_notification(
        self,
        *,
        event: NotificationEvent,
        status: NotificationStatus,
        summary: str,
        payload: t.Dict[str, t.Any],
        environment: t.Optional[str] = None,
        run_id: t.Optional[str] = None,
        plan_id: t.Optional[str] = None,
        username: t.Optional[str] = None,
    ) -> str:
        """Insert one notification row.

        Args:
            event: Notification event.
            status: Notification status.
            summary: Short text summary for list views.
            payload: Structured event payload.
            environment: Target environment when applicable.
            run_id: Associated run identifier when applicable.
            plan_id: Associated plan identifier when applicable.
            username: User recipient for per-user deliveries.

        Returns:
            The generated notification id.
        """
        notification_id = str(uuid.uuid4())
        created_ts_ns = time.time_ns()

        df = pd.DataFrame([
            {
                "id": notification_id,
                "created_ts_ns": created_ts_ns,
                "event": event.value,
                "status": status.value,
                "environment": environment,
                "run_id": run_id,
                "plan_id": plan_id,
                "username": username,
                "summary": summary,
                "payload": json.dumps(payload),
            }
        ])

        self.engine_adapter.insert_append(
            self.notifications_table,
            df,
            target_columns_to_types=self._notification_columns_to_types,
            track_rows_processed=False,
        )
        return notification_id

    def list_notifications(
        self,
        *,
        environment: t.Optional[str] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        run_id: t.Optional[str] = None,
        plan_id: t.Optional[str] = None,
        events: t.Optional[t.Sequence[NotificationEvent]] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> t.Tuple[t.List[Notification], bool]:
        """List notifications newest first with optional filters and offset pagination.

        Args:
            environment: Filter by environment. Defaults to ``c.PROD`` on the
                environment feed path. When ``run_id`` or ``plan_id`` is set, only
                applied when explicitly provided.
            start_ts: Include rows with ``created_ts_ns`` at or after this Unix
                timestamp (seconds).
            end_ts: Include rows with ``created_ts_ns`` at or before this Unix
                timestamp (seconds).
            run_id: Filter by run id (uses ``run_id`` index when set).
            plan_id: Filter by plan id (uses ``plan_id`` index when set and
                ``run_id`` is not).
            events: Filter by one or more event names (rare; applied after the
                index-leading predicate).
            limit: Maximum rows to return.
            offset: Number of rows to skip.

        Returns:
            Tuple of matching notifications ordered newest first and whether more
            rows exist beyond this page.
        """
        start_ns = start_ts * _NS_PER_SECOND if start_ts is not None else None
        end_ns = end_ts * _NS_PER_SECOND if end_ts is not None else None

        conditions: t.List[exp.Expression] = []

        # Index-leading predicate: run_id wins over plan_id when both are set;
        # else plan_id; else prod environment feed.
        if run_id is not None:
            conditions.append(_col_eq("run_id", run_id))
        elif plan_id is not None:
            conditions.append(_col_eq("plan_id", plan_id))
        else:
            conditions.append(_col_eq("environment", environment or c.PROD))

        # Time bounds on created_ts_ns (start_ts/end_ts are Unix seconds).
        if start_ns is not None:
            conditions.append(
                exp.GTE(
                    this=exp.column("created_ts_ns"),
                    expression=exp.Literal.number(start_ns),
                )
            )
        if end_ns is not None:
            conditions.append(
                exp.LTE(
                    this=exp.column("created_ts_ns"),
                    expression=exp.Literal.number(end_ns),
                )
            )

        # Optional environment filter when anchor is run_id/plan_id (rare).
        if environment is not None and (run_id is not None or plan_id is not None):
            conditions.append(_col_eq("environment", environment))

        # Event type filter (rare); applied after the index-leading predicate.
        if events:
            conditions.append(
                exp.column("event").isin(*[
                    exp.Literal.string(event.value) for event in events
                ])
            )

        query = (
            exp.select(
                exp.column("id"),
                exp.column("created_ts_ns"),
                exp.column("event"),
                exp.column("status"),
                exp.column("summary"),
                exp.column("payload"),
                exp.column("environment"),
                exp.column("run_id"),
                exp.column("plan_id"),
            )
            .from_(self.notifications_table)
            .where(exp.and_(*conditions))
            .order_by(exp.Ordered(this=exp.column("created_ts_ns"), desc=True))
            .limit(limit + 1)
            .offset(offset)
        )

        rows = fetchall(self.engine_adapter, query)
        has_more = len(rows) > limit
        if has_more:
            rows = rows[:limit]

        notifications: t.List[Notification] = []
        for row in rows:
            payload_raw = row[5]
            if isinstance(payload_raw, str):
                payload = json.loads(payload_raw)
            elif payload_raw is None:
                payload = {}
            else:
                payload = t.cast(t.Dict[str, t.Any], payload_raw)

            notifications.append(
                Notification(
                    id=row[0],
                    created_ts=int(row[1]) // _NS_PER_SECOND,
                    event=row[2],
                    status=row[3],
                    summary=row[4],
                    payload=payload,
                    environment=row[6],
                    run_id=row[7],
                    plan_id=row[8],
                )
            )
        return notifications, has_more
