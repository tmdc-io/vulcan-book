"""Query service state management for caching and execution tracking."""

from __future__ import annotations

import json
import logging
import typing as t
from datetime import datetime, timedelta, timezone

from sqlglot import exp

from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import raise_if_not_postgres
from vulcan.utils.migration import index_text_type, blob_text_type
from vulcan.utils.date import to_timestamp
from vulcan.utils import random_id

# Import Pydantic models and query types
from vulcan.core.query.definitions import (
    QueryResult,
    QueryFingerprintResult,
    QueryRequest,
    QueryStatus,
    QueryStatusEnum,
    Perspective,
)

logger = logging.getLogger(__name__)


class QueryState:
    """Manages database operations for query execution, fingerprinting, and perspectives.

    This class implements a three-tier query execution strategy system:

    1. **from_cache**: Cache hit - result already exists, return immediately
       - Creates request record with strategy='from_cache'
       - Links to existing result via result_id
       - Extracts primary_request_id from original request for lineage tracking
       - Sets execution timestamps from original request

    2. **await_primary**: Deduplication - another identical query is in-flight
       - Creates request record with strategy='await_primary'
       - Links to primary request via primary_request_id
       - Automatically updated when primary completes (SUCCESS/FAILED/CANCELLED)
       - Shares result_id and execution timestamps with primary

    3. **execute**: New execution - query must be executed
       - Creates request record with strategy='execute'
       - Queued for background processing
       - Executed by worker, result stored in object store
       - On completion, updates awaiting secondary requests automatically

    Key Design Decisions:
    - All requests tracked in _query_requests for complete auditability
    - Terminal status changes (SUCCESS/FAILED/CANCELLED) automatically propagate to awaiting requests
    - Fingerprint-based caching with model dependency tracking for invalidation
    - Perspectives track request_id (mutable, latest result) and denormalized query definition fields
    """

    def __init__(
        self,
        engine_adapter: EngineAdapter,
        schema: t.Optional[str] = None,
    ):
        self.engine_adapter = engine_adapter
        self.schema = schema

        # Determine portable types based on dialect
        index_type = index_text_type(engine_adapter.dialect)

        # Table references
        self.results_table = exp.table_("_query_results", db=schema)
        self.fingerprints_table = exp.table_("_query_fingerprints", db=schema)
        self.requests_table = exp.table_("_query_requests", db=schema)
        self.perspectives_table = exp.table_("_query_perspective", db=schema)
        # Note: Named "requests" not "statements" because it tracks the full execution
        # lifecycle (status, timing, result) not just the SQL text. API uses "statement"
        # as the user-facing term while internal code tracks the execution "request".

        # Column types for _query_results
        self._results_columns_to_types = {
            "result_id": exp.DataType.build(index_type),
            "object_store_path": exp.DataType.build("text"),
            "row_count": exp.DataType.build("bigint"),
            "size_bytes": exp.DataType.build("bigint"),
            "columns": exp.DataType.build("jsonb"),
            "sql": exp.DataType.build("text"),
            "references": exp.DataType.build("jsonb"),
            "created_ts": exp.DataType.build("bigint"),
        }

        # Column types for _query_fingerprints
        self._fingerprints_columns_to_types = {
            "fingerprint": exp.DataType.build(index_type),
            "result_id": exp.DataType.build(index_type),
            "depends_on": exp.DataType.build("text[]"),  # PostgreSQL array type
            "created_ts": exp.DataType.build("bigint"),
            "expires_ts": exp.DataType.build("bigint"),
            "invalidated_by_run_id": exp.DataType.build(
                index_type
            ),  # Run ID that invalidated this fingerprint entry
            "invalidated_ts": exp.DataType.build("bigint"),  # Timestamp when invalidation occurred
        }

        # Column types for _query_requests
        self._requests_columns_to_types = {
            "request_id": exp.DataType.build(index_type),
            "strategy": exp.DataType.build("text"),
            "execution_status": exp.DataType.build("text"),
            "primary_request_id": exp.DataType.build(index_type),
            "fingerprint": exp.DataType.build(index_type),
            "sql_query": exp.DataType.build("text"),
            "normalized_sql": exp.DataType.build("text"),
            "params": exp.DataType.build("jsonb"),
            "depends_on": exp.DataType.build("text[]"),
            "gateway": exp.DataType.build(index_type),
            "submitted_by": exp.DataType.build("text"),
            "submitted_ts": exp.DataType.build("bigint"),
            "ttl": exp.DataType.build("int"),
            "meta": exp.DataType.build("jsonb"),
            "query_type": exp.DataType.build("text"),
            "semantic_query": exp.DataType.build("text"),
            "rest_query": exp.DataType.build("jsonb"),
            "graphql_query": exp.DataType.build("text"),
            "perspective_id": exp.DataType.build(index_type),
            "pgq_job_id": exp.DataType.build("bigint"),
            "execution_start_ts": exp.DataType.build("bigint"),
            "execution_end_ts": exp.DataType.build("bigint"),
            "cached_at_ts": exp.DataType.build(
                "bigint"
            ),  # When result was cached (for from_cache strategy)
            "result_id": exp.DataType.build(index_type),
            "error_message": exp.DataType.build("text"),
        }

        # Column types for _perspectives
        self._perspectives_columns_to_types = {
            "perspective_id": exp.DataType.build(index_type),
            "slug": exp.DataType.build("text"),
            "name": exp.DataType.build("text"),
            "description": exp.DataType.build("text"),
            "tags": exp.DataType.build("text[]"),
            "terms": exp.DataType.build("text[]"),
            "owner": exp.DataType.build("text"),
            "request_id": exp.DataType.build(index_type),
            "fingerprint": exp.DataType.build(
                index_type
            ),  # Fingerprint of original query (denormalized)
            # Denormalized Query Definition Fields
            "sql_query": exp.DataType.build("text"),
            "normalized_sql": exp.DataType.build("text"),
            "params": exp.DataType.build("jsonb"),
            "gateway": exp.DataType.build("text"),
            "ttl": exp.DataType.build("int"),
            "meta": exp.DataType.build("jsonb"),
            "query_type": exp.DataType.build("text"),
            "semantic_query": exp.DataType.build("text"),
            "rest_query": exp.DataType.build("jsonb"),
            "graphql_query": exp.DataType.build("text"),
            "depends_on": exp.DataType.build("text[]"),
            "auto_refresh": exp.DataType.build("boolean"),
            "is_public": exp.DataType.build("boolean"),
            "allowed_user_ids": exp.DataType.build("text[]"),
            "created_at": exp.DataType.build("bigint"),
            "updated_at": exp.DataType.build("bigint"),
            "created_by": exp.DataType.build("text"),
            "updated_by": exp.DataType.build("text"),
        }

    def get_result_by_id(self, result_id: str) -> t.Optional[QueryResult]:
        """Get result metadata by result_id.

        Result metadata includes schema (columns), row count, size, and object store path.
        The actual data is stored in object store (S3/MinIO), not in the database.
        """
        df = self.engine_adapter.fetchdf(
            exp.select("*")  # TODO: Expand with columns
            .from_(self.results_table)
            .where(exp.column("result_id").eq(result_id))
        )

        if len(df) == 0:
            return None

        result_dict = df.to_dict("records")[0]

        # Parse JSON columns field if present (stored as JSONB in PostgreSQL)
        if result_dict.get("columns") and isinstance(result_dict["columns"], str):
            try:
                result_dict["columns"] = json.loads(result_dict["columns"])
            except (json.JSONDecodeError, TypeError):
                logger.warning(f"Failed to parse columns for result {result_id[:16]}...")
                result_dict["columns"] = []

        # Parse JSON references field if present (stored as JSONB in PostgreSQL)
        # Convert from [[model, field], ...] format back to [(model, field), ...] tuples
        if result_dict.get("references"):
            if isinstance(result_dict["references"], str):
                try:
                    references_dict = json.loads(result_dict["references"])
                    # Convert lists back to tuples: [[model, field], ...] -> [(model, field), ...]
                    result_dict["references"] = {
                        col: [(ref[0], ref[1]) for ref in refs]
                        for col, refs in references_dict.items()
                    }
                except (json.JSONDecodeError, TypeError, IndexError):
                    logger.warning(f"Failed to parse references for result {result_id[:16]}...")
                    result_dict["references"] = None
            elif isinstance(result_dict["references"], dict):
                # Already parsed, but may need tuple conversion
                result_dict["references"] = {
                    col: [(ref[0], ref[1]) if isinstance(ref, list) else ref for ref in refs]
                    for col, refs in result_dict["references"].items()
                }

        return QueryResult(**result_dict)

    def delete_result_by_id(self, result_id: str) -> None:
        """Delete result metadata by ID (must cleanup object store separately)."""
        self.engine_adapter.execute(
            exp.delete(self.results_table).where(exp.column("result_id").eq(result_id))
        )

    def get_fingerprint_result(
        self,
        fingerprint: str,
    ) -> t.Optional[QueryFingerprintResult]:
        """Get fingerprint result by fingerprint (returns None if not found or expired).

        Checks cache for existing result matching the fingerprint:
        - Returns None if fingerprint not found
        - Returns None if fingerprint expired (expires_ts < now)
        - Returns None if fingerprint invalidated (invalidated_ts is set)
        - Returns QueryFingerprintResult if valid cache entry exists

        This is the core cache lookup used by the "from_cache" strategy.
        """
        now_ts = to_timestamp(datetime.now(timezone.utc))

        query = (
            exp.select(
                exp.column("fingerprint", "c"),
                exp.column("result_id", "c"),
                exp.column("depends_on", "c"),
                exp.column("created_ts", "c").as_("cached_at_ts"),
                exp.column("expires_ts", "c"),
                exp.column("invalidated_by_run_id", "c"),
                exp.column("invalidated_ts", "c"),
                exp.column("object_store_path", "r"),
                exp.column("row_count", "r"),
                exp.column("size_bytes", "r"),
                exp.column("columns", "r"),
                exp.column("created_ts", "r").as_("result_created_ts"),
            )
            .from_(self.fingerprints_table.as_("c"))
            .join(
                self.results_table.as_("r"),
                on=exp.column("result_id", "c").eq(exp.column("result_id", "r")),
            )
            .where(exp.column("fingerprint", "c").eq(fingerprint))
            .where(
                exp.or_(
                    exp.column("expires_ts", "c").is_(exp.null()),  # Never expires
                    exp.column("expires_ts", "c") > now_ts,  # Not yet expired
                )
            )
            # Note: invalidated_ts check happens in is_result_fresh(), not here
            # This allows us to return invalidated entries for staleness detection
        )

        df = self.engine_adapter.fetchdf(query)

        if len(df) == 0:
            return None

        fingerprint_dict = df.to_dict("records")[0]

        # Parse JSON columns field
        if fingerprint_dict.get("columns") and isinstance(fingerprint_dict["columns"], str):
            try:
                fingerprint_dict["columns"] = json.loads(fingerprint_dict["columns"])
            except (json.JSONDecodeError, TypeError):
                logger.warning(f"Failed to parse columns for {fingerprint[:16]}...")
                fingerprint_dict["columns"] = []

        return QueryFingerprintResult(**fingerprint_dict)

    def is_result_fresh(
        self,
        fingerprint: str,
        result_id: str,
    ) -> bool:
        """Check if result is fresh (not expired) by comparing with fingerprint entry.

        A result is considered fresh if:
        1. Fingerprint entry exists and matches result_id
        2. Fingerprint not invalidated (invalidated_ts is NULL)
        3. Fingerprint not expired (expires_ts is NULL or expires_ts > now)

        Used for staleness detection - if result is stale, cache should be invalidated.
        """
        if not fingerprint:
            return True  # No fingerprint means no cache, so always "fresh"

        # Get fingerprint entry
        query = (
            exp.select(
                exp.column("result_id"),
                exp.column("invalidated_ts"),
                exp.column("expires_ts"),
            )
            .from_(self.fingerprints_table)
            .where(exp.column("fingerprint").eq(fingerprint))
        )

        df = self.engine_adapter.fetchdf(query)

        if len(df) == 0:
            return True

        fingerprint_entry = df.to_dict("records")[0]

        if fingerprint_entry["result_id"] != result_id:
            return False

        if fingerprint_entry.get("invalidated_ts") is not None:
            return False

        if fingerprint_entry.get("expires_ts") is not None:
            now_ts = to_timestamp(datetime.now(timezone.utc))
            if fingerprint_entry["expires_ts"] < now_ts:
                return False

        return True

    def delete_fingerprint_entry(self, fingerprint: str) -> None:
        """Delete fingerprint entry by fingerprint."""
        self.engine_adapter.execute(
            exp.delete(self.fingerprints_table).where(exp.column("fingerprint").eq(fingerprint))
        )

    def cleanup_expired_fingerprints(
        self,
        retention_days: int = 7,
    ) -> int:
        """Cleanup expired fingerprint entries older than retention period (maintenance operation).

        Removes fingerprint entries that:
        - Have an expiration timestamp (expires_ts is not NULL)
        - Expired before the cutoff timestamp (retention_days ago)

        This is a maintenance operation to prevent unbounded growth of fingerprint table.
        Only removes entries with explicit expiration - entries without expiration are kept.
        """
        cutoff_ts = to_timestamp(datetime.now(timezone.utc) - timedelta(days=retention_days))

        result = self.engine_adapter.execute(
            exp.delete(self.fingerprints_table).where(
                exp.and_(
                    # Only entries that have an expiration (not NULL)
                    exp.column("expires_ts").is_(exp.null()).not_(),
                    # Only entries expired before cutoff
                    exp.column("expires_ts") < cutoff_ts,
                )
            )
        )

        affected = getattr(result, "rowcount", 0)

        if affected > 0:
            logger.info(
                f"Cleaned up {affected} fingerprint entries expired >{retention_days} days ago"
            )

        return affected

    def create_request(
        self,
        request_id: str,
        strategy: str,
        fingerprint: str,
        sql_query: str,
        normalized_sql: str,
        params: t.Optional[t.Union[t.Dict, t.List]],
        gateway: str,
        submitted_by: t.Optional[str] = None,
        depends_on: t.Optional[t.List[str]] = None,
        ttl: int = 0,
        meta: t.Optional[t.Dict] = None,
        query_type: t.Optional[str] = None,
        semantic_query: t.Optional[str] = None,
        rest_query: t.Optional[t.Dict] = None,
        graphql_query: t.Optional[str] = None,
        perspective_id: t.Optional[str] = None,
        # Fields specific to strategy
        execution_status: t.Optional[str] = None,  # Required for strategy='execute'
        primary_request_id: t.Optional[
            str
        ] = None,  # Required for strategy='await_primary', or extracted from original request for 'from_cache'
        cached_at_ts: t.Optional[int] = None,  # Set for strategy='from_cache'
        result_id: t.Optional[str] = None,  # Set immediately for strategy='from_cache'
    ) -> None:
        """Create new query request record for any resolution strategy (from_cache, await_primary, execute).

        For 'from_cache' strategy:
        - If result_id is provided, automatically fetches the original request that created this result
        - Extracts primary_request_id, execution_start_ts, and execution_end_ts from original request
        - Raises ValueError if original request not found (data inconsistency)
        """
        import pandas as pd

        # Validate strategy-specific requirements
        if strategy == "await_primary":
            if not primary_request_id:
                raise ValueError(
                    f"primary_request_id is required for strategy='await_primary'. "
                    f"Request {request_id} cannot be created without a primary request ID."
                )

        # For from_cache strategy, fetch original request and extract execution metadata
        # This ensures cached requests inherit execution timestamps and primary_request_id
        # for proper lineage tracking and auditability
        execution_start_ts_value = None
        execution_end_ts_value = None
        primary_request_id_value = primary_request_id

        if strategy == "from_cache" and result_id:
            # result_id is the request_id of the original request that created this result
            original_request = self.get_request_by_id(result_id)
            if not original_request:
                raise ValueError(
                    f"Original request not found for cached result: result_id={result_id}. "
                    f"This indicates data inconsistency - cache entry exists but original request is missing."
                )
            # Extract execution metadata from original request
            # For primary_request_id:
            # - If original request had a primary_request_id, use it (original was awaiting another primary)
            # - Otherwise, use result_id (original request's request_id) as primary_request_id
            #   (original request was itself a primary, so cached request should reference it)
            primary_request_id_value = original_request.primary_request_id or result_id
            execution_start_ts_value = original_request.execution_start_ts
            execution_end_ts_value = original_request.execution_end_ts

        df = pd.DataFrame(
            [
                {
                    "request_id": request_id,
                    "strategy": strategy,
                    "execution_status": execution_status,
                    "primary_request_id": primary_request_id_value,
                    "fingerprint": fingerprint,
                    "sql_query": sql_query,
                    "normalized_sql": normalized_sql,
                    "params": json.dumps(params) if params else None,
                    "depends_on": (depends_on if depends_on else None),  # Empty list → NULL
                    "gateway": gateway,
                    "submitted_by": submitted_by,
                    "submitted_ts": to_timestamp(datetime.now(timezone.utc)),
                    "ttl": ttl,
                    "meta": json.dumps(meta) if meta else None,
                    "query_type": query_type,
                    "semantic_query": semantic_query,
                    "rest_query": json.dumps(rest_query) if rest_query else None,
                    "graphql_query": graphql_query,
                    "perspective_id": perspective_id,
                    "pgq_job_id": None,  # Set later by mark_queued()
                    "execution_start_ts": execution_start_ts_value,  # For from_cache (from original request), otherwise set later by mark_in_progress()
                    "execution_end_ts": execution_end_ts_value,  # For from_cache (from original request), otherwise set later by complete_request() or mark_failed()
                    "cached_at_ts": cached_at_ts,  # Set for from_cache strategy
                    "result_id": result_id,  # Immediate for from_cache, set later for execute
                    "error_message": None,
                }
            ]
        )

        self.engine_adapter.insert_append(
            self.requests_table,
            df,
            target_columns_to_types=self._requests_columns_to_types,
            track_rows_processed=False,
        )

    def mark_request_completed(
        self,
        request_id: str,
        result_id: str,
        object_store_path: str,
        row_count: int,
        size_bytes: int,
        columns: t.List[t.Dict[str, str]],
        fingerprint: str,
        depends_on: t.Optional[t.List[str]] = None,
        ttl_minutes: int = 0,
        sql: t.Optional[str] = None,
        references: t.Optional[t.Dict[str, t.List[t.Tuple[str, str]]]] = None,
    ) -> None:
        """Mark query request as completed with result and fingerprint entry (transactional).

        Also updates all awaiting secondary requests to SUCCESS status automatically.

        This method performs an atomic transaction to ensure consistency:
        1. Result metadata stored in _query_results
        2. Fingerprint cache entry updated (upsert pattern)
        3. Primary request status updated to SUCCESS
        4. All awaiting secondary requests updated (via _update_request)
        5. Perspective request_id updated (if applicable)

        If any step fails, entire transaction rolls back to prevent partial state.

        Args:
            request_id: Request ID to mark as completed
            result_id: Result ID linking to _query_results
            object_store_path: Path to Parquet file in ObjectStore
            row_count: Number of rows in result
            size_bytes: Size of result file in bytes
            columns: Column schema as list of dicts
            fingerprint: Query fingerprint (required for cache entry creation)
            depends_on: Model dependencies for cache invalidation
            ttl_minutes: Cache TTL in minutes (0 = never expires)
            sql: SQL query that produced this result
            references: Field-level lineage mapping {column_name: [(model_name, field_name), ...]}
        """
        now_ts = to_timestamp(datetime.now(timezone.utc))

        # Use explicit transaction for atomicity
        # All operations must succeed together or all roll back
        with self.engine_adapter.transaction():
            # 1. Store result metadata
            self._store_result_metadata(
                result_id=result_id,
                object_store_path=object_store_path,
                row_count=row_count,
                size_bytes=size_bytes,
                columns=columns,
                created_ts=now_ts,
                sql=sql,
                references=references,
            )

            # 2. Store fingerprint entry (always created for completed requests)
            self._store_fingerprint_entry(
                fingerprint=fingerprint,
                result_id=result_id,
                depends_on=depends_on,
                ttl_minutes=ttl_minutes,
                created_ts=now_ts,
            )

            # 3. Get primary request (for perspective_id)
            primary_request = self._get_request_or_raise(request_id)

            # 4. Update primary request status to SUCCESS
            # This automatically updates awaiting secondary requests via _update_request
            # When _update_request sees a terminal status (SUCCESS), it calls
            # _update_awaiting_requests_status to batch-update all requests with
            # strategy='await_primary' and primary_request_id=request_id
            self._update_request(
                request_id,
                execution_status=QueryStatus.SUCCESS,
                result_id=result_id,
                execution_end_ts=now_ts,
            )

            # 5. Update perspective if this request belongs to one
            if primary_request.perspective_id:
                self._update_request_id_for_perspective(
                    perspective_id=primary_request.perspective_id,
                    request_id=request_id,
                )

        logger.info(f"Request {request_id} completed successfully (transactional)")

    def mark_request_queued(self, request_id: str, pgq_job_id: int) -> None:
        """Mark request as queued in pgqueuer."""
        self._update_request(
            request_id,
            execution_status=QueryStatus.QUEUED,
            pgq_job_id=pgq_job_id,
        )
        logger.debug(f"Request {request_id} marked as QUEUED (pgq_job_id={pgq_job_id})")

    def mark_request_in_progress(self, request_id: str) -> None:
        """Mark request as being processed by worker."""
        self._update_request(
            request_id,
            execution_status=QueryStatus.IN_PROGRESS,
            execution_start_ts=to_timestamp(datetime.now(timezone.utc)),
        )
        logger.debug(f"Request {request_id} marked as IN_PROGRESS")

    def mark_request_failed(self, request_id: str, error_message: str) -> None:
        """Mark request as failed with error."""
        self._update_request(
            request_id,
            execution_status=QueryStatus.FAILED,
            error_message=error_message,
            execution_end_ts=to_timestamp(datetime.now(timezone.utc)),
        )
        logger.debug(f"Request {request_id} marked as FAILED")

    def mark_request_cancelled(self, request_id: str) -> None:
        """Mark request as cancelled by user."""
        self._update_request(
            request_id,
            execution_status=QueryStatus.CANCELLED,
            execution_end_ts=to_timestamp(datetime.now(timezone.utc)),
        )
        logger.debug(f"Request {request_id} marked as CANCELLED")

    def get_request_by_id(self, request_id: str) -> t.Optional[QueryRequest]:
        """Get request details by ID."""
        df = self.engine_adapter.fetchdf(
            exp.select("*")  # TODO: Expand with columns
            .from_(self.requests_table)
            .where(exp.column("request_id").eq(request_id))
        )

        if len(df) == 0:
            return None

        request_dict = df.to_dict("records")[0]
        for field in ["params", "meta", "rest_query"]:
            if request_dict.get(field) and isinstance(request_dict[field], str):
                try:
                    request_dict[field] = json.loads(request_dict[field])
                except (json.JSONDecodeError, TypeError):
                    logger.warning(f"Failed to parse {field} for request {request_id[:16]}...")
                    request_dict[field] = None

        return QueryRequest(**request_dict)

    def get_awaiting_requests_by_primary_request_id(
        self, primary_request_id: str
    ) -> t.List[QueryRequest]:
        """Get QueryRequest objects waiting for this primary request.

        Returns all requests with:
        - strategy='await_primary'
        - primary_request_id=primary_request_id
        - perspective_id IS NOT NULL

        Args:
            primary_request_id: The primary request ID

        Returns:
            List of QueryRequest objects (awaiting requests that are perspectives)
        """
        df = self.engine_adapter.fetchdf(
            exp.select("*")
            .from_(self.requests_table)
            .where(
                exp.column("strategy").eq("await_primary")
                & exp.column("primary_request_id").eq(primary_request_id)
                & exp.column("perspective_id").is_(exp.null()).not_()
            )
        )

        if len(df) == 0:
            return []

        requests = []
        for _, row in df.iterrows():
            request_dict = row.to_dict()

            # Parse JSON fields (same as get_request_by_id)
            for field in ["params", "meta", "rest_query"]:
                if request_dict.get(field) and isinstance(request_dict[field], str):
                    try:
                        request_dict[field] = json.loads(request_dict[field])
                    except (json.JSONDecodeError, TypeError):
                        logger.warning(
                            f"Failed to parse {field} for request {request_dict.get('request_id', 'unknown')[:16]}..."
                        )
                        request_dict[field] = None

            requests.append(QueryRequest(**request_dict))

        return requests

    def get_in_flight_request_by_fingerprint(self, fingerprint: str) -> t.Optional[QueryRequest]:
        """Get in-flight request by fingerprint for deduplication (returns earliest QUEUED or IN_PROGRESS request).

        Used to implement the "await_primary" strategy:
        - When a new query arrives with same fingerprint as an in-flight query
        - Instead of executing again, create a secondary request that waits on the primary
        - Returns the earliest in-flight request (by submitted_ts) to ensure fairness
        - Only checks strategy='execute' requests (not 'from_cache' or 'await_primary')
        """
        df = self.engine_adapter.fetchdf(
            exp.select("*")  # TODO: Expand with columns
            .from_(self.requests_table)
            .where(exp.column("fingerprint").eq(fingerprint))
            .where(exp.column("strategy").eq("execute"))
            .where(exp.column("execution_status").isin(*QueryStatus.ACTIVE))
            .order_by(exp.column("submitted_ts"))
            .limit(1)
        )

        if len(df) == 0:
            return None

        request_dict = df.to_dict("records")[0]

        # Parse JSON params field if present
        if request_dict.get("params") and isinstance(request_dict["params"], str):
            try:
                request_dict["params"] = json.loads(request_dict["params"])
            except (json.JSONDecodeError, TypeError):
                logger.warning(f"Failed to parse params for in-flight request")
                request_dict["params"] = None

        return QueryRequest(**request_dict)

    def get_recent_failed_execution_by_fingerprint(
        self,
        fingerprint: str,
        window_seconds: int = 300,
    ) -> t.Optional[QueryRequest]:
        """Get most recent FAILED request by fingerprint within time window (negative cache to avoid re-executing broken queries).

        Implements negative caching to prevent rapid re-execution of broken queries:
        - If a query failed recently (within window_seconds), don't execute again immediately
        - Returns the most recent failure to allow caller to return error immediately
        - Window defaults to 5 minutes to balance between avoiding spam and allowing retries
        - Only checks strategy='execute' requests (actual executions, not cache hits)
        """
        cutoff_ts = to_timestamp(datetime.now(timezone.utc) - timedelta(seconds=window_seconds))

        df = self.engine_adapter.fetchdf(
            exp.select("*")  # TODO: Expand with columns
            .from_(self.requests_table)
            .where(exp.column("fingerprint").eq(fingerprint))
            .where(exp.column("strategy").eq("execute"))
            .where(exp.column("execution_status").eq(QueryStatus.FAILED))
            .where(exp.column("execution_end_ts") > cutoff_ts)
            .order_by(exp.column("execution_end_ts").desc())
            .limit(1)
        )

        if len(df) == 0:
            return None

        request_dict = df.to_dict("records")[0]

        # Parse JSON params field if present
        if request_dict.get("params") and isinstance(request_dict["params"], str):
            try:
                request_dict["params"] = json.loads(request_dict["params"])
            except (json.JSONDecodeError, TypeError):
                logger.warning("Failed to parse params for failed request")
                request_dict["params"] = None

        return QueryRequest(**request_dict)

    def create_perspective(
        self,
        perspective_id: str,
        slug: str,
        request_id: str,
        fingerprint: str,
        # Denormalized query fields
        sql_query: str,
        # Metadata fields (required)
        name: str,
        owner: str,
        # Denormalized query fields (optional)
        normalized_sql: t.Optional[str] = None,
        params: t.Optional[t.Union[t.Dict, t.List]] = None,
        gateway: t.Optional[str] = None,
        ttl: int = 0,
        meta: t.Optional[t.Dict] = None,
        query_type: t.Optional[str] = None,
        semantic_query: t.Optional[str] = None,
        rest_query: t.Optional[t.Dict] = None,
        graphql_query: t.Optional[str] = None,
        depends_on: t.Optional[t.List[str]] = None,
        # Metadata fields (optional)
        description: t.Optional[str] = None,
        tags: t.Optional[t.List[str]] = None,
        terms: t.Optional[t.List[str]] = None,
        auto_refresh: bool = True,
        is_public: bool = False,
        allowed_user_ids: t.Optional[t.List[str]] = None,
        created_by: t.Optional[str] = None,
    ) -> None:
        """Create a new perspective."""
        import pandas as pd
        import json

        now_ts = to_timestamp(datetime.now(timezone.utc))

        df = pd.DataFrame(
            [
                {
                    "perspective_id": perspective_id,
                    "slug": slug,
                    "name": name,
                    "description": description,
                    "tags": tags if tags else None,
                    "terms": terms if terms else None,
                    "owner": owner,
                    "request_id": request_id,
                    "fingerprint": fingerprint,
                    # Denormalized query fields
                    "sql_query": sql_query,
                    "normalized_sql": normalized_sql,
                    "params": json.dumps(params) if params else None,
                    "gateway": gateway,
                    "ttl": ttl,
                    "meta": json.dumps(meta) if meta else None,
                    "query_type": query_type,
                    "semantic_query": semantic_query,
                    "rest_query": json.dumps(rest_query) if rest_query else None,
                    "graphql_query": graphql_query,
                    "depends_on": depends_on if depends_on else None,
                    "auto_refresh": auto_refresh,
                    "is_public": is_public,
                    "allowed_user_ids": allowed_user_ids if allowed_user_ids else None,
                    "created_at": now_ts,
                    "updated_at": now_ts,
                    "created_by": created_by or owner,
                    "updated_by": created_by or owner,
                }
            ]
        )

        self.engine_adapter.insert_append(
            self.perspectives_table,
            df,
            target_columns_to_types=self._perspectives_columns_to_types,
            track_rows_processed=False,
        )

        logger.info(f"Created perspective: {perspective_id} (slug: {slug})")

    def get_perspective_by_slug(self, slug: str) -> t.Optional[Perspective]:
        """Get perspective by slug."""
        query = (
            exp.select(
                exp.column("perspective_id"),
                exp.column("slug"),
                exp.column("name"),
                exp.column("description"),
                exp.column("tags"),
                exp.column("terms"),
                exp.column("owner"),
                exp.column("request_id"),
                exp.column("fingerprint"),
                # Denormalized query fields
                exp.column("sql_query"),
                exp.column("normalized_sql"),
                exp.column("params"),
                exp.column("gateway"),
                exp.column("ttl"),
                exp.column("meta"),
                exp.column("query_type"),
                exp.column("semantic_query"),
                exp.column("rest_query"),
                exp.column("graphql_query"),
                exp.column("depends_on"),
                exp.column("auto_refresh"),
                exp.column("is_public"),
                exp.column("allowed_user_ids"),
                exp.column("created_at"),
                exp.column("updated_at"),
                exp.column("created_by"),
                exp.column("updated_by"),
            )
            .from_(self.perspectives_table)
            .where(exp.column("slug").eq(slug))
        )

        df = self.engine_adapter.fetchdf(query)

        if len(df) == 0:
            return None

        return self._parse_perspective_dict(df.to_dict("records")[0])

    def get_perspective_by_id(self, perspective_id: str) -> t.Optional[Perspective]:
        """Get perspective by ID."""
        query = (
            exp.select(
                exp.column("perspective_id"),
                exp.column("slug"),
                exp.column("name"),
                exp.column("description"),
                exp.column("tags"),
                exp.column("terms"),
                exp.column("owner"),
                exp.column("request_id"),
                exp.column("fingerprint"),
                # Denormalized query fields
                exp.column("sql_query"),
                exp.column("normalized_sql"),
                exp.column("params"),
                exp.column("gateway"),
                exp.column("ttl"),
                exp.column("meta"),
                exp.column("query_type"),
                exp.column("semantic_query"),
                exp.column("rest_query"),
                exp.column("graphql_query"),
                exp.column("depends_on"),
                exp.column("auto_refresh"),
                exp.column("is_public"),
                exp.column("allowed_user_ids"),
                exp.column("created_at"),
                exp.column("updated_at"),
                exp.column("created_by"),
                exp.column("updated_by"),
            )
            .from_(self.perspectives_table)
            .where(exp.column("perspective_id").eq(perspective_id))
        )

        df = self.engine_adapter.fetchdf(query)

        if len(df) == 0:
            return None

        return self._parse_perspective_dict(df.to_dict("records")[0])

    def update_perspective(
        self,
        perspective_id: str,
        request_id: t.Optional[str] = None,
        fingerprint: t.Optional[str] = None,
        # Denormalized query fields
        sql_query: t.Optional[str] = None,
        normalized_sql: t.Optional[str] = None,
        params: t.Optional[t.Union[t.Dict, t.List]] = None,
        gateway: t.Optional[str] = None,
        ttl: t.Optional[int] = None,
        meta: t.Optional[t.Dict] = None,
        query_type: t.Optional[str] = None,
        semantic_query: t.Optional[str] = None,
        rest_query: t.Optional[t.Dict] = None,
        graphql_query: t.Optional[str] = None,
        depends_on: t.Optional[t.List[str]] = None,
        updated_by: t.Optional[str] = None,
        **kwargs,  # For other fields like name, description, tags, etc.
    ) -> None:
        """Update perspective fields.

        When updating query definition, provide fingerprint and denormalized query fields.
        If query fields are provided, fingerprint must also be provided.

        Args:
            perspective_id: Perspective ID to update
            request_id: Optional current request_id (for result link)
            fingerprint: Optional fingerprint (required if updating query definition)
            sql_query: Optional SQL query
            normalized_sql: Optional normalized SQL
            params: Optional query parameters
            gateway: Optional gateway name
            ttl: Optional TTL
            meta: Optional metadata
            query_type: Optional query type
            semantic_query: Optional semantic query
            rest_query: Optional REST query
            graphql_query: Optional GraphQL query
            depends_on: Optional dependencies
            updated_by: Optional user ID who made the update
            **kwargs: Other fields like name, description, tags, terms, auto_refresh, is_public, allowed_user_ids
        """
        import json

        now_ts = to_timestamp(datetime.now(timezone.utc))

        update_props = {
            "updated_at": now_ts,
        }

        # Check if updating query definition (any query field provided)
        has_query_fields = any(
            [
                sql_query is not None,
                normalized_sql is not None,
                params is not None,
                gateway is not None,
                ttl is not None,
                meta is not None,
                query_type is not None,
                semantic_query is not None,
                rest_query is not None,
                graphql_query is not None,
                depends_on is not None,
            ]
        )

        # If updating query definition, fingerprint must be provided
        if has_query_fields and fingerprint is None:
            raise ValueError("fingerprint must be provided when updating query definition fields")

        # Update query definition fields if provided
        if has_query_fields:
            if fingerprint is not None:
                update_props["fingerprint"] = fingerprint
            if sql_query is not None:
                update_props["sql_query"] = sql_query
            if normalized_sql is not None:
                update_props["normalized_sql"] = normalized_sql
            if params is not None:
                update_props["params"] = json.dumps(params) if params else None
            if gateway is not None:
                update_props["gateway"] = gateway
            if ttl is not None:
                update_props["ttl"] = ttl
            if meta is not None:
                update_props["meta"] = json.dumps(meta) if meta else None
            if query_type is not None:
                update_props["query_type"] = query_type
            if semantic_query is not None:
                update_props["semantic_query"] = semantic_query
            if rest_query is not None:
                update_props["rest_query"] = json.dumps(rest_query) if rest_query else None
            if graphql_query is not None:
                update_props["graphql_query"] = graphql_query
            if depends_on is not None:
                update_props["depends_on"] = depends_on if depends_on else None

        # Update request_id if provided
        if request_id is not None:
            update_props["request_id"] = request_id

        # Update updated_by if provided
        if updated_by is not None:
            update_props["updated_by"] = updated_by

        # Handle other metadata fields
        if "name" in kwargs:
            update_props["name"] = kwargs["name"]
        if "description" in kwargs:
            update_props["description"] = kwargs["description"]
        if "tags" in kwargs:
            update_props["tags"] = kwargs["tags"]
        if "terms" in kwargs:
            update_props["terms"] = kwargs["terms"]
        if "auto_refresh" in kwargs:
            update_props["auto_refresh"] = kwargs["auto_refresh"]
        if "is_public" in kwargs:
            update_props["is_public"] = kwargs["is_public"]
        if "allowed_user_ids" in kwargs:
            update_props["allowed_user_ids"] = kwargs["allowed_user_ids"]

        if len(update_props) == 1:  # Only updated_at
            logger.warning(f"No fields to update for perspective {perspective_id}")
            return

        self.engine_adapter.update_table(
            self.perspectives_table,
            update_props,
            where=exp.column("perspective_id").eq(perspective_id),
        )

    def delete_perspective(self, perspective_id: str) -> None:
        """Delete perspective by ID."""
        self.engine_adapter.execute(
            exp.delete(self.perspectives_table).where(
                exp.column("perspective_id").eq(perspective_id)
            )
        )
        logger.info(f"Deleted perspective: {perspective_id}")

    def list_perspectives(
        self,
        current_user_id: str,
        is_public: t.Optional[bool] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> t.Tuple[t.List[Perspective], bool]:
        """List perspectives accessible to current user.

        Access control ensures users only see:
        - Their own perspectives (owner = current_user_id)
        - Public perspectives
        - Perspectives shared with them (current_user_id in allowed_user_ids)
        """
        query = exp.select(
            exp.column("perspective_id"),
            exp.column("slug"),
            exp.column("name"),
            exp.column("description"),
            exp.column("tags"),
            exp.column("terms"),
            exp.column("owner"),
            exp.column("request_id"),
            exp.column("fingerprint"),
            # Denormalized query fields
            exp.column("sql_query"),
            exp.column("normalized_sql"),
            exp.column("params"),
            exp.column("gateway"),
            exp.column("ttl"),
            exp.column("meta"),
            exp.column("query_type"),
            exp.column("semantic_query"),
            exp.column("rest_query"),
            exp.column("graphql_query"),
            exp.column("depends_on"),
            exp.column("is_public"),
            exp.column("allowed_user_ids"),
            exp.column("auto_refresh"),
            exp.column("created_at"),
            exp.column("updated_at"),
            exp.column("created_by"),
            exp.column("updated_by"),
        ).from_(self.perspectives_table)

        conditions = []

        # Access control: public OR owner OR current_user_id in allowed_user_ids
        access_condition = exp.or_(
            exp.column("is_public").eq(True),
            exp.column("owner").eq(current_user_id),
            exp.Exists(
                this=exp.select(exp.Literal.number(1))
                .from_(
                    exp.Unnest(
                        expressions=[exp.column("allowed_user_ids")],
                        alias=exp.TableAlias(this=exp.to_identifier("_user_id")),
                    )
                )
                .where(exp.column("_user_id").eq(current_user_id))
            ),
        )
        conditions.append(access_condition)

        if is_public is not None:
            conditions.append(exp.column("is_public").eq(is_public))

        if conditions:
            query = query.where(exp.and_(*conditions))

        # Sort by latest (most recently updated) to oldest
        query = query.order_by(exp.column("updated_at").desc())
        query = query.limit(limit + 1).offset(offset)

        df = self.engine_adapter.fetchdf(query)

        has_more = len(df) > limit
        if has_more:
            df = df.head(limit)

        perspectives = []
        for record in df.to_dict("records"):
            perspectives.append(self._parse_perspective_dict(record))

        return perspectives, has_more

    def list_perspectives_to_refresh(
        self,
        since_ts_ms: int,
        limit: int = 100,
        offset: int = 0,
    ) -> t.Tuple[t.List[Perspective], bool]:
        """
        List perspectives that need refreshing due to invalidated fingerprints.

        Finds perspectives whose fingerprints have been invalidated (due to model changes)
        after the given timestamp. Only includes perspectives with auto_refresh enabled.

        Why JOIN with fingerprints table:
        - _query_perspective stores fingerprint (the query fingerprint)
        - _query_fingerprints tracks invalidation status (invalidated_ts column)
        - When models change, fingerprints get marked with invalidated_ts
        - JOIN matches perspective.fingerprint with fingerprints.fingerprint to check invalidation
        - This filters perspectives that need refreshing

        Sort order: created_at ASC, perspective_id ASC (oldest perspectives first, stable pagination)

        Args:
            since_ts_ms: Timestamp in milliseconds - only return perspectives with fingerprints
                        invalidated after this timestamp
            limit: Maximum number of perspectives to return
            offset: Number of perspectives to skip (for pagination)

        Returns:
            Tuple of (perspectives_list, has_more) where has_more indicates if there are
            more results beyond the current page
        """
        query = (
            exp.select(
                # Perspective fields including denormalized query fields
                exp.column("perspective_id", "p"),
                exp.column("slug", "p"),
                exp.column("name", "p"),
                exp.column("description", "p"),
                exp.column("tags", "p"),
                exp.column("terms", "p"),
                exp.column("owner", "p"),
                exp.column("request_id", "p"),  # Current request_id
                exp.column("fingerprint", "p"),  # Fingerprint (stored in perspective table)
                # Denormalized query fields
                exp.column("sql_query", "p"),
                exp.column("normalized_sql", "p"),
                exp.column("params", "p"),
                exp.column("gateway", "p"),
                exp.column("ttl", "p"),
                exp.column("meta", "p"),
                exp.column("query_type", "p"),
                exp.column("semantic_query", "p"),
                exp.column("rest_query", "p"),
                exp.column("graphql_query", "p"),
                exp.column("depends_on", "p"),
                exp.column("auto_refresh", "p"),
                exp.column("is_public", "p"),
                exp.column("allowed_user_ids", "p"),
                exp.column("created_at", "p"),
                exp.column("updated_at", "p"),
                exp.column("created_by", "p"),
                exp.column("updated_by", "p"),
            )
            .from_(self.perspectives_table.as_("p"))
            .join(
                self.fingerprints_table.as_("c"),
                on=exp.column("fingerprint", "p").eq(exp.column("fingerprint", "c")),
                join_type="INNER",  # Must have fingerprint entry to check invalidation
            )
            .where(
                exp.and_(
                    # Check if fingerprint has been invalidated
                    exp.column("invalidated_ts", "c").is_(exp.null()).not_(),  # Must be invalidated
                    exp.column("invalidated_ts", "c") > since_ts_ms,  # Invalidated after timestamp
                    exp.column("auto_refresh", "p").eq(
                        True
                    ),  # Only auto-refresh enabled perspectives
                )
            )
            .distinct()
            .order_by(
                exp.column("created_at", "p"),  # Oldest first
                exp.column("perspective_id", "p"),  # Stable tiebreaker
            )
            .limit(limit)
            .offset(offset)
        )

        df = self.engine_adapter.fetchdf(query)

        perspectives = []
        for record in df.to_dict("records"):
            perspectives.append(self._parse_perspective_dict(record))

        has_more = len(perspectives) == limit

        return perspectives, has_more

    def _store_result_metadata(
        self,
        result_id: str,
        object_store_path: str,
        row_count: int,
        size_bytes: int,
        columns: t.List[t.Dict[str, str]],
        created_ts: int,
        sql: t.Optional[str] = None,
        references: t.Optional[t.Dict[str, t.List[t.Tuple[str, str]]]] = None,
    ) -> None:
        """Store result metadata in _query_results table."""
        import pandas as pd

        # Convert references tuples to lists for JSON serialization
        references_json = None
        if references:
            references_json = {
                col: [[model, field] for model, field in refs] for col, refs in references.items()
            }

        result_df = pd.DataFrame(
            [
                {
                    "result_id": result_id,
                    "object_store_path": object_store_path,
                    "row_count": row_count,
                    "size_bytes": size_bytes,
                    "columns": json.dumps(columns),
                    "sql": sql,
                    "references": json.dumps(references_json) if references_json else None,
                    "created_ts": created_ts,
                }
            ]
        )

        self.engine_adapter.insert_append(
            self.results_table,
            result_df,
            target_columns_to_types=self._results_columns_to_types,
            track_rows_processed=False,
        )

    def _store_fingerprint_entry(
        self,
        fingerprint: str,
        result_id: str,
        depends_on: t.Optional[t.List[str]],
        ttl_minutes: t.Optional[int],
        created_ts: int,
    ) -> None:
        """Store fingerprint entry in _query_fingerprints table (upsert pattern).

        Implements upsert by DELETE + INSERT:
        - Deletes any existing entry for this fingerprint
        - Inserts new entry with updated result_id and timestamps
        - This ensures cache always points to latest result for a fingerprint

        The depends_on field tracks model dependencies for cache invalidation:
        - When models in depends_on are executed, cache entries are invalidated
        - See ActivityState.store_run_activity() for invalidation logic
        """
        import pandas as pd

        expires_ts = None
        if ttl_minutes is not None:
            expires_dt = datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes)
            expires_ts = to_timestamp(expires_dt)

        # Delete existing entry, then insert new one (upsert pattern)
        # This ensures fingerprint always points to latest result
        self.engine_adapter.execute(
            exp.delete(self.fingerprints_table).where(exp.column("fingerprint").eq(fingerprint))
        )

        fingerprint_df = pd.DataFrame(
            [
                {
                    "fingerprint": fingerprint,
                    "result_id": result_id,
                    "depends_on": depends_on if depends_on else None,
                    "created_ts": created_ts,
                    "expires_ts": None,
                    "invalidated_by_run_id": None,
                    "invalidated_ts": None,
                }
            ]
        )

        self.engine_adapter.insert_append(
            self.fingerprints_table,
            fingerprint_df,
            target_columns_to_types=self._fingerprints_columns_to_types,
            track_rows_processed=False,
        )

    def _get_request_or_raise(self, request_id: str) -> QueryRequest:
        """Get request by ID, raising ValueError if not found.

        Helper method to avoid duplication of fetch+validate logic.

        Args:
            request_id: Request ID to fetch

        Returns:
            QueryRequest object

        Raises:
            ValueError: If request not found
        """
        request = self.get_request_by_id(request_id)
        if not request:
            raise ValueError(f"Request {request_id} not found")
        return request

    def _update_request(
        self,
        request_id: str,
        execution_status: t.Optional[str] = None,
        pgq_job_id: t.Optional[int] = None,
        execution_start_ts: t.Optional[int] = None,
        execution_end_ts: t.Optional[int] = None,
        result_id: t.Optional[str] = None,
        error_message: t.Optional[str] = None,
        patch_id: t.Optional[str] = None,
    ) -> None:
        """Internal method to update request fields.

        If updating to a terminal status (SUCCESS, FAILED, CANCELLED), automatically
        updates all awaiting secondary requests with the same status.
        """
        # Build properties dict (only non-None values)
        properties = {}
        if execution_status is not None:
            properties["execution_status"] = execution_status
        if pgq_job_id is not None:
            properties["pgq_job_id"] = pgq_job_id
        if execution_start_ts is not None:
            properties["execution_start_ts"] = execution_start_ts
        if execution_end_ts is not None:
            properties["execution_end_ts"] = execution_end_ts
        if result_id is not None:
            properties["result_id"] = result_id
        if error_message is not None:
            properties["error_message"] = error_message
        if patch_id is not None:
            properties["patch_id"] = patch_id

        if not properties:
            logger.warning(f"No properties to update for request {request_id}")
            return

        # Single UPDATE statement
        self.engine_adapter.update_table(
            self.requests_table,
            properties,
            where=exp.column("request_id").eq(request_id),
        )

        # If updating to terminal status, propagate to awaiting secondary requests
        # This ensures all requests waiting on this primary are updated atomically
        # Terminal statuses: SUCCESS (completed), FAILED (error), CANCELLED (user cancelled)
        # Non-terminal statuses (QUEUED, IN_PROGRESS) don't propagate - secondary requests stay waiting
        terminal_statuses = {QueryStatus.SUCCESS, QueryStatus.FAILED, QueryStatus.CANCELLED}
        if execution_status in terminal_statuses:
            # Get request to extract execution_start_ts (needed for secondary updates)
            # We need the full request object to get execution_start_ts which may have been
            # set earlier (e.g., by mark_request_in_progress())
            request = self.get_request_by_id(request_id)
            if request:
                # Just call it - method handles empty case internally (returns early if no awaiting requests)
                # This is called automatically whenever a request reaches terminal status,
                # ensuring secondary requests are always updated consistently
                self._update_awaiting_requests_status(
                    primary_request_id=request_id,
                    execution_status=execution_status,
                    execution_start_ts=request.execution_start_ts or execution_start_ts,
                    execution_end_ts=execution_end_ts or to_timestamp(datetime.now(timezone.utc)),
                    result_id=result_id,
                    error_message=error_message
                    or (
                        f"Failed because primary request failed"
                        if execution_status == QueryStatus.FAILED
                        else None
                    ),
                )

    def _update_awaiting_requests_status(
        self,
        primary_request_id: str,
        execution_status: str,
        execution_start_ts: t.Optional[int],
        execution_end_ts: int,
        result_id: t.Optional[str] = None,
        error_message: t.Optional[str] = None,
    ) -> None:
        """Update all awaiting requests with primary's status and timestamps.

        Also updates perspectives for awaiting requests that have perspective_id.

        This method implements the "await_primary" strategy completion logic:
        - When a primary request reaches a terminal status, all secondary requests
          waiting on it must be updated to the same status
        - Uses batch UPDATE for efficiency (single SQL statement)
        - Updates perspectives for secondary requests that belong to perspectives

        Args:
            primary_request_id: The primary request ID
            execution_status: Status to set (SUCCESS, FAILED, or CANCELLED)
            execution_start_ts: Primary request's execution start timestamp
            execution_end_ts: Primary request's execution end timestamp
            result_id: Result ID to assign (only for SUCCESS status)
            error_message: Error message (only for FAILED status)
        """
        # Get all awaiting requests (strategy='await_primary' with matching primary_request_id)
        # Only fetch request_id and perspective_id - we don't need full request objects
        awaiting_requests_df = self.engine_adapter.fetchdf(
            exp.select(exp.column("request_id"), exp.column("perspective_id"))
            .from_(self.requests_table)
            .where(
                exp.column("strategy").eq("await_primary")
                & exp.column("primary_request_id").eq(primary_request_id)
            )
        )

        if awaiting_requests_df.empty:
            return  # No secondary requests waiting on this primary

        awaiting_request_ids = awaiting_requests_df["request_id"].tolist()

        # Build update properties based on status
        # All secondary requests get the same execution timestamps as primary
        update_properties = {
            "execution_status": execution_status,
            "execution_start_ts": execution_start_ts,
            "execution_end_ts": execution_end_ts,
        }

        # SUCCESS: Share result_id with secondary requests (they reuse the same result)
        if execution_status == QueryStatus.SUCCESS and result_id:
            update_properties["result_id"] = result_id

        # FAILED: Propagate error message to secondary requests
        if execution_status == QueryStatus.FAILED and error_message:
            update_properties["error_message"] = error_message

        # Batch update all awaiting requests at once (single UPDATE with WHERE ... IN (...))
        # More efficient than looping and updating one-by-one
        self.engine_adapter.update_table(
            self.requests_table,
            update_properties,
            where=exp.column("request_id").isin(*awaiting_request_ids),
        )

        status_label = execution_status.lower()
        logger.info(
            f"Updated {len(awaiting_request_ids)} awaiting request(s) to {status_label} "
            f"(primary={primary_request_id})"
        )

        # Update perspectives for awaiting requests (single loop)
        # When a secondary request completes, its perspective's request_id must be updated
        # to point to the completed secondary request (not the primary)
        # This allows perspectives to track their latest result correctly
        for _, row in awaiting_requests_df.iterrows():
            awaiting_perspective_id = row["perspective_id"]
            if awaiting_perspective_id:
                self._update_request_id_for_perspective(
                    perspective_id=awaiting_perspective_id,
                    request_id=row["request_id"],
                )
                logger.debug(
                    f"Updated perspective '{awaiting_perspective_id}' request_id to "
                    f"awaiting request '{row['request_id']}'"
                )

    def _parse_perspective_dict(self, perspective_dict: t.Dict[str, t.Any]) -> Perspective:
        """Parse JSON fields in perspective dict and return Perspective object."""
        # Parse JSON fields
        for field in ["params", "meta", "rest_query"]:
            if perspective_dict.get(field) and isinstance(perspective_dict[field], str):
                try:
                    perspective_dict[field] = json.loads(perspective_dict[field])
                except (json.JSONDecodeError, TypeError):
                    logger.warning(f"Failed to parse {field} for perspective")
                    perspective_dict[field] = None

        # Handle array fields that might be None
        for field in ["depends_on", "tags", "terms", "allowed_user_ids"]:
            if perspective_dict.get(field) is None:
                perspective_dict[field] = []

        # Remove original_request_id if present (for backward compatibility during migration)
        perspective_dict.pop("original_request_id", None)

        return Perspective(**perspective_dict)

    def _update_request_id_for_perspective(self, perspective_id: str, request_id: str) -> None:
        """Update perspective request_id to point to completed request.

        This method is called only when a query request is completed (typically from
        mark_request_completed()). It updates the perspective's request_id field to point
        to the newly completed request, allowing the perspective to track its latest result.

        Only updates if the new request's fingerprint matches the perspective's stored fingerprint.
        This prevents overwriting the perspective's request_id when the user has updated the
        perspective (changing its query definition) after the refresh job was scheduled.

        Race condition scenario:
        - T1: Refresh job scheduled with query fingerprint ABC123
        - T2: User updates perspective to new query (fingerprint XYZ789)
        - T3: Old job completes → fingerprint check prevents overwriting newer definition

        Since perspectives store fingerprint directly, we can compare it directly with the
        new request's fingerprint without JOINs.
        """
        now_ts = to_timestamp(datetime.now(timezone.utc))

        # Get new request's fingerprint
        new_request = self.get_request_by_id(request_id)
        if not new_request:
            logger.warning(f"Request {request_id} not found, skipping perspective update")
            return

        new_fingerprint = new_request.fingerprint

        # Build UPDATE statement with WHERE clause
        # WHERE perspective_id matches AND fingerprint matches (stored fingerprint = new request fingerprint)
        # The fingerprint check prevents race conditions:
        # - If user updated perspective query after refresh was scheduled, fingerprint won't match
        # - Update is skipped, preserving the newer query definition
        # - This ensures old refresh jobs don't overwrite newer perspective definitions
        update_stmt = exp.update(
            self.perspectives_table.as_("p"),
            {
                "request_id": request_id,
                "updated_at": now_ts,
            },
            where=exp.and_(
                exp.column("perspective_id", "p").eq(perspective_id),
                exp.column("fingerprint", "p").eq(
                    new_fingerprint
                ),  # Compare stored fingerprint with new request fingerprint
            ),
        )

        # Execute SQLGlot expression
        self.engine_adapter.execute(update_stmt)

        logger.debug(
            f"Updated perspective {perspective_id} request_id to {request_id} (fingerprint match verified)"
        )

    def get_usage_metrics(self, week_start: datetime | None = None) -> dict[str, t.Any]:
        """Return usage metrics over _query_requests for the given week.

        Notes:
            This aggregation is currently implemented for a Postgres-backed statestore.
        """
        from vulcan.core.state_sync.db.query_metrics import (
            fetch_usage_metrics,
            week_bounds_ms,
        )
        from vulcan.utils.errors import VulcanError

        raise_if_not_postgres(self.engine_adapter, feature="get_usage_metrics")

        if not self.schema:
            raise VulcanError(
                "Query usage metrics aggregation requires QueryState.schema to be set."
            )

        week_start_ms, week_end_ms, prev_week_start_ms, prev_prev_week_start_ms = week_bounds_ms(
            week_start
        )
        return fetch_usage_metrics(
            self.engine_adapter,
            schema=self.schema,
            week_start_ms=week_start_ms,
            week_end_ms=week_end_ms,
            prev_week_start_ms=prev_week_start_ms,
            prev_prev_week_start_ms=prev_prev_week_start_ms,
        )
