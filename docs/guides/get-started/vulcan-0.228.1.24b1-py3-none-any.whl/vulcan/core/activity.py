"""Activity tracking for Vulcan operations.

This module provides models and utilities for tracking Vulcan activities:
- PlanActivity: Deployment change tracking and history
- RunActivity: Model execution metrics and timing
- ActivityCapturingConsoleWrapper: Console wrapper for capturing execution data

Activities are stored in state_sync and exposed via REST API for
observability, auditing, and reporting.
"""

from __future__ import annotations

import typing as t
from pathlib import Path
from typing import Any, Literal

from pydantic import ConfigDict, Field

import logging
import os
import time

_activity_logger = logging.getLogger(__name__)

from vulcan.core import constants as c
from vulcan.core.node import NodeType, SchemaDrift
from vulcan.core.model.kind import ModelKindName
from vulcan.core.snapshot.definition import Intervals
from vulcan.core.model.definition import AuditResult
from vulcan.core.snapshot import SnapshotChangeCategory, Snapshot, SnapshotIntervals, SnapshotTableInfo
from vulcan.core.soda3.spec import CheckOutcome, QualitySummary, CheckResult, ModelProfile

# Literal type for change category (string values for better API documentation)
SnapshotChangeCategoryLiteral = Literal[
    "BREAKING",
    "NON_BREAKING",
    "FORWARD_ONLY",
    "INDIRECT_BREAKING",
    "INDIRECT_NON_BREAKING",
    "METADATA",
]
from vulcan.utils.pydantic import PydanticModel, model_validator
from vulcan.utils.errors import NodeAuditsErrors
from vulcan.utils.concurrency import NodeExecutionFailedError
from vulcan.utils.date import TimeLike, to_timestamp
from sqlglot import exp

if t.TYPE_CHECKING:
    from vulcan.core.plan import Plan
    from vulcan.core.context_diff import ContextDiff
    from vulcan.core.environment import EnvironmentNamingInfo
    from vulcan.core.snapshot import Snapshot
    from vulcan.core.console import Console, QueryExecutionStats
    from vulcan.core.snapshot.definition import Interval
    from vulcan.utils.git import GitClient

ImpactType = Literal["direct", "indirect"]


class ErrorExec(PydanticModel):
    """Unified error model for audit and execution failures."""

    model_config = ConfigDict(exclude_none=True, extra="ignore")

    model_fqn: t.Optional[str] = None  # Fully qualified model name (None if error can't be assigned to a model)
    model_name: t.Optional[str] = None  # Short model name (None if error can't be assigned)
    error_class: str  # Error class name (e.g., "AuditError", "ProgrammingError", "ConnectionError")
    message: str  # Human-readable error message
    is_audit_error: bool = False  # True for audit failures, False for execution errors
    audit_name: t.Optional[str] = None  # Name of the audit that failed (audit errors only)
    audit_failed_rows: t.Optional[int] = None  # Number of rows that failed the audit (audit errors only)
    audit_sql: t.Optional[str] = None  # SQL query that was used for the audit check (audit errors only)
    audit_args: t.Optional[t.Dict[str, t.Any]] = None  # Audit configuration arguments (audit errors only)
    audit_adapter_dialect: t.Optional[str] = None  # SQL dialect of the adapter that ran the audit (audit errors only)

    @staticmethod
    def serialize_audit_args(
        audit_args: t.Optional[t.Dict[str, t.Any]], dialect: t.Optional[str] = None
    ) -> t.Optional[t.Dict[str, t.Any]]:
        """Recursively convert sqlglot expressions in audit_args to serializable strings.
        
        Args:
            audit_args: Dictionary that may contain sqlglot expressions, or None
            dialect: Optional SQL dialect for converting expressions to strings
            
        Returns:
            Dictionary with sqlglot expressions converted to strings, or None if input was None
        """
        if audit_args is None or not audit_args:
            return audit_args
        
        def _serialize_value(value: t.Any) -> t.Any:
            """Recursively serialize a value, converting sqlglot expressions to strings."""
            if isinstance(value, exp.Expression):
                # Convert sqlglot expression to SQL string
                return value.sql(dialect=dialect) if dialect else value.sql()
            elif isinstance(value, dict):
                # Recursively process nested dictionaries
                return {k: _serialize_value(v) for k, v in value.items()}
            elif isinstance(value, (list, tuple)):
                # Recursively process lists/tuples
                serialized_list = [_serialize_value(item) for item in value]
                # Preserve tuple type if original was a tuple
                return tuple(serialized_list) if isinstance(value, tuple) else serialized_list
            else:
                # Keep primitive types as-is
                return value
        
        serialized = {}
        for key, value in audit_args.items():
            serialized[key] = _serialize_value(value)
        
        return serialized

    @model_validator(mode="before")
    @classmethod
    def _serialize_audit_args_on_init(cls, data: t.Any) -> t.Any:
        """Serialize audit_args before model creation using audit_adapter_dialect if provided."""
        if isinstance(data, dict):
            # Get dialect from audit_adapter_dialect field
            dialect = data.get("audit_adapter_dialect")
            
            # Serialize audit_args if present and contains sqlglot expressions
            if "audit_args" in data and data["audit_args"] is not None:
                data["audit_args"] = cls.serialize_audit_args(data["audit_args"], dialect=dialect)
        
        return data


class EnvironmentChange(PydanticModel):
    """Represents changes in a single environment since a timestamp.
    
    Used by watchers to determine if an environment needs full rebuild (has_plan=True)
    or incremental update (has_run=True with has_plan=False).
    """

    environment: str

    # True if any plans occurred (triggers full API EnvContext rebuild)
    has_plan: bool = False

    # True if any runs occurred (triggers incremental update when has_plan=False)
    has_run: bool = False


class ModelLatestAction(PydanticModel):
    """Latest plan and run information for a model."""

    model_name: str

    # Plan information (nullable - model may not have a plan yet)
    plan_id: t.Optional[str] = None
    plan_start_ts: t.Optional[int] = None  # When plan application started (Unix ms)
    plan_end_ts: t.Optional[int] = None    # When plan application ended (Unix ms)
    impact_type: t.Optional[ImpactType] = None  # 'direct' or 'indirect'

    # Run information (nullable - model may not have a run yet)
    run_id: t.Optional[str] = None
    run_start_ts: t.Optional[int] = None  # When execution started (Unix ms)
    run_end_ts: t.Optional[int] = None    # When execution ended (Unix ms)
    rows_affected: t.Optional[int] = None
    bytes_processed: t.Optional[int] = None
    evaluation_ms: t.Optional[int] = None
    
    # Success status
    success: t.Optional[bool] = None

    @property
    def plan_duration(self) -> t.Optional[int]:
        """Plan application duration in milliseconds."""
        if self.plan_start_ts and self.plan_end_ts:
            return self.plan_end_ts - self.plan_start_ts
        return None

    @property
    def run_duration(self) -> t.Optional[int]:
        """Run execution duration in milliseconds."""
        if self.run_start_ts and self.run_end_ts:
            return self.run_end_ts - self.run_start_ts
        return None

    @property
    def has_plan(self) -> bool:
        """Whether model has plan information."""
        return self.plan_id is not None

    @property
    def has_run(self) -> bool:
        """Whether model has run information."""
        return self.run_id is not None


class BackfillInfo(PydanticModel):
    """Backfill information for a model."""

    model_config = ConfigDict(extra="ignore")

    name: str  # Display name (e.g., "users")
    fqn: str  # Fully qualified name (e.g., "db.schema.users")
    node_type: NodeType  # MODEL, AUDIT, SEED, etc.
    snapshot_id: str  # Unique snapshot identifier
    version: str  # Snapshot version hash
    model_kind: t.Optional[ModelKindName] = None  # Model type (INCREMENTAL, VIEW, etc.)
    intervals: Intervals  # Time intervals to backfill
    is_directly_modified: bool = False  # True if directly changed, False if indirect/cascade

    @property
    def merged_intervals(self) -> Intervals:
        from vulcan.core.snapshot.definition import merge_intervals

        return merge_intervals(self.intervals)

    def format_intervals(self, unit: t.Optional[str] = None) -> str:
        """Format as '[full refresh]', '[2025-06-30 - 2025-07-06]', etc."""
        from vulcan.core.snapshot.definition import format_intervals

        return format_intervals(self.merged_intervals, unit)

    @classmethod
    def from_plan(
        cls,
        plan: "Plan",
        default_catalog: t.Optional[str] = None,
    ) -> t.List["BackfillInfo"]:
        """Build list of BackfillInfo from Plan missing_intervals.
        
        Args:
            plan: The plan containing missing_intervals and context_diff
            default_catalog: Default catalog name for display name generation
            
        Returns:
            List of BackfillInfo objects for snapshots requiring backfill
        """
        context_diff = plan.context_diff
        environment_naming_info = plan.environment_naming_info
        backfills = []

        for snapshot_intervals in plan.missing_intervals or []:
            snapshot_id = snapshot_intervals.snapshot_id
            if not snapshot_intervals.intervals or snapshot_id not in context_diff.snapshots:
                continue

            snapshot = context_diff.snapshots[snapshot_id]
            is_directly_modified = (
                snapshot.name in context_diff.modified_snapshots
                and context_diff.directly_modified(snapshot.name)
            )

            # Build BackfillInfo fields
            name = plan.get_snapshot_display_name(snapshot, default_catalog)
            model_kind = snapshot.model_kind_name if snapshot.node_type == NodeType.MODEL else None

            backfills.append(
                cls(
                    name=name,
                    fqn=snapshot.name,
                    node_type=snapshot.node_type,
                    snapshot_id=snapshot.identifier,
                    version=snapshot.version,
                    model_kind=model_kind,
                    intervals=snapshot_intervals.intervals,
                    is_directly_modified=is_directly_modified,
                )
            )

        return backfills


class ChangeDisplay(PydanticModel):
    """Base change information with full node details."""

    model_config = ConfigDict(extra="ignore")

    name: str  # Display name (e.g., "users")
    fqn: str  # Fully qualified name (e.g., "db.schema.users")
    snapshot_id: str  # Unique snapshot identifier
    version: str  # Snapshot version hash
    node_type: NodeType  # MODEL, AUDIT, SEED, etc.
    model_kind: t.Optional[ModelKindName] = None  # Model type (INCREMENTAL, VIEW, etc.)
    parents: t.Set[str] = Field(default_factory=set)  # Parent node names (within modified set)


class ChangeDirect(ChangeDisplay):
    """Directly modified node with full change details and nested relationships."""

    diff: str  # SQL/text diff
    indirect: t.List[ChangeDisplay] = Field(default_factory=list)  # Indirect children (nested)
    direct: t.List[ChangeDisplay] = Field(default_factory=list)  # Direct children (nested)
    change_category: t.Optional[SnapshotChangeCategoryLiteral] = None
    
    # Additional metadata from ModifiedNode
    data_hash_changed: bool = False
    metadata_hash_changed: bool = False
    parent_data_hash_changed: bool = False
    old_version: str = ""
    old_snapshot_id: str = ""
    schema_diff: t.Optional["SchemaDrift"] = None
    needs_backfill: bool = False


class ChangeIndirect(ChangeDisplay):
    """Indirectly affected node."""

    change_category: t.Optional[SnapshotChangeCategoryLiteral] = None
    needs_backfill: bool = False


class ChangeAdded(ChangeDisplay):
    """Newly added node."""
    pass


class ChangeRemoved(ChangeDisplay):
    """Removed node."""
    pass


class ModelsDiff(PydanticModel):
    """Unified hierarchical change structure for a plan.
    
    Replaces flat lists (added, removed, modified, downstream) with a structured
    hierarchy that includes nested relationships and rich metadata.
    """

    model_config = ConfigDict(extra="ignore")

    direct: t.List[ChangeDirect] = Field(default_factory=list)  # Directly modified nodes
    indirect: t.List[ChangeIndirect] = Field(default_factory=list)  # Indirectly affected nodes
    added: t.List[ChangeAdded] = Field(default_factory=list)  # Newly added nodes
    removed: t.List[ChangeRemoved] = Field(default_factory=list)  # Removed nodes
    metadata: t.List[ChangeDisplay] = Field(default_factory=list)  # Metadata-only changes

    @classmethod
    def from_plan(
        cls,
        plan: "Plan",
        default_catalog: t.Optional[str] = None,
    ) -> "ModelsDiff":
        """Build ModelsDiff from Plan object with full change details.
        
        Args:
            plan: The plan containing context_diff
            default_catalog: Default catalog name for view name generation
            
        Returns:
            ModelsDiff with hierarchical change structure
        """
        from vulcan.core.snapshot.definition import SnapshotId
        
        context_diff = plan.context_diff
        environment_naming_info = plan.environment_naming_info
        modified_snapshots = context_diff.modified_snapshots.items()

        def model_kind(snapshot: Snapshot) -> t.Optional[ModelKindName]:
            """Extract model kind for model nodes only."""
            if snapshot.node_type == NodeType.MODEL:
                return snapshot.model_kind_name
            return None

        def _get_parents(
            current: Snapshot, visited: t.Optional[t.Dict[str, t.Set[str]]] = None
        ) -> t.Set[str]:
            """Get parent names that are also in the modified set.
            
            Returns unquoted FQNs to match the format used in ChangeDisplay.fqn.
            """
            # Store FQNs for consistent comparison
            current_fqn = current.name
            visited = visited or {current_fqn: {p.name for p in current.parents}}
            parents: t.Set[str] = set()
            for parent in current.parents:
                parent_fqn = parent.name
                if parent.name not in context_diff.modified_snapshots:
                    continue
                (snapshot, _) = context_diff.modified_snapshots[parent.name]
                parents = (
                    parents
                    | {parent_fqn}
                    | visited.get(parent_fqn, _get_parents(snapshot, visited))
                )
            return parents

        def _build_change_display(
            snapshot: Snapshot,
            parents: t.Set[str],
        ) -> ChangeDisplay:
            """Build base ChangeDisplay from snapshot."""
            return ChangeDisplay(
                name=plan.get_snapshot_display_name(snapshot, default_catalog),
                fqn=snapshot.name,
                snapshot_id=snapshot.identifier,
                version=snapshot.version,
                node_type=snapshot.node_type,
                model_kind=model_kind(snapshot),
                parents=parents,
            )

        # Build change lists
        metadata: t.List[ChangeDisplay] = []
        direct: t.List[ChangeDirect] = []
        indirect: t.List[ChangeIndirect] = []
        added: t.List[ChangeAdded] = []
        removed: t.List[ChangeRemoved] = []

        # Process modified snapshots
        for name, (current, old_snap) in modified_snapshots:
            parents = _get_parents(current)
            base_change = _build_change_display(current, parents)
            
            if context_diff.directly_modified(name):
                # Build ChangeDirect with full details
                change_direct = ChangeDirect(
                    **base_change.model_dump(),
                    diff=context_diff.text_diff(name) or "",
                    change_category=current.change_category.name if current.change_category else None,
                    data_hash_changed=old_snap.fingerprint.data_hash != current.fingerprint.data_hash if old_snap else False,
                    metadata_hash_changed=old_snap.fingerprint.metadata_hash != current.fingerprint.metadata_hash if old_snap else False,
                    parent_data_hash_changed=old_snap.fingerprint.parent_data_hash != current.fingerprint.parent_data_hash if old_snap else False,
                    old_version=old_snap.version or "" if old_snap else "",
                    old_snapshot_id=old_snap.identifier if old_snap else "",
                    schema_diff=context_diff.schema_diff(name),
                    needs_backfill=current.is_new_version,
                )
                direct.append(change_direct)
            elif context_diff.indirectly_modified(name):
                # Build ChangeIndirect
                change_indirect = ChangeIndirect(
                    **base_change.model_dump(),
                    change_category=current.change_category.name if current.change_category else None,
                    needs_backfill=current.is_new_version,
                )
                indirect.append(change_indirect)
            elif context_diff.metadata_updated(name):
                # Metadata-only change
                metadata.append(base_change)

        # Process added snapshots
        for snapshot_id in context_diff.added:
            if snapshot_id in context_diff.snapshots:
                snapshot = context_diff.snapshots[snapshot_id]
                parents = _get_parents(snapshot)
                base_change = _build_change_display(snapshot, parents)
                added.append(ChangeAdded(**base_change.model_dump()))

        # Process removed snapshots (SnapshotTableInfo objects)
        for snapshot_id, snapshot_info in context_diff.removed_snapshots.items():
            # SnapshotTableInfo has: name, identifier (property), version, node_type, kind_name
            name = snapshot_info.display_name(environment_naming_info, default_catalog, dialect=None)
            removed.append(ChangeRemoved(
                name=name,
                fqn=snapshot_info.name,
                snapshot_id=snapshot_info.identifier,
                version=snapshot_info.version or "",
                node_type=snapshot_info.node_type,
                model_kind=snapshot_info.kind_name,  # SnapshotTableInfo has kind_name
                parents=set(),
            ))

        # Build nested relationships: populate direct/indirect children for each ChangeDirect
        # Use FQN for comparison since parents set contains FQNs (from parent.name)
        for change_direct in direct:
            change_direct.indirect = [
                ChangeDisplay(**c.model_dump())
                for c in indirect
                if change_direct.fqn in c.parents
            ]
            change_direct.direct = [
                ChangeDisplay(**c.model_dump())
                for c in direct
                if change_direct.fqn in c.parents
            ]

        return cls(
            direct=direct,
            indirect=indirect,
            added=added,
            removed=removed,
            metadata=metadata,
        )


class PlanActivity(PydanticModel):
    """Complete plan activity: what changed, what's affected, what needs backfill.
    
    This class is frozen (immutable) - fields cannot be modified after creation.
    To create a modified version, use model_copy() with update parameters.
    
    Changes are represented hierarchically via ModelsDiff, which includes:
    - direct: Directly modified nodes with full details and nested relationships
    - indirect: Indirectly affected nodes
    - added: Newly added nodes
    - removed: Removed nodes
    - metadata: Metadata-only changes
    """

    model_config = ConfigDict(extra="ignore", frozen=True)

    plan_id: str  # Unique plan identifier
    environment: str  # Environment name (e.g., "prod", "dev")
    start_ts: int  # Plan application start time (Unix timestamp in milliseconds)
    end_ts: int  # Plan application end time (Unix timestamp in milliseconds)
    executor: str = "unknown"  # Username who executed the plan
    git_commit_sha: t.Optional[str] = None  # Git commit SHA (if in a git repo)
    git_commit_url: t.Optional[str] = None  # Clickable commit URL for the current remote
    prev_plan_id: t.Optional[str] = None  # Previous plan ID (for lineage tracking)
    plan_seq: int = 0  # Sequential number per environment (1, 2, 3...)
    version: str = c.DEFAULT_VERSION  # Data product SemVer at apply time (persisted in ``plan_diff`` JSON)
    requirements_diff: t.Optional[str] = None  # ndiff of Python deps vs prior env (when present)
    env_statements_diff: t.Optional[str] = None  # SQL/Python env statement ndiffs (when present)

    # Unified hierarchical change structure (replaces added/removed/modified/downstream)
    changes: ModelsDiff = Field(default_factory=ModelsDiff)
    
    backfills: t.List[BackfillInfo] = Field(default_factory=list)  # Models requiring backfill
    errors: t.List[ErrorExec] = Field(
        default_factory=list
    )  # All errors (audit + execution) that occurred during plan application
    success: bool = True  # True if plan applied successfully, False otherwise

    @property
    def apply_duration_ts(self) -> float:
        """Total plan application duration in milliseconds."""
        return float(self.end_ts - self.start_ts)

    @property
    def has_changes(self) -> bool:
        """Whether this plan has any changes."""
        req_note = (self.requirements_diff or "").strip()
        env_note = (self.env_statements_diff or "").strip()
        return bool(
            self.changes.direct
            or self.changes.indirect
            or self.changes.added
            or self.changes.removed
            or self.changes.metadata
            or self.backfills
            or req_note
            or env_note
        )

    @property
    def has_breaking_changes(self) -> bool:
        """Has breaking changes (direct or indirect)."""
        for change in self.changes.direct:
            if change.change_category in ("BREAKING", "INDIRECT_BREAKING"):
                return True
        for change in self.changes.indirect:
            if change.change_category == "INDIRECT_BREAKING":
                return True
        return False

    @property
    def requires_backfill(self) -> bool:
        """Has any backfills."""
        return len(self.backfills) > 0

    @property
    def models_affected_directly(self) -> t.List[str]:
        """List of model names directly affected by this plan (added, modified, removed)."""
        models = set()
        for change in self.changes.direct + self.changes.added + self.changes.removed:
            if change.node_type == NodeType.MODEL:
                models.add(change.name)
        return sorted(models)

    @property
    def models_affected_indirectly(self) -> t.List[str]:
        """List of model names indirectly affected by this plan (downstream impacts)."""
        models = set()
        for change in self.changes.indirect:
            if change.node_type == NodeType.MODEL:
                models.add(change.name)
        return sorted(models)


class AuditOutcomeItem(PydanticModel):
    """One audit execution outcome for capture / APIs (serializable)."""

    model_config = ConfigDict(extra="ignore")

    audit_name: str
    skipped: bool
    blocking: bool
    failed_row_count: t.Optional[int] = None
    passed: bool
    query_sql: t.Optional[str] = None


class ModelIntervalAudits(PydanticModel):
    """Audit outcomes for one model snapshot and one interval batch."""

    model_config = ConfigDict(extra="ignore")

    model_fqn: str
    model_name: t.Optional[str] = None
    interval_start: t.Optional[str] = None
    interval_end: t.Optional[str] = None
    outcomes: t.List[AuditOutcomeItem] = Field(default_factory=list)


class IntervalExec(PydanticModel):
    """Execution data for a single interval (batch)."""

    model_config = ConfigDict(extra="ignore")

    start_ts: int  # Interval start timestamp (Unix timestamp in seconds)
    end_ts: int  # Interval end timestamp (Unix timestamp in seconds)
    evaluation_ms: int = 0  # Batch SQL evaluation duration in milliseconds
    rows_affected: int  # Number of rows processed in this batch


class ModelExec(PydanticModel):
    """
    Execution data for a single model (pure metrics, no errors).

    Timing Fields Explained:
    - start_ts/end_ts: Wall-clock time (includes all overhead)
    - evaluation_ms: Pure SQL evaluation duration only (sum of all batch SQL durations)

    Example: If a model runs 3 batches with SQL times of 2000ms, 3000ms, 1000ms, plus 5000ms overhead:
    - evaluation_ms = 6000 milliseconds (SQL only)
    - end_ts - start_ts = 11000 milliseconds (total wall-clock)
    - Overhead = 5000 milliseconds (network, Python processing, etc.)
    """

    name: str  # Short model name (e.g., "users")
    fqn: str  # Fully qualified name (e.g., "db.schema.users")
    model_kind: t.Optional[ModelKindName] = None  # Model type (e.g., INCREMENTAL_BY_TIME_RANGE, VIEW, SEED)
    start_ts: int  # Model execution start time (Unix timestamp in seconds)
    end_ts: int = 0  # Model execution end time (Unix timestamp in seconds, 0 if not completed)
    total_batches: int = 0  # Total number of batches/intervals executed
    evaluation_ms: int = 0  # Total SQL evaluation duration across all batches in milliseconds
    rows_affected: int = 0  # Total rows processed across all batches
    bytes_processed: int = 0  # Total bytes processed (if available from engine)
    intervals: t.List[IntervalExec] = Field(default_factory=list)  # Per-batch execution details


class RunActivity(PydanticModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    run_id: str  # Unique run identifier (UUID)
    plan_id: str  # Plan ID that was executed
    environment: str  # Environment name (e.g., "prod", "dev")
    start_ts: int  # Run start time (Unix timestamp in milliseconds)
    end_ts: int  # Run end time (Unix timestamp in milliseconds)
    models_affected: t.List[ModelExec]  # List of all models executed in this run
    errors: t.List[ErrorExec] = Field(default_factory=list)  # All errors (audit + execution) that occurred
    audits: t.List[ModelIntervalAudits] = Field(default_factory=list)
    success: bool  # True if run completed without errors, False otherwise
    run_seq: int = 0  # Sequential number per environment (1, 2, 3...)

    @property
    def run_duration_ts(self) -> float:
        """Total run duration in milliseconds (wall-clock, from Context timing)."""
        return float(self.end_ts - self.start_ts)

    @property
    def total_evaluation_ms(self) -> int:
        """Sum of all model evaluation durations (SQL only) in milliseconds."""
        return sum(m.evaluation_ms for m in self.models_affected)

    @property
    def parallelism_factor(self) -> t.Optional[float]:
        """Parallelism achieved (>1 means parallel execution)."""
        if self.run_duration_ts == 0:
            return None
        return self.total_evaluation_ms / self.run_duration_ts

    @property
    def rows_affected(self) -> int:
        """Total rows affected across all models."""
        return sum(m.rows_affected for m in self.models_affected)

    @property
    def bytes_processed(self) -> int:
        """Total bytes processed across all models."""
        return sum(m.bytes_processed for m in self.models_affected)
    

class RunActivityWithChecksAndProfile(RunActivity):
    quality: t.List[CheckResult] = Field(
        default_factory=list,
        description="Quality check results.",
    )

    profile: t.List[ModelProfile] = Field(
        default_factory=list,
        description="Profile metrics",
    )

    def is_healthy(self) -> bool:
        if not self.quality:
            return True  # Default to healthy if no checks
        for check_result in self.quality:
            if check_result.outcome == CheckOutcome.FAIL:
                return False
        return True


def build_run_activity(
    run_id: str,
    plan_id: str,
    environment: str,
    start_ts: int,
    end_ts: int,
    models: t.List[ModelExec],
    errors: t.List[ErrorExec],
    success: bool,
    audits: t.Optional[t.List[ModelIntervalAudits]] = None,
) -> RunActivity:
    """Build RunActivity from captured console data and context information.

    Args:
        run_id: Unique run identifier
        plan_id: Plan identifier
        environment: Environment name
        start_ts: Unix timestamp when run started (milliseconds)
        end_ts: Unix timestamp when run ended (milliseconds)
        models: List of model executions captured by console
        errors: List of errors captured by console
        success: Whether run completed successfully
        audits: Optional per-interval audit captures from the activity console wrapper

    Returns:
        Complete RunActivity object
    """
    return RunActivity(
        run_id=run_id,
        plan_id=plan_id,
        environment=environment,
        start_ts=start_ts,
        end_ts=end_ts,
        models_affected=models,
        errors=errors,
        audits=audits or [],
        success=success,
    )


def _get_executor() -> str:
    """Get username of person executing the plan."""
    return os.environ.get("SQLMESH_USER", os.environ.get("USER", "unknown"))


def build_plan_activity(
    plan: "Plan",
    start_ts: int,
    end_ts: int,
    git_client: "GitClient",
    default_catalog: t.Optional[str] = None,
    errors: t.Optional[t.List[ErrorExec]] = None,
    success: bool = True,
    version: str = c.DEFAULT_VERSION,
) -> PlanActivity:
    """Build plan activity from Plan object with timing information.

    Args:
        plan: The plan to build activity from
        start_ts: When plan application started (Unix timestamp in milliseconds)
        end_ts: When plan application completed (Unix timestamp in milliseconds)
        git_client: Shared Git client for commit lookups
        default_catalog: Default catalog name (optional)
        errors: List of errors that occurred during plan application (optional)
        success: Whether plan application succeeded (default: True)
        version: Data product SemVer from config at apply time (stored in state ``plan_diff`` JSON).
    """
    context_diff = plan.context_diff
    req_diff: t.Optional[str] = None
    if context_diff.has_requirement_changes:
        req_raw = context_diff.requirements_diff()
        req_diff = req_raw.strip() if req_raw.strip() else None
    env_diff: t.Optional[str] = None
    if context_diff.has_environment_statements_changes:
        env_raw = context_diff.environment_statements_diff_text(
            include_python_env=not context_diff.is_new_environment
        )
        env_diff = env_raw.strip() if env_raw.strip() else None

    # Extract Git commit SHA
    git_commit_sha = None
    git_commit_url = None
    try:
        commit_info = git_client.commit_info()
        git_commit_sha = commit_info.sha
        git_commit_url = commit_info.url
    except Exception:
        pass

    changes = ModelsDiff.from_plan(plan, default_catalog)
    backfills = BackfillInfo.from_plan(plan, default_catalog)

    return PlanActivity(
        plan_id=plan.plan_id,
        environment=plan.environment.name,
        start_ts=start_ts,
        end_ts=end_ts,
        executor=_get_executor(),
        git_commit_sha=git_commit_sha,
        git_commit_url=git_commit_url,
        prev_plan_id=plan.previous_plan_id,
        changes=changes,
        backfills=backfills,
        errors=errors or [],
        success=success,
        version=version,
        requirements_diff=req_diff,
        env_statements_diff=env_diff,
    )


class ActivityCapturingConsoleWrapper:
    """
    Wraps any Console implementation to capture run execution data.

    This is a transparent proxy that:
    - Intercepts key console methods to capture execution metrics
    - Delegates all other methods to the wrapped console
    - Adds get_captured_data() returning models, audits, errors, and success

    Works with any console (TerminalConsole, NoopConsole, etc.) without
    requiring them to implement anything special.

    Usage:
        base_console = get_console()
        capturing_console = ActivityCapturingConsoleWrapper(base_console)
    """

    def __init__(self, wrapped_console: "Console"):
        """
        Initialize wrapper around a console.

        Args:
            wrapped_console: The Console implementation to wrap
        """
        # Use object.__setattr__ to bypass our custom __setattr__ during initialization.
        # This avoids circular dependency since our __setattr__ tries to access self._wrapped,
        # which doesn't exist yet during __init__.
        object.__setattr__(self, "_wrapped", wrapped_console)
        object.__setattr__(self, "_models", {})
        object.__setattr__(self, "_errors", [])
        object.__setattr__(self, "_audits", [])
        object.__setattr__(self, "_run_success", True)

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._wrapped, name)

    def __setattr__(self, name: str, value: t.Any) -> None:
        if name in ("_wrapped", "_models", "_errors", "_audits", "_run_success"):
            object.__setattr__(self, name, value)
        else:
            setattr(self._wrapped, name, value)

    def start_snapshot_evaluation_progress(
        self,
        snapshot: Snapshot,
        audit_only: bool = False,
    ) -> None:
        """Capture model start, then delegate to wrapped console."""
        if snapshot.is_model:
            fqn = snapshot.name  # Fully qualified name (e.g., "db.schema.users")
            name = snapshot.node.name  # Model name (e.g., "users")

            self._models[fqn] = ModelExec(
                name=name,
                fqn=fqn,
                model_kind=snapshot.model_kind_name,
                start_ts=int(time.time()),
            )

        return self._wrapped.start_snapshot_evaluation_progress(snapshot, audit_only)

    def on_audits_completed(
        self,
        snapshot: Snapshot,
        audit_results: t.List[AuditResult],
        *,
        start: t.Optional[TimeLike] = None,
        end: t.Optional[TimeLike] = None,
        adapter_dialect: str = "",
    ) -> None:
        """Record full audit outcomes (before optional ``NodeAuditsErrors``), then delegate."""
        outcomes: t.List[AuditOutcomeItem] = []
        for ar in audit_results:
            if ar.skipped:
                passed = False
            elif ar.count is None:
                passed = False
            else:
                passed = ar.count == 0
            qsql = ar.query.sql(dialect=adapter_dialect) if ar.query is not None else None
            outcomes.append(
                AuditOutcomeItem(
                    audit_name=ar.audit.name,
                    skipped=ar.skipped,
                    blocking=ar.blocking,
                    failed_row_count=ar.count,
                    passed=passed,
                    query_sql=qsql,
                )
            )
        capture = ModelIntervalAudits(
            model_fqn=snapshot.name,
            model_name=snapshot.node.name if snapshot.is_model else None,
            interval_start=str(start) if start is not None else None,
            interval_end=str(end) if end is not None else None,
            outcomes=outcomes,
        )
        self._audits.append(capture)

        summary = "; ".join(
            f"{it.audit_name}:{'skip' if it.skipped else 'pass' if it.passed else f'fail({it.failed_row_count})'}"
            for it in capture.outcomes
        ) or "none"
        _activity_logger.info(
            "[audits] %s | %s [%s..%s] %s",
            capture.model_name or "-",
            capture.model_fqn,
            capture.interval_start or "?",
            capture.interval_end or "?",
            summary,
        )

        return self._wrapped.on_audits_completed(
            snapshot,
            audit_results,
            start=start,
            end=end,
            adapter_dialect=adapter_dialect,
        )

    def update_snapshot_evaluation_progress(
        self,
        snapshot: Snapshot,
        interval: "Interval",
        batch_idx: int,
        evaluation_duration_ms: t.Optional[int],
        num_audits_passed: int,
        num_audits_failed: int,
        audit_only: bool = False,
        execution_stats: t.Optional["QueryExecutionStats"] = None,
        auto_restatement_triggers: t.Optional[t.Any] = None,
    ) -> None:
        """Capture batch metrics, then delegate to wrapped console."""
        if snapshot.is_model:
            fqn = snapshot.name
            model = self._models.get(fqn)

            # Defensive: If model wasn't initialized, skip update
            # (should not happen in normal flow, but guards against unexpected call order)
            if model is not None:
                model.total_batches += 1

                if evaluation_duration_ms:
                    model.evaluation_ms += evaluation_duration_ms

                if execution_stats:
                    if execution_stats.total_rows_processed is not None:
                        model.rows_affected += execution_stats.total_rows_processed
                    if execution_stats.total_bytes_processed is not None:
                        model.bytes_processed += execution_stats.total_bytes_processed

                # Convert interval timestamps to Unix seconds (int)
                # interval is a tuple of date strings or timestamp objects
                interval_exec = IntervalExec(
                    start_ts=int(to_timestamp(interval[0])) if interval else 0,
                    end_ts=int(to_timestamp(interval[1])) if interval else 0,
                    evaluation_ms=evaluation_duration_ms if evaluation_duration_ms else 0,
                    rows_affected=(
                        execution_stats.total_rows_processed
                        if execution_stats and execution_stats.total_rows_processed is not None
                        else 0
                    ),
                )
                model.intervals.append(interval_exec)
                model.end_ts = int(time.time())

        return self._wrapped.update_snapshot_evaluation_progress(
            snapshot,
            interval,
            batch_idx,
            evaluation_duration_ms,
            num_audits_passed,
            num_audits_failed,
            audit_only,
            execution_stats,
            auto_restatement_triggers,
        )

    def stop_evaluation_progress(self, success: bool = True) -> None:
        """Capture final status, then delegate to wrapped console."""
        self._run_success = success
        return self._wrapped.stop_evaluation_progress(success)

    def log_failed_models(self, errors: t.List[NodeExecutionFailedError]) -> None:
        """Capture all errors as ErrorExec objects, then delegate to wrapped console."""
        from vulcan.core.snapshot import SnapshotId

        for error in errors:
            # Extract model info (defensive - handles SnapshotId and snapshot objects)
            model_fqn = None
            model_name = None

            if isinstance(error.node, SnapshotId):
                model_fqn = error.node.name
            elif hasattr(error.node, "snapshot_name"):
                model_fqn = error.node.snapshot_name

            if model_fqn and model_fqn in self._models:
                model_name = self._models[model_fqn].name

            if isinstance(error.__cause__, NodeAuditsErrors):
                # Create ErrorExec for each audit failure
                for audit_error in error.__cause__.errors:
                    exec_error = ErrorExec(
                        model_fqn=model_fqn,
                        model_name=model_name,
                        error_class="AuditError",
                        message=str(audit_error),  # "audit_name audit error: N rows failed"
                        is_audit_error=True,
                        audit_name=audit_error.audit_name,
                        audit_failed_rows=audit_error.count,
                        audit_sql=audit_error.query.sql() if audit_error.query else None,
                        audit_args=audit_error.audit_args,
                        audit_adapter_dialect=audit_error.adapter_dialect,
                    )
                    self._errors.append(exec_error)
            else:
                # Create ErrorExec for execution failure
                cause = error.__cause__ if error.__cause__ else error
                error_msg = str(cause)

                # Truncate very long error messages
                if len(error_msg) > 2000:
                    error_msg = error_msg[:2000] + "... (truncated)"

                exec_error = ErrorExec(
                    model_fqn=model_fqn,
                    model_name=model_name,
                    error_class=cause.__class__.__name__,
                    message=error_msg,
                    is_audit_error=False,
                )
                self._errors.append(exec_error)

        # Update run success flag
        if errors:
            self._run_success = False

        return self._wrapped.log_failed_models(errors)

    def get_captured_data(
        self,
    ) -> t.Tuple[
        t.List[ModelExec],
        t.List[ModelIntervalAudits],
        t.List[ErrorExec],
        bool,
    ]:
        """Return captured execution data: (models, audits, errors, success)."""
        models = list(self._models.values())
        audits = list(self._audits)
        errors = list(self._errors)
        return (
            models,
            audits,
            errors,
            self._run_success,
        )
