"""Utility functions for parameter placeholder conversion using SQLParams."""
from __future__ import annotations

import logging
import typing as t
import re

from sqlparams import SQLParams


logger = logging.getLogger(__name__)


_NUMERIC_DOLLAR_RE = re.compile(r"\$\d+\b")
_NUMERIC_AT_RE = re.compile(r"(?<!@)@_?\d+\b")
_PYFORMAT_RE = re.compile(r"%\([^)]+\)s")
# Match :name, but avoid ::type casts by ensuring the first : isn't preceded by another :
_NAMED_RE = re.compile(r"(?<!:):([A-Za-z_][A-Za-z0-9_]*)\b")


def _likely_input_style(sql: str, style: str) -> bool:
    """Heuristic to decide whether *sql* likely uses the given placeholder style.

    SQLParams can raise IndexError/ValueError both for missing params AND for style mismatch.
    We only want to raise when the attempted style appears to match the SQL's placeholders.
    """
    if style == "qmark":
        return "?" in sql
    if style == "numeric_dollar":
        return bool(_NUMERIC_DOLLAR_RE.search(sql))
    if style == "numeric_at":
        return bool(_NUMERIC_AT_RE.search(sql))
    if style == "named":
        return bool(_NAMED_RE.search(sql))
    if style == "format":
        return "%s" in sql
    if style == "pyformat":
        return bool(_PYFORMAT_RE.search(sql))
    return False


def _rewrite_numeric_at_to_dollar(sql: str) -> str:
    """Rewrite T-SQL-style numeric parameters (@_1, @1) into SQLParams numeric_dollar ($1).

    Some SQL generators (and some DB backends) emit `@_1` style placeholders. Those are not a
    PEP-249 paramstyle, and most DB-API drivers won't bind them automatically (SQL Server will
    treat them as undeclared scalar variables).
    """

    def _repl(match: re.Match) -> str:
        raw = match.group(0)  # e.g. "@_12" or "@3"
        digits = re.sub(r"\D", "", raw)
        return f"${digits}"

    return _NUMERIC_AT_RE.sub(_repl, sql)


def normalize_query_params(
    input_query: str,
    input_parameters: t.Union[t.Dict[str, t.Any], t.Sequence[t.Any], None],
    output_style: str = "format",
) -> t.Tuple[str, t.Union[t.List[t.Any], t.Dict[str, t.Any], None]]:
    """
    Normalize SQL query parameters using SQLParams.
    
    Converts between placeholder styles (e.g. `?`, `$1`, `:name`, `%(name)s`) and returns
    the query + parameters in the requested *output_style*.
    Uses SQLParams to perform correct placeholder rewriting and parameter re-ordering.
    
    Args:
        input_query: The SQL query with parameters
        input_parameters: The parameters to be used in the query
            - For ? and $ style: list of parameters
            - For :name style: dict of parameter names to values
        output_style: Target output paramstyle (PEP-249): one of
            {"qmark", "numeric", "named", "format", "pyformat"}.
        
    Returns:
        tuple: (normalized_query, normalized_parameters)
            - If no params: (query, None)
            - Otherwise: query rewritten to *output_style* and params converted to the
              appropriate type (list/tuple vs dict) depending on output_style.
            
    Example:
        query = "SELECT * FROM users WHERE name = ?"
        params = ["John"]
        normalize_query_params(query, params, output_style="format")
        ("SELECT * FROM users WHERE name = %s", ["John"])
    """
    # If no parameters provided, return unchanged
    if input_parameters is None:
        return input_query, None
    
    # Convert to requested output_style.
    # Try each input style in order.
    # NOTE: Do not short-circuit on "truthiness" because empty sequences / dicts should still
    # participate in validation (e.g. raise if placeholders exist but params are empty).
    if input_parameters is not None:
        rewritten_query = input_query
        # Handle SQL Server-style numeric variables (`@_1`, `@2`) by rewriting them to `$1`, `$2`
        # so SQLParams can normalize them.
        if _NUMERIC_AT_RE.search(rewritten_query):
            rewritten_query = _rewrite_numeric_at_to_dollar(rewritten_query)

        # Try qmark first if ? is present, otherwise try format first.
        # Include pyformat for cases where the query already uses %(name)s placeholders.
        styles = (
            ["qmark", "format", "numeric_dollar", "named", "pyformat"]
            if "?" in rewritten_query
            else ["format", "numeric_dollar", "qmark", "named", "pyformat"]
        )
        
        for style in styles:
            try:
                # Create a converter with enhanced features
                converter = SQLParams(
                    in_style=style,
                    out_style=output_style,
                    # Escape % in SQL to prevent format string issues
                    escape_char="%",
                    # Expand tuples for IN clauses
                    expand_tuples=True,
                    # Strip SQL comments to prevent parameter detection in comments
                    strip_comments=True,
                    # Allow parameters in quoted strings
                    allow_out_quotes=True,
                )
                
                # Try to format with input parameters
                output_sql, output_params = converter.format(rewritten_query, input_parameters)
                
                # If the query was modified or parameters were found, we found our style
                if output_sql != rewritten_query or output_params:
                    return output_sql, output_params
                    
            except (IndexError, ValueError) as e:
                # IndexError/ValueError from SQLParams can indicate:
                # - style mismatch (try next style), or
                # - missing/invalid parameters for the actual placeholder style (raise).
                logger.debug(f"Parameter error with style {style}: {e}", exc_info=True)
                if _likely_input_style(rewritten_query, style):
                    raise
                continue
            except Exception as e:
                # If an error was raised, try next style
                logger.debug(f"Style {style} didn't match: {e}", exc_info=True)
                continue
    
    # If we get here, no style matched
    # Pass through unchanged
    return input_query, input_parameters

