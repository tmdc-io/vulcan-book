from __future__ import annotations

import logging
import os
import smtplib
import sys
import typing as t
from datetime import datetime, timezone
from email.message import EmailMessage

import requests
from pydantic import Field, SecretStr
from pydantic.functional_validators import BeforeValidator

from vulcan.core.console import Console, get_console
from vulcan.integrations import slack, teams
from vulcan.utils.errors import (
    ApiClientError,
    AuditError,
    ConfigError,
    MissingDependencyError,
    raise_for_status,
)
from vulcan.utils.pydantic import PydanticModel, model_validator
from vulcan.core.notification import (
    ApplyEndPayload,
    ApplyFailurePayload,
    ApplyStartPayload,
    AuditFailurePayload,
    DqEndPayload,
    DqStartPayload,
    MigrationEndPayload,
    MigrationFailurePayload,
    MigrationStartPayload,
    NotificationEvent,
    NotificationPayload,
    NotificationStatus,
    PlanChangePayload,
    RunEndPayload,
    RunFailurePayload,
    RunStartPayload,
)


logger = logging.getLogger(__name__)

if t.TYPE_CHECKING:
    from slack_sdk import WebClient, WebhookClient


def _vulcan_version() -> str:
    try:
        from vulcan import __version__

        return __version__
    except ImportError:
        return "0.0.0"


def _text_detail_from_payload(msg: str, payload: NotificationPayload) -> str:
    if isinstance(payload, (RunFailurePayload, ApplyFailurePayload, MigrationFailurePayload)):
        return f"{msg}\n{payload.exc}"
    if isinstance(payload, AuditFailurePayload):
        model_name = payload.model_name or "unknown"
        row_label = "row" if payload.count == 1 else "rows"
        return (
            f"{msg}\n"
            f"'{payload.audit_name}' audit error: {payload.count} {row_label} failed "
            f"on model '{model_name}'"
        )
    return msg


def _apply_str_env_defaults(data: dict[str, t.Any], *field_env_pairs: tuple[str, str]) -> None:
    for field, env_key in field_env_pairs:
        if not data.get(field) and (v := os.getenv(env_key, "").strip()):
            data[field] = v


def _parse_notify_on(value: t.Any) -> t.FrozenSet[NotificationEvent]:
    if isinstance(value, str):
        if value == "*":
            return frozenset(NotificationEvent)
        raise ValueError("notify_on must contain valid notification events")

    if isinstance(value, list):
        if not value:
            return frozenset()
        return frozenset(
            event if isinstance(event, NotificationEvent) else NotificationEvent(event)
            for event in value
        )

    raise ValueError("notify_on must contain valid notification events")


# Config accepts '*' (all events) or a list of event names; stored as a frozenset.
NotifyOn = t.Annotated[t.FrozenSet[NotificationEvent], BeforeValidator(_parse_notify_on)]


class BaseNotificationTarget(PydanticModel, frozen=True):
    """
    Base notification target model. Provides a command for sending notifications that is currently only used
    by the built-in scheduler.

    Notification functions follow a naming convention of `notify_` + NotificationEvent value.
    """

    type_: str
    notify_on: NotifyOn = frozenset()

    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        """Send a notification.

        Text targets use ``msg`` and may append detail from ``payload``. Structured
        targets override this method and consume ``event``, ``payload``, and ``msg`` as
        the CloudEvents/DB summary.

        Args:
            notification_status: The status of the notification.
            msg: Human-readable message; also used as the structured summary.
            event: Notification event name for structured delivery.
            payload: Structured event payload for CloudEvents/DB persistence.
        """

    def notify_apply_start(self, environment: str, plan_id: str, **kwargs: t.Any) -> None:
        """Notify when an apply starts.

        Args:
            environment: The target environment of the plan.
            plan_id: plan_id that is being applied.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.INFO,
            f"Plan `{plan_id}` apply started for environment `{environment}`.",
            event=NotificationEvent.APPLY_START,
            payload=ApplyStartPayload(environment=environment, plan_id=plan_id, extras=kwargs),
        )

    def notify_apply_end(self, environment: str, plan_id: str, **kwargs: t.Any) -> None:
        """Notify when an apply ends.

        Args:
            environment: The target environment of the plan.
            plan_id: plan_id that was applied.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.SUCCESS,
            f"Plan `{plan_id}` apply finished for environment `{environment}`.",
            event=NotificationEvent.APPLY_END,
            payload=ApplyEndPayload(environment=environment, plan_id=plan_id, extras=kwargs),
        )

    def notify_run_start(self, environment: str, run_id: str, **kwargs: t.Any) -> None:
        """Notify when a Vulcan run starts.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.INFO,
            f"Vulcan run `{run_id}` started for environment `{environment}`.",
            event=NotificationEvent.RUN_START,
            payload=RunStartPayload(environment=environment, run_id=run_id, extras=kwargs),
        )

    def notify_run_end(self, environment: str, run_id: str, **kwargs: t.Any) -> None:
        """Notify when a Vulcan run ends.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.SUCCESS,
            f"Vulcan run `{run_id}` finished for environment `{environment}`.",
            event=NotificationEvent.RUN_END,
            payload=RunEndPayload(environment=environment, run_id=run_id, extras=kwargs),
        )

    def notify_run_failure(
        self, environment: str, run_id: str, exc: str, **kwargs: t.Any
    ) -> None:
        """Notify in the case of a run failure.

        Args:
            environment: The target environment of the run.
            run_id: The run identifier.
            exc: The exception stack trace.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.FAILURE,
            f"Vulcan run `{run_id}` failed for environment `{environment}`.",
            event=NotificationEvent.RUN_FAILURE,
            payload=RunFailurePayload(
                environment=environment, run_id=run_id, exc=exc, extras=kwargs
            ),
        )

    def notify_migration_start(self, **kwargs: t.Any) -> None:
        """Notify when a Vulcan migration starts.

        Args:
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.INFO,
            "Vulcan migration started.",
            event=NotificationEvent.MIGRATION_START,
            payload=MigrationStartPayload(extras=kwargs),
        )

    def notify_migration_end(self, **kwargs: t.Any) -> None:
        """Notify when a Vulcan migration ends.

        Args:
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.SUCCESS,
            "Vulcan migration finished.",
            event=NotificationEvent.MIGRATION_END,
            payload=MigrationEndPayload(extras=kwargs),
        )

    def notify_apply_failure(
        self, environment: str, plan_id: str, exc: str, **kwargs: t.Any
    ) -> None:
        """Notify in the case of an apply failure.

        Args:
            environment: The target environment of the run.
            plan_id: The plan id of the failed apply
            exc: The exception stack trace.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.FAILURE,
            f"Plan `{plan_id}` in environment `{environment}` apply failed.",
            event=NotificationEvent.APPLY_FAILURE,
            payload=ApplyFailurePayload(
                environment=environment, plan_id=plan_id, exc=exc, extras=kwargs
            ),
        )

    def notify_audit_failure(
        self,
        audit_error: AuditError,
        *,
        run_id: t.Optional[str] = None,
        plan_id: t.Optional[str] = None,
        environment: t.Optional[str] = None,
        **kwargs: t.Any,
    ) -> None:
        """Notify in the case of an audit failure.

        Args:
            audit_error: The audit error.
            run_id: Run identifier when the audit ran inside a Vulcan run.
            plan_id: Plan identifier when the audit ran during plan apply.
            environment: Target environment name.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.FAILURE,
            "Audit failure.",
            event=NotificationEvent.AUDIT_FAILURE,
            payload=AuditFailurePayload(
                audit_name=audit_error.audit_name,
                model_name=audit_error.model_name,
                count=audit_error.count,
                audit_sql=audit_error.sql(pretty=True),
                run_id=run_id,
                plan_id=plan_id,
                environment=environment,
                extras=kwargs,
            ),
        )

    def notify_migration_failure(self, exc: str, **kwargs: t.Any) -> None:
        """Notify in the case of a migration failure.

        Args:
            exc: The exception stack trace.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.FAILURE,
            "Vulcan migration failed.",
            event=NotificationEvent.MIGRATION_FAILURE,
            payload=MigrationFailurePayload(exc=exc, extras=kwargs),
        )

    def notify_plan_change(
        self,
        environment: str,
        plan_id: str,
        added: int,
        modified: int,
        removed: int,
        directly_modified: t.List[str],
        downstream_affected: int,
        has_breaking_changes: bool,
        requires_backfill: bool,
        **kwargs: t.Any,
    ) -> None:
        """Notify when a plan introduces code/data changes.
        
        Only fired when plan_diff.has_changes == True.
        
        Args:
            environment: The target environment.
            plan_id: Plan identifier.
            added: Number of new models/audits/checks added.
            modified: Number of models modified (total).
            removed: Number of models removed.
            directly_modified: List of directly modified model names (not FQN).
            downstream_affected: Number of models indirectly affected.
            has_breaking_changes: Whether plan contains breaking changes.
            requires_backfill: Whether plan requires data backfill.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        # Build change summary
        total_changes = added + modified + removed
        msg = (
            f"Plan Change Applied\n"
            f"Environment: {environment} | Plan: {plan_id}\n\n"
            f"Summary: {total_changes} total changes\n"
            f"  - Added: {added}\n"
            f"  - Modified: {modified}\n"
            f"  - Removed: {removed}\n"
            f"  - Downstream affected: {downstream_affected}\n"
        )
        
        # Add directly modified models
        if directly_modified:
            msg += f"\nDirectly modified:\n"
            for model in directly_modified[:10]:
                msg += f"  - {model}\n"
            if len(directly_modified) > 10:
                msg += f"  ... and {len(directly_modified) - 10} more\n"
        
        # Add warnings for critical changes
        if has_breaking_changes:
            msg += "\n[WARNING] Breaking changes detected\n"
        
        if requires_backfill:
            msg += "[INFO] Backfills required\n"

        self.send(
            NotificationStatus.SUCCESS,
            msg,
            event=NotificationEvent.PLAN_CHANGE,
            payload=PlanChangePayload(
                environment=environment,
                plan_id=plan_id,
                added=added,
                modified=modified,
                removed=removed,
                directly_modified=directly_modified,
                downstream_affected=downstream_affected,
                has_breaking_changes=has_breaking_changes,
                requires_backfill=requires_backfill,
                extras=kwargs,
            ),
        )

    def _format_check_issues(
        self,
        title: str,
        issues_by_dimension: t.Dict[str, t.List[str]],
        indent: str = "  ",
    ) -> t.List[str]:
        """Format check issues (failures or warnings) by dimension.
        
        Args:
            title: Section title (e.g., "Failures:" or "Warnings:")
            issues_by_dimension: Dimension to list of model names.
            indent: Base indentation (default: 2 spaces). Models get double indent.
            
        Returns:
            List of formatted lines, or empty list if no issues.
        """
        if not issues_by_dimension:
            return []
        
        lines = ["", title]
        for dimension in sorted(issues_by_dimension.keys()):
            models = issues_by_dimension[dimension]
            lines.append(f"{indent}- {dimension}")
            for model in sorted(models):
                lines.append(f"{indent}{indent}→ {model}")
        
        return lines

    def notify_dq_start(
        self,
        run_id: str,
        environment: str,
        model_count: int,
        **kwargs: t.Any,
    ) -> None:
        """Notify when a data quality scan starts.
        
        Args:
            run_id: Run identifier.
            environment: Target environment.
            model_count: Number of models with DQ suites.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        self.send(
            NotificationStatus.INFO,
            f"Data quality scan started for run `{run_id}` in environment `{environment}` "
            f"({model_count} models).",
            event=NotificationEvent.DQ_START,
            payload=DqStartPayload(
                run_id=run_id,
                environment=environment,
                model_count=model_count,
                extras=kwargs,
            ),
        )

    def notify_dq_end(
        self,
        run_id: str,
        environment: str,
        total_checks: int,
        passed: int,
        failed: int,
        warned: int,
        not_evaluated: int,
        model_count: int,
        pass_rate: float,
        failures_by_dimension: t.Dict[str, t.List[str]],
        warnings_by_dimension: t.Dict[str, t.List[str]],
        **kwargs: t.Any,
    ) -> None:
        """Notify when a data quality scan completes.
        
        Args:
            run_id: Run identifier.
            environment: Target environment.
            total_checks: Total number of checks executed.
            passed: Number of passed checks.
            failed: Number of failed checks.
            warned: Number of warned checks.
            not_evaluated: Number of checks that couldn't be evaluated.
            model_count: Number of models checked.
            pass_rate: Pass rate percentage (0-100).
            failures_by_dimension: Dimension to list of failed model names.
            warnings_by_dimension: Dimension to list of warned model names.
            **kwargs: Ad-hoc fields stored under ``payload.extras``.
        """
        title = "Data Quality Failures" if failed > 0 else "Data Quality Scan Complete"
        lines = [
            "\n\n"
            f"{title}",
            f"Run: {run_id} | Environment: {environment}",
            "",
            f"Summary: {total_checks} checks executed",
            f"  - Passed: {passed}",
        ]
        
        if failed > 0:
            lines.append(f"  - Failed: {failed}")
        if warned > 0:
            lines.append(f"  - Warned: {warned}")
        if not_evaluated > 0:
            lines.append(f"  - Not evaluated: {not_evaluated}")
        
        lines.extend([
            "",
            f"Models checked: {model_count}",
            f"Score: {pass_rate:.2f}%",
        ])
        
        # Add failures and warnings by dimension
        lines.extend(self._format_check_issues("Failures:", failures_by_dimension))
        lines.extend(self._format_check_issues("Warnings:", warnings_by_dimension))
        
        if failed > 0:
            status = NotificationStatus.FAILURE
        elif warned > 0:
            status = NotificationStatus.WARNING
        else:
            status = NotificationStatus.SUCCESS

        self.send(
            status,
            "\n".join(lines),
            event=NotificationEvent.DQ_END,
            payload=DqEndPayload(
                run_id=run_id,
                environment=environment,
                total_checks=total_checks,
                passed=passed,
                failed=failed,
                warned=warned,
                not_evaluated=not_evaluated,
                model_count=model_count,
                pass_rate=pass_rate,
                failures_by_dimension=failures_by_dimension,
                warnings_by_dimension=warnings_by_dimension,
                extras=kwargs,
            ),
        )

    @property
    def is_configured(self) -> bool:
        return True


class BaseTextBasedNotificationTarget(BaseNotificationTarget):
    """
    A base class for unstructured notification targets (e.g.: console, email, etc.)
    """

    def send_text_message(self, notification_status: NotificationStatus, msg: str) -> None:
        """Send the notification message as text."""

    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        self.send_text_message(
            notification_status,
            _text_detail_from_payload(msg, payload),
        )


class ConsoleNotificationTarget(BaseTextBasedNotificationTarget):
    """
    Example console notification target. Keeping this around for testing purposes.
    """

    type_: t.Literal["console"] = Field(alias="type", default="console")
    _console: t.Optional[Console] = None

    @property
    def console(self) -> Console:
        if not self._console:
            self._console = get_console()
        return self._console

    def send_text_message(self, notification_status: NotificationStatus, msg: str) -> None:
        if notification_status.is_success:
            self.console.log_success(msg)
        elif notification_status.is_failure:
            self.console.log_error(msg)
        else:
            self.console.log_status_update(msg)


class BaseSlackNotificationTarget(BaseNotificationTarget):
    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        status_emoji = {
            NotificationStatus.PROGRESS: slack.SlackAlertIcon.START,
            NotificationStatus.SUCCESS: slack.SlackAlertIcon.SUCCESS,
            NotificationStatus.FAILURE: slack.SlackAlertIcon.FAILURE,
            NotificationStatus.WARNING: slack.SlackAlertIcon.WARNING,
            NotificationStatus.INFO: slack.SlackAlertIcon.INFO,
        }

        composed = slack.message().add_primary_blocks(
            slack.header_block(f"{status_emoji[notification_status]} Vulcan Notification"),
            slack.context_block(f"*Status:* `{notification_status.value}`"),
            slack.divider_block(),
            slack.text_section_block(f"*Message*: {msg}"),
        )

        details = []
        if isinstance(payload, AuditFailurePayload):
            details = [
                slack.fields_section_block(
                    f"*Audit*: `{payload.audit_name}`",
                    f"*Model*: `{payload.model_name}`",
                    f"*Count*: `{payload.count}`",
                ),
            ]
            if payload.audit_sql:
                details.append(slack.preformatted_rich_text_block(payload.audit_sql))
        elif isinstance(payload, (RunFailurePayload, ApplyFailurePayload, MigrationFailurePayload)):
            details = [slack.preformatted_rich_text_block(payload.exc)]

        composed.add_primary_blocks(
            *details,
            slack.divider_block(),
            slack.context_block(
                f"*Vulcan Version:* {_vulcan_version()}", f"*Python Version:* {sys.version}"
            ),
        )

        composed.add_text(msg)

        self._send_slack_message(
            composed=composed.slack_message,
        )

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        """Send a composed message Slack.

        Args:
            composed: the formatted message to send to Slack
        """


class SlackWebhookNotificationTarget(BaseSlackNotificationTarget):
    url: t.Optional[str] = None
    type_: t.Literal["slack_webhook"] = Field(alias="type", default="slack_webhook")
    _client: t.Optional[WebhookClient] = None

    @model_validator(mode="before")
    @classmethod
    def _apply_slack_webhook_env_defaults(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data
        _apply_str_env_defaults(data, ("url", "SLACK_WEBHOOK_URL"))
        return data

    @property
    def client(self) -> WebhookClient:
        if not self._client:
            try:
                from slack_sdk import WebhookClient
            except ModuleNotFoundError as e:
                raise MissingDependencyError(
                    "Missing Slack dependencies. Run `pip install 'vulcan[slack]'` to install them."
                ) from e

            if not self.url:
                raise ConfigError("Missing Slack webhook URL")

            self._client = WebhookClient(url=self.url)
        return self._client

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        self.client.send(
            text=composed["text"],
            blocks=composed["blocks"],
            attachments=composed["attachments"],  # type: ignore
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.url)


class SlackApiNotificationTarget(BaseSlackNotificationTarget):
    token: t.Optional[str] = None
    channel: t.Optional[str] = None
    type_: t.Literal["slack_api"] = Field(alias="type", default="slack_api")
    _client: t.Optional[WebClient] = None

    @model_validator(mode="before")
    @classmethod
    def _apply_slack_api_env_defaults(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data
        _apply_str_env_defaults(data, ("token", "SLACK_API_TOKEN"))
        return data

    @property
    def client(self) -> WebClient:
        if not self._client:
            try:
                from slack_sdk import WebClient
            except ModuleNotFoundError as e:
                raise MissingDependencyError(
                    "Missing Slack dependencies. Run `pip install 'vulcan[slack]'` to install them."
                ) from e

            self._client = WebClient(token=self.token)
        return self._client

    def _send_slack_message(self, composed: slack.TSlackMessage) -> None:
        if not self.channel:
            raise ConfigError("Missing Slack channel for notification")

        self.client.chat_postMessage(
            channel=self.channel,
            text=composed["text"],
            blocks=composed["blocks"],
            attachments=composed["attachments"],  # type: ignore
        )

    @property
    def is_configured(self) -> bool:
        return all((self.token, self.channel))


class BaseTeamsNotificationTarget(BaseNotificationTarget):
    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        composed = teams.build_notification_message(
            status=notification_status,
            msg=msg,
            event=event,
            payload=payload,
        )
        self._post_teams_message(composed)

    def _post_teams_message(self, composed: dict[str, t.Any]) -> None:
        """Post a composed Adaptive Card message to Teams."""


class TeamsWebhookNotificationTarget(BaseTeamsNotificationTarget):
    url: t.Optional[str] = None
    timeout: int = 10
    type_: t.Literal["teams_webhook"] = Field(alias="type", default="teams_webhook")

    @model_validator(mode="before")
    @classmethod
    def _apply_teams_webhook_env_defaults(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data
        _apply_str_env_defaults(data, ("url", "TEAMS_WEBHOOK_URL"))
        return data

    def _post_teams_message(self, composed: dict[str, t.Any]) -> None:
        if not self.url:
            raise ConfigError("Missing Teams webhook URL for notification")

        response = requests.post(self.url, json=composed, timeout=self.timeout)
        raise_for_status(response)

    @property
    def is_configured(self) -> bool:
        return bool(self.url)


class BasicSMTPNotificationTarget(BaseTextBasedNotificationTarget):
    DEFAULT_PORT: t.ClassVar[int] = 465

    host: t.Optional[str] = None
    port: t.Optional[int] = None
    user: t.Optional[str] = None
    password: t.Optional[SecretStr] = None
    sender: t.Optional[str] = None
    recipients: t.Optional[t.FrozenSet[str]] = None
    subject: t.Optional[str] = "Vulcan Notification"
    type_: t.Literal["smtp"] = Field(alias="type", default="smtp")

    @model_validator(mode="before")
    @classmethod
    def _apply_smtp_env_defaults(cls, data: t.Any) -> t.Any:
        if not isinstance(data, dict):
            return data

        _apply_str_env_defaults(
            data,
            ("host", "SMTP_HOST"),
            ("user", "SMTP_USER"),
            ("sender", "SMTP_SENDER"),
        )

        if not data.get("password") and (v := os.getenv("SMTP_PASSWORD", "").strip()):
            data["password"] = v

        if data.get("port") is None and (v := os.getenv("SMTP_PORT", "").strip()):
            try:
                data["port"] = int(v)
            except ValueError as e:
                raise ValueError(f"Invalid SMTP_PORT environment variable: {v!r}") from e

        if data.get("port") is None:
            data["port"] = cls.DEFAULT_PORT

        return data

    def send_text_message(
        self,
        notification_status: NotificationStatus,
        msg: str,
    ) -> None:
        if not self.host:
            raise ConfigError("Missing SMTP host for notification")

        email = EmailMessage()
        email["Subject"] = self.subject
        email["To"] = ",".join(self.recipients or [])
        email["From"] = self.sender
        email.set_content(msg)
        with smtplib.SMTP_SSL(host=self.host, port=self.port or self.DEFAULT_PORT) as smtp:
            if self.user and self.password:
                smtp.login(user=self.user, password=self.password.get_secret_value())
            smtp.send_message(email)

    @property
    def is_configured(self) -> bool:
        return all((self.host, self.user, self.password, self.sender))


class GenericNotificationTarget(BaseNotificationTarget):
    """A generic notification target that can be used to create custom notification targets.

    This target is not meant to be used directly, but rather as a base class for custom notification targets.

    The `send` method should be overridden to provide the actual notification functionality.

    Example:
    ```python
    class MyCustomNotificationTarget(GenericNotificationTarget):
        def send(
            self,
            notification_status: NotificationStatus,
            msg: str,
            *,
            event: NotificationEvent,
            payload: NotificationPayload,
        ) -> None:
            print(f"Sending notification: {msg}")
    ```
    """

    type_: t.Literal["generic"] = Field(alias="type", default="generic")


class CloudEventsNotificationTarget(BaseNotificationTarget):
    """Notification target that forwards structured events as CloudEvents to an HTTP endpoint.

    Inherits ``notify_*`` from ``BaseNotificationTarget`` and overrides ``send`` to POST
    structured records. ``msg`` is used as the CloudEvents ``summary`` field.
    """

    url: str
    source: str = "/vulcan/notifications"
    # Optional extra HTTP headers to send with each request (e.g. auth tokens).
    # Kept as a dict for easy config authoring; __hash__ is overridden to use a hashable view.
    headers: t.Dict[str, str] = Field(default_factory=dict)
    timeout: int = 10
    type_: t.Literal["cloudevents"] = Field(alias="type", default="cloudevents")

    @property
    def is_configured(self) -> bool:
        return True

    def __hash__(self) -> int:  # type: ignore[override]
        """Custom hash so this target can be stored in sets despite dict headers."""
        return hash(
            (
                self.type_,
                self.url,
                self.source,
                self.timeout,
                frozenset(self.notify_on),
                tuple(sorted(self.headers.items())),
            )
        )

    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        self._emit(
            event,
            notification_status,
            payload.model_dump(mode="json", exclude_none=True),
            msg.strip(),
        )

    def _emit(
        self,
        event: NotificationEvent,
        status: NotificationStatus,
        payload: t.Dict[str, t.Any],
        summary: str,
    ) -> None:
        if not self.url:
            # Misconfigured target, fail fast.
            raise ConfigError("Missing CloudEvents notification endpoint URL")

        # Import here to avoid hard dependency at module import time if unused.
        from cloudevents.conversion import to_structured
        from cloudevents.http import CloudEvent

        attributes = {
            "type": f"{event.value}",
            "source": self.source,
            "datacontenttype": "application/json",
            "time": datetime.now(timezone.utc).isoformat(),
        }

        data: t.Dict[str, t.Any] = {
            "status": status.value,
            "event": event.value,
            "summary": summary,
            "payload": payload,
        }

        cloud_event = CloudEvent(attributes, data)
        headers, body = to_structured(cloud_event)

        # Merge user-provided headers without clobbering CloudEvents-required ones.
        if self.headers:
            for key, value in self.headers.items():
                if key not in headers:
                    headers[key] = value

        # requests expects plain dict for headers and bytes for body.
        response = requests.post(self.url, data=body, headers=headers, timeout=self.timeout)
        try:
            # Reuse shared HTTP error handling logic, but keep notifications best-effort.
            raise_for_status(response)
        except ApiClientError as e:
            logger.error(
                "CloudEvents notification failed for event %s: | url: %s | status: %s | payload: %r",
                event.value,
                self.url,
                e.code,
                payload,
            )


class DbNotificationTarget(BaseNotificationTarget):
    type_: t.Literal["state_store"] = Field(alias="type", default="state_store")
    username: t.Optional[str] = None

    @classmethod
    def create(
        cls,
        store_fn: t.Callable[..., None],
        username: t.Optional[str] = None,
    ) -> DbNotificationTarget:
        target = cls(username=username)
        object.__setattr__(target, "_store_fn", store_fn)
        return target

    @property
    def is_configured(self) -> bool:
        return True

    def send(
        self,
        notification_status: NotificationStatus,
        msg: str,
        *,
        event: NotificationEvent,
        payload: NotificationPayload,
    ) -> None:
        payload_dict = payload.model_dump(mode="json", exclude_none=True)
        environment = getattr(payload, "environment", None)
        run_id = getattr(payload, "run_id", None)
        plan_id = getattr(payload, "plan_id", None)
        try:
            self._store_fn(
                event=event,
                status=notification_status,
                summary=msg.strip(),
                payload=payload_dict,
                environment=environment,
                run_id=run_id,
                plan_id=plan_id,
                username=self.username,
            )
        except Exception:
            logger.exception(
                "Failed to persist notification event '%s' to state DB.",
                event.value,
            )

    def __hash__(self) -> int:
        return hash((self.type_, self.username))

    def __eq__(self, other: object) -> bool:
        return isinstance(other, DbNotificationTarget) and self.username == other.username


NotificationTarget = t.Annotated[
    t.Union[
        BasicSMTPNotificationTarget,
        GenericNotificationTarget,
        ConsoleNotificationTarget,
        SlackApiNotificationTarget,
        SlackWebhookNotificationTarget,
        TeamsWebhookNotificationTarget,
        CloudEventsNotificationTarget,
    ],
    Field(discriminator="type_"),
]


class NotificationTargetManager:
    """Wrapper around a list of notification targets.

    Calling a notification target's "notify_" method on this object will call it
    on all registered notification targets.
    """

    def __init__(
        self,
        notification_targets: t.Dict[NotificationEvent, t.Set[NotificationTarget]] | None = None,
        user_notification_targets: t.Dict[str, t.Set[NotificationTarget]] | None = None,
        username: str | None = None,
    ) -> None:
        self.notification_targets = notification_targets or {}
        self.user_notification_targets = user_notification_targets or {}
        self.username = username

    def _deliver(
        self,
        notification_target: NotificationTarget,
        event: NotificationEvent,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        """Invoke one target and log delivery failures without aborting fan-out."""
        try:
            notify_func = self._get_notification_function(notification_target, event)
            notify_func(*args, **kwargs)
        except Exception:
            logger.exception(
                "Notification delivery failed for event '%s' and target type '%s'.",
                event.value,
                notification_target.type_,
            )

    def notify(self, event: NotificationEvent, *args: t.Any, **kwargs: t.Any) -> None:
        """Call the 'notify_`event`' function of all notification targets that care about the event."""
        if self.username:
            self.notify_user(event, self.username, *args, **kwargs)
        else:
            for notification_target in self.notification_targets.get(event, set()):
                self._deliver(notification_target, event, *args, **kwargs)

    def notify_user(
        self, event: NotificationEvent, username: str, *args: t.Any, **kwargs: t.Any
    ) -> None:
        """Call the 'notify_`event`' function of the user's notification targets that care about the event."""
        notification_targets = self.user_notification_targets.get(username, set())
        for notification_target in notification_targets:
            if event in notification_target.notify_on:
                self._deliver(notification_target, event, *args, **kwargs)

    def _get_notification_function(
        self, notification_target: NotificationTarget, event: NotificationEvent
    ) -> t.Callable:
        """Fetch the function for a notification event"""
        return getattr(notification_target, f"notify_{event.value}")
