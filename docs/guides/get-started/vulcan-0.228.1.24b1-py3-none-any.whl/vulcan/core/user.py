import typing as t
from enum import Enum

from vulcan.core.notification_target import (
    BasicSMTPNotificationTarget,
    NotificationTarget,
    SlackApiNotificationTarget,
)
from vulcan.utils.pydantic import PydanticModel, ValidationInfo, field_validator


class UserRole(str, Enum):
    """A role to associate the user with"""

    REQUIRED_APPROVER = "required_approver"

    @property
    def is_required_approver(self) -> bool:
        return self == UserRole.REQUIRED_APPROVER


class User(PydanticModel):
    """Vulcan user information that can be used for notifications"""

    username: str
    """The name to refer to the user"""
    github_username: t.Optional[str] = None
    """The github login username"""
    slack_username: t.Optional[str] = None
    """The slack username"""
    email: t.Optional[str] = None
    """The email for the user (full address)"""
    roles: t.List[UserRole] = []
    """List of roles to associate with the user"""
    notification_targets: t.List[NotificationTarget] = []
    """List of notification targets"""
    type: str = "MEMBER"
    """The type of user"""
    
    @property
    def is_required_approver(self) -> bool:
        """Indicates if this is a required approver for PR approvals."""
        return UserRole.REQUIRED_APPROVER in self.roles

    @field_validator("notification_targets", mode="after")
    def validate_notification_targets(
        cls,
        v: t.List[NotificationTarget],
        info: ValidationInfo,
    ) -> t.List[NotificationTarget]:
        email = info.data.get("email")
        slack_username = info.data.get("slack_username")
        result: t.List[NotificationTarget] = []

        for target in v:
            if isinstance(target, BasicSMTPNotificationTarget):
                # Default omitted SMTP recipients to user.email; explicit recipients may differ.
                if not target.recipients:
                    if not email:
                        raise ValueError(
                            "User email is required when SMTP notification targets omit recipients"
                        )
                    target = target.model_copy(update={"recipients": frozenset([email])})
                # Explicit recipients are allowed to differ from user.email (e.g. work inbox,
                # shared alias). Only the omitted-recipients case above defaults to email.
                # elif target.recipients != {email}:
                #     raise ValueError("Recipient emails do not match user email")
            elif isinstance(target, SlackApiNotificationTarget):
                # Default omitted Slack channel to slack_username; explicit channel may differ.
                if not target.channel:
                    if not slack_username:
                        raise ValueError(
                            "User slack_username is required when Slack API targets omit channel"
                        )
                    target = target.model_copy(update={"channel": slack_username})
            result.append(target)

        return result
