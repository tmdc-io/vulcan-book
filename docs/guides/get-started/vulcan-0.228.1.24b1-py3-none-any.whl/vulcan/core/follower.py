from __future__ import annotations

import typing as t
from enum import Enum

from pydantic import Field

from vulcan.utils.pydantic import PydanticModel


class FollowerGranularity(str, Enum):
    """Time bucket granularity for follower analytics."""

    DAY = "day"
    WEEK = "week"
    MONTH = "month"


class Follower(PydanticModel):
    """Persisted follower row for the current data product."""

    user_id: str
    active: bool
    followed_at: int
    updated_at: int
    metadata: t.Dict[str, t.Any] = Field(default_factory=dict)


class FollowerAnalyticsPeriod(PydanticModel):
    """Active follower count at the end of one analytics bucket."""

    period_start: int
    period_end: int
    active_followers: int


class FollowerAnalyticsPagination(PydanticModel):
    """Pagination metadata for bucket-based analytics."""

    offset: int
    limit: int
    has_more: bool = True


class FollowerAnalytics(PydanticModel):
    """Follower counts and optional bucket-based analytics."""

    total_active: int
    granularity: t.Optional[FollowerGranularity] = None
    offset: t.Optional[int] = None
    limit: t.Optional[int] = None
    series: t.Optional[t.List[FollowerAnalyticsPeriod]] = None
    pagination: t.Optional[FollowerAnalyticsPagination] = None
