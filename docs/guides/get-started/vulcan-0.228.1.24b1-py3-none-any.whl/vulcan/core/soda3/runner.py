from __future__ import annotations

import json
import logging
import re
import types
import typing as t
from datetime import date, datetime

import vulcan.core.soda3  # noqa: F401 — package __init__ patches Soda before imports below

import yaml
from soda.common.log import Log, LogLevel
from soda.execution.check.check import CheckOutcome
from soda.scan import Scan

from vulcan.core import constants as c
from vulcan.core.soda3 import _NAME_ATTR_KEY, _DIMENSION_ATTR_KEY
from vulcan.core.soda3.cloud import SodaStateSyncBackend, SodaStateSyncSampler
from vulcan.core.soda3.spec import (
    CheckExecutionSummary,
    DataQualitySpec,
    ProfileExecutionSummary,
    SchemaProfileResult,
    SchemaStats,
    _table_alias,
    build_sodacl_yaml,
    validate_dq_dimension,
)
from vulcan.utils.date import (
    TimeLike,
    date_dict,
    make_inclusive,
    now_timestamp,
    to_datetime,
)
from vulcan.utils.errors import ConfigError

if t.TYPE_CHECKING:
    from vulcan.core.activity import ModelExec
    from vulcan.core.context import Context
    from vulcan.core.model import Model

logger = logging.getLogger(__name__)

_LOG_LEVEL_TO_PY = {
    LogLevel.ERROR: logging.ERROR,
    LogLevel.WARNING: logging.WARNING,
    LogLevel.INFO: logging.INFO,
    LogLevel.DEBUG: logging.DEBUG,
}


def _sanitize_soda_name(s: str) -> str:
    """Sanitize a string to match Soda's data source name regex: ``^[a-z_][a-z_0-9]+$``."""
    s = s.lower()
    return re.sub(r"[^a-z0-9_]", "_", s)


def _soda_str(value: t.Any) -> str:
    """
    Coerce a Python value to the string form used for Soda scan template variables.

    Datetimes use ISO formatting; ``list`` / ``dict`` / ``tuple`` / ``set`` are JSON-encoded
    (with ``default=str``); other values use ``str()``.

    Args:
        value: Any substitution value destined for ``scan.add_variables``.

    Returns:
        A string safe to pass into Soda's variable map.
    """
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (list, dict, tuple)):
        try:
            return json.dumps(value, default=str, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(value)
    if isinstance(value, set):
        try:
            return json.dumps(sorted(value, key=str), default=str, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(value)
    return str(value)


def _create_soda_data_source_config(
    context: "Context",
    gateway_name: str,
    catalog: t.Optional[str] = None,
    schema: t.Optional[str] = None,
) -> t.Dict[str, t.Any]:
    """
    Build the connection descriptor Soda uses for one warehouse batch (gateway + catalog/schema).

    Args:
        context: Vulcan context (config, connections).
        gateway_name: Gateway to take connection settings from.
        catalog: Optional catalog for the scan's default database.
        schema: Optional schema for the scan's default database.

    Returns:
        A mapping suitable for ``connection.soda_conn_config`` / Spark session wiring.
    """
    gateway_config = context.config.get_gateway(gateway_name)
    connection = gateway_config.connection
    return connection.soda_conn_config(catalog=catalog, schema=schema)


def _build_soda_variables(
    context: "Context",
    gateway_name: str,
    environment: str,
    *,
    execution_time: t.Optional[TimeLike] = None,
    start: t.Optional[TimeLike] = None,
    end: t.Optional[TimeLike] = None,
) -> t.Dict[str, str]:
    """
    Merge date/time and project variables into the dict passed to ``scan.add_variables``.

    Time keys follow model-rendering semantics (inclusive bounds when ``start``/``end`` are set).
    Gateway variables override base date keys; project variables fill remaining names. The active
    ``gateway`` name is always included.

    Args:
        context: Vulcan context.
        gateway_name: Gateway used for dialect, gateway-level variables, and connection.
        environment: Environment name (for debug logging only).
        execution_time: Optional logical execution time; defaults to "now" in the date dict.
        start: Optional interval start (inclusive with ``end`` when both set).
        end: Optional interval end.

    Returns:
        All keys and values as strings, as required by Soda.
    """
    dialect = context.config.get_connection(gateway_name).DIALECT
    gateway_config = context.config.get_gateway(gateway_name)

    start_time, end_time = (
        make_inclusive(start or c.EPOCH, end or c.EPOCH, dialect=dialect)
        if start is not None or end is not None
        else (None, None)
    )

    dd = date_dict(
        to_datetime(execution_time or now_timestamp()),
        start_time,
        end_time,
    )
    gw = gateway_config.variables or {}
    cfg = context.config.variables or {}

    merged: t.Dict[str, t.Any] = {
        **dd,
        **gw,
        "gateway": gateway_name,
        **{k: v for k, v in cfg.items() if k not in {*dd, *gw, "gateway"}},
    }

    result = {key: _soda_str(val) for key, val in merged.items()}
    logger.debug(
        "Soda scan variables (gateway=%r, environment=%r)\n%s\n",
        gateway_name,
        environment,
        yaml.dump(
            {"variables": result},
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=True,
        ).rstrip(),
    )
    return result


def _extract_check_details(check_dict: t.Dict[str, t.Any]) -> t.Dict[str, t.Any]:
    """
    Project a raw Soda check dict into the shape stored in execution summaries and logs.

    Args:
        check_dict: Check payload from ``check.get_dict()`` (Soda internal format).

    Returns:
        Dict with ``name``, ``type``, ``column``, ``definition``, ``outcome_reasons``,
        ``value``, and ``query`` keys for UI and console trees.
    """
    diagnostics = check_dict.get("diagnostics", {})

    return {
        "name": check_dict.get(_NAME_ATTR_KEY, "unnamed"),
        "type": check_dict.get("type", "unknown"),
        "column": check_dict.get("column"),
        "definition": check_dict.get("definition"),
        "outcome_reasons": check_dict.get("outcomeReasons", []),
        "value": diagnostics.get("value"),
        "query": diagnostics.get("query"),
    }


def _build_execution_summary(
    scan: Scan,
    model_name_to_filter_exp: t.Dict[str, t.Optional[str]],
    table_to_model_name: t.Optional[t.Dict[str, str]] = None,
) -> CheckExecutionSummary:
    """
    Aggregate per-check outcomes from a finished scan by model and quality dimension.

    Args:
        scan: Completed Soda ``Scan`` instance.
        model_name_to_filter_exp: Map of logical model name to optional DQ filter expression.
        table_to_model_name: Optional map from Soda table identifier to logical model name.

    Returns:
        ``CheckExecutionSummary`` with nested counts and failed/warned check detail lists.
    """
    results_by_model: t.Dict[str, t.Dict[str, t.Any]] = {}
    table_to_model_name = table_to_model_name or {}
    checks = getattr(scan, "_checks", [])

    for check in checks:
        check_dict = check.get_dict()

        resource_attrs = check_dict.get("resourceAttributes", [])
        attributes = {
            attr["name"]: attr["value"] for attr in resource_attrs if isinstance(attr, dict)
        }

        raw_table = check_dict.get("table")
        model_name = table_to_model_name.get(raw_table) or raw_table or "unknown"

        dimension = validate_dq_dimension(attributes.get(_DIMENSION_ATTR_KEY))
        outcome = check.outcome

        if model_name not in results_by_model:
            filter_expr = model_name_to_filter_exp.get(model_name, None)
            results_by_model[model_name] = {"filter": filter_expr, "dimensions": {}}

        if dimension not in results_by_model[model_name]["dimensions"]:
            results_by_model[model_name]["dimensions"][dimension] = {
                "passed": 0,
                "failed": 0,
                "warned": 0,
                "not_evaluated": 0,
                "failed_checks": [],
                "warned_checks": [],
                "not_evaluated_checks": [],
            }

        dimension_stats = results_by_model[model_name]["dimensions"][dimension]
        if outcome == CheckOutcome.PASS:
            dimension_stats["passed"] += 1
        elif outcome == CheckOutcome.FAIL:
            dimension_stats["failed"] += 1
            dimension_stats["failed_checks"].append(_extract_check_details(check_dict))
        elif outcome == CheckOutcome.WARN:
            dimension_stats["warned"] += 1
            dimension_stats["warned_checks"].append(_extract_check_details(check_dict))
        elif outcome is None:
            dimension_stats["not_evaluated"] += 1
            dimension_stats["not_evaluated_checks"].append(_extract_check_details(check_dict))

    return CheckExecutionSummary(results=results_by_model)


def _merge_check_summaries(
    summaries: t.Optional[t.List[CheckExecutionSummary]],
) -> t.Optional[CheckExecutionSummary]:
    """
    Merge several ``CheckExecutionSummary`` instances (e.g. per-schema runs) into one.

    Args:
        summaries: List of summaries to combine; ``None`` or empty yields no merge.

    Returns:
        A single summary with summed counts and extended check lists, or ``None`` if there
        was nothing to merge, or the sole input if only one summary was provided.
    """
    if not summaries:
        return None
    if len(summaries) == 1:
        return summaries[0]

    merged_results: t.Dict[str, t.Dict[str, t.Any]] = {}

    for summary in summaries:
        for model_name, model_data in summary.results.items():
            merged_model = merged_results.setdefault(
                model_name,
                {
                    "filter": model_data.get("filter"),
                    "dimensions": {},
                },
            )
            merged_dims = merged_model["dimensions"]

            for dim, stats in model_data.get("dimensions", {}).items():
                if dim not in merged_dims:
                    merged_dims[dim] = {
                        "passed": 0,
                        "failed": 0,
                        "warned": 0,
                        "not_evaluated": 0,
                        "failed_checks": [],
                        "warned_checks": [],
                        "not_evaluated_checks": [],
                    }
                target = merged_dims[dim]
                target["passed"] += stats.get("passed", 0)
                target["failed"] += stats.get("failed", 0)
                target["warned"] += stats.get("warned", 0)
                target["not_evaluated"] += stats.get("not_evaluated", 0)
                target["failed_checks"].extend(stats.get("failed_checks", []))
                target["warned_checks"].extend(stats.get("warned_checks", []))
                target["not_evaluated_checks"].extend(
                    stats.get("not_evaluated_checks", [])
                )

    return CheckExecutionSummary(results=merged_results)


def _models_by_fqn_from_environment_snapshots(
    context: "Context",
    environment: str,
    model_execs: t.Sequence["ModelExec"],
) -> t.Dict[str, "Model"]:
    """
    Map snapshot FQN (``snapshot.name``) to ``Model`` for DQ resolution.

    ``Context.get_model`` only searches ``context._models``, which may be empty when the
    context never loaded project files. Snapshots in ``state_sync`` still carry the deployed
    ``Model`` (including ``dq``) for the target environment.

    Args:
        context: Vulcan context (uses ``state_sync``).
        environment: Environment name whose snapshot set should be loaded.
        model_execs: Sequence of :class:`~vulcan.core.activity.ModelExec` rows (uses ``fqn``).

    Returns:
        Map ``me.fqn`` → ``Model`` for snapshots in the environment that match executed FQNs.
    """
    if not model_execs:
        return {}

    exec_fqns = {me.fqn for me in model_execs}

    env = context.state_sync.get_environment(environment)
    if not env:
        logger.debug(
            "[soda3] Environment %r not found in state_sync; skipping snapshot model index",
            environment,
        )
        return {}

    by_fqn: t.Dict[str, "Model"] = {}

    for snapshot in context.state_sync.get_snapshots(env.snapshots).values():
        if not snapshot.is_model:
            continue
        if snapshot.name not in exec_fqns:
            continue
        by_fqn[snapshot.name] = snapshot.model

    return by_fqn


def _collect_batch_results(
    scan: Scan,
    schema_prefix: str,
    schema_profile_results: t.List[SchemaProfileResult],
    prefix_stats: t.Dict[str, SchemaStats],
    table_to_model_name: t.Optional[t.Dict[str, str]] = None,
) -> None:
    """
    Append this scan's column-profile results into shared lists and update per-prefix stats.

    Args:
        scan: Scan after ``execute()`` (must expose ``_profile_columns_result_tables``).
        schema_prefix: Batch key (e.g. ``catalog.schema``).
        schema_profile_results: Mutable list of batch dicts; this call appends one entry.
        prefix_stats: Mutable map from prefix to ``SchemaStats``; updated for ``schema_prefix``.
        table_to_model_name: Optional alias-to-model map for counting distinct tables.

    Returns:
        None (mutates ``schema_profile_results`` and ``prefix_stats`` in place).
    """
    if not hasattr(scan, "_profile_columns_result_tables"):
        return

    schema_profiles = scan._profile_columns_result_tables

    schema_profile_results.append(
        {
            "prefix": schema_prefix,
            "profiles": schema_profiles,
            "table_to_model_name": table_to_model_name or {},
        }
    )

    prefix_tables = set()
    total_columns = 0

    for profile_table in schema_profiles:
        if hasattr(profile_table, "get_cloud_dict"):
            profile_dict = profile_table.get_cloud_dict()
            table = profile_dict.get("table")
            column_profiles = profile_dict.get("columnProfiles", [])

            if table_to_model_name:
                table = table_to_model_name.get(table, table)

            if table:
                prefix_tables.add(table)
            total_columns += len(column_profiles)

    prefix_stats[schema_prefix] = SchemaStats(
        tables=len(prefix_tables),
        columns=total_columns,
    )

    logger.info(f"✅ Batch complete: {total_columns} columns in {len(prefix_tables)} tables")


def _build_profile_execution_summary(
    schema_profile_results: t.List[SchemaProfileResult],
    prefix_stats: t.Dict[str, SchemaStats],
    run_id: str,
    environment: str,
) -> ProfileExecutionSummary:
    """
    Build a run-level profile summary from accumulated ``SchemaProfileResult`` batches.

    Args:
        schema_profile_results: Batches produced by ``_collect_batch_results``.
        prefix_stats: Per-prefix table/column counts from those batches.
        run_id: Run identifier for linking to activity.
        environment: Vulcan environment name.

    Returns:
        ``ProfileExecutionSummary`` with ``model_profiles`` and ``prefix_stats``.
    """
    model_profiles: t.Dict[str, t.List[str]] = {}

    for schema_result in schema_profile_results:
        profile_tables = schema_result["profiles"]
        table_to_model_name = schema_result.get("table_to_model_name") or {}

        for profile_table in profile_tables:
            if hasattr(profile_table, "get_cloud_dict"):
                profile_dict = profile_table.get_cloud_dict()
            else:
                continue

            raw_table = profile_dict.get("table")
            column_profiles = profile_dict.get("columnProfiles", [])

            if raw_table and column_profiles:
                model_key = table_to_model_name.get(raw_table, raw_table)

                if model_key not in model_profiles:
                    model_profiles[model_key] = []

                for col_profile in column_profiles:
                    col_name = col_profile.get("columnName")
                    if col_name:
                        model_profiles[model_key].append(col_name)

    return ProfileExecutionSummary(
        run_id=run_id,
        environment=environment,
        model_profiles=model_profiles,
        prefix_stats=prefix_stats,
    )


def _patch_soda_scan_logs(scan: Scan, *, label: str) -> None:
    """
    Replace ``scan._logs.log`` so messages are mirrored to this module's logger.

    Soda's error aggregation (``get_error_logs``) still receives structured ``Log`` entries.

    Args:
        scan: Scan instance before ``execute``.
        label: Tag prefix for log lines (typically the model name).

    Returns:
        None.

    Note:
        Uses Soda private APIs; verify after major ``soda`` upgrades.
    """
    logs = scan._logs

    def wrapped(
        _logs_self: t.Any,
        level: LogLevel,
        message: str,
        location: t.Any,
        doc: t.Any,
        exception: BaseException | None,
    ) -> None:
        py_level = _LOG_LEVEL_TO_PY.get(level, logging.INFO)
        logger.log(py_level, "[%s] %s", label, message)
        if exception is not None:
            logger.log(py_level, "[%s] %s", label, exception)
        entry = Log(
            level=level,
            message=message,
            location=location,
            doc=doc,
            exception=exception,
        )
        _logs_self.logs.append(entry)

    logs.log = types.MethodType(wrapped, logs)


def validate_dq_spec_sodacl_parses(spec: DataQualitySpec, model_name: str) -> None:
    """
    Parse generated SodaCL with Soda to catch syntax errors before plan/apply.

    Uses :func:`build_sodacl_yaml` so validation matches :func:`run_data_quality_scan`.
    ``spec._path`` should already be set so :exc:`ConfigError` messages name the file.

    Scan setup mirrors :func:`run_data_quality_scan` where parsing cares: log mirroring,
    scan definition name, and data source name. Unlike the runner, we do not call
    ``add_configuration_yaml_str`` / Spark wiring — there is no gateway or physical
    relation at load time, and ``add_sodacl_yaml_str`` only needs a named data source
    placeholder.

    Args:
        spec: Parsed data quality spec.
        model_name: Logical model name (same value as ``depends_on`` / ``Model.name``
            passed to :func:`build_sodacl_yaml`).

    Raises:
        ConfigError: If Soda reports errors while ingesting the SodaCL string or raises.
    """
    path = spec._path
    path_label = str(path) if path is not None else "(unknown dq file path)"

    sodacl_yaml = build_sodacl_yaml(spec, model_name)

    scan = Scan()
    _patch_soda_scan_logs(scan, label=model_name)
    scan_def_safe = _sanitize_soda_name(model_name)
    data_source_name = f"soda3_load_validation_{scan_def_safe}"
    scan.set_scan_definition_name(data_source_name)
    scan.set_data_source_name(data_source_name)

    try:
        scan.add_sodacl_yaml_str(sodacl_yaml)
    except Exception as e:
        raise ConfigError(
            f"Invalid kind: dq file {path_label}: SodaCL validation failed: {e}"
        ) from e

    if not scan.has_error_logs():
        return

    messages = _sodacl_error_messages(scan)
    detail = (
        "; ".join(messages)
        if messages
        else "SodaCL validation failed. See https://docs.soda.io/sodacl-reference/"
    )
    raise ConfigError(f"Invalid kind: dq file {path_label}: {detail}")


def _sodacl_error_messages(scan: Scan) -> t.List[str]:
    """
    Collect human-readable error strings from a ``Scan`` after a failed parse.

    Args:
        scan: Scan instance that reported error logs.

    Returns:
        Messages from Soda error logs, if any.
    """
    getter = getattr(scan, "get_error_logs", None)
    if callable(getter):
        return [getattr(log, "message", str(log)) for log in getter()]

    out: t.List[str] = []
    logs = getattr(scan, "_logs", None)
    log_list = getattr(logs, "logs", None) if logs is not None else None
    if not log_list:
        return out

    for log in log_list:
        level = getattr(log, "level", None)
        is_error = str(level) == "ERROR" or getattr(level, "name", None) == "ERROR"
        if is_error:
            out.append(getattr(log, "message", str(log)))
    return out


def _print_scan_outcome(scan: Scan, *, label: str) -> None:
    """
    Log a short pass/fail count and any Soda error logs after ``scan.execute()``.

    Args:
        scan: Finished scan.
        label: Tag for log lines (typically the model name).

    Returns:
        None.
    """
    if scan.has_error_logs():
        for log in scan.get_error_logs():
            logger.warning("[soda3:%s] %s", label, log.message)
    checks = getattr(scan, "_checks", [])
    passed = sum(1 for c in checks if getattr(c, "outcome", None) == CheckOutcome.PASS)
    failed = sum(1 for c in checks if getattr(c, "outcome", None) == CheckOutcome.FAIL)
    logger.info(
        "[soda3:%s] checks=%s pass=%s fail=%s",
        label,
        len(checks),
        passed,
        failed,
    )


def run_data_quality_scan(
    context: "Context",
    model: "Model",
    *,
    run_id: str = "",
    environment: str,
    execution_time: t.Optional[TimeLike] = None,
    start: t.Optional[TimeLike] = None,
    end: t.Optional[TimeLike] = None,
) -> t.Optional[
    t.Tuple[
        CheckExecutionSummary,
        Scan,
        str,
        t.Dict[str, str],
    ]
]:
    """
    Run a Soda scan for ``model.dq`` and persist results via ``SodaStateSyncBackend``.

    Builds SodaCL from the DQ spec, configures the data source from the default gateway,
    attaches variables and the state-sync cloud backend, executes the scan, and returns
    objects needed to roll up checks and profiles across models.

    Args:
        context: Vulcan context (config, state sync, optional Spark session).
        model: Model whose ``dq`` spec is executed; if ``dq`` is ``None``, returns ``None``.
        run_id: Optional run id passed to the backend for state linkage.
        environment: Active environment name.
        execution_time: Optional logical time for template variables.
        start: Optional interval start for template variables.
        end: Optional interval end for template variables.

    Returns:
        ``(check_summary, scan, schema_prefix, table_to_model_name)`` for use with
        :func:`run_soda3_for_successful_models`, or ``None`` if the model has no ``dq`` spec.

    Raises:
        ConfigError: If no default gateway is configured.
    """
    spec = getattr(model, "dq", None)
    if spec is None:
        return None

    gateway_name = context.config.default_gateway_name
    if not gateway_name:
        raise ConfigError("No default gateway configured; cannot run soda3 DQ.")

    combined_sodacl = build_sodacl_yaml(spec, model.name)
    logger.debug("[soda3: runner] %s <<- DQ <<- \n%s", model.name, combined_sodacl)

    table_expr = model.fully_qualified_table
    catalog, schema = table_expr.catalog, table_expr.db
    schema_prefix = f"{catalog}.{schema}"
    alias = _table_alias(model.name)
    table_to_model_name = {alias: str(model.name), str(model.name): str(model.name)}
    schema_prefix_safe = schema_prefix.replace(".", "_").lower()
    project_name = (context.config.project or "vulcan").replace("-", "_")

    data_source_name = _sanitize_soda_name(
        f"soda3_{project_name}_{environment}_{schema_prefix_safe}"
    )

    scan = Scan()
    _patch_soda_scan_logs(scan, label=model.name)
    scan.set_scan_definition_name(data_source_name)
    scan.set_data_source_name(data_source_name)

    soda_data_source_config = _create_soda_data_source_config(
        context=context,
        gateway_name=gateway_name,
        catalog=catalog,
        schema=schema,
    )
    is_spark_programmatic = soda_data_source_config.get("__soda_programmatic__") == "spark_df"
    if is_spark_programmatic:
        spark_session = context.spark
        if catalog:
            spark_session.catalog.setCurrentCatalog(catalog)
        if schema:
            spark_session.catalog.setCurrentDatabase(schema)
        scan.add_spark_session(spark_session, data_source_name=data_source_name)
    else:
        data_source_yaml = yaml.dump({f"data_source {data_source_name}": soda_data_source_config})
        scan.add_configuration_yaml_str(data_source_yaml)

    scan.add_sodacl_yaml_str(combined_sodacl)
    soda_variables = _build_soda_variables(
        context=context,
        gateway_name=gateway_name,
        environment=environment,
        execution_time=execution_time,
        start=start,
        end=end,
    )
    if soda_variables:
        scan.add_variables(soda_variables)

    backend = SodaStateSyncBackend(
        state_sync=context.state_sync,
        environment=environment,
        run_id=run_id or None,
        table_to_model_name=table_to_model_name,
    )
    scan._configuration.soda_cloud = backend
    scan._configuration.sampler = SodaStateSyncSampler(backend=backend)
    scan.set_verbose(True)

    scan.execute()
    _print_scan_outcome(scan, label=model.name)

    filter_val = spec.filter.strip() if spec.filter else None
    check_summary = _build_execution_summary(
        scan,
        {str(model.name): filter_val},
        table_to_model_name,
    )
    return check_summary, scan, schema_prefix, table_to_model_name


def run_soda3_for_successful_models(
    context: "Context",
    successful_model_execs: t.Sequence["ModelExec"],
    *,
    run_id: str,
    environment: str,
    execution_time: t.Optional[TimeLike] = None,
    start: t.Optional[TimeLike] = None,
    end: t.Optional[TimeLike] = None,
) -> t.Tuple[
    t.Optional[CheckExecutionSummary],
    t.Optional[ProfileExecutionSummary],
]:
    """
    Run DQ scans for each successful model execution that has a ``dq`` spec on the ``Model``.

    Models are resolved from ``state_sync`` snapshots for ``environment``, keyed only by
    ``ModelExec.fqn`` (same as ``snapshot.name``).

    Per-model failures are logged and skipped so other models still run. Check summaries are
    merged; profile batches are collected into one ``ProfileExecutionSummary`` when any
    profiling ran.

    Args:
        context: Vulcan context.
        successful_model_execs: Model execution records (must include ``fqn``) from the run.
        run_id: Run id for state and profile summary.
        environment: Environment name.
        execution_time: Optional logical time forwarded to each scan.
        start: Optional interval start forwarded to each scan.
        end: Optional interval end forwarded to each scan.

    Returns:
        ``(merged_check_summary, merged_profile_summary)``. Either element may be ``None`` if no
        checks or no profile data was produced.

    Note:
        Exceptions from :func:`run_data_quality_scan` are caught per model, logged, and do not
        abort the loop.
    """
    check_summaries: t.List[CheckExecutionSummary] = []
    schema_profile_results: t.List[SchemaProfileResult] = []
    prefix_stats: t.Dict[str, t.Any] = {}

    models_by_fqn = _models_by_fqn_from_environment_snapshots(
        context, environment, successful_model_execs
    )

    for me in successful_model_execs:
        m = models_by_fqn.get(me.fqn)
        if m is None:
            logger.debug(
                "[soda3] Skipping DQ for %s (%s): model not in context or environment snapshots",
                me.name,
                me.fqn,
            )
            continue
        try:
            out = run_data_quality_scan(
                context,
                m,
                run_id=run_id,
                environment=environment,
                execution_time=execution_time,
                start=start,
                end=end,
            )
            if out is None:
                continue
            check_summary, scan, schema_prefix, table_to_model_map = out
            check_summaries.append(check_summary)
            _collect_batch_results(
                scan,
                schema_prefix,
                schema_profile_results,
                prefix_stats,
                table_to_model_map,
            )
        except Exception as e:
            logger.error(
                "[soda3] DQ failed for model %s: %s",
                me.name,
                e,
                exc_info=True,
            )

    merged_check = _merge_check_summaries(check_summaries) if check_summaries else None
    merged_profile = (
        _build_profile_execution_summary(
            schema_profile_results,
            prefix_stats,
            run_id,
            environment,
        )
        if schema_profile_results
        else None
    )
    return merged_check, merged_profile
