from __future__ import annotations

# Keys used in DQ YAML, Soda check bodies, and ``resourceAttributes`` (keep in sync across loader/spec/runner/cloud).
_NAME_ATTR_KEY = "name"
_DESCRIPTION_ATTR_KEY = "description"
_DIMENSION_ATTR_KEY = "dimension"

# --- Soda patches (must run before ``Scan`` / ``Check`` identity) ------------------

# Disable Soda telemetry by patching at multiple levels for robustness.
try:
    from soda.common.config_helper import ConfigHelper

    _config_helper = ConfigHelper.get_instance()
    _config_helper._ConfigHelper__config["send_anonymous_usage_stats"] = False
except Exception:
    pass

try:
    import soda.execution.check.check as _soda_check

    _original_create_identity = _soda_check.Check.create_identity

    def _patched_create_identity(self, with_datasource=True, with_filename=False):
        return _original_create_identity(self, with_datasource, with_filename)

    _soda_check.Check.create_identity = _patched_create_identity
except Exception as e:
    raise Exception("Failed to patch Soda create_identity") from e

