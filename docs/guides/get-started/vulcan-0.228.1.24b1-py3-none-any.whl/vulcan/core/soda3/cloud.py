from __future__ import annotations

import logging
import typing as t
import uuid

from vulcan.core.soda3 import (  # package __init__ patches Soda before soda.* imports
    _NAME_ATTR_KEY,
    _DESCRIPTION_ATTR_KEY,
    _DIMENSION_ATTR_KEY,
)

from soda.cloud.cloud import Cloud
from soda.cloud.historic_descriptor import HistoricDescriptor
from soda.common.json_helper import JsonHelper
from soda.__version__ import SODA_CORE_VERSION
from soda.execution.check.change_over_time_metric_check import ChangeOverTimeMetricCheck
from soda.scan import Scan
from soda.sampler.sample_ref import SampleRef
from soda.sampler.sample_context import SampleContext

from vulcan.core.soda3.spec import ScanResults
from vulcan.core.state_sync import StateSync
from vulcan.utils.date import to_timestamp

logger = logging.getLogger(__name__)


def _normalize_skipped_change_checks(scan: Scan) -> None:
    for check in scan._checks:
        if check.outcome is not None or check.force_send_results_to_cloud or getattr(check, "historic_diff_values", None):
            continue
        # Change-over-time checks need prior metric runs before Soda can compare.
        # When history is missing, Soda only logs and moves on—it does not set an
        # outcome or ask the cloud backend to store the result (unlike anomaly checks,
        # which call add_outcome_reason and still get persisted as not_evaluated).
        # Our scan-result filter drops checks with no outcome and no force_send, so
        # fix that here before we build what goes into the state store.
        #
        # Mark skipped change-over-time checks for persistence.
        if isinstance(check, ChangeOverTimeMetricCheck):
            check.add_outcome_reason(
                outcome_type="insufficient_historic_data",
                message="Insufficient metric history for change-over-time evaluation.",
                severity="warn",
            )


def _remap_table_fields(
    rows: t.Iterable[t.Dict[str, t.Any]],
    table_to_model_name: t.Dict[str, str],
) -> None:
    if not table_to_model_name:
        return
    for row in rows:
        table_name = row.get("table")
        if not table_name:
            continue
        logical = table_to_model_name.get(table_name)
        if logical:
            row["table"] = logical


class SodaStateSyncBackend(Cloud):

    def __init__(
        self,
        state_sync: StateSync,
        environment: str,
        run_id: t.Optional[str] = None,
        table_to_model_name: t.Optional[t.Dict[str, str]] = None,
    ):
        self.state_sync = state_sync
        self.environment = environment
        self.run_id = run_id
        self.table_to_model_name: t.Dict[str, str] = table_to_model_name or {}
        self.host = "vulcan-state-sync"
        self._logs_buffer: t.List[str] = []
        self._queries_buffer: t.List[str] = []

    def send_scan_results(self, scan: Scan) -> None:
        try:
            _normalize_skipped_change_checks(scan)
            scan_results = self._build_scan_results(scan)
            self.state_sync.quality_state.store_checks_and_profile_results(
                scan_results=scan_results,
                run_id=self.run_id,
                environment=self.environment,
            )
            self._capture_logs_and_queries(scan_results)
        except Exception as e:
            logger.error(
                f"Failed to store check results: {e}",
                exc_info=True,
                extra={
                    "event_type": "check_storage_failure",
                    "environment": self.environment,
                },
            )

    def _build_scan_results(self, scan: Scan) -> ScanResults:
        checks = []
        for check in scan._checks:
            if (check.outcome is not None or check.force_send_results_to_cloud is True) and check.archetype is None:
                d = check.get_dict()
                d["identity"] = check.create_identity()
                checks.append(d)

        automated_monitoring_checks = []
        for check in scan._checks:
            if (check.outcome is not None or check.force_send_results_to_cloud is True) and check.archetype is not None:
                d = check.get_dict()
                d["identity"] = check.create_identity()
                automated_monitoring_checks.append(d)

        _remap_table_fields(checks + automated_monitoring_checks, self.table_to_model_name)

        profiling = [
            profile_table.get_cloud_dict()
            for profile_table in scan._profile_columns_result_tables + scan._sample_tables_result_tables
        ]
        _remap_table_fields(profiling, self.table_to_model_name)

        query_list = []
        for query in scan._queries:
            query_list += query.get_cloud_dicts()

        metrics = [metric.get_cloud_dict() for metric in scan._metrics]
        _remap_table_fields(metrics, self.table_to_model_name)

        metadata = [
            discover_tables_result.get_cloud_dict()
            for discover_tables_result in scan._discover_tables_result_tables
        ]

        logs = [log.get_cloud_dict() for log in scan._logs.logs]

        failed_row_samples = SodaStateSyncBackend._extract_samples_from_scan(scan)
        logger.info(f"Extracted {len(failed_row_samples)} failed row sample(s) from scan context")

        SodaStateSyncBackend._inject_samples_into_diagnostics(checks, failed_row_samples)

        scan_results_dict = JsonHelper.to_jsonnable(
            {
                "scanId": getattr(scan, "_scan_id", None) or str(uuid.uuid4()),
                "definitionName": scan._scan_definition_name,
                "defaultDataSource": scan._data_source_name,
                "dataTimestamp": scan._data_timestamp,
                "scanStartTimestamp": to_timestamp(scan._scan_start_timestamp),
                "scanEndTimestamp": to_timestamp(scan._scan_end_timestamp),
                "hasErrors": scan.has_error_logs(),
                "hasWarnings": scan.has_check_warns(),
                "hasFailures": scan.has_check_fails(),
                "metrics": metrics,
                "checks": checks,
                "queries": query_list,
                "automatedMonitoringChecks": automated_monitoring_checks,
                "profiling": profiling,
                "metadata": metadata,
                "logs": logs,
                "sodaCoreVersion": SODA_CORE_VERSION,
            }
        )

        return scan_results_dict

    def _capture_logs_and_queries(self, scan_results: t.Dict[str, t.Any]) -> None:
        for query in scan_results.get("queries", []):
            if isinstance(query, dict):
                self._queries_buffer.append(query.get("sql", str(query)))
            else:
                self._queries_buffer.append(str(query))

    @staticmethod
    def _inject_samples_into_diagnostics(
        checks: t.List[t.Dict[str, t.Any]],
        failed_row_samples: t.Dict[str, t.Any],
    ) -> None:
        samples_by_check_name = {}
        for storage_key, sample_data in failed_row_samples.items():
            check_name = sample_data.get("check_name")
            if check_name:
                samples_by_check_name[check_name] = sample_data

        for check in checks:
            check_name = check.get(_NAME_ATTR_KEY)
            if not check_name:
                continue

            sample_data = samples_by_check_name.get(check_name)
            if not sample_data:
                continue

            diagnostics = check.get("diagnostics")
            if not diagnostics or "blocks" not in diagnostics:
                continue

            for block in diagnostics["blocks"]:
                if block.get("type") == "file" and block.get("title") == "Failed Rows":
                    file_info = block.get("file", {})
                    block["type"] = "record"
                    block["record"] = {
                        "columns": file_info.get("columns", []),
                        "totalRowCount": sample_data.get("row_count", 0),
                        "storedRowCount": len(sample_data.get("sample_rows", [])),
                        "samples": sample_data.get("sample_rows", []),
                    }
                    block.pop("file", None)

                    logger.debug(
                        f"Injected {len(sample_data.get('sample_rows', []))} sample rows "
                        f"into diagnostics for check '{check_name}'"
                    )

    @staticmethod
    def _extract_samples_from_scan(scan: Scan) -> t.Dict[str, t.Any]:
        samples = {}
        if hasattr(scan, "scan_context"):
            for key, value in scan.scan_context.items():
                if key.startswith("_vulcan_failed_row_samples_"):
                    samples[key] = value
        return samples

    def is_samples_disabled(self) -> bool:
        return False

    def get_check_attributes_schema(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.List[t.Dict[str, t.Any]]:
        return [
            {"name": _DESCRIPTION_ATTR_KEY, "type": "text"},
            {"name": _DIMENSION_ATTR_KEY, "type": "text"},
        ]

    def upload_sample(
        self,
        scan: t.Any,
        sample_rows: t.List[t.Dict[str, t.Any]],
        sample_file_name: str,
        samples_limit: t.Optional[int] = None,
        sample_context: t.Optional[t.Any] = None,
    ) -> str:
        check_name = sample_context.check_name if sample_context else None
        sample_name = sample_context.sample_name if sample_context else sample_file_name

        normalized_sample_rows = JsonHelper.to_jsonnable(sample_rows)

        storage_key = (
            f"_vulcan_failed_row_samples_{check_name}_{sample_name}"
            if check_name
            else f"_vulcan_failed_row_samples_{sample_name}"
        )

        sample_data = {
            "sample_rows": normalized_sample_rows,
            "row_count": len(sample_rows),
            "sample_name": sample_name,
            "check_name": check_name,
            "query": sample_context.query if sample_context else None,
            "samples_limit": samples_limit,
            "table_name": (
                sample_context.partition.table.table_name
                if sample_context and sample_context.partition and sample_context.partition.table
                else None
            ),
            "column_name": (
                sample_context.column.column_name
                if sample_context and sample_context.column
                else None
            ),
        }

        scan.scan_context_set(storage_key, sample_data, overwrite=True)
        return storage_key

    @property
    def soda_cloud_trace_ids(self) -> t.List[str]:
        return []

    def get_historic_data(self, historic_descriptor: HistoricDescriptor) -> t.Dict[str, t.Any]:
        from soda.cloud.historic_descriptor import (
            HistoricMeasurementsDescriptor,
            HistoricCheckResultsDescriptor,
            HistoricChangeOverTimeDescriptor,
        )

        try:
            measurements = {}
            check_results = {}

            if isinstance(historic_descriptor, HistoricMeasurementsDescriptor):
                results = self.state_sync.quality_state.get_historic_measurements(
                    metric_identity=historic_descriptor.metric_identity,
                    limit=historic_descriptor.limit or 100,
                )
                measurements = {"results": results}

            elif isinstance(historic_descriptor, HistoricCheckResultsDescriptor):
                results = self.state_sync.quality_state.get_historic_check_results(
                    check_identity=historic_descriptor.check_identity,
                    limit=historic_descriptor.limit or 100,
                )
                check_results = {"results": results}

            elif isinstance(historic_descriptor, HistoricChangeOverTimeDescriptor):
                results = self.state_sync.quality_state.get_historic_metric_change_over_time(
                    metric_identity=historic_descriptor.metric_identity,
                    same_day_last_week=historic_descriptor.change_over_time_cfg.same_day_last_week,
                )
                measurements = {"results": results}

            else:
                logger.warning(f"Unsupported historic descriptor type: {type(historic_descriptor)}")
                return {"measurements": {}, "check_results": {}}

            return {
                "measurements": measurements,
                "check_results": check_results,
            }

        except Exception as e:
            logger.error(f"Failed to fetch historic data: {e}", exc_info=True)
            return {"measurements": {}, "check_results": {}}

    def get_logs(self) -> t.List[str]:
        return self._logs_buffer

    def get_queries(self) -> t.List[str]:
        return self._queries_buffer


class SodaStateSyncSampler:

    def __init__(self, backend: t.Optional[SodaStateSyncBackend] = None):
        self.logs = None
        self.backend = backend

    def store_sample(self, sample_context: SampleContext) -> SampleRef:
        sample_rows = sample_context.sample.get_rows()
        row_count = sample_context.sample.get_rows_count()
        sample_schema = sample_context.sample.get_schema()

        if self.backend:
            self.backend.upload_sample(
                scan=sample_context.scan,
                sample_rows=sample_rows,
                sample_file_name=sample_context.get_sample_file_name(),
                samples_limit=sample_context.samples_limit,
                sample_context=sample_context,
            )

        if sample_context.samples_limit is not None:
            stored_row_count = min(row_count, sample_context.samples_limit)
        else:
            stored_row_count = row_count

        return SampleRef(
            name=sample_context.sample_name,
            schema=sample_schema,
            total_row_count=row_count,
            stored_row_count=stored_row_count,
            type="state-sync",
            message=f"Stored in state sync ({stored_row_count} rows)",
        )
