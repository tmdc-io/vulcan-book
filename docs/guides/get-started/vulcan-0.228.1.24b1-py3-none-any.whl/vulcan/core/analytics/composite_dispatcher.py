"""Fan-out dispatcher that forwards events to multiple child dispatchers.

The composite owns no threading or queueing of its own; each child manages
its own cadence and resources. Exceptions from one child are isolated and
logged so that other children still receive the event.
"""

from __future__ import annotations

import logging
import typing as t

from vulcan.core.analytics.dispatcher import EventDispatcher

logger = logging.getLogger(__name__)


class CompositeDispatcher(EventDispatcher):
    """Forwards every operation to each child dispatcher with fault isolation.

    Args:
        dispatchers: Children to fan out to. May be empty (acts as a no-op).
    """

    def __init__(self, dispatchers: t.Sequence[EventDispatcher]):
        self._dispatchers: t.List[EventDispatcher] = list(dispatchers)

    def add_event(self, event: t.Dict[str, t.Any]) -> None:
        for d in self._dispatchers:
            try:
                d.add_event(event)
            except Exception as e:
                logger.warning(
                    "Composite child %s failed to accept event: %s",
                    type(d).__name__,
                    e,
                )

    def flush(self) -> None:
        for d in self._dispatchers:
            try:
                d.flush()
            except Exception as e:
                logger.warning(
                    "Composite child %s failed to flush: %s",
                    type(d).__name__,
                    e,
                )

    def shutdown(self, flush: bool = True) -> None:
        for d in self._dispatchers:
            try:
                d.shutdown(flush=flush)
            except Exception as e:
                logger.warning(
                    "Composite child %s failed to shut down: %s",
                    type(d).__name__,
                    e,
                )
