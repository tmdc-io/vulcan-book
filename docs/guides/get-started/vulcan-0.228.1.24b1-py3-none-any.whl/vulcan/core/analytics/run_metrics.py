"""Record run / check / profile metrics via the analytics collector."""

from __future__ import annotations

import logging
import typing as t

logger = logging.getLogger(__name__)


def record_run_activity_metrics(
    *,
    environment: str,
    run_start_ts: int,
    run_end_ts: int,
    models: t.Sequence[t.Any],
    config: t.Any,
    success: bool,
) -> None:
    """Emit run-level Prometheus events for a completed run."""
    from vulcan.core import analytics

    duration_s = max((run_end_ts - run_start_ts) / 1000.0, 0.0)
    engine = getattr(config, "dialect", None) or "unknown"
    status = "success" if success else "failed"

    try:
        analytics.collector.on_run_completed(
            environment=environment,
            status=status,
            duration_s=duration_s,
            models=len(models),
            engine=engine,
        )
    except Exception as e:
        logger.warning("Failed to record run activity metrics: %s", e)


def record_run_activity_with_quality(
    run_activity: t.Any,
    config: t.Any,
) -> None:
    """Emit metrics from a stored ``RunActivity`` (includes quality/profile when present)."""
    try:
        environment = run_activity.environment
        record_run_activity_metrics(
            environment=environment,
            run_start_ts=run_activity.start_ts,
            run_end_ts=run_activity.end_ts,
            models=run_activity.models_affected,
            config=config,
            success=run_activity.success,
        )
    except Exception as e:
        logger.warning("Failed to resolve run activity metrics: %s", e)
        return

    check_results: t.List[t.Dict[str, t.Any]] = []
    if getattr(run_activity, "quality", None):
        for cr in run_activity.quality:
            check_results.append(
                {
                    "check_type": cr.check_type if hasattr(cr, "check_type") else "unknown",
                    "status": cr.outcome.value if hasattr(cr, "outcome") else "unknown",
                    "duration_s": 0.0,
                }
            )

    profiles: t.List[t.Dict[str, t.Any]] = []
    if getattr(run_activity, "profile", None):
        for mp in run_activity.profile:
            col_count = len(mp.columns) if mp.columns else 0
            if col_count > 0:
                profiles.append(
                    {
                        "duration_s": 0.0,
                        "columns": col_count,
                    }
                )

    record_check_and_profile_metrics(
        environment=environment,
        check_results=check_results,
        profiles=profiles,
    )


def record_check_and_profile_metrics(
    *,
    environment: str,
    check_results: t.Sequence[t.Dict[str, t.Any]],
    profiles: t.Sequence[t.Dict[str, t.Any]],
) -> None:
    from vulcan.core import analytics

    if check_results:
        try:
            analytics.collector.on_checks_recorded(
                environment=environment,
                results=list(check_results),
            )
        except Exception as e:
            logger.warning("Failed to record check metrics: %s", e)

    if profiles:
        try:
            analytics.collector.on_profiles_recorded(
                environment=environment,
                profiles=list(profiles),
            )
        except Exception as e:
            logger.warning("Failed to record profile metrics: %s", e)


def soda_check_results_to_metric_rows(
    check_summary: t.Any,
) -> t.List[t.Dict[str, t.Any]]:
    """Flatten Soda ``CheckExecutionSummary`` into per-dimension check metric rows."""
    rows: t.List[t.Dict[str, t.Any]] = []
    if check_summary is None:
        return rows

    for _model_name, model_data in getattr(check_summary, "results", {}).items():
        for dimension, stats in model_data.get("dimensions", {}).items():
            for status_key, prom_status in (
                ("passed", "passed"),
                ("failed", "failed"),
                ("warned", "warn"),
                ("not_evaluated", "skipped"),
            ):
                count = int(stats.get(status_key, 0))
                for _ in range(count):
                    rows.append(
                        {
                            "check_type": str(dimension),
                            "status": prom_status,
                            "duration_s": 0.0,
                        }
                    )
    return rows


def soda_profile_summary_to_metric_rows(profile_summary: t.Any) -> t.List[t.Dict[str, t.Any]]:
    rows: t.List[t.Dict[str, t.Any]] = []
    if profile_summary is None:
        return rows

    for _model_name, columns in getattr(profile_summary, "model_profiles", {}).items():
        col_count = len(columns) if columns else 0
        if col_count > 0:
            rows.append({"duration_s": 0.0, "columns": col_count})
    return rows
