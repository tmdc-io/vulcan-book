"""Background queue-depth polling for Prometheus telemetry."""

from __future__ import annotations

import asyncio
import logging
import typing as t

logger = logging.getLogger(__name__)


async def start_queue_depth_poller(
    queue_manager: t.Any,
    interval: int = 10,
) -> None:
    """Poll PGQueuer depth and emit via ``analytics.collector``.

    Launch with ``asyncio.create_task`` from the API lifespan when
    ``prometheus`` push is configured (root-level config).
    """
    while True:
        try:
            eps = list(queue_manager.entrypoint_registry.keys()) or ["query_execution"]
            for ep in eps:
                try:
                    depth = await queue_manager.queries.queued_work([ep])
                except Exception:
                    depth = 0
                try:
                    from vulcan.core import analytics

                    analytics.collector.on_query_queue_depth(
                        entrypoint=ep,
                        depth=int(depth),
                    )
                except Exception:
                    pass
        except Exception as e:
            logger.debug("Queue depth poll failed: %s", e)

        await asyncio.sleep(interval)
