"""Prometheus dispatcher for the analytics pipeline.

PrometheusDispatcher implements the ``EventDispatcher`` contract so that
``AnalyticsCollector`` fans analytics events out to Prometheus (and may
share a ``CompositeDispatcher`` with CloudEvents when that is configured).
It owns metric declarations, event-to-metric routing, and Pushgateway
transport for the analytics collector pipeline.

Design notes:
  * Self-contained: owns its own ``CollectorRegistry`` (no module-level
    globals) so callers can construct multiple dispatchers in tests.
  * Graceful degradation: if ``prometheus_client`` is missing or
    ``pushgateway_url`` is empty, the dispatcher silently no-ops. Callers
    don't need to special-case "metrics off".
  * Exceptions never propagate out of ``add_event`` — instrumentation must
    not break business logic.
"""

from __future__ import annotations

import json
import logging
import threading
import typing as t
import urllib.request

logger = logging.getLogger(__name__)


try:
    from prometheus_client import (
        CollectorRegistry,
        Counter,
        Gauge,
        Histogram,
        pushadd_to_gateway,
    )
    from prometheus_client.exposition import default_handler as _prom_default_handler

    _PROM_AVAILABLE = True
except Exception as ex:  # pragma: no cover - exercised only on missing dep
    CollectorRegistry = None  # type: ignore[assignment, misc]
    Counter = None  # type: ignore[assignment, misc]
    Gauge = None  # type: ignore[assignment, misc]
    Histogram = None  # type: ignore[assignment, misc]
    pushadd_to_gateway = None  # type: ignore[assignment]
    _prom_default_handler = None  # type: ignore[assignment]
    _PROM_AVAILABLE = False
    logger.warning("prometheus_client unavailable, PrometheusDispatcher will no-op: %s", ex)


from vulcan.core.analytics.dispatcher import EventDispatcher


_DURATION_BUCKETS: t.Tuple[float, ...] = (
    1,
    5,
    15,
    30,
    60,
    120,
    300,
    600,
    1200,
    1800,
    3600,
)
_FAST_DURATION_BUCKETS: t.Tuple[float, ...] = (
    0.05,
    0.1,
    0.25,
    0.5,
    1,
    2.5,
    5,
    10,
    30,
    60,
)
_COUNT_BUCKETS: t.Tuple[float, ...] = (1, 2, 5, 10, 20, 50, 100, 200, 500)
_ROW_BUCKETS: t.Tuple[float, ...] = (
    10,
    100,
    1_000,
    10_000,
    100_000,
    1_000_000,
    10_000_000,
    100_000_000,
)
_BYTE_BUCKETS: t.Tuple[float, ...] = (
    1_000_000,
    5_000_000,
    10_000_000,
    50_000_000,
    100_000_000,
    500_000_000,
    1_000_000_000,
    10_000_000_000,
    100_000_000_000,
)

_BASE_LABELS: t.Tuple[str, ...] = ("tenant", "data_product", "environment")


class PushgatewayCounterCache:
    """Per-dispatcher counter batch: fetch PG values once, then monotonic inc.

    Each ``vulcan plan`` or ``vulcan run`` starts a fresh ``CollectorRegistry`` whose
    counters begin at zero. ``pushadd_to_gateway`` alone does not make counters
    monotonic across processes: the pushed sample is still ``1``, not ``previous+1``.

    Fetch current Pushgateway values for this job + grouping key, reserve
    ``prev + amount`` in a local cache, apply the delta to the in-memory counter,
    then pushadd.
    """

    def __init__(
        self,
        *,
        pushgateway_url: str,
        job: str,
        grouping_key: t.Mapping[str, str],
        fetch_timeout_sec: float = 2.0,
    ) -> None:
        self._pushgateway_url = pushgateway_url.rstrip("/")
        self._job = job
        self._grouping_key = dict(grouping_key)
        self._fetch_timeout_sec = fetch_timeout_sec
        self._cached_values: t.Dict[str, float] = {}
        self._cache_lock = threading.Lock()
        self._batch_open = False

    def close_batch(self) -> None:
        """End the current batch so the next increment re-fetches Pushgateway."""
        self._batch_open = False

    def ensure_batch(self) -> None:
        """Fetch Pushgateway counter values once per push cycle."""
        if self._batch_open:
            return
        fetched: t.Dict[str, float] = {}
        try:
            req = urllib.request.Request(f"{self._pushgateway_url}/metrics")
            with urllib.request.urlopen(req, timeout=self._fetch_timeout_sec) as resp:
                filters = [f'job="{self._job}"'] + [
                    f'{k}="{v}"' for k, v in self._grouping_key.items()
                ]
                for line in resp.read().decode().splitlines():
                    if line.startswith("#") or not line.strip():
                        continue
                    parts = line.rsplit(" ", 1)
                    if len(parts) == 2 and all(part in parts[0] for part in filters):
                        fetched[parts[0]] = float(parts[1])
        except Exception:
            pass
        with self._cache_lock:
            self._cached_values.clear()
            self._cached_values.update(fetched)
        self._batch_open = True

    def inc_counter(self, counter: t.Any, labels: t.Dict[str, str], amount: int = 1) -> None:
        """
        Increment a Prometheus counter using Pushgateway-backed monotonic values.

        Args:
            counter: ``prometheus_client.Counter`` (or labeled child).
            labels: Label dict passed to ``counter.labels(**labels)``.
            amount: Non-negative increment (may be > 1 for batched test counts).
        """
        if amount <= 0:
            return
        self.ensure_batch()
        name = counter._name
        child = counter.labels(**labels)
        new_value = self._reserve(name, labels, amount=amount)

        current_value = 0.0
        value_ref = getattr(child, "_value", None)
        if value_ref is not None and hasattr(value_ref, "get"):
            try:
                current_value = float(value_ref.get())
            except Exception:
                current_value = 0.0

        delta = new_value - current_value
        if delta > 0:
            child.inc(delta)

    def _build_cache_key(self, metric_name: str, labels: t.Dict[str, str]) -> str:
        sorted_labels = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return f"{metric_name}_total{{{sorted_labels}}}"

    def _is_counter_line(self, cached_key: str, metric_name: str) -> bool:
        return "_total{" in cached_key or (
            cached_key.startswith(metric_name + "{")
            and "_bucket" not in cached_key
            and "_sum" not in cached_key
            and "_count" not in cached_key
            and "_created" not in cached_key
        )

    def _reserve(self, metric_name: str, labels: t.Dict[str, str], amount: int) -> float:
        with self._cache_lock:
            prev = 0.0
            update_key: t.Optional[str] = None
            for cached_key, value in self._cached_values.items():
                if metric_name in cached_key and all(
                    f'{k}="{v}"' in cached_key for k, v in labels.items()
                ):
                    if self._is_counter_line(cached_key, metric_name):
                        prev = value
                        update_key = cached_key
                        break
            new_value = prev + amount
            if update_key is not None:
                self._cached_values[update_key] = new_value
            else:
                self._cached_values[self._build_cache_key(metric_name, labels)] = new_value
            return new_value


class PrometheusDispatcher(EventDispatcher):
    """Translate analytics events into Prometheus metric operations.

    Args:
        pushgateway_url: HTTP(S) URL of the Pushgateway. Empty disables push.
        job: Pushgateway ``job`` label (e.g. ``"vulcan-api"``).
        push_interval_sec: Period of the background push loop.
        push_timeout_sec: Upper bound on a single push attempt (seconds).
        base_labels: ``tenant`` / ``data_product`` etc. attached to every
            metric. Per-event labels like ``environment`` come from the
            event payload.
        grouping_key: Pushgateway grouping key (per-process identity so
            different replicas don't overwrite each other's series).
        start_pusher: When ``True`` (default), spawn a daemon thread that
            pushes every ``push_interval_sec``. Tests should pass ``False``
            and drive ``flush()`` manually.

    Note:
        Construction never raises on missing ``prometheus_client`` or an
        empty ``pushgateway_url`` — the dispatcher quietly becomes a
        no-op so callers don't need ``if metrics_enabled`` branches.
    """

    def __init__(
        self,
        pushgateway_url: str,
        job: str = "vulcan",
        push_interval_sec: int = 10,
        push_timeout_sec: float = 2.0,
        base_labels: t.Optional[t.Mapping[str, str]] = None,
        grouping_key: t.Optional[t.Mapping[str, str]] = None,
        start_pusher: bool = True,
    ):
        self._pushgateway_url = (pushgateway_url or "").strip()
        self._job = job
        self._push_interval_sec = max(1, int(push_interval_sec))
        self._push_timeout_sec = float(push_timeout_sec)
        self._base_labels: t.Dict[str, str] = dict(base_labels or {})
        self._grouping_key: t.Dict[str, str] = dict(grouping_key or {})

        self._enabled = _PROM_AVAILABLE and bool(self._pushgateway_url)

        # Allocate the registry + metric objects only when we'll actually
        # push. The docstring promises "silent no-op" in disabled mode and
        # that includes "no allocations".
        self._registry: t.Any = CollectorRegistry() if self._enabled else None
        self._metrics: t.Dict[str, t.Any] = self._declare_metrics() if self._enabled else {}

        self._handlers: t.Dict[str, t.Callable[[t.Dict[str, t.Any]], None]] = (
            self._build_handlers() if self._enabled else {}
        )
        self._counter_cache = (
            PushgatewayCounterCache(
                pushgateway_url=self._pushgateway_url,
                job=self._job,
                grouping_key=self._grouping_key,
                fetch_timeout_sec=self._push_timeout_sec,
            )
            if self._enabled
            else None
        )

        self._stop_event = threading.Event()
        self._pusher_thread: t.Optional[threading.Thread] = None
        if start_pusher and self._enabled:
            self._pusher_thread = threading.Thread(
                target=self._push_loop,
                name="VulcanPromDispatcher",
                daemon=True,
            )
            self._pusher_thread.start()

    def is_enabled(self) -> bool:
        return self._enabled

    def add_event(self, event: t.Dict[str, t.Any]) -> None:
        if not self._enabled:
            return
        event_type = event.get("event_type", "")
        handler = self._handlers.get(event_type)
        if handler is None:
            logger.debug("PrometheusDispatcher: no handler for %s", event_type)
            return
        try:
            raw = event.get("event")
            data: t.Dict[str, t.Any] = json.loads(raw) if isinstance(raw, str) else (raw or {})
            handler(data)
        except Exception as e:
            logger.warning("PrometheusDispatcher: handler for %s failed: %s", event_type, e)

    def flush(self) -> None:
        if not self._enabled:
            return
        self._push()

    def shutdown(self, flush: bool = True) -> None:
        self._stop_event.set()
        if self._pusher_thread is not None and self._pusher_thread.is_alive():
            self._pusher_thread.join(timeout=5)
        if flush and self._enabled:
            self._push()

    # ────────────────────── push loop / transport ──────────────────────

    def _bounded_push_handler(self, url, method, timeout, headers, data):
        """Clamp ``prometheus_client``'s 30 s default urlopen timeout."""
        if _prom_default_handler is None:
            raise RuntimeError("prometheus_client not available")
        return _prom_default_handler(url, method, self._push_timeout_sec, headers, data)

    def _push(self) -> bool:
        """
        Push the registry to the Pushgateway once.

        Returns:
            ``True`` on success, ``False`` when the gateway client is
            unavailable or the HTTP push raises. Errors are logged at
            WARNING; never propagated.
        """
        if pushadd_to_gateway is None:
            return False
        try:
            kwargs: t.Dict[str, t.Any] = dict(
                gateway=self._pushgateway_url,
                job=self._job,
                registry=self._registry,
                handler=self._bounded_push_handler,
            )
            if self._grouping_key:
                kwargs["grouping_key"] = self._grouping_key
            pushadd_to_gateway(**kwargs)
            if self._counter_cache is not None:
                self._counter_cache.close_batch()
            logger.debug(
                "PrometheusDispatcher pushed to %s (job=%s)",
                self._pushgateway_url,
                self._job,
            )
            return True
        except Exception as e:
            logger.warning("PrometheusDispatcher push failed: %s", e)
            return False

    def _push_loop(self) -> None:
        """
        Daemon push loop with exponential backoff on consecutive failures.

        On success, sleeps for ``push_interval_sec``. On failure, sleeps
        for the current backoff (starting at ``push_interval_sec`` and
        doubling up to ``max_backoff``) so a dead Pushgateway can never
        be hammered at full cadence.
        """
        backoff = float(self._push_interval_sec)
        max_backoff = max(float(self._push_interval_sec) * 12, 60.0)
        while not self._stop_event.is_set():
            if self._push():
                wait_s = float(self._push_interval_sec)
                backoff = float(self._push_interval_sec)
            else:
                wait_s = backoff
                backoff = min(backoff * 2.0, max_backoff)
            if self._stop_event.wait(timeout=wait_s):
                break

    # ────────────────────── metric declarations ──────────────────────

    def _declare_metrics(self) -> t.Dict[str, t.Any]:
        r = self._registry
        m: t.Dict[str, t.Any] = {}

        m["plan_total"] = Counter(
            "vulcan_plan_total",
            "Total plan invocations.",
            list(_BASE_LABELS) + ["status"],
            registry=r,
        )
        m["plan_duration"] = Histogram(
            "vulcan_plan_duration_seconds",
            "Plan duration distribution.",
            list(_BASE_LABELS) + ["plan_type"],
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["plan_models_affected"] = Histogram(
            "vulcan_plan_models_affected",
            "Blast radius - models affected per plan.",
            list(_BASE_LABELS) + ["change_type"],
            buckets=_COUNT_BUCKETS,
            registry=r,
        )
        m["virtual_update_total"] = Counter(
            "vulcan_virtual_update_total",
            "Virtual layer updates that skip compute.",
            list(_BASE_LABELS),
            registry=r,
        )

        m["run_total"] = Counter(
            "vulcan_run_total",
            "Top-level run invocations.",
            list(_BASE_LABELS) + ["status"],
            registry=r,
        )
        m["run_duration"] = Histogram(
            "vulcan_run_duration_seconds",
            "End-to-end DAG wall clock.",
            list(_BASE_LABELS),
            buckets=_DURATION_BUCKETS,
            registry=r,
        )

        m["backfill_total"] = Counter(
            "vulcan_backfill_total",
            "Backfill invocations by trigger type.",
            list(_BASE_LABELS) + ["trigger", "status"],
            registry=r,
        )
        m["backfill_duration"] = Histogram(
            "vulcan_backfill_duration_seconds",
            "Backfill duration distribution.",
            list(_BASE_LABELS),
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["backfill_intervals_total"] = Histogram(
            "vulcan_backfill_intervals_total",
            "Date intervals backfilled per run.",
            list(_BASE_LABELS),
            buckets=_COUNT_BUCKETS,
            registry=r,
        )
        m["backfill_active"] = Gauge(
            "vulcan_backfill_active",
            "Currently active backfills.",
            list(_BASE_LABELS),
            registry=r,
        )

        m["check_total"] = Counter(
            "vulcan_check_total",
            "Check executions by type and status.",
            ["tenant", "data_product", "check_type", "status"],
            registry=r,
        )
        m["check_duration"] = Histogram(
            "vulcan_check_duration_seconds",
            "Check execution duration.",
            ["tenant", "data_product", "check_type"],
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["check_warnings_total"] = Counter(
            "vulcan_check_warnings_total",
            "Check warning count.",
            ["tenant", "data_product", "check_type"],
            registry=r,
        )

        m["test_total"] = Counter(
            "vulcan_test_total",
            "Unit test executions by status.",
            ["tenant", "data_product", "status"],
            registry=r,
        )
        m["test_duration"] = Histogram(
            "vulcan_test_duration_seconds",
            "Total test suite duration.",
            list(_BASE_LABELS),
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["test_coverage_ratio"] = Gauge(
            "vulcan_test_coverage_ratio",
            "Ratio of models with at least one test.",
            ["tenant", "data_product"],
            registry=r,
        )

        m["audit_total"] = Counter(
            "vulcan_audit_total",
            "Audit executions by status.",
            list(_BASE_LABELS) + ["status"],
            registry=r,
        )
        m["audit_duration"] = Histogram(
            "vulcan_audit_duration_seconds",
            "Audit execution duration.",
            list(_BASE_LABELS),
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["audit_blocked_plans_total"] = Counter(
            "vulcan_audit_blocked_plans_total",
            "Plans blocked by audit failures.",
            list(_BASE_LABELS),
            registry=r,
        )
        m["audit_blocked_runs_total"] = Counter(
            "vulcan_audit_blocked_runs_total",
            "Runs blocked by audit failures.",
            list(_BASE_LABELS),
            registry=r,
        )

        m["cache_hit_total"] = Counter(
            "vulcan_cache_hit_total",
            "Cache hits.",
            ["tenant", "data_product", "api"],
            registry=r,
        )
        m["cache_miss_total"] = Counter(
            "vulcan_cache_miss_total",
            "Cache misses.",
            ["tenant", "data_product", "api"],
            registry=r,
        )

        m["api_http_requests_total"] = Counter(
            "vulcan_api_http_requests_total",
            "Total HTTP requests to the Vulcan API.",
            ["method", "path", "status"],
            registry=r,
        )
        m["api_http_request_duration"] = Histogram(
            "vulcan_api_http_request_duration_seconds",
            "HTTP request duration in seconds.",
            ["method", "path"],
            buckets=_FAST_DURATION_BUCKETS,
            registry=r,
        )

        m["gateway_query_duration"] = Histogram(
            "vulcan_gateway_query_duration_seconds",
            "Engine query duration.",
            ["tenant", "data_product", "gateway", "engine"],
            buckets=_FAST_DURATION_BUCKETS,
            registry=r,
        )
        m["gateway_errors_total"] = Counter(
            "vulcan_gateway_errors_total",
            "Engine connection/query errors.",
            ["tenant", "data_product", "gateway", "error_type"],
            registry=r,
        )

        m["policy_evaluation_duration"] = Histogram(
            "vulcan_policy_evaluation_duration_seconds",
            "Heimdall policy evaluation duration.",
            ["tenant", "data_product", "policy_type"],
            buckets=_FAST_DURATION_BUCKETS,
            registry=r,
        )
        m["policy_denial_total"] = Counter(
            "vulcan_policy_denial_total",
            "Policy denials.",
            ["tenant", "data_product", "subject_type", "reason"],
            registry=r,
        )

        m["query_queue_depth"] = Gauge(
            "vulcan_query_queue_depth",
            "Queries waiting in the execution queue.",
            ["tenant", "data_product", "entrypoint"],
            registry=r,
        )
        m["query_queue_wait"] = Histogram(
            "vulcan_query_queue_wait_seconds",
            "Time a query spent waiting in the queue before execution.",
            ["tenant", "data_product", "entrypoint"],
            buckets=_FAST_DURATION_BUCKETS,
            registry=r,
        )

        m["activity_events_emitted_total"] = Counter(
            "vulcan_activity_events_emitted_total",
            "Events emitted to Activity API.",
            ["tenant", "data_product", "event_type"],
            registry=r,
        )

        # ── Semantic compilation / transpiler ──
        m["semantic_compilation_total"] = Counter(
            "vulcan_semantic_compilation_total",
            "Semantic-layer SQL compilations by status.",
            ["tenant", "data_product", "engine", "status"],
            registry=r,
        )
        m["semantic_compilation_duration"] = Histogram(
            "vulcan_semantic_compilation_duration_seconds",
            "Semantic compilation duration.",
            ["tenant", "data_product", "engine"],
            buckets=_FAST_DURATION_BUCKETS,
            registry=r,
        )
        m["semantic_transpiler_errors_total"] = Counter(
            "vulcan_semantic_transpiler_errors_total",
            "Transpiler service/transport errors by class.",
            ["tenant", "data_product", "engine", "api", "error_class"],
            registry=r,
        )

        m["profile_duration"] = Histogram(
            "vulcan_profile_duration_seconds",
            "Column profiling duration.",
            ["tenant", "data_product"],
            buckets=_DURATION_BUCKETS,
            registry=r,
        )
        m["profile_columns_scanned_total"] = Counter(
            "vulcan_profile_columns_scanned_total",
            "Columns profiled.",
            ["tenant", "data_product"],
            registry=r,
        )

        # ── Snapshot / environment counts ──
        m["snapshots_active"] = Gauge(
            "vulcan_snapshots_active",
            "Active snapshots in the current environment.",
            ["tenant", "data_product", "environment"],
            registry=r,
        )
        m["environments_active"] = Gauge(
            "vulcan_environments_active",
            "Active environments for the data product.",
            ["tenant", "data_product"],
            registry=r,
        )

        return m

    # ────────────────────── routing / handlers ──────────────────────

    def _build_handlers(
        self,
    ) -> t.Dict[str, t.Callable[[t.Dict[str, t.Any]], None]]:
        return {
            "PLAN_COMPLETED": self._handle_plan,
            "RUN_COMPLETED": self._handle_run,
            "CHECKS_RECORDED": self._handle_checks_recorded,
            "PROFILES_RECORDED": self._handle_profiles_recorded,
            "BACKFILL_STARTED": self._handle_backfill_started,
            "BACKFILL_COMPLETED": self._handle_backfill,
            "TEST_COMPLETED": self._handle_test,
            "AUDIT_COMPLETED": self._handle_audit,
            "CACHE_EVENT": self._handle_cache,
            "API_HTTP_REQUEST": self._handle_api_http_request,
            "GATEWAY_QUERY": self._handle_gateway_query,
            "GATEWAY_ERROR": self._handle_gateway_error,
            "POLICY_EVALUATED": self._handle_policy,
            "QUEUE_WAIT": self._handle_queue_wait,
            "QUERY_QUEUE_DEPTH": self._handle_query_queue_depth,
            "ACTIVITY_EMITTED": self._handle_activity_emitted,
            "SEMANTIC_COMPILATION": self._handle_semantic_compilation,
            "TRANSPILER_ERROR": self._handle_transpiler_error,
            "SNAPSHOT_ENV": self._handle_snapshot_env,
            "VIRTUAL_LAYER_UPDATE": self._handle_virtual_layer_update,
        }

    def _base(self, environment: t.Optional[str] = None) -> t.Dict[str, str]:
        """Return ``tenant`` + ``data_product`` (+ ``environment`` if given)."""
        out = {
            "tenant": self._base_labels.get("tenant", ""),
            "data_product": self._base_labels.get("data_product", ""),
        }
        if environment is not None:
            out["environment"] = environment
        return out

    def _inc(self, metric_key: str, labels: t.Dict[str, str], amount: int = 1) -> None:
        """Monotonic counter increment with Pushgateway read-then-add batching."""
        if self._counter_cache is None:
            return
        self._counter_cache.inc_counter(self._metrics[metric_key], labels, amount=amount)

    def _handle_plan(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        self._inc("plan_total", {**base, "status": data.get("status", "")})
        self._metrics["plan_duration"].labels(**base, plan_type=data.get("plan_type", "")).observe(
            float(data.get("duration_s", 0.0))
        )
        if "models_count" in data:
            self._metrics["plan_models_affected"].labels(
                **base, change_type=data.get("change_type", "")
            ).observe(float(data["models_count"]))
        if data.get("has_virtual_update"):
            self._inc("virtual_update_total", base)

    def _handle_run(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        self._inc("run_total", {**base, "status": data.get("status", "")})
        self._metrics["run_duration"].labels(**base).observe(float(data.get("duration_s", 0.0)))

    def _handle_checks_recorded(self, data: t.Dict[str, t.Any]) -> None:
        tp = {"tenant": self._base_labels.get("tenant", ""), "data_product": self._base_labels.get("data_product", "")}
        for row in data.get("results") or []:
            check_type = row.get("check_type", "unknown")
            status = row.get("status", "unknown")
            check_labels = {**tp, "check_type": check_type, "status": status}
            self._inc("check_total", check_labels)
            self._metrics["check_duration"].labels(**tp, check_type=check_type).observe(
                float(row.get("duration_s", 0.0))
            )
            if status == "warn":
                self._inc("check_warnings_total", {**tp, "check_type": check_type})

    def _handle_profiles_recorded(self, data: t.Dict[str, t.Any]) -> None:
        tp = {"tenant": self._base_labels.get("tenant", ""), "data_product": self._base_labels.get("data_product", "")}
        for profile in data.get("profiles") or []:
            self._metrics["profile_duration"].labels(**tp).observe(float(profile.get("duration_s", 0.0)))
            col_count = int(profile.get("columns", 0))
            if col_count > 0:
                self._inc("profile_columns_scanned_total", tp, amount=col_count)

    def _handle_backfill_started(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base(data.get("environment", ""))
        self._metrics["backfill_active"].labels(**base).inc()

    def _handle_backfill(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        self._inc(
            "backfill_total",
            {
                **base,
                "trigger": data.get("trigger", ""),
                "status": data.get("status", ""),
            },
        )
        self._metrics["backfill_duration"].labels(**base).observe(
            float(data.get("duration_s", 0.0))
        )
        if "intervals" in data:
            self._metrics["backfill_intervals_total"].labels(**base).observe(
                float(data["intervals"])
            )
        if data.get("status") in ("success", "failed"):
            self._metrics["backfill_active"].labels(**base).set(0)

    # Payload-key -> Prometheus ``status`` label value. Dashboard queries
    # from before the analytics unification use ``"error"`` and ``"skip"``
    # (not ``"errors"`` / ``"skipped"``); preserve them here.
    _TEST_STATUS_LABELS: t.ClassVar[t.Mapping[str, str]] = {
        "passed": "passed",
        "failed": "failed",
        "errors": "error",
        "skipped": "skip",
    }

    def _handle_test(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        tp = {"tenant": base["tenant"], "data_product": base["data_product"]}
        for payload_key, label_value in self._TEST_STATUS_LABELS.items():
            count = int(data.get(payload_key, 0))
            if count:
                self._inc("test_total", {**tp, "status": label_value}, amount=count)
        self._metrics["test_duration"].labels(**base).observe(float(data.get("duration_s", 0.0)))
        total_models = int(data.get("total_models", 0))
        if total_models > 0:
            models_with_tests = int(data.get("models_with_tests", 0))
            self._metrics["test_coverage_ratio"].labels(**tp).set(models_with_tests / total_models)

    def _handle_audit(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        self._inc("audit_total", {**base, "status": data.get("status", "")})
        self._metrics["audit_duration"].labels(**base).observe(float(data.get("duration_s", 0.0)))
        if data.get("blocked_plan"):
            self._inc("audit_blocked_plans_total", base)
        if data.get("blocked_run"):
            self._inc("audit_blocked_runs_total", base)

    def _handle_cache(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        api = data.get("api", "rest")
        if data.get("hit"):
            self._inc("cache_hit_total", {**base, "api": api})
        else:
            self._inc("cache_miss_total", {**base, "api": api})

    def _handle_api_http_request(self, data: t.Dict[str, t.Any]) -> None:
        method = data.get("method", "")
        path = data.get("path", "")
        status = data.get("status", "")
        labels = {"method": method, "path": path, "status": status}
        self._inc("api_http_requests_total", labels)
        self._metrics["api_http_request_duration"].labels(method=method, path=path).observe(
            float(data.get("duration_s", 0.0))
        )

    def _handle_gateway_query(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._metrics["gateway_query_duration"].labels(
            **base,
            gateway=data.get("gateway", ""),
            engine=data.get("engine", "unknown"),
        ).observe(float(data.get("duration_s", 0.0)))

    def _handle_gateway_error(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._inc(
            "gateway_errors_total",
            {
                **base,
                "gateway": data.get("gateway", ""),
                "error_type": data.get("error_type", "unknown"),
            },
        )

    def _handle_policy(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._metrics["policy_evaluation_duration"].labels(
            **base, policy_type=data.get("policy_type", "")
        ).observe(float(data.get("duration_s", 0.0)))
        if data.get("denied"):
            self._inc(
                "policy_denial_total",
                {
                    **base,
                    "subject_type": data.get("subject_type", ""),
                    "reason": data.get("reason", ""),
                },
            )

    def _handle_queue_wait(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._metrics["query_queue_wait"].labels(
            **base, entrypoint=data.get("entrypoint", "")
        ).observe(float(data.get("wait_seconds", 0.0)))

    def _handle_query_queue_depth(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._metrics["query_queue_depth"].labels(
            **base, entrypoint=data.get("entrypoint", "")
        ).set(float(data.get("depth", 0)))

    def _handle_activity_emitted(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._inc("activity_events_emitted_total", {**base, "event_type": data.get("event_type", "")})

    def _handle_semantic_compilation(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        engine = data.get("engine", "unknown")
        status = data.get("status", "")
        self._inc("semantic_compilation_total", {**base, "engine": engine, "status": status})
        self._metrics["semantic_compilation_duration"].labels(**base, engine=engine).observe(
            float(data.get("duration_s", 0.0))
        )

    def _handle_transpiler_error(self, data: t.Dict[str, t.Any]) -> None:
        base = self._base()
        self._inc(
            "semantic_transpiler_errors_total",
            {
                **base,
                "engine": data.get("engine", "unknown"),
                "api": data.get("api", ""),
                "error_class": data.get("error_class", "unknown"),
            },
        )

    def _handle_snapshot_env(self, data: t.Dict[str, t.Any]) -> None:
        env = data.get("environment", "")
        base = self._base(env)
        tp = {"tenant": base["tenant"], "data_product": base["data_product"]}
        if "snapshot_count" in data:
            self._metrics["snapshots_active"].labels(**base).set(float(data["snapshot_count"]))
        if "environment_count" in data:
            self._metrics["environments_active"].labels(**tp).set(float(data["environment_count"]))

    def _handle_virtual_layer_update(self, data: t.Dict[str, t.Any]) -> None:
        self._inc("virtual_update_total", self._base(data.get("environment", "")))
