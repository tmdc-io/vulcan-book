from __future__ import annotations

import atexit
import logging
import os
import typing as t
from functools import wraps

from vulcan.core.analytics.collector import AnalyticsCollector
from vulcan.core.analytics.composite_dispatcher import CompositeDispatcher
from vulcan.core.analytics.dispatcher import (
    AsyncEventDispatcher,
    EventDispatcher,
    EventEmitter,
    NoopEventDispatcher,
)
from vulcan.core.analytics.prometheus_dispatcher import PrometheusDispatcher

# DataOS-managed identity fields. Used as the Pushgateway grouping_key so
# series from different replicas/processes don't clobber each other.
_DATAOS_GROUPING_KEY_ENV: t.Mapping[str, str] = {
    "resource_id": "DATAOS_RESOURCE_ID",
    "resource_type": "DATAOS_TYPE",
    "tenant_name": "DATAOS_TENANT_ID",
    "instance_name": "DATAOS_INSTANCE_TENANT_ID",
    "dataplane_name": "DATAOS_FQDN",
    "user_name": "DATAOS_RUN_AS_USER",
}


def _resolve_pushgateway_grouping_key() -> t.Dict[str, str]:
    """Build a Pushgateway grouping_key from DataOS env vars; empty dict if any is missing."""
    key: t.Dict[str, str] = {}
    for field, env in _DATAOS_GROUPING_KEY_ENV.items():
        value = os.environ.get(env)
        if not value:
            return {}
        key[field] = value
    version = os.environ.get("VULCAN_VERSION", "latest")
    key["instance"] = f"vulcan:{version}"
    key["stack_name"] = "vulcan"
    key["stack_version"] = version
    return key


logger = logging.getLogger(__name__)

if t.TYPE_CHECKING:
    import sys

    if sys.version_info >= (3, 10):
        from typing import ParamSpec
    else:
        from typing_extensions import ParamSpec

    from vulcan.core.config.analytics import PrometheusConfig

    _P = ParamSpec("_P")
    _T = t.TypeVar("_T")


# Starts as Noop, replaced by Context after config loads. See AnalyticsConfig docstring for rationale.
collector: AnalyticsCollector = AnalyticsCollector(dispatcher=NoopEventDispatcher())


def _shutdown_collector() -> None:
    """Shutdown handler that always references the current global collector."""
    global collector
    collector.shutdown(flush=True)


def init_collector_from_config(
    enabled: bool = True,
    base_url: str = "",
    api_key: str = "",
    tenant: str = "",
    source_name: str = "vulcan",
    enable_search: bool = True,
    retention_days: int = 30,
    timeout: int = 10,
    product_name: t.Optional[str] = None,
    prometheus_config: t.Optional["PrometheusConfig"] = None,
) -> AnalyticsCollector:
    """Initialize analytics collector from config values.

    Prometheus is always attached when configured, regardless of ``enabled``.
    CloudEvents requires ``enabled=True`` and valid credentials.
    """
    dispatchers: t.List[EventDispatcher] = []

    if (
        prometheus_config is not None
        and prometheus_config.enabled
        and prometheus_config.pushgateway_url
    ):
        grouping_key = dict(prometheus_config.grouping_key) if prometheus_config.grouping_key else {}
        if not grouping_key:
            grouping_key = _resolve_pushgateway_grouping_key()
        dispatchers.append(
            PrometheusDispatcher(
                pushgateway_url=prometheus_config.pushgateway_url,
                job=prometheus_config.job,
                push_interval_sec=prometheus_config.push_interval_sec,
                push_timeout_sec=prometheus_config.push_timeout_sec,
                base_labels={"tenant": tenant, "data_product": product_name or ""},
                grouping_key=grouping_key,
            )
        )

    # CloudEvents requires analytics.enabled and valid credentials.
    if not enabled:
        if not dispatchers:
            return AnalyticsCollector(dispatcher=NoopEventDispatcher())
        # Prometheus-only: skip CloudEvents entirely.
        dispatcher: EventDispatcher = dispatchers[0]
        return AnalyticsCollector(
            dispatcher=dispatcher,
            product_name=product_name,
            tenant_name=tenant,
        )

    # Validate required CloudEvents config.
    missing = []
    if not base_url or not base_url.strip():
        missing.append("base_url")
    if not api_key or not api_key.strip():
        missing.append("api_key")
    if not tenant or not tenant.strip():
        missing.append("tenant")

    if missing:
        logger.warning(
            f"CloudEvents analytics missing required config: {', '.join(missing)}. "
            "CloudEvents dispatcher will be skipped."
        )
    else:
        emitter = EventEmitter(
            base_url=base_url,
            api_key=api_key,
            tenant=tenant,
            source_name=source_name,
            enable_search=enable_search,
            search_retention_days=retention_days,
            read_timeout_sec=timeout,
            connect_timeout_sec=timeout,
        )
        dispatchers.append(AsyncEventDispatcher(emitter=emitter))

    if not dispatchers:
        dispatcher = NoopEventDispatcher()
    elif len(dispatchers) == 1:
        dispatcher = dispatchers[0]
    else:
        dispatcher = CompositeDispatcher(dispatchers)

    return AnalyticsCollector(
        dispatcher=dispatcher,
        product_name=product_name,
        tenant_name=tenant,
    )


# Register shutdown handler (uses function to always get current global collector)
atexit.register(_shutdown_collector)


def classify_gateway_error(error: Exception) -> str:
    """Map an execution exception to a stable gateway error label."""
    error_name = type(error).__name__.lower()
    if "timeout" in error_name:
        return "timeout"
    if "connection" in error_name:
        return "connection"
    if "permission" in error_name or "auth" in error_name:
        return "auth"
    if "operational" in error_name:
        return "operational"
    if "database" in error_name or "sql" in error_name:
        return "database"
    return "unknown"


def classify_transpiler_error(error: Exception) -> str:
    """Map a transpiler exception to a stable error_class label."""
    if getattr(error, "is_connection_error", False):
        return "connection_error"
    if getattr(error, "code", 0) == 503:
        return "503"
    if 400 <= getattr(error, "code", 0) < 500:
        return "bad_request"
    return "unknown"


def disable_analytics() -> None:
    """Disable analytics by replacing collector with Noop."""
    global collector
    collector.shutdown(flush=False)
    collector = AnalyticsCollector(dispatcher=NoopEventDispatcher())


def cli_analytics(func: t.Callable[_P, _T]) -> t.Callable[_P, _T]:
    """Decorator for CLI commands to track analytics."""
    @wraps(func)
    def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T:
        import click
        from click.core import ParameterSource

        arg_keys = set()
        command_chain = []

        cli_context: click.Context = click.get_current_context()
        cli_context_cursor: t.Optional[click.Context] = cli_context
        while cli_context_cursor:
            arg_keys |= {
                k
                for k, source in cli_context_cursor._parameter_source.items()
                if source == ParameterSource.COMMANDLINE
            }
            command_chain.append(cli_context_cursor.info_name)
            cli_context_cursor = cli_context_cursor.parent

        command_name, *parent_command_names = command_chain

        common_context: t.Dict[str, t.Any] = {
            "command_name": command_name,
            "command_args": arg_keys,
            "parent_command_names": parent_command_names,
        }

        if "github" in parent_command_names:
            cicd_bot_config = None
            github_controller = cli_context.obj.get("github")
            if github_controller:
                cicd_bot_config = github_controller._context.config.cicd_bot
            collector.on_cicd_command(**common_context, cicd_bot_config=cicd_bot_config)
        else:
            collector.on_cli_command(**common_context)

        return func(*args, **kwargs)

    return wrapper


def python_api_analytics(func: t.Callable[_P, _T]) -> t.Callable[_P, _T]:
    """Decorator for Python API methods to track analytics."""
    @wraps(func)
    def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T:
        import inspect

        from vulcan import magics

        should_log = True

        try:
            stack = inspect.stack()
        except Exception:
            stack = []

        for frame in stack:
            if "click/" in frame.filename or frame.filename == magics.__file__:
                # Magics and CLI are reported separately.
                should_log = False
                break

        if should_log:
            collector.on_python_api_command(command_name=func.__name__, command_args=kwargs)

        return func(*args, **kwargs)

    return wrapper
