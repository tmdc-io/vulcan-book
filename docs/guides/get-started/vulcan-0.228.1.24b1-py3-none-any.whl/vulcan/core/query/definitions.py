from __future__ import annotations

import typing as t
from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, Field, computed_field


# Query resolution strategies
QueryStrategy = t.Literal["from_cache", "await_primary", "execute"]


class QueryStatus:
    """
    Query request status constants.

    ┌─────────────────────────────────────────────────────────┐
    │                   Request Lifecycle                     │
    └─────────────────────────────────────────────────────────┘

    ACCEPTED         QUEUED          IN_PROGRESS
        │                │                  │
        ├──enqueue()──►  │                  │
        │                ├──worker picks──► │
        │                │                  │
        │                │                  ├──────► SUCCESS
        │                │                  │
        │                │                  ├──────► FAILED
        │                │                  │
        └─────cancel─────┴───cancel────────►└──────► CANCELLED

    Lifecycle:
        ACCEPTED → QUEUED → IN_PROGRESS → SUCCESS/FAILED/CANCELLED
    """

    ACCEPTED = "ACCEPTED"  # Request received, before queuing
    QUEUED = "QUEUED"  # Job enqueued in pgqueuer
    IN_PROGRESS = "IN_PROGRESS"  # Worker processing
    SUCCESS = "SUCCESS"  # Completed successfully
    FAILED = "FAILED"  # Failed with error
    CANCELLED = "CANCELLED"  # Cancelled by user

    # All valid statuses
    ALL = (ACCEPTED, QUEUED, IN_PROGRESS, SUCCESS, FAILED, CANCELLED)

    # Active/in-flight statuses
    ACTIVE = (ACCEPTED, QUEUED, IN_PROGRESS)


class QueryStatusEnum(str, Enum):
    """Enum wrapper for query execution status."""

    ACCEPTED = QueryStatus.ACCEPTED
    QUEUED = QueryStatus.QUEUED
    IN_PROGRESS = QueryStatus.IN_PROGRESS
    SUCCESS = QueryStatus.SUCCESS
    FAILED = QueryStatus.FAILED
    CANCELLED = QueryStatus.CANCELLED


class QueryResult(BaseModel):
    """
    Query execution result metadata.
    
    Represents a stored query result (Parquet file in object storage).
    
    From: _query_results table
    Used by: QueryState.get_result()
    """
    result_id: str  # Unique result identifier (usually same as request_id)
    object_store_path: str  # Relative path in object storage (e.g., 'results/{id}.parquet')
    row_count: int  # Number of rows in result DataFrame
    size_bytes: int  # Size of Parquet file in bytes
    columns: t.List[t.Dict[str, str]]  # Column schema: [{'name': str, 'type': str}]. Types: integer, decimal, string, boolean, timestamp, duration
    sql: t.Optional[str] = None  # SQL query that produced this result
    references: t.Optional[t.Dict[str, t.List[t.List[str]]]] = None  # Field-level lineage: {column_name: [[model_name, field_name], ...]}
    created_ts: int  # When result was stored (Unix milliseconds)
    
    @computed_field
    @property
    def age_seconds(self) -> int:
        """Age of result in seconds."""
        now_ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return int((now_ts - self.created_ts) / 1000)
    
    @computed_field
    @property
    def size_mb(self) -> float:
        """Size in megabytes (rounded to 2 decimals)."""
        return round(self.size_bytes / (1024 * 1024), 2)


class QueryFingerprintResult(BaseModel):
    """
    Query fingerprint result with metadata.
    
    Combines fingerprint metadata (fingerprint, TTL) with result metadata (size, columns).
    This is a JOIN of _query_fingerprints and _query_results, flattened for convenience.
    
    From: _query_fingerprints JOIN _query_results
    Used by: QueryState.get_fingerprint_result()
    """
    # Fingerprint metadata (from _query_fingerprints)
    fingerprint: str  # Query fingerprint (normalized SQL + params + gateway)
    result_id: str  # Result identifier (FK to _query_results)
    depends_on: t.Optional[t.List[str]] = None  # Model dependencies for cache invalidation
    cached_at_ts: int  # When cache entry was created (Unix milliseconds)
    expires_ts: t.Optional[int] = None  # When cache expires (Unix milliseconds), None = never expires
    invalidated_by_run_id: t.Optional[str] = None  # Run ID that invalidated this cache entry
    invalidated_ts: t.Optional[int] = None  # When invalidation occurred (Unix milliseconds)
    
    # Result metadata (from _query_results, JOINed for convenience)
    object_store_path: str  # Relative path in object storage
    row_count: int  # Number of rows in result
    size_bytes: int  # Size of Parquet file in bytes
    columns: t.List[t.Dict[str, str]]  # Column schema
    result_created_ts: int  # When result was stored (Unix milliseconds)
    
    @computed_field
    @property
    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        if self.expires_ts is None:
            return False
        now_ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return now_ts > self.expires_ts
    
    @computed_field
    @property
    def cache_age_seconds(self) -> int:
        """Age of cache entry in seconds (since cached_at_ts)."""
        now_ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return int((now_ts - self.cached_at_ts) / 1000)
    
    @computed_field
    @property
    def result_age_seconds(self) -> int:
        """Age of underlying result in seconds (since result_created_ts)."""
        now_ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return int((now_ts - self.result_created_ts) / 1000)
    
    @computed_field
    @property
    def ttl_seconds(self) -> t.Optional[int]:
        """
        Original TTL in seconds (if cache has expiration).
        Returns None if cache never expires.
        """
        if self.expires_ts is None:
            return None
        return int((self.expires_ts - self.cached_at_ts) / 1000)
    
    @computed_field
    @property
    def size_mb(self) -> float:
        """Size in megabytes (rounded to 2 decimals)."""
        return round(self.size_bytes / (1024 * 1024), 2)
    
    def to_result(self) -> QueryResult:
        """Convert to standalone QueryResult."""
        return QueryResult(
            result_id=self.result_id,
            object_store_path=self.object_store_path,
            row_count=self.row_count,
            size_bytes=self.size_bytes,
            columns=self.columns,
            created_ts=self.result_created_ts
        )


class QueryRequest(BaseModel):
    """
    Query request (comprehensive audit log).
    
    Tracks ALL query requests regardless of resolution strategy.
    Every POST /statement creates a row with one of three strategies:
    - from_cache: Served from existing cache entry
    - await_primary: Waiting for in-flight execution
    - execute: New execution
    
    From: _query_requests table
    Used by: QueryState.get_request(), get_in_flight_request()
    """
    # Identity & Strategy
    request_id: str
    strategy: QueryStrategy
    fingerprint: str
    
    # Query Definition
    sql_query: str
    normalized_sql: str
    params: t.Optional[t.Union[t.Dict, t.List]] = None
    depends_on: t.Optional[t.List[str]] = None
    gateway: t.Optional[str] = None
    
    # Request Metadata
    submitted_by: t.Optional[str] = None
    submitted_ts: int
    # Cache TTL hint in minutes.
    # 0 means "never expires" (no TTL hint), matching the legacy None semantics.
    ttl: int = 0
    meta: t.Optional[t.Dict] = None
    
    # Query Type & Original Query Forms
    query_type: t.Optional[str] = None
    semantic_query: t.Optional[str] = None
    rest_query: t.Optional[t.Dict] = None
    graphql_query: t.Optional[str] = None
    
    # Perspective Link (internal, not exposed in APIs)
    perspective_id: t.Optional[str] = None
    
    # Execution Lifecycle (ONLY for strategy='execute')
    execution_status: t.Optional[str] = None
    pgq_job_id: t.Optional[int] = None
    execution_start_ts: t.Optional[int] = None
    execution_end_ts: t.Optional[int] = None
    
    # Deduplication Link (ONLY for strategy='await_primary')
    primary_request_id: t.Optional[str] = None
    
    # Cache Metadata (ONLY for strategy='from_cache')
    cached_at_ts: t.Optional[int] = None
    
    # Result or Error
    result_id: t.Optional[str] = None
    error_message: t.Optional[str] = None
    
    @computed_field
    @property
    def execution_duration_ms(self) -> t.Optional[int]:
        """
        Execution duration in milliseconds.
        Returns None if not yet started or still in progress.
        Only applicable for strategy='execute'.
        """
        if self.execution_start_ts is None or self.execution_end_ts is None:
            return None
        return self.execution_end_ts - self.execution_start_ts
    
    @computed_field
    @property
    def queue_wait_time_ms(self) -> t.Optional[int]:
        """
        Queue wait time in milliseconds (submitted → started).
        Returns None if not yet started.
        Only applicable for strategy='execute'.
        """
        if self.execution_start_ts is None:
            return None
        return self.execution_start_ts - self.submitted_ts
    
    @computed_field
    @property
    def total_duration_ms(self) -> t.Optional[int]:
        """
        Total duration in milliseconds (submitted → ended).
        Returns None if not yet ended.
        Only applicable for strategy='execute'.
        """
        if self.execution_end_ts is None:
            return None
        return self.execution_end_ts - self.submitted_ts
    
    @computed_field
    @property
    def age_seconds(self) -> int:
        """Age of request in seconds (since submission)."""
        now_ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return int((now_ts - self.submitted_ts) / 1000)


class Perspective(BaseModel):
    """
    Perspective database model.
    
    Represents a saved query with auto-refresh capabilities.
    
    Core fields from _query_perspective table.
    Query definition fields are denormalized from the original statement_id.
    """
    # Core table fields (from _query_perspective)
    perspective_id: str
    slug: str
    name: str
    description: t.Optional[str] = None
    tags: t.List[str] = []
    terms: t.List[str] = []
    owner: str
    request_id: t.Optional[str] = None  # Current request_id (for result link, updates on refresh)
    fingerprint: str  # Fingerprint of original query (immutable, denormalized for performance)
    
    # Denormalized Query Definition Fields
    sql_query: t.Optional[str] = None
    normalized_sql: t.Optional[str] = None
    params: t.Optional[t.Union[t.Dict, t.List]] = None
    gateway: t.Optional[str] = None
    # Cache TTL hint in minutes.
    # 0 means "never expires" (no TTL hint), matching the legacy None semantics.
    ttl: int = 0
    meta: t.Optional[t.Dict] = None
    query_type: t.Optional[str] = None
    semantic_query: t.Optional[str] = None
    rest_query: t.Optional[t.Dict] = None
    graphql_query: t.Optional[str] = None
    depends_on: t.Optional[t.List[str]] = None
    
    auto_refresh: bool = True
    is_public: bool = False
    allowed_user_ids: t.List[str] = []
    created_at: int  # Unix milliseconds
    updated_at: int  # Unix milliseconds
    created_by: t.Optional[str] = None
    updated_by: t.Optional[str] = None
