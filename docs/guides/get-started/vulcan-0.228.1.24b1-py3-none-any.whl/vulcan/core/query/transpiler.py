from __future__ import annotations

import logging
import typing as t
from urllib.parse import urljoin

import httpx
import pydantic
from pydantic import Field

from schema.auth import SecurityContext
from schema.rest_query import RestQuery
from vulcan.core.config import Config
from vulcan.core.dialect import wrap_query_with_alias_mapping
from vulcan.utils.errors import ApiError, VulcanError, TranspilerError
from vulcan.utils.pydantic import PydanticModel

if t.TYPE_CHECKING:
    from vulcan.core.context import Context


logger = logging.getLogger(__name__)

# Mapping from connection dialect to Transpiler db_type (X-DB-Type header)
SEMANTIC_DIALECT_MAPPING: t.Dict[str, str] = {
    "duckdb": "duckdb",
    "snowflake": "snowflake",
    "databricks": "databricks-jdbc",
    "bigquery": "bigquery",
    "postgres": "postgres",
    "redshift": "redshift",
    "mysql": "mysql",
    "spark": "spark",
    "trino": "trino",
    "athena": "athena",
    "fabric": "mssql",
    "mssql": "mssql",
    "tsql": "mssql",
}


def get_transpiler_params_from_snapshots(
    context: "Context",
    environment: t.Optional[str] = None,
) -> t.Dict[str, t.Any]:
    """
    Derive schema, tenant_id, name, db_type from finalized snapshots for TranspilerClient.transpile().

    Produces the ``schema.cube.CubeSchema`` wire shape (Cube.js-native ``cubes`` / ``views``
    keys). Tenant, project name, and warehouse dialect are resolved from ``context.config``
    directly.

    Args:
        context: Vulcan ``Context`` whose state holds the finalized environment snapshots.
        environment: Target environment name; falls back to ``config.default_target_environment``.

    Returns:
        Dict with ``schema`` (dict-dumped CubeSchema), ``tenant_id``, ``name``, ``db_type``,
        ready to splat into ``TranspilerClient.transpile(**params, ...)``.

    Raises:
        VulcanError: If ``config.tenant``, ``config.name``, or the connection dialect is unset.
    """
    schema = context.cube_schema_for_environment(environment).model_dump(
        mode="json", exclude_none=True
    )
    cfg = context.config
    tenant_id = (cfg.tenant or "").strip()
    if not tenant_id:
        raise VulcanError(
            "config.tenant is unset; set DATAOS_TENANT_ID or YAML `tenant` "
            "before calling the transpiler."
        )
    name = (cfg.name or "").strip()
    if not name:
        raise VulcanError(
            "config.name is unset; configure the project name in YAML "
            "before calling the transpiler."
        )

    connection = cfg.get_connection()
    dialect = getattr(connection, "DIALECT", None) or getattr(connection, "type_", None)
    if not dialect:
        raise VulcanError(
            "Connection has no DIALECT; cannot determine db_type for transpiler. "
            "Ensure a gateway connection is configured."
        )
    db_type = SEMANTIC_DIALECT_MAPPING.get(dialect, dialect)

    return {
        "schema": schema,
        "tenant_id": tenant_id,
        "name": name,
        "db_type": db_type,
    }


class TranspilerReply(PydanticModel):
    """Reply from Transpiler /v1/sql."""

    model_config = pydantic.ConfigDict(extra="ignore")

    sql: t.Dict[str, t.Any] = Field(
        ...,
        description="SQL generation result containing sql array, aliases, order, etc.",
    )
    
    # Internal field to store wrapped SQL (not part of API response)
    _wrapped_sql: t.Optional[str] = None

    @property
    def sql_statement(self) -> str:
        """Return the SQL statement as a string."""
        sql_data = self.sql.get("sql", [])
        if isinstance(sql_data, list) and len(sql_data) > 0:
            # First element is the SQL string
            return sql_data[0]
        return str(sql_data)

    @property
    def wrapped_sql_statement(self) -> str:
        """Return wrapped SQL with column aliases applied, or original SQL if not wrapped."""
        if self._wrapped_sql is not None:
            return self._wrapped_sql
        return self.sql_statement

    @property
    def sql_params(self) -> t.Optional[t.List[t.Any]]:
        """Return positional SQL parameters, if present."""
        sql_data = self.sql.get("sql", [])
        if isinstance(sql_data, list) and len(sql_data) > 1:
            # Second element is the parameters array
            params = sql_data[1]
            return params if params else None
        return None

    @property
    def alias_mapping(self) -> t.Dict[str, str]:
        """Return mapping from SQL aliases to semantic member names."""
        return self.sql.get("aliasNameToMember", {})

    @property
    def order(self) -> list:
        """Get order clause information."""
        return self.sql.get("order", [])


class TranspilerClient:
    """Async HTTP client for the Transpiler /v1/sql endpoint."""

    def __init__(
        self,
        url: str,
        timeout: int = 30,
        headers: t.Optional[t.Dict[str, str]] = None,
    ):
        self.url = url
        self.timeout = timeout
        self.default_headers = headers or {}
        self._client: t.Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "TranspilerClient":
        """Create an underlying AsyncClient for use in a context manager."""
        self._client = httpx.AsyncClient(
            timeout=self.timeout,
            headers=self.default_headers,
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Close the underlying AsyncClient on context manager exit."""
        if self._client:
            await self._client.aclose()

    async def transpile(
        self,
        query: RestQuery | str,
        *,
        # By default we disable Cube post-processing so Vulcan controls result shaping.
        disable_post_processing: bool = True,
        user: str,
        security_context: SecurityContext | None = None,
        headers: t.Optional[t.Dict[str, str]] = None,
        dialect: t.Optional[str] = None,
        # Central transpiler payload (required when calling central API)
        schema: t.Optional[t.Dict[str, t.Any]] = None,
        tenant_id: t.Optional[str] = None,
        request_id: t.Optional[str] = None,
        db_type: t.Optional[str] = None,
        name: t.Optional[str] = None,
    ) -> TranspilerReply:
        """Transpile a REST or semantic SQL query via Transpiler /v1/sql."""
        if not self._client:
            raise RuntimeError("TranspilerClient must be used as async context manager")

        if isinstance(query, RestQuery):
            format_value = "rest"
            query_value: t.Any = query.model_dump(exclude_none=True, by_alias=True)
        else:
            format_value = "sql"
            query_value = query

        request_headers: t.Dict[str, str] = {**self.default_headers, **(headers or {})}

        # All-or-nothing: central transpiler requires schema, tenant_id, request_id, db_type, name
        central_params = {
            "schema": schema,
            "tenant_id": tenant_id,
            "request_id": request_id,
            "db_type": db_type,
            "name": name,
        }
        missing = [
            k for k, v in central_params.items()
            if v is None or (isinstance(v, str) and not v.strip())
        ]
        if missing:
            raise ValueError(
                f"Central transpiler requires all of: schema, tenant_id, request_id, db_type, name. "
                f"Missing: {', '.join(missing)}"
            )

        payload = {
            "query": query_value,
            "format": format_value,
            "disable_post_processing": disable_post_processing,
            "schema": schema,
        }
        request_headers["X-Request-Id"] = request_id
        request_headers["X-Tenant-Id"] = tenant_id
        request_headers["X-DB-Type"] = db_type
        request_headers["X-User"] = user
        request_headers["X-Vulcan-Id"] = name
        request_headers.update((security_context or SecurityContext()).to_headers())

        # Log high-level request information
        logger.info(
            "Transpiler request start url=%s format=%s disable_post_processing=%s",
            self.url,
            format_value,
            disable_post_processing,
        )

        try:
            response = await self._client.post(
                self.url,
                json=payload,
                headers=request_headers,
            )

            logger.info(
                "Transpiler response status=%s format=%s",
                response.status_code,
                format_value,
            )

            if response.status_code != 200:
                try:
                    data = response.json() if response.content else {}
                except Exception:
                    data = {}
                err = data.get("error")
                if isinstance(err, dict) and "code" in err and "message" in err:
                    message = err["message"]
                else:
                    message = data.get("detail", data.get("message", f"HTTP {response.status_code}"))
                logger.error(
                    "Transpiler non-200 response status=%s format=%s error=%s",
                    response.status_code,
                    format_value,
                    message,
                    extra={"status_code": response.status_code, "format": format_value},
                )
                raise TranspilerError(
                    message=message,
                    code=response.status_code,
                    response_data=data,
                )

            try:
                data = response.json()
            except Exception as json_error:
                logger.error(
                    "Transpiler invalid JSON response format=%s error=%s",
                    format_value,
                    json_error,
                )
                logger.debug(
                    "Transpiler raw response (first 500 chars): %s",
                    response.text[:500],
                )
                # 502 – Bad Gateway (invalid response shape / JSON)
                raise TranspilerError(
                    message=f"Invalid JSON response from Transpiler: {str(json_error)}",
                    code=502,
                )

            # Check for error status in response body even when HTTP status is 200
            sql_data = data.get("sql", {})
            if isinstance(sql_data, dict) and sql_data.get("status") == "error":
                error_message = sql_data.get("error", "Unknown error from Transpiler")
                query_type = sql_data.get("query_type", "unknown")
                logger.error(
                    "Transpiler error in response body status=%s format=%s error=%s query_type=%s",
                    response.status_code,
                    format_value,
                    error_message,
                    query_type,
                    extra={
                        "status_code": response.status_code,
                        "format": format_value,
                        "query_type": query_type,
                    },
                )
                # 400 – Bad Request (query error, even though HTTP status is 200)
                raise TranspilerError(
                    message=error_message,
                    code=400,
                    response_data=data,
                    query_type=query_type,
                )

            reply = TranspilerReply(**data)
            
            # Wrap SQL with alias mapping if dialect provided
            if dialect and reply.alias_mapping:
                try:
                    wrapped_sql = wrap_query_with_alias_mapping(
                        reply.sql_statement,
                        reply.alias_mapping,
                        dialect=dialect
                    )
                    reply._wrapped_sql = wrapped_sql
                    logger.debug(
                        "Wrapped SQL with alias mapping: dialect=%s, columns=%s",
                        dialect,
                        len(reply.alias_mapping)
                    )
                except Exception as wrap_error:
                    logger.warning(
                        "Failed to wrap SQL with alias mapping: %s. Using original SQL.",
                        wrap_error,
                        exc_info=True
                    )
                    # Continue with original SQL if wrapping fails
            
            logger.debug(
                "Transpiler reply parsed format=%s sql_len=%s params_count=%s",
                format_value,
                len(reply.sql_statement),
                0 if reply.sql_params is None else len(reply.sql_params),
            )
            logger.debug("Transpiler raw SQL: %s", reply.sql_statement)
            if reply._wrapped_sql is not None:
                logger.debug("Transpiler wrapped SQL: %s", reply._wrapped_sql)
            return reply

        except httpx.RequestError as e:
            logger.error(
                "Transpiler connection error url=%s format=%s error=%s",
                self.url,
                format_value,
                e,
            )
            # 503 – Service Unavailable (connect errors)
            raise TranspilerError(
                message=f"Failed to connect to Transpiler: {str(e)}",
                code=503,
                is_connection_error=True,
            )
        except TranspilerError:
            raise
        except Exception as e:  # pragma: no cover - defensive logging
            logger.error(
                "Unexpected error in Transpiler client url=%s format=%s error=%s",
                self.url,
                format_value,
                e,
            )
            # 500 – Internal Server Error (unexpected client bug)
            raise TranspilerError(
                message=f"Unexpected error: {str(e)}",
                code=500,
            )


def make_transpiler_client(config: Config, token: t.Optional[str] = None) -> TranspilerClient:
    """Create a TranspilerClient from a Vulcan Config.

    Token resolution: explicit ``token`` param > ``config.transpiler.token`` > no auth.
    """
    base = config.transpiler.base_url
    base = base if base.endswith("/") else base + "/"
    transpiler_url = urljoin(base, "v1/sql")
    headers = {}
    effective_token = token or config.transpiler.token
    if effective_token:
        headers["Authorization"] = f"Bearer {effective_token}"
    return TranspilerClient(
        url=transpiler_url,
        timeout=config.transpiler.timeout,
        headers=headers if headers else None,
    )

