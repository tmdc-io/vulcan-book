import io
import logging
import typing as t

import pandas as pd
from fsspec.spec import AbstractFileSystem

from vulcan.core.config.object_store import ObjectStoreConfig
from vulcan.utils.errors import ObjectStoreError, VulcanError

if t.TYPE_CHECKING:
    import s3fs
    import gcsfs
    import adlfs

logger = logging.getLogger(__name__)


class ObjectStoreClient:
    """
    Manages query result storage across S3, GCS, Azure, and MinIO.
    Uses fsspec for provider abstraction and PyArrow for Parquet serialization.
    """

    def __init__(
        self,
        config: ObjectStoreConfig,
        *,
        tenant: str,
        project: str,
    ):
        """Initialize with object store configuration.

        Query results are stored under:
          <base_path>/<tenant>/<project>/results/<result_id>.parquet
        """
        self.config = config
        tenant = tenant.strip() if isinstance(tenant, str) else ""
        project = project.strip() if isinstance(project, str) else ""
        if not tenant or not project:
            raise ValueError(
                "ObjectStoreClient requires non-empty `tenant` and `project` to build result paths. "
                "These should come from config.yaml (tenant/name)."
            )
        self.tenant = tenant
        self.project = project
        # Bake tenant/project into the effective base path so the remaining layout stays stable.
        base = self.config.base_path.rstrip("/")
        self._base_path = f"{base}/{self.tenant}/{self.project}"
        self._fs: t.Optional[AbstractFileSystem] = None

    @property
    def fs(self) -> AbstractFileSystem:
        """Lazy-load filesystem (connects on first use)."""
        if self._fs is None:
            self._fs = self._get_filesystem()
        return self._fs

    def validate_connection(self) -> None:
        """
        Validate object store with read/write/delete test.
        Raises ObjectStoreError with provider-specific hints if validation fails.
        """
        import time
        from vulcan.utils import random_id

        test_key = f".healthcheck/test_{random_id()}_{int(time.time() * 1000)}.txt"
        test_data = b"Object store validation test"
        full_path = f"{self.config.bucket}/{test_key}"

        try:
            # Write test
            with self.fs.open(full_path, "wb") as f:
                f.write(test_data)

            # Read test
            with self.fs.open(full_path, "rb") as f:
                read_data = f.read()

            if read_data != test_data:
                raise ObjectStoreError("Data integrity check failed")

            # Delete test
            self.fs.delete(full_path)

        except ObjectStoreError:
            raise
        except FileNotFoundError as e:
            raise ObjectStoreError(f"Bucket '{self.config.bucket}' not found: {e}")
        except PermissionError as e:
            raise ObjectStoreError(f"Permission denied for bucket '{self.config.bucket}': {e}")
        except Exception as e:
            provider = self.config.provider
            hints = {
                "s3": "Check AWS credentials and bucket name",
                "minio": "Check endpoint URL, credentials, and bucket name",
                "gcs": "Check GCS credentials and bucket name",
                "adls": "Check Azure credentials and container name",
            }
            hint = hints.get(provider, "Check credentials and bucket name")
            raise ObjectStoreError(
                f"Validation failed ({provider}, {self.config.bucket}): {e}\nHint: {hint}"
            )

    def upload_result(self, df: pd.DataFrame, result_id: str) -> int:
        """Upload DataFrame as Parquet, returns size in bytes."""
        relative_path = self._result_id_to_path(result_id)
        full_path = f"{self.config.bucket}/{relative_path}"

        try:
            # Convert DataFrame to Parquet bytes
            buffer = io.BytesIO()
            df.to_parquet(
                buffer,
                compression=self.config.compression,
                engine="pyarrow",  # Use PyArrow engine
                index=False,  # Don't include DataFrame index
            )
            buffer.seek(0)
            parquet_bytes = buffer.read()
            size_bytes = len(parquet_bytes)

            # Upload to object store
            with self.fs.open(full_path, "wb") as f:
                f.write(parquet_bytes)

            return size_bytes

        except Exception as e:
            raise ObjectStoreError(f"Failed to upload result: {e}") from e

    def generate_presigned_url(self, result_id: str, expiry_mins: t.Optional[int] = None) -> str:
        """Generate presigned download URL (falls back to storage URL if unsupported)."""
        relative_path = self._result_id_to_path(result_id)
        expiry_mins = expiry_mins or self.config.presigned_url_expiry_mins
        expiry_seconds = expiry_mins * 60
        full_path = f"{self.config.bucket}/{relative_path}"

        try:
            if hasattr(self.fs, "url"):
                url = self.fs.url(full_path, expires=expiry_seconds)  # s3fs, gcsfs
            elif hasattr(self.fs, "signed_url"):
                url = self.fs.signed_url(full_path, expires=expiry_seconds)  # Azure
            else:
                url = self._construct_storage_url(relative_path)
                logger.warning(f"Presigned URLs not supported for {self.config.provider}")
            return url
        except Exception:
            return self._construct_storage_url(relative_path)

    def get_result(self, result_id: str) -> pd.DataFrame:
        """Download and read result as DataFrame."""
        relative_path = self._result_id_to_path(result_id)
        full_path = f"{self.config.bucket}/{relative_path}"

        try:
            with self.fs.open(full_path, "rb") as f:
                return pd.read_parquet(f, engine="pyarrow")
        except Exception as e:
            raise ObjectStoreError(f"Failed to download result: {e}") from e

    def delete_result(self, result_id: str) -> None:
        """Delete result from storage (ignores FileNotFoundError)."""
        relative_path = self._result_id_to_path(result_id)
        full_path = f"{self.config.bucket}/{relative_path}"

        try:
            self.fs.rm(full_path)
        except FileNotFoundError:
            pass
        except Exception as e:
            raise ObjectStoreError(f"Failed to delete result: {e}") from e

    def _result_id_to_path(self, result_id: str) -> str:
        """Convert result_id to relative storage path."""
        return f"{self._base_path}/results/{result_id}.parquet"

    def _construct_storage_url(self, relative_path: str) -> str:
        """Construct storage URL (e.g., s3://bucket/path)."""
        bucket = self.config.bucket
        provider = self.config.provider

        if provider in ["s3", "minio"]:
            return f"s3://{bucket}/{relative_path}"
        elif provider == "gcs":
            return f"gs://{bucket}/{relative_path}"
        elif provider == "azure":
            account = self.config.credentials.get("storage_account")
            return f"abfs://{bucket}@{account}.dfs.core.windows.net/{relative_path}"
        else:
            return f"{provider}://{bucket}/{relative_path}"

    def _get_filesystem(self) -> AbstractFileSystem:
        """Get filesystem implementation based on provider."""
        provider = self.config.provider

        if provider in ["s3", "minio"]:
            return self._get_s3_filesystem()
        elif provider == "gcs":
            return self._get_gcs_filesystem()
        elif provider == "azure":
            return self._get_azure_filesystem()
        else:
            raise ValueError(f"Unsupported provider: {provider}")

    def _get_s3_filesystem(self) -> "s3fs.S3FileSystem":
        """Configure S3/MinIO filesystem."""
        import s3fs

        creds = self.config.credentials

        fs_kwargs = {
            "key": creds.get("access_key_id"),
            "secret": creds.get("secret_access_key"),
            "asynchronous": False,  # Force synchronous mode (Vulcan is sync)
            "client_kwargs": {"region_name": creds.get("region", "us-east-1")},
        }

        # MinIO requires endpoint_url
        if "endpoint_url" in creds:
            endpoint = creds["endpoint_url"]
            fs_kwargs["endpoint_url"] = endpoint
            fs_kwargs["use_ssl"] = endpoint.startswith("https://")

        return s3fs.S3FileSystem(**fs_kwargs)

    def _get_gcs_filesystem(self) -> "gcsfs.GCSFileSystem":
        """Configure GCS filesystem."""
        import gcsfs

        creds = self.config.credentials
        project_id = creds.get("project_id")
        creds_file = creds.get("credentials_file")

        if creds_file:
            return gcsfs.GCSFileSystem(
                token=creds_file, project=project_id, asynchronous=False  # Force synchronous mode
            )
        else:
            # Use default credentials (e.g., from gcloud CLI)
            return gcsfs.GCSFileSystem(
                project=project_id, asynchronous=False  # Force synchronous mode
            )

    def _get_azure_filesystem(self) -> "adlfs.AzureBlobFileSystem":
        """Configure Azure filesystem (tries connection string, account key, service principal, defaults)."""
        import adlfs

        creds = self.config.credentials

        # 1. Try connection string
        if "connection_string" in creds:
            return adlfs.AzureBlobFileSystem(
                connection_string=creds["connection_string"],
                asynchronous=False,  # Force synchronous mode
            )

        # 2. Try account key
        account_name = creds.get("storage_account")
        account_key = creds.get("storage_key")

        if account_name and account_key:
            return adlfs.AzureBlobFileSystem(
                account_name=account_name,
                account_key=account_key,
                asynchronous=False,  # Force synchronous mode
            )

        # 3. Try service principal
        if all(k in creds for k in ["tenant_id", "client_id", "client_secret"]):
            return adlfs.AzureBlobFileSystem(
                account_name=account_name,
                tenant_id=creds["tenant_id"],
                client_id=creds["client_id"],
                client_secret=creds["client_secret"],
                asynchronous=False,  # Force synchronous mode
            )

        # 4. Default credentials (Managed Identity, Azure CLI)
        return adlfs.AzureBlobFileSystem(
            account_name=account_name, asynchronous=False  # Force synchronous mode
        )
