import json

from fastapi import FastAPI

from api.main import create_app


def generate_openapi_spec(app: FastAPI, path: str) -> None:
    """Generate OpenAPI JSON spec from FastAPI app"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(app.openapi(), f, indent=2)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate OpenAPI specification")
    parser.add_argument("--output", default="openapi.json", help="Path to output OpenAPI spec file")
    args = parser.parse_args()

    app = create_app()
    generate_openapi_spec(app, args.output)
    print(f"OpenAPI spec generated: {args.output}")
