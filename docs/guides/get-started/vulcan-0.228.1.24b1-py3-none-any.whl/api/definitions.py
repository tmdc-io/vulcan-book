from __future__ import annotations

import typing as t

from vulcan.utils.pydantic import PydanticModel
from pydantic import Field as PydanticField, ConfigDict


class Link(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,  # Allow fields to be populated by both field name and alias
        exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    )
    
    href: str  # Target URI (required)
    method: t.Optional[str] = None  # HTTP method (default: GET)
    type: t.Optional[str] = None  # Response media type
    title: t.Optional[str] = None  # Human-readable description
    templated: t.Optional[bool] = None  # True if href uses URI templates like /models/{name}


class SelfLink(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,  # Allow fields to be populated by both field name and alias
    )
    
    self_link: Link = PydanticField(alias="self", serialization_alias="self")

    @classmethod
    def from_href(cls, href: str) -> "SelfLink":
        return cls.model_construct(self_link=Link(href=href))


class Pagination(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,  # Allow fields to be populated by both field name and alias
    )
    
    limit: int  # Number of items per page
    offset: int  # Number of items skipped
    has_more: bool  # Whether there are more items available
    order_by: str
    order_direction: str

