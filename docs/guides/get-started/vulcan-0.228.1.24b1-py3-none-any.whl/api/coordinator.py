"""Leader election for the environment change watcher.

Uses a PostgreSQL advisory lock held on a dedicated ``asyncpg``
connection to ensure only one replica runs the polling loop at a time.
"""

from __future__ import annotations

import hashlib
import logging
import typing as t

import asyncpg

logger = logging.getLogger(__name__)


def _watcher_lock_id(schema: str) -> int:
    """Derive a stable advisory lock ID from the state schema name.

    PostgreSQL advisory locks take a 64-bit integer key.  We hash the
    schema to avoid collisions between different projects sharing the
    same database.  The ``& 0x7FFFFFFFFFFFFFFF`` mask keeps the value
    within the signed-int64 range that ``pg_try_advisory_lock`` expects.
    """
    return int(hashlib.sha256(f"env_watcher:{schema}".encode()).hexdigest(), 16) & 0x7FFFFFFFFFFFFFFF


class WatcherLeaderCoordinator:
    """Leader election via a dedicated PostgreSQL advisory lock connection.

    Holds a single long-lived ``asyncpg`` connection (outside the pool).
    The session-level advisory lock lives on that connection for the full
    watcher lifetime.  If the connection drops (crash, network partition),
    PostgreSQL releases the lock and a surviving replica acquires it on
    its next attempt.

    Startup bookkeeping is unified here: the first successful leadership
    acquisition marks ``startup_done`` so the watcher loop can proceed
    without repeating first-leader-only work on every iteration.
    """

    def __init__(self, connection_dsn: str, state_schema: str) -> None:
        self._dsn = connection_dsn
        self._lock_id = _watcher_lock_id(state_schema)
        self._conn: t.Optional[asyncpg.Connection] = None
        self._leader = False
        self._startup_done = False

    async def ensure_leadership(self) -> bool:
        """Try to acquire or verify leadership.

        Returns True when this process holds the advisory lock on a live
        connection.  Returns False when the lock is held elsewhere or the
        connection cannot be established.
        """
        if self._leader:
            try:
                await self._conn.fetchval("SELECT 1")
                return True
            except Exception:
                logger.warning("Leader connection lost, resetting leadership")
                await self._reset()
                return False

        try:
            if self._conn is None or self._conn.is_closed():
                self._conn = await asyncpg.connect(self._dsn)

            row = await self._conn.fetchrow(
                "SELECT pg_try_advisory_lock($1) AS acquired", self._lock_id,
            )
            self._leader = bool(row and row["acquired"])
            if self._leader:
                logger.info("Acquired watcher leader lock (lock_id=%d)", self._lock_id)
            return self._leader
        except Exception as exc:
            logger.debug("Leadership acquisition failed: %s", exc)
            await self._reset()
            return False

    @property
    def is_leader(self) -> bool:
        if not self._leader:
            return False
        if self._conn is None or self._conn.is_closed():
            self._leader = False
            return False
        return True

    @property
    def startup_done(self) -> bool:
        return self._startup_done

    def mark_startup_done(self) -> None:
        self._startup_done = True

    async def release(self) -> None:
        """Release leadership by closing the dedicated connection."""
        await self._reset()

    async def _reset(self) -> None:
        self._leader = False
        conn, self._conn = self._conn, None
        if conn is not None:
            try:
                await conn.close()
            except Exception:
                pass
