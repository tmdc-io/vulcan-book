"""Heimdall API response models.

Defines Pydantic models for Heimdall authorization responses.
"""

from __future__ import annotations

from typing import Optional, List

from pydantic import BaseModel, Field


class AuthorizeResult(BaseModel):
    """Successful authorization result containing user identity.
    
    Attributes:
        id: User identifier (e.g., "akshayjaintmdcio")
        tags: List of roles and permissions (e.g., ["roles:id:operator", "users:id:akshayjaintmdcio"])
    """
    
    id: str = Field(..., description="User identifier")
    tags: List[str] = Field(default_factory=list, description="User roles and permissions")


class AuthorizeError(BaseModel):
    """Authorization error details.
    
    Attributes:
        status: HTTP status code from Heimdall
        message: Error message describing the failure
    """
    
    status: int = Field(..., description="Error status code")
    message: str = Field(..., description="Error message")


class AuthorizeResponse(BaseModel):
    """Heimdall authorization response.
    
    Attributes:
        allow: Whether the operation is allowed
        valid: Whether the token is valid
        result: User identity (present on successful auth)
        error: Error details (present on failed auth)
        heimdall_status: HTTP status code from Heimdall (set by client, not in response body)
    
    Example (success - HTTP 200):
        {
            "allow": true,
            "valid": true,
            "result": {"id": "user123", "tags": ["roles:id:operator"]}
        }
    
    Example (failure - HTTP 400):
        {
            "allow": false,
            "valid": false,
            "error": {"status": 400, "message": "ParseTokenV2, not an apikey and not a jwt"}
        }
    """
    
    allow: bool = Field(..., description="Whether the operation is allowed")
    valid: bool = Field(..., description="Whether the token is valid")
    result: Optional[AuthorizeResult] = Field(None, description="User identity on success")
    error: Optional[AuthorizeError] = Field(None, description="Error details on failure")
    heimdall_status: Optional[int] = Field(None, description="HTTP status from Heimdall (set by client)")
    
    @property
    def user_id(self) -> Optional[str]:
        """Get user ID from result."""
        return self.result.id if self.result else None
    
    @property
    def user_tags(self) -> List[str]:
        """Get user tags from result."""
        return self.result.tags if self.result else []
    
    @property
    def error_message(self) -> Optional[str]:
        """Get error message if present."""
        return self.error.message if self.error else None

