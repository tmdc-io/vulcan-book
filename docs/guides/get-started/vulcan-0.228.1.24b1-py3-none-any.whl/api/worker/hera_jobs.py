from __future__ import annotations

import logging
import typing as t
from datetime import timedelta

from pgqueuer.errors import DuplicateJobError
from pgqueuer.models import Job
from pydantic import BaseModel
from vulcan.core import constants as c

from api.utils.async_blocking import run_blocking

logger = logging.getLogger(__name__)

HERA_SYNC_ENTRYPOINT = "hera_sync"
_DEFAULT_DELAY = timedelta(seconds=5)
MAX_RETRIES = 3

# IMPORTANT: This dict is process-local. It works because the env watcher
# (which sets the flag on DuplicateJobError) and the Hera job handler
# (which reads/clears it on completion) run on the same event loop in the
# same FastAPI process. If the worker is ever split into a separate process,
# this mechanism must move to a database-backed flag.
_dirty: dict[str, bool] = {}


class HeraSyncPayload(BaseModel):
    kind: t.Literal["full_sync", "run_status", "perspective_sync", "perspective_delete"]
    environment: str
    plan_id: t.Optional[str] = None
    update_run_status: bool = False
    perspective_id: t.Optional[str] = None
    slug: t.Optional[str] = None
    retry_count: int = 0


def _dirty_key(kind: str, environment: str) -> str:
    return f"{kind}:{environment}"


def _is_prod(environment: str) -> bool:
    """Return ``True`` when the target environment is production."""
    return environment == c.PROD


def _dedupe_key(payload: HeraSyncPayload) -> str:
    """Build the PGQueuer dedupe key for a Hera payload."""
    parts = [HERA_SYNC_ENTRYPOINT, payload.kind, payload.environment]
    if payload.kind == "full_sync":
        parts.append(payload.plan_id or "")
    else:
        parts.append(str(payload.retry_count))
    if payload.kind in {"perspective_sync", "perspective_delete"}:
        parts.append(payload.perspective_id or payload.slug or "")
    return ":".join(parts)


async def _enqueue(
    qm: t.Any,
    payload: HeraSyncPayload,
    *,
    delay: timedelta,
    dirty_on_duplicate: bool,
) -> t.Any:
    """Enqueue a Hera job, converting duplicates into dirty follow-ups."""
    if not _is_prod(payload.environment):
        return None

    try:
        return await qm.queries.enqueue(
            [HERA_SYNC_ENTRYPOINT],
            [payload.model_dump_json().encode("utf-8")],
            execute_after=[delay],
            dedupe_key=[_dedupe_key(payload)],
        )
    except DuplicateJobError:
        if dirty_on_duplicate:
            _dirty[_dirty_key(payload.kind, payload.environment)] = True
            logger.debug(
                "Hera %s already pending/running for %s; dirty flag set",
                payload.kind,
                payload.environment,
            )
        else:
            logger.debug(
                "Hera %s already pending/running for %s; dropping duplicate",
                payload.kind,
                payload.environment,
            )
        return None


async def enqueue_hera_full_sync(
    qm: t.Any,
    environment: str,
    plan_id: str,
    delay: timedelta = _DEFAULT_DELAY,
    update_run_status: bool = False,
    retry_count: int = 0,
) -> t.Any:
    """Enqueue a delayed full Hera sync for a production environment."""
    return await _enqueue(
        qm,
        HeraSyncPayload(
            kind="full_sync",
            environment=environment,
            plan_id=plan_id,
            update_run_status=update_run_status,
            retry_count=retry_count,
        ),
        delay=delay,
        dirty_on_duplicate=False,
    )


async def enqueue_hera_run_status(
    qm: t.Any,
    environment: str,
    delay: timedelta = _DEFAULT_DELAY,
    retry_count: int = 0,
) -> t.Any:
    """Enqueue a delayed Hera run-status refresh for a production environment."""
    return await _enqueue(
        qm,
        HeraSyncPayload(kind="run_status", environment=environment, retry_count=retry_count),
        delay=delay,
        dirty_on_duplicate=True,
    )


async def enqueue_hera_perspective_sync(
    qm: t.Any,
    environment: str,
    perspective_id: str,
    retry_count: int = 0,
) -> t.Any:
    """Enqueue a Hera perspective sync for a production environment."""
    return await _enqueue(
        qm,
        HeraSyncPayload(
            kind="perspective_sync",
            environment=environment,
            perspective_id=perspective_id,
            retry_count=retry_count,
        ),
        delay=timedelta(0),
        dirty_on_duplicate=False,
    )


async def enqueue_hera_perspective_delete(
    qm: t.Any,
    environment: str,
    slug: str,
    retry_count: int = 0,
) -> t.Any:
    """Enqueue a Hera perspective delete for a production environment."""
    return await _enqueue(
        qm,
        HeraSyncPayload(
            kind="perspective_delete",
            environment=environment,
            slug=slug,
            retry_count=retry_count,
        ),
        delay=timedelta(0),
        dirty_on_duplicate=False,
    )


def register_hera_entrypoints(
    qm: t.Any,
    context: t.Any,
    query_state: t.Any,
    manager: t.Any,
) -> None:
    """Register the serialized Hera worker entrypoint on the PGQueuer queue manager."""
    from vulcan.core.hera.sync import (
        delete_perspective_from_hera,
        sync_latest_run_status,
        sync_perspective_by_id_to_hera,
        sync_to_hera,
    )

    @qm.entrypoint(HERA_SYNC_ENTRYPOINT, concurrency_limit=1)
    async def handle_hera_sync(job: Job):  # noqa: ANN001
        payload = HeraSyncPayload.model_validate_json(job.payload.decode("utf-8"))
        env = payload.environment
        kind = payload.kind
        result: t.Any = None
        dispatch_error: Exception | None = None

        try:
            if kind == "full_sync":
                env_ctx = await run_blocking(manager.get_env_context, env)
                result = await run_blocking(
                    sync_to_hera,
                    context,
                    env,
                    metadata=env_ctx.metadata,
                    query_state=query_state,
                )
                if payload.update_run_status:
                    run_status_result = await run_blocking(sync_latest_run_status, context, env)
                    if isinstance(result, dict) and isinstance(run_status_result, dict):
                        result = {**result, **run_status_result}
                    elif run_status_result is not None:
                        result = run_status_result
            elif kind == "run_status":
                result = await run_blocking(sync_latest_run_status, context, env)
            elif kind == "perspective_sync":
                if not payload.perspective_id:
                    logger.warning("Missing perspective_id for Hera perspective sync job")
                    return
                await run_blocking(
                    sync_perspective_by_id_to_hera,
                    context,
                    query_state,
                    payload.perspective_id,
                    env,
                )
                result = {"environment": env}
            elif kind == "perspective_delete":
                if not payload.slug:
                    logger.warning("Missing slug for Hera perspective delete job")
                    return
                await run_blocking(delete_perspective_from_hera, context, payload.slug, env)
                result = {"environment": env}
            else:
                logger.warning("Unknown Hera job kind: %s", kind)
                return
        except Exception as exc:  # pragma: no cover - re-raised after follow-up scheduling
            dispatch_error = exc

        if dispatch_error is not None:
            if payload.retry_count < MAX_RETRIES:
                backoff = _DEFAULT_DELAY * (2 ** payload.retry_count)
                if kind == "full_sync":
                    if not payload.plan_id:
                        logger.error("Hera full_sync retry skipped: missing plan_id")
                        return
                    await enqueue_hera_full_sync(
                        qm,
                        env,
                        payload.plan_id,
                        delay=backoff,
                        update_run_status=payload.update_run_status,
                        retry_count=payload.retry_count + 1,
                    )
                elif kind == "run_status":
                    await enqueue_hera_run_status(
                        qm,
                        env,
                        delay=backoff,
                        retry_count=payload.retry_count + 1,
                    )
                elif kind == "perspective_sync":
                    await enqueue_hera_perspective_sync(
                        qm,
                        env,
                        payload.perspective_id or "",
                        retry_count=payload.retry_count + 1,
                    )
                elif kind == "perspective_delete":
                    await enqueue_hera_perspective_delete(
                        qm,
                        env,
                        payload.slug or "",
                        retry_count=payload.retry_count + 1,
                    )
                logger.warning(
                    "Hera %s failed, retry %d scheduled: %s",
                    kind,
                    payload.retry_count + 1,
                    dispatch_error,
                )
                return

            logger.error("Hera %s exhausted %d retries: %s", kind, MAX_RETRIES, dispatch_error)
            return

        if kind == "run_status" and _dirty.pop(_dirty_key(kind, env), False):
            await enqueue_hera_run_status(
                qm,
                env,
                delay=timedelta(0),
                retry_count=payload.retry_count + 1,
            )
