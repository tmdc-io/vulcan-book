"""
Background worker for query execution.
Runs as async task in same process as API.
"""

import asyncio
import logging
import typing as t
from datetime import timedelta

from pgqueuer.models import Job
from pydantic import BaseModel, Field, field_validator
from vulcan import Context
from vulcan.core.config.pgq import PGQConfig

logger = logging.getLogger(__name__)

from vulcan.core import analytics
from api.utils.async_blocking import run_blocking
from api.utils.engine_adapter import request_engine_adapter


class QueryJobPayload(BaseModel):
    """
    Payload contract for PGQueuer jobs between API and worker.

    This model defines the exact contract for query execution jobs,
    ensuring type safety and preventing mismatches between the API
    (which creates the payload) and the worker (which consumes it).

    Serialized to JSON and passed via PGQueuer.
    """

    request_id: str  # Unique request identifier
    fingerprint: str  # Query fingerprint for caching
    gateway: t.Optional[str] = None  # Execution gateway (e.g., 'duckdb', 'default')
    sql: str  # SQL to execute (already wrapped with column aliases if needed)
    params: t.Optional[t.Union[t.List[t.Any], t.Dict[str, t.Any]]] = (
        None  # Query parameters (positional list or named dict)
    )
    ttl_minutes: int = Field(
        default=0, ge=0, le=43200
    )  # Cache TTL in minutes (0=never expires, or 5-43200)
    depends_on: t.Optional[t.List[str]] = None  # Model dependencies for cache invalidation
    environment: str  # Environment name (e.g., 'prod', 'dev') for context routing
    perspective_id: t.Optional[str] = None  # Perspective to sync on successful refresh

    @field_validator("ttl_minutes")
    @classmethod
    def validate_ttl_minutes(cls, v: int) -> int:
        if v == 0 or 5 <= v <= 43200:
            return v
        raise ValueError("ttl_minutes must be 0 (never expires) or between 5 and 43200 minutes")


class QueryExecutor:
    """Executes queries from queue with persistent state and object storage."""

    def __init__(self, context: Context, query_state, object_store: t.Optional[t.Any] = None):
        """
        Initialize QueryExecutor.

        Args:
            context: Vulcan context for query execution
            query_state: QueryState instance for persistent storage
            object_store: ObjectStoreClient instance for result storage (optional)
        """
        self.context = context
        self.query_state = query_state
        self.object_store = object_store

    def _extract_columns(self, df) -> list:
        """
        Extract minimal column schema from pandas DataFrame.

        Returns:
            [{"name": str, "type": str}, ...]

        Type mapping:
            - integer: int8, int16, int32, int64, Int8, Int16, Int32, Int64
            - decimal: float16, float32, float64, Float32, Float64
            - boolean: bool, boolean
            - timestamp: datetime64[*] (all timezone variants)
            - duration: timedelta64[*]
            - string: object, string, category (default)
        """

        def map_dtype(dtype_str: str) -> str:
            """Map pandas dtype to simple type."""
            if any(x in dtype_str for x in ["int", "Int"]):
                return "integer"
            if any(x in dtype_str for x in ["float", "Float"]):
                return "decimal"
            if "bool" in dtype_str:
                return "boolean"
            if "datetime64" in dtype_str:
                return "timestamp"
            if "timedelta" in dtype_str:
                return "duration"
            return "string"

        return [{"name": col, "type": map_dtype(str(dtype))} for col, dtype in df.dtypes.items()]

    async def execute_query(
        self,
        request_id: str,
        sql: str,
        environment: str,
        fingerprint: str,
        params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None,
        gateway: t.Optional[str] = None,
        ttl_minutes: int = 0,
        depends_on_models: t.Optional[list] = None,
    ) -> t.Dict[str, t.Any]:
        """
        Execute a single query with persistent state and object storage.

        Args:
            request_id: Unique request identifier (execution_id)
            sql: SQL query to execute (already wrapped with column aliases if needed)
            params: Query parameters as either:
                - Dict[str, Any]: Named parameters from /statement endpoint
                - List[Any]: Positional parameters from transpiler (semantic queries)
                - None: No parameters
                Note: Transpiler always outputs List. Dict is only from direct SQL submissions.
            environment: Environment name (e.g., 'prod', 'dev')
            fingerprint: Query fingerprint for caching (required for cache management)
            gateway: Execution gateway (optional, not used in this method but kept for payload consistency)
            ttl_minutes: TTL for cache entry (0 = never expires)
            depends_on_models: List of models this query depends on

        Returns:
            Result dict with status, row_count, result_url/error
        """
        logger.info(f"[{request_id}] Starting query execution")
        logger.debug(f"[{request_id}] SQL: {sql}")
        logger.debug(f"[{request_id}] Parameters: {params}")

        # Update status to IN_PROGRESS.  ``query_state.*`` methods are sync
        # SQL calls; wrap them in ``run_blocking`` so the event loop keeps
        # dispatching other jobs while this one is waiting on Postgres.
        await run_blocking(self.query_state.mark_request_in_progress, request_id)

        try:
            # Execute query
            # Note: fetchdf is sync, but we're in async context
            # Run in thread pool to avoid blocking event loop
            import time as _time

            _engine_start = _time.perf_counter()
            loop = asyncio.get_event_loop()
            request_gateway = gateway or self.context.config.default_gateway_name

            def _execute() -> t.Any:
                with request_engine_adapter(self.context, request_gateway) as request_adapter:
                    if params is not None:
                        return request_adapter.fetchdf_with_params(sql, params)
                    return request_adapter.fetchdf(sql)

            df = await loop.run_in_executor(None, _execute)
            _engine_duration = _time.perf_counter() - _engine_start
            _engine = (
                getattr(self.context.engine_adapter, "dialect", "unknown")
                if getattr(self.context, "engine_adapter", None)
                else "unknown"
            )
            try:
                analytics.collector.on_gateway_query(
                    gateway=gateway or "default",
                    engine=_engine,
                    duration_s=_engine_duration,
                )
            except Exception as metric_err:
                logger.warning("Failed to record gateway query metric: %s", metric_err)

            row_count = len(df)
            logger.info(f"[{request_id}] Query executed successfully: {row_count} rows")

            # Extract field references using lineage
            references = None
            try:
                from vulcan.core.lineage import extract_field_references

                references = extract_field_references(
                    sql=sql,
                    output_columns=list(df.columns),
                    context=self.context,
                )
            except Exception:
                pass  # Don't fail the request if lineage extraction fails

            # Upload to object storage (if available)
            if self.object_store:
                try:
                    columns = self._extract_columns(df)
                    logger.debug(f"[{request_id}] Extracted schema: {len(columns)} columns")

                    # Both the S3 upload and the sync DB transaction are
                    # blocking I/O.  Running them inline on the event loop
                    # freezes every other in-flight job for the duration of
                    # the upload (can be seconds for large results).  Extract
                    # into a single sync helper and hand it to the shared
                    # executor so other jobs keep making progress.
                    result_info = await run_blocking(
                        self._finalize_success,
                        request_id=request_id,
                        df=df,
                        columns=columns,
                        row_count=row_count,
                        fingerprint=fingerprint,
                        depends_on_models=depends_on_models,
                        ttl_minutes=ttl_minutes,
                        sql=sql,
                        references=references,
                    )
                    logger.info(f"[{request_id}] Request completed successfully")
                except Exception as storage_error:
                    logger.error(
                        f"[{request_id}] Object storage operation failed: {storage_error}",
                        exc_info=True,
                    )
                    raise storage_error
            else:
                # No object storage - return in-memory result (not recommended for production)
                logger.warning(
                    f"[{request_id}] No object storage configured, returning in-memory result"
                )
                raise Exception("No object storage configured")

            logger.info(f"[{request_id}] Execution completed successfully")
            return {"status": "SUCCESS", **result_info}

        except Exception as e:
            logger.error(f"[{request_id}] Query execution failed: {e}", exc_info=True)
            try:
                analytics.collector.on_gateway_error(
                    gateway=gateway or "default",
                    error_type=analytics.classify_gateway_error(e),
                )
            except Exception as metric_err:
                logger.warning("Failed to record gateway error metric: %s", metric_err)

            # Update state to FAILED.  Offload the sync DB write so a busy
            # state-sync DB does not pin the event loop on the error path.
            try:
                await run_blocking(
                    self.query_state.mark_request_failed,
                    request_id,
                    error_message=str(e),
                )
            except Exception as mark_failed_error:
                logger.error(
                    "[%s] Failed to persist FAILED status: %s",
                    request_id,
                    mark_failed_error,
                    exc_info=True,
                )

            return {"status": "FAILED", "error": str(e)}

    def _finalize_success(
        self,
        *,
        request_id: str,
        df: t.Any,
        columns: list,
        row_count: int,
        fingerprint: str,
        depends_on_models: t.Optional[list],
        ttl_minutes: int,
        sql: str,
        references: t.Any,
    ) -> t.Dict[str, t.Any]:
        """Upload result + mark completed; clean up on DB failure.

        Pure sync helper.  Intended to be called via ``run_blocking`` from
        the async executor so the S3 upload and the ``mark_request_completed``
        DB transaction happen in a worker thread rather than on the event
        loop.  Keeping both writes inside the same call preserves the
        transactional contract: if the DB transaction fails, the just-
        uploaded result file is deleted before the exception propagates so
        the object store never outlives its state-sync metadata.
        """
        size_bytes = self.object_store.upload_result(df, result_id=request_id)
        object_store_path = f"results/{request_id}.parquet"
        logger.info(f"[{request_id}] Result uploaded to object store: {size_bytes} bytes")

        try:
            self.query_state.mark_request_completed(
                request_id=request_id,
                result_id=request_id,
                object_store_path=object_store_path,
                row_count=row_count,
                size_bytes=size_bytes,
                columns=columns,
                fingerprint=fingerprint,
                depends_on=depends_on_models,
                ttl_minutes=ttl_minutes,
                sql=sql,
                references=references,
            )
        except Exception as db_error:
            logger.error(f"[{request_id}] Database transaction failed: {db_error}")
            logger.info(f"[{request_id}] Cleaning up uploaded result file")
            try:
                self.object_store.delete_result(request_id)
                logger.info(f"[{request_id}] Cleanup completed successfully")
            except Exception as cleanup_error:
                logger.warning(f"[{request_id}] Cleanup failed: {cleanup_error}")
            raise db_error

        return {
            "result_id": request_id,
            "object_store_path": object_store_path,
            "row_count": row_count,
            "size_bytes": size_bytes,
        }

    async def process_job(self, job: Job):
        """Process a single job from pgqueuer."""
        try:
            from datetime import datetime, timezone

            wait_seconds = max(
                (datetime.now(timezone.utc) - job.created).total_seconds(),
                0.0,
            )
            analytics.collector.on_queue_wait(
                entrypoint=job.entrypoint,
                wait_seconds=wait_seconds,
            )
        except Exception as metric_err:
            logger.warning("Failed to record query queue wait metric: %s", metric_err)

        # Deserialize payload using Pydantic for type safety
        payload = QueryJobPayload.model_validate_json(job.payload.decode("utf-8"))

        result = await self.execute_query(
            request_id=payload.request_id,
            sql=payload.sql,
            params=payload.params,
            environment=payload.environment,
            fingerprint=payload.fingerprint,
            gateway=payload.gateway,
            ttl_minutes=payload.ttl_minutes,
            depends_on_models=payload.depends_on or [],  # Convert None to empty list
        )
        return result


async def start_worker(
    context: Context,
    qm,
    query_state,
    object_store,
    pgq_config: PGQConfig,
    manager=None,
):
    """
    Start background worker task with persistent state and object storage.

    Args:
        context: Vulcan context for query execution
        qm: PGQueuer QueueManager
        query_state: QueryState instance for persistent storage
        object_store: ObjectStoreClient instance for result storage (optional)
        pgq_config: PGQ configuration for queue settings
        manager: Unused; retained for call-site compatibility.

    This runs continuously in the background.
    """
    logger.info("Starting background worker...")

    executor = QueryExecutor(context, query_state, object_store)

    @qm.entrypoint(
        "query_execution",
        concurrency_limit=pgq_config.concurrency_limit,
        requests_per_second=pgq_config.requests_per_second,
    )
    async def handle_query_execution(job: Job):
        """Handle query execution jobs."""
        logger.info(f"Handling query execution job: {job.payload}")
        payload = QueryJobPayload.model_validate_json(job.payload.decode("utf-8"))
        result = await executor.process_job(job)

        if (
            result.get("status") == "SUCCESS"
            and payload.perspective_id
            and payload.environment == "prod"
        ):
            from api.worker.hera_jobs import enqueue_hera_perspective_sync

            # Best-effort: lineage sync must never fail the query job.
            # Any queue/storage error is logged and swallowed so the query
            # result (already written) is not incorrectly marked as failed.
            try:
                await enqueue_hera_perspective_sync(qm, payload.environment, payload.perspective_id)
            except Exception:
                logger.exception(
                    "Failed to enqueue Hera perspective sync for perspective_id=%s; "
                    "query result is unaffected",
                    payload.perspective_id,
                )

        return result

    from api.worker.hera_jobs import register_hera_entrypoints

    register_hera_entrypoints(qm, context, query_state, manager)

    logger.info("Worker listening on queues: query_execution")
    await qm.run(
        batch_size=pgq_config.batch_size,
        max_concurrent_tasks=pgq_config.max_concurrent_tasks,
        dequeue_timeout=timedelta(seconds=pgq_config.dequeue_timeout),
    )
