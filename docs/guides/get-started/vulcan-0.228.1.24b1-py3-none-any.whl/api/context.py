from __future__ import annotations

import asyncio
from functools import cached_property
import logging
import threading
import typing as t

from vulcan.core.context import Context
from vulcan.core import constants as c
from vulcan.core.model import Model
from vulcan.core.export.bi_artifacts import build_export_artifacts
from schema.metadata import ModelEntry as MetadataModelEntry

logger = logging.getLogger(__name__)


class EnvContext:
    def __init__(
        self,
        context: Context,
        environment: str = "prod",
    ):
        self.context = context
        self.environment = environment

        env = context.state_sync.get_environment(environment)
        if not env:
            available = [e.name for e in context.state_sync.get_environments()]
            raise ValueError(
                f"Environment '{environment}' not found. Available: {', '.join(available)}"
            )
        self.plan_id = getattr(env, "plan_id", None)

        self.snapshots = context.state_sync.get_snapshots(env.finalized_or_current_snapshots)

        self.model_freshness_ts: t.Dict[str, int] = {}
        self.export_artifacts: t.Dict[str, t.Dict[str, str]] = {}
        # Exported ``schema.metadata.Metadata`` (built in ``_load``; ``EnvContext`` fails if unavailable).
        # ``SemanticSchema`` (built in ``_load``; same failure semantics) — GET /api/v1/metadata/semantic.
        # ``export_artifacts`` (built in ``_load``; generated ZIPs served from GET /api/v1/metadata/exports/*).
        self.product = context.config.project
        self.tenant = context.config.tenant

        self._load()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    @property
    def query_validator(self):
        from api.utils.query_validator import QueryValidator

        gateway = (
            self.metadata.gateway.name
            if self.metadata.gateway
            else self.context.config.default_gateway_name
        )
        return QueryValidator(self, gateway=gateway)

    def get_dialect(self, gateway: str) -> t.Optional[str]:
        try:
            connection = self.context.config.get_connection(gateway)
            dialect = getattr(connection, "DIALECT", None)
            if dialect:
                logger.debug("Extracted dialect '%s' from gateway '%s'", dialect, gateway)
            else:
                logger.warning(
                    "No DIALECT attribute found on connection for gateway '%s' (type: %s)",
                    gateway,
                    type(connection).__name__,
                )
            return dialect
        except Exception as e:
            logger.warning(
                "Failed to extract dialect from context: gateway=%s, error=%s", gateway, e
            )
            return None

    def load_model_freshness_ts(self) -> None:
        activity_state = self.context.state_sync.activity_state
        self.model_freshness_ts = activity_state.get_last_successful_run_end_ts_by_model(
            environment=self.environment,
        )

    def did_models_change_after(self, ts: int, model_names: t.Optional[t.List[str]]) -> bool:
        if not model_names or not ts:
            return False

        for model_name in model_names:
            model_last_run_ts = self.model_freshness_ts.get(model_name)
            if model_last_run_ts and model_last_run_ts > ts:
                return True

        return False

    def get_model(self, model_name: str) -> t.Optional[Model]:
        for snapshot in self.snapshots.values():
            if snapshot.is_model and snapshot.model.name == model_name:
                return snapshot.model
        return None

    @cached_property
    def metrics_by_name(self) -> dict[str, MetadataModelEntry]:
        return {
            entry.name: entry
            for entry in (self.metadata.models or [])
            if entry.kind == "METRIC"
        }

    # =========================================================================
    # INITIALIZATION
    # =========================================================================

    def _load(self) -> None:
        # Metadata
        self.metadata = self.context.metadata_for_environment(self.environment)

        # SemanticSchema
        from vulcan.core.export.semantic import build_semantic_schema

        self.semantic_schema = build_semantic_schema(self.metadata)

        # Export artifacts
        self._generate_export_artifacts_from_metadata()

        # Model freshness timestamps
        self.load_model_freshness_ts()

    def _generate_export_artifacts_from_metadata(self) -> None:
        if self.metadata.env != c.PROD:
            return

        try:
            artifacts = build_export_artifacts(self.metadata)
            self.export_artifacts = {
                name: {"path": str(artifact.path)} for name, artifact in artifacts.items()
            }
        except Exception as e:
            logger.error(
                "Export artifact pre-generation failed during EnvContext load (env=%s): %s",
                self.environment,
                e,
                exc_info=True,
            )


class EnvContextManager:
    def __init__(self, context: Context):
        self.context = context
        self._env_contexts: t.Dict[str, EnvContext] = {}
        self._lock = asyncio.Lock()
        # _build_lock guards sync, cold-miss EnvContext construction in get_env_context.
        # _lock remains the async writer lock for on_plan_change/on_run_change mutations.
        self._build_lock = threading.Lock()
        self.plan_version: t.Dict[str, int] = {}
        self.run_version: t.Dict[str, int] = {}
        self.qm = None  # set by lifespan after PGQ init

    def get_env_context(self, environment: str) -> EnvContext:
        ctx = self._env_contexts.get(environment)
        if ctx is not None:
            return ctx

        with self._build_lock:
            ctx = self._env_contexts.get(environment)
            if ctx is not None:
                return ctx

            env_obj = self.context.state_sync.get_environment(environment)
            if env_obj is None:
                available_envs = [
                    e.name for e in self.context.state_sync.get_environments_summary()
                ]
                raise ValueError(
                    f"Environment '{environment}' not found. "
                    f"Available environments: {', '.join(available_envs) if available_envs else 'none'}"
                )

            built = EnvContext(self.context, environment)
            self._env_contexts[environment] = built
            return built

    def get_plan_version(self, environment: str) -> int:
        return self.plan_version.get(environment, 0)

    def get_run_version(self, environment: str) -> int:
        return self.run_version.get(environment, 0)

    async def on_plan_change(self, environment: str) -> None:
        from api.utils.cache import CachePolicy, get_cache_storage

        # EnvContext construction runs metadata export and is CPU-heavy.
        # Running it inline on the event loop would freeze every other
        # endpoint for the duration of the build (observed multi-second
        # freezes on large environments). Offload to the default thread
        # executor so the loop keeps servicing requests while the new
        # context is built.
        new_ctx = await asyncio.to_thread(EnvContext, self.context, environment)

        async with self._lock:
            self._env_contexts[environment] = new_ctx
            self.plan_version[environment] = self.plan_version.get(environment, 0) + 1

        # Cache keys are shaped like ``cache:v1:<policy>:<environment>:...``
        # where ``<policy>`` is the ``CachePolicy`` value (``plan_change``,
        # ``run_change``, ``ttl``).  Invalidate every policy for this env.
        cache = get_cache_storage()
        plan_invalidated = cache.invalidate_pattern(
            f"cache:v1:{CachePolicy.PLAN_CHANGE.value}:{environment}:"
        )
        run_invalidated = cache.invalidate_pattern(
            f"cache:v1:{CachePolicy.RUN_CHANGE.value}:{environment}:"
        )
        ttl_invalidated = cache.invalidate_pattern(
            f"cache:v1:{CachePolicy.TTL.value}:{environment}:"
        )

        logger.info(
            f"Plan change for '{environment}' (v{self.plan_version[environment]}): "
            f"invalidated {plan_invalidated} plan caches, "
            f"{run_invalidated} run caches, {ttl_invalidated} ttl caches"
        )

    async def on_run_change(
        self,
        environment: str,
        model_names: t.Optional[t.Sequence[str]] = None,
    ) -> None:
        from api.utils.cache import CachePolicy, get_cache_storage

        async with self._lock:
            if environment in self._env_contexts:
                self._env_contexts[environment].load_model_freshness_ts()
                logger.info(
                    "Reloaded model_freshness_ts for '%s' (%d models)",
                    environment,
                    len(self._env_contexts[environment].model_freshness_ts),
                )
            self.run_version[environment] = self.run_version.get(environment, 0) + 1

        cache = get_cache_storage()
        run_invalidated = cache.invalidate_pattern(
            f"cache:v1:{CachePolicy.RUN_CHANGE.value}:{environment}:"
        )

        logger.info(
            f"Run change for '{environment}' (v{self.run_version[environment]}): "
            f"invalidated {run_invalidated} run caches"
        )
