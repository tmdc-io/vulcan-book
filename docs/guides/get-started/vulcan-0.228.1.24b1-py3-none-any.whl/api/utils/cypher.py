import re
import typing as t


def detect_write_operation(query: str) -> t.Tuple[bool, t.Optional[str]]:
    """
    Detect write operations in Cypher queries using hybrid approach.
    
    Formats query first to normalize whitespace, then removes string literals and comments
    to reduce false positives, and finally checks for write operation keywords.
    
    Returns (is_write, detected_operation).
    
    TODO: If this rudimentary way fails, we should use a proper Cypher parser
    (e.g., https://github.com/tmdc-io/kuzu/blob/master/src/antlr4/Cypher.g4)
    to parse the query and check for write operations.
    """
    # Step 1: Format query to normalize whitespace and structure
    try:
        formatted_query = format_cypher_query(query)
    except Exception:
        # If formatting fails, use original query (better to check than skip)
        formatted_query = query
    
    # Step 2: Remove string literals to avoid false positives
    # Match single and double quoted strings
    query_no_strings = re.sub(r"'[^']*'|\"[^\"]*\"", "", formatted_query)
    
    # Step 3: Remove line comments (// ...) and block comments (/* ... */)
    query_no_comments = re.sub(r"//.*?$", "", query_no_strings, flags=re.MULTILINE)
    query_no_comments = re.sub(r"/\*.*?\*/", "", query_no_comments, flags=re.DOTALL)
    
    # Step 4: Normalize for analysis
    normalized = query_no_comments.upper()
    
    # Step 5: Define write operations with word boundary patterns
    write_patterns = [
        (r'\bCREATE\s+', "CREATE"),
        (r'\bMERGE\s+', "MERGE"),
        (r'\bDELETE\s+', "DELETE"),
        (r'\bDETACH\s+DELETE\s+', "DETACH DELETE"),
        (r'\bREMOVE\s+', "REMOVE"),
        (r'\bSET\s+', "SET"),
        (r'\bDROP\s+', "DROP"),
        (r'\bALTER\s+', "ALTER"),
        (r'\bCALL\s+CREATE', "CALL CREATE"),
        (r'\bCALL\s+DROP', "CALL DROP"),
    ]
    
    # Step 6: Check for write operations
    for pattern, operation in write_patterns:
        if re.search(pattern, normalized):
            return True, operation
    
    return False, None


def format_cypher_query(query: str) -> str:
    """
    Format Cypher query according to Neo4j style guide.

    Based on: https://github.com/tmdc-io/cypher-query-formatter
    Style guide: https://neo4j.com/developer/cypher-style-guide/

    Args:
        query: Raw Cypher query string

    Returns:
        Formatted Cypher query string

    Example:
        >>> format_cypher_query("match (n) where n.age>30 return n")
        'MATCH (n)\\nWHERE n.age > 30\\nRETURN n'
    """
    # 1. Keywords uppercase with spaces (AND, OR, XOR, DISTINCT, AS, IN, etc.)
    keywords = r'\b(WHEN|CASE|AND|OR|XOR|DISTINCT|AS|IN|STARTS WITH|ENDS WITH|CONTAINS|NOT|SET|ORDER BY)\b'
    query = re.sub(
        keywords,
        lambda m: ' ' + m.group(0).upper().strip() + ' ',
        query,
        flags=re.IGNORECASE
    )

    # 2. Literals lowercase (null, true, false)
    literals = r"\b(NULL|TRUE|FALSE)\b"
    query = re.sub(
        literals,
        lambda m: ' ' + m.group(0).lower().strip() + ' ',
        query,
        flags=re.IGNORECASE
    )

    # 3. Main clauses on new lines with uppercase
    main_clauses = r"\b(CASE|DETACH DELETE|DELETE|MATCH|MERGE|LIMIT|OPTIONAL MATCH|RETURN|UNWIND|UNION|WHERE|WITH|GROUP BY)\b"
    query = re.sub(
        main_clauses,
        lambda m: "\n" + re.sub(r"^\s+", "", m.group(0).upper()) + " ",
        query,
        flags=re.IGNORECASE,
    )

    # 4. Cleanup whitespace
    query = re.sub(r'^\s+', '', query, flags=re.MULTILINE)  # Remove leading whitespace
    query = re.sub(r'\s+$', '', query, flags=re.MULTILINE)  # Remove trailing whitespace
    query = re.sub(r',([^\s])', lambda m: ', ' + m.group(0).replace(',', ''), query)  # Space after comma
    query = re.sub(r' +', ' ', query)  # Multiple spaces to single space
    
    # 5. Indent ON CREATE and ON MATCH clauses
    on_clauses = r"\b(ON CREATE|ON MATCH)\b"
    query = re.sub(
        on_clauses,
        lambda m: "\n  " + re.sub(r"^\s+", "", m.group(0).upper()) + " ",
        query,
        flags=re.IGNORECASE,
    )

    # 6. Format map literals (braces with content)
    def format_braces(match):
        content = match.group(0).strip()[1:-1].strip()
        if not content:
            return " {}"
        indented = re.sub(r"(\r\n|\n|\r)", "\n  ", content)
        return " {\n  " + indented + "\n}"

    query = re.sub(r" \{([\S\s]*?)\}", format_braces, query)

    # 7. Remove multiple consecutive empty lines
    query = re.sub(r"\n\s*\n", "\n", query)

    return query.strip()
