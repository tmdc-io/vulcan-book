from __future__ import annotations

import json
import logging
import typing as t
from datetime import date, datetime
from decimal import Decimal
from hashlib import sha256

from sqlglot import exp, parse_one
from sqlglot.errors import SqlglotError

from vulcan.core.dialect import find_tables, fqn_to_unquoted
from vulcan.utils.errors import QueryValidationError
from vulcan.utils.pydantic import PydanticModel

from api.context import EnvContext

logger = logging.getLogger(__name__)


ALLOWED_STATEMENT_TYPES = (
    exp.Select,
    exp.Union,
    exp.Intersect,
    exp.Except,
    exp.Subquery,
    exp.Values,
)

FORBIDDEN_STATEMENT_TYPES = (
    exp.Insert,
    exp.Update,
    exp.Delete,
    exp.Merge,
    exp.Create,
    exp.Drop,
    exp.Alter,
    exp.TruncateTable,
    exp.Replace,
    exp.Command,
)


class ValidatedQuery(PydanticModel):
    """Result of query validation."""

    sql_query: str
    normalized_sql: str
    fingerprint: str
    depends_on: t.List[str]
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None


def _default_json_serializer(obj: t.Any) -> str:
    """Custom JSON serializer for types that json.dumps doesn't handle natively."""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    elif isinstance(obj, Decimal):
        return str(obj)
    elif isinstance(obj, bytes):
        return obj.hex()
    else:
        return str(obj)


def _normalize_params(params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]]) -> str:
    """Normalize query parameters for fingerprinting."""
    if params is None:
        return ""

    return json.dumps(
        params,
        sort_keys=True,
        separators=(",", ":"),
        default=_default_json_serializer,
        ensure_ascii=True,
    )


class QueryValidator:
    """Validates SQL queries against Vulcan models and generates fingerprints."""

    def __init__(self, env_context: EnvContext, gateway: str = ""):
        self.env_context = env_context
        self.context = env_context.context
        self.gateway = gateway or env_context.context.config.default_gateway_name
        connection = self.context.config.get_connection(self.gateway)
        self.dialect = getattr(connection, "DIALECT", None) or self.context.default_dialect
        self.default_catalog = connection.get_catalog()

        self.model_fqn_to_name: t.Dict[str, str] = {}
        for snapshot in self.env_context.snapshots.values():
            if snapshot.is_model:
                self.model_fqn_to_name[snapshot.model.fqn] = snapshot.model.name

        self.available_tables: t.List[str] = [
            fqn_to_unquoted(fqn, dialect=self.dialect)
            for fqn in self.model_fqn_to_name.keys()
        ]

    def validate_query(
        self,
        sql: str,
        params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None,
        query_type: t.Optional[str] = None,
    ) -> ValidatedQuery:
        """Validate SQL query and generate fingerprint."""
        expression = self._parse_sql(sql)
        # Enforce read-only only for raw SQL statements. Semantic endpoints go through the Transpiler.
        if query_type in (None, "RAW_SQL"):
            self._ensure_read_only(expression)

        table_refs = self._extract_tables(expression)
        depends_on = self._ensure_tables_exist(table_refs)

        normalized_sql = self._normalize_sql(expression)

        normalized_params = _normalize_params(params)
        combined = f"{self.gateway}:{normalized_sql}:{normalized_params}"
        fingerprint = sha256(combined.encode("utf-8")).hexdigest()

        return ValidatedQuery(
            sql_query=sql,
            normalized_sql=normalized_sql,
            fingerprint=fingerprint,
            depends_on=depends_on,
            params=params,
        )

    def _ensure_read_only(self, expression: exp.Expression) -> None:
        """Validate query is read-only (no data manipulation)."""
        if not isinstance(expression, ALLOWED_STATEMENT_TYPES):
            raise QueryValidationError(
                "DATA_MANIPULATION_DETECTED",
                f"Only SELECT queries are allowed. Found: {type(expression).__name__}",
            )

        for node in expression.walk():
            if isinstance(node, FORBIDDEN_STATEMENT_TYPES):
                raise QueryValidationError(
                    "DATA_MANIPULATION_DETECTED",
                    f"Data manipulation not allowed: {type(node).__name__}",
                )

    def _ensure_tables_exist(self, table_refs: t.Set[str]) -> t.List[str]:
        """Validate that table_refs (FQNs from find_tables) exist in loaded snapshots."""
        depends_on = []
        not_found = []

        for table_ref in table_refs:
            if table_ref in self.model_fqn_to_name:
                depends_on.append(self.model_fqn_to_name[table_ref])
            else:
                not_found.append(table_ref)

        if not_found:
            not_found_unquoted = [
                fqn_to_unquoted(table_ref, dialect=self.dialect)
                for table_ref in not_found
            ]
            not_found_str = ", ".join([f"'{table}'" for table in not_found_unquoted])
            available_tables_str = ", ".join([f"'{table}'" for table in self.available_tables])
            raise QueryValidationError(
                "NOT_FOUND",
                f"{not_found_str} not found. "
                f"Available tables: {available_tables_str}",
            )

        return depends_on

    def _parse_sql(self, sql: str) -> exp.Expression:
        """Parse SQL string into SQLGlot expression."""
        try:
            return parse_one(sql, read=self.dialect)
        except SqlglotError as e:
            raise QueryValidationError("PARSE_ERROR", f"Failed to parse SQL: {str(e)}")
        except Exception as e:
            raise QueryValidationError("PARSE_ERROR", f"Unexpected parse error: {str(e)}")

    def _extract_tables(self, expression: exp.Expression) -> t.Set[str]:
        """Extract table references from SQL expression."""
        try:
            return find_tables(
                expression=expression,
                default_catalog=self.default_catalog,
                dialect=self.dialect,
            )
        except Exception as e:
            raise QueryValidationError(
                "TABLE_EXTRACTION_ERROR", f"Failed to extract tables: {str(e)}"
            )

    def _normalize_sql(self, expression: exp.Expression) -> str:
        """Normalize SQL expression to string."""
        try:
            return expression.sql(
                dialect=self.dialect,
                pretty=True,
                comments=False,
                normalize=True,
                normalize_functions="upper",
            )
        except Exception as e:
            raise QueryValidationError(
                "NORMALIZATION_ERROR", f"Failed to normalize SQL: {str(e)}"
            )
