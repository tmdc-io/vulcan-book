from __future__ import annotations

# Create and close a fresh engine adapter per API request so connections do not get reused or expire unexpectedly.
from contextlib import contextmanager
from typing import Iterator

from vulcan.core.context import Context


def create_request_engine_adapter(context: Context, gateway: str):
    return context.config.get_connection(gateway).create_engine_adapter()


@contextmanager
def request_engine_adapter(context: Context, gateway: str) -> Iterator[object]:
    adapter = create_request_engine_adapter(context, gateway)
    try:
        yield adapter
    finally:
        adapter.close()
