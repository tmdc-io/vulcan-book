"""
SQL Dialect Transpilation Utility

Provides SQL query conversion between different SQL dialects using SQLGlot.
Supports MySQL, PostgreSQL, BigQuery, Snowflake, DuckDB, and more.
"""

from __future__ import annotations

import logging
import typing as t

from sqlglot import transpile
from sqlglot.errors import ParseError

logger = logging.getLogger(__name__)

# Supported SQL dialects for conversion
SUPPORTED_DIALECTS = {
    "mysql": "MySQL",
    "postgres": "PostgreSQL",
    "postgresql": "PostgreSQL",
    "bigquery": "BigQuery",
    "snowflake": "Snowflake",
    "duckdb": "DuckDB",
    "sqlite": "SQLite",
    "redshift": "Redshift",
    "clickhouse": "ClickHouse",
    "databricks": "Databricks",
}

# Normalize dialect names
DIALECT_ALIASES = {
    "postgresql": "postgres",
    "bq": "bigquery",
    "gcp": "bigquery",
}


class SQLTranspilationError(Exception):
    """Raised when SQL transpilation fails."""
    
    def __init__(self, message: str, original_error: t.Optional[Exception] = None):
        self.message = message
        self.original_error = original_error
        super().__init__(self.message)


def normalize_dialect(dialect: str) -> str:
    """
    Normalize dialect name to standard SQLGlot format.
    
    Args:
        dialect: Dialect name (case-insensitive)
        
    Returns:
        Normalized dialect name
        
    Examples:
        >>> normalize_dialect("MySQL")
        'mysql'
        >>> normalize_dialect("POSTGRESQL")
        'postgres'
        >>> normalize_dialect("bq")
        'bigquery'
    """
    dialect_lower = dialect.lower().strip()
    return DIALECT_ALIASES.get(dialect_lower, dialect_lower)


def is_supported_dialect(dialect: str) -> bool:
    """
    Check if a dialect is supported for transpilation.
    
    Args:
        dialect: Dialect name
        
    Returns:
        True if dialect is supported, False otherwise
    """
    normalized = normalize_dialect(dialect)
    return normalized in SUPPORTED_DIALECTS


def get_supported_dialects() -> t.List[str]:
    """
    Get list of supported dialect names.
    
    Returns:
        List of supported dialect identifiers
    """
    return list(SUPPORTED_DIALECTS.keys())


def convert_sql_dialect(
    query: str,
    source: str,
    target: str,
    pretty: bool = False,
) -> str:
    """
    Convert SQL query from source dialect to target dialect.
    
    Args:
        query: SQL query to convert
        source: Source SQL dialect (e.g., "mysql", "postgres")
        target: Target SQL dialect
        pretty: Whether to format the output (default: False)
        
    Returns:
        Converted SQL query in target dialect
        
    Raises:
        SQLTranspilationError: If conversion fails
        
    Examples:
        >>> convert_sql_dialect(
        ...     "SELECT `user_id` FROM `users` LIMIT 10",
        ...     source="mysql",
        ...     target="postgres"
        ... )
        'SELECT user_id FROM users LIMIT 10'
    """
    # Normalize dialect names
    source_normalized = normalize_dialect(source)
    target_normalized = normalize_dialect(target)
    
    # Validate dialects
    if not is_supported_dialect(source_normalized):
        supported = ", ".join(get_supported_dialects())
        raise SQLTranspilationError(
            f"Unsupported source dialect: '{source}'. Supported dialects: {supported}"
        )
    
    if not is_supported_dialect(target_normalized):
        supported = ", ".join(get_supported_dialects())
        raise SQLTranspilationError(
            f"Unsupported target dialect: '{target}'. Supported dialects: {supported}"
        )
    
    # No conversion needed if source == target
    if source_normalized == target_normalized:
        logger.debug(f"Source and target dialects are the same ({source_normalized}), skipping conversion")
        return query
    
    # Attempt conversion
    try:
        logger.debug(
            f"Transpiling SQL: {source_normalized} → {target_normalized}",
            extra={
                "source_dialect": source_normalized,
                "target_dialect": target_normalized,
                "query_preview": query[:100] if len(query) > 100 else query,
            }
        )
        
        converted = transpile(
            query,
            read=source_normalized,
            write=target_normalized,
            pretty=pretty
        )[0]
        
        logger.debug(
            f"SQL transpilation successful",
            extra={
                "source_dialect": source_normalized,
                "target_dialect": target_normalized,
                "original_length": len(query),
                "converted_length": len(converted),
            }
        )
        
        return converted
        
    except ParseError as e:
        logger.error(
            f"SQL parsing failed during transpilation",
            extra={
                "source_dialect": source_normalized,
                "target_dialect": target_normalized,
                "error": str(e),
                "query_preview": query[:200] if len(query) > 200 else query,
            }
        )
        raise SQLTranspilationError(
            f"Failed to parse SQL query as {SUPPORTED_DIALECTS[source_normalized]}: {str(e)}",
            original_error=e
        )
    
    except Exception as e:
        logger.error(
            f"Unexpected error during SQL transpilation",
            extra={
                "source_dialect": source_normalized,
                "target_dialect": target_normalized,
                "error": str(e),
                "error_type": type(e).__name__,
            }
        )
        raise SQLTranspilationError(
            f"SQL transpilation failed: {str(e)}",
            original_error=e
        )


def get_gateway_dialect(gateway: t.Optional[str]) -> str:
    """
    Map gateway name to SQL dialect identifier.
    
    Args:
        gateway: Gateway name (e.g., "postgres", "duckdb")
        
    Returns:
        SQL dialect identifier for SQLGlot
        
    Examples:
        >>> get_gateway_dialect("postgres")
        'postgres'
        >>> get_gateway_dialect("duckdb")
        'duckdb'
        >>> get_gateway_dialect(None)
        'postgres'
    """
    if not gateway:
        return "postgres"  # Default
    
    # Map gateway names to dialect identifiers
    gateway_dialect_map = {
        "postgres": "postgres",
        "postgresql": "postgres",
        "duckdb": "duckdb",
        "bigquery": "bigquery",
        "snowflake": "snowflake",
        "redshift": "redshift",
        "clickhouse": "clickhouse",
        "databricks": "databricks",
        "sqlite": "sqlite",
    }
    
    gateway_lower = gateway.lower().strip()
    return gateway_dialect_map.get(gateway_lower, "postgres")

