"""Utilities for running blocking code without stalling the asyncio event loop.

The API has several hot paths that end up calling into synchronous Vulcan
internals (``QueryState``, ``EngineAdapter``), the object store client, or
pandas.  Executing any of those on the event loop blocks *every* concurrent
request until the call returns - including Kubernetes liveness/readiness
probes.  This module provides a dedicated ``ThreadPoolExecutor`` and a thin
``run_blocking`` coroutine that routes such work off the loop.

Why a dedicated pool rather than ``asyncio.to_thread``?

    ``asyncio.to_thread`` uses the loop's default executor, which is shared
    with every other library that happens to call ``run_in_executor`` (HTTP
    libraries, pandas/pyarrow, etc.).  Under pressure that pool saturates,
    mixing latency-sensitive auth work with heavy serialization.  A named,
    purpose-built pool lets us size API I/O concurrency independently and
    expose meaningful thread names in traces.

Environment variables:

- ``VULCAN_API_IO_WORKERS`` - pool size. Default ``16``, bounded to
  ``[1, 512]``. Values > CPU count are appropriate because the work is
  overwhelmingly I/O-bound.  Operators targeting > ~500 RPS/pod should
  bump this; ``32-64`` is appropriate for the 1-3K RPS scalability plan.
  Note: each worker thread holds one psycopg connection to the state
  Postgres (via Vulcan's ``ThreadLocalConnectionPool``), so this also
  caps state-store connection fan-out per pod.
- ``VULCAN_API_IO_SHUTDOWN_DRAIN_S`` - how long shutdown waits for in-flight
  tasks to finish before giving up. Default ``10.0`` s, bounded to
  ``[0, 60]`` s. ``0`` disables the wait entirely (best-effort shutdown).

Both values are parsed defensively via :mod:`api.utils.env`; a malformed or
out-of-range env var falls back to the default with a WARNING log rather
than crash-looping the pod at import time.

Lifecycle is one-shot: once :func:`shutdown_api_io_executor` has run, any
subsequent call to :func:`get_api_io_executor` (and therefore any
:func:`run_blocking` call) raises ``RuntimeError`` rather than silently
spinning up a fresh pool during the tail of a SIGTERM.
"""

from __future__ import annotations

import asyncio
import contextvars
import functools
import logging
import typing as t
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import wait as futures_wait
from threading import Lock

from api.utils.env import parse_positive_float_env, parse_positive_int_env

logger = logging.getLogger(__name__)

T = t.TypeVar("T")

# Floor 1 / ceiling 512: no realistic workload requires more than 512 threads,
# and ``ThreadPoolExecutor(max_workers=100000)`` would happily try to spawn
# 100 000 OS threads on first use.
_DEFAULT_WORKERS = parse_positive_int_env(
    "VULCAN_API_IO_WORKERS",
    default=16,
    floor=1,
    ceiling=512,
)

# Bounded drain on shutdown: how long we wait for in-flight tasks to complete
# before telling the executor to exit. ``0`` means "do not wait" (best-effort).
_SHUTDOWN_DRAIN_TIMEOUT_S = parse_positive_float_env(
    "VULCAN_API_IO_SHUTDOWN_DRAIN_S",
    default=10.0,
    floor=0.0,
    ceiling=60.0,
)

_executor: t.Optional[ThreadPoolExecutor] = None
_executor_lock = Lock()
_shutdown_requested: bool = False

# Tracks ``concurrent.futures.Future`` objects returned by ``executor.submit``
# so that :func:`shutdown_api_io_executor` can bound-wait on the in-flight
# subset. We cannot rely on the executor's internal work queue because it
# drops entries as soon as a worker picks them up.
_pending_futures: t.Set[Future] = set()
_pending_lock = Lock()


def get_api_io_executor() -> ThreadPoolExecutor:
    """Return the process-wide API I/O executor, creating it on first use.

    Raises ``RuntimeError`` if :func:`shutdown_api_io_executor` has already
    run. The pool is deliberately one-shot so that a late-arriving caller
    during SIGTERM cannot silently resurrect a fresh pool that would then
    never be cleaned up.
    """
    global _executor
    with _executor_lock:
        if _shutdown_requested:
            raise RuntimeError("API I/O pool shut down")
        if _executor is None:
            _executor = ThreadPoolExecutor(
                max_workers=_DEFAULT_WORKERS,
                thread_name_prefix="VulcanAPIIO",
            )
            logger.info(
                "Initialized VulcanAPIIO thread pool (max_workers=%s)",
                _DEFAULT_WORKERS,
            )
        return _executor


def _track(fut: Future) -> Future:
    with _pending_lock:
        _pending_futures.add(fut)
    fut.add_done_callback(_untrack)
    return fut


def _untrack(fut: Future) -> None:
    with _pending_lock:
        _pending_futures.discard(fut)


def shutdown_api_io_executor() -> None:
    """Stop the executor with a bounded wait on in-flight work.

    Cancels queued-but-not-started tasks immediately. Waits up to
    ``VULCAN_API_IO_SHUTDOWN_DRAIN_S`` seconds (default 10 s) for currently
    executing tasks to finish, then gives up and lets the process exit.

    Safe to call twice: the second call is a no-op so shutdown hooks can be
    chained without worrying about double-invocation.
    """
    global _executor, _shutdown_requested
    with _executor_lock:
        if _shutdown_requested:
            return
        _shutdown_requested = True
        executor, _executor = _executor, None
    if executor is None:
        return

    with _pending_lock:
        pending_snapshot = set(_pending_futures)

    try:
        executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        logger.warning("VulcanAPIIO executor shutdown raised", exc_info=True)

    if pending_snapshot and _SHUTDOWN_DRAIN_TIMEOUT_S > 0:
        _, not_done = futures_wait(pending_snapshot, timeout=_SHUTDOWN_DRAIN_TIMEOUT_S)
        if not_done:
            logger.warning(
                "VulcanAPIIO drain: %d task(s) still running after %.1fs",
                len(not_done),
                _SHUTDOWN_DRAIN_TIMEOUT_S,
            )
    elif pending_snapshot:
        logger.info(
            "VulcanAPIIO drain skipped (timeout=0); %d task(s) left in-flight",
            len(pending_snapshot),
        )


async def run_blocking(
    func: t.Callable[..., T],
    *args: t.Any,
    timeout: t.Optional[float] = None,
    **kwargs: t.Any,
) -> T:
    """Run *func* in the API I/O pool, preserving contextvars.

    Use this anywhere an ``async def`` endpoint or task needs to call a
    synchronous function that performs non-trivial I/O (SQL, HTTP, S3) or
    CPU-bound work (pandas/arrow).  The call is awaited like normal::

        df = await run_blocking(query_state.get_dataframe, request_id)

    Any exception raised inside *func* propagates to the caller.

    ``timeout`` (seconds, optional) unblocks the caller with
    :class:`asyncio.TimeoutError` if the sync call exceeds it. The caveat:
    Python provides no safe way to interrupt a running thread, so the worker
    keeps running to completion in the background. Treat ``timeout`` as a
    caller-side escape valve, not as a substitute for real socket / SQL
    timeouts configured inside *func*.

    Cancelling the awaited task also does NOT interrupt the worker thread;
    it only unblocks the coroutine. ``contextvars`` are copied into the
    worker's call frame via ``ctx.run``, but any further threads or
    subprocesses that *func* itself spawns will not inherit those vars -
    that is a Python ``contextvars`` limitation, not a bug in this helper.

    Raises ``RuntimeError`` if called after :func:`shutdown_api_io_executor`.
    """
    executor = get_api_io_executor()
    loop = asyncio.get_running_loop()
    ctx = contextvars.copy_context()
    call = functools.partial(ctx.run, func, *args, **kwargs)

    cfut = executor.submit(call)
    _track(cfut)
    afut = asyncio.wrap_future(cfut, loop=loop)

    if timeout is None:
        return await afut
    try:
        return await asyncio.wait_for(afut, timeout=timeout)
    except asyncio.TimeoutError:
        logger.warning(
            "run_blocking(%s) exceeded %.2fs; worker thread continues",
            getattr(func, "__qualname__", repr(func)),
            timeout,
        )
        raise


def get_executor_stats() -> t.Dict[str, t.Any]:
    """Return a small dict of runtime metrics for observability.

    Prefer calling this from a lightweight ``/debug`` endpoint rather than
    hot-path code; it acquires the executor's internal lock.
    """
    if _executor is None:
        return {
            "initialized": False,
            "max_workers": _DEFAULT_WORKERS,
            "shutdown": _shutdown_requested,
        }
    return {
        "initialized": True,
        "max_workers": _executor._max_workers,
        # ``_work_queue`` is a ``queue.SimpleQueue`` or ``queue.Queue`` -
        # size is approximate but useful for alerting on saturation.
        "pending": _executor._work_queue.qsize(),
        "threads": len(_executor._threads),
        "tracked_inflight": len(_pending_futures),
        "shutdown": _shutdown_requested,
    }
