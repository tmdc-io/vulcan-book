"""Defensive env-var parsers for api/ runtime knobs.

All parsers share the same safety contract:

- never raise; malformed input falls back to ``default`` with a WARNING so a
  misconfigured Helm template cannot crash-loop the pod on a config typo;
- clamp to ``[floor, ceiling]`` with a WARNING on out-of-range input so an
  operator typo cannot silently disable a safety rail;
- treat unset, empty, and whitespace-only values as "use default" silently so
  Helm templates that substitute ``""`` for unset optional values behave the
  same as omitting the variable.

Mirrors timeout parsing in :mod:`vulcan.core.analytics.prometheus_dispatcher`;
keeping an ``api/``-local copy respects module-boundary discipline.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


def parse_positive_float_env(
    name: str,
    *,
    default: float,
    floor: float,
    ceiling: float,
) -> float:
    """Parse a float env var without ever raising.

    Unset, empty, or whitespace-only values return *default* silently.
    Non-numeric values log a WARNING and return *default*.
    Values outside ``[floor, ceiling]`` log a WARNING and are clamped.
    """
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = float(raw.strip())
    except ValueError:
        logger.warning("Invalid %s=%r; using default %.2f.", name, raw, default)
        return default
    if value < floor:
        logger.warning("%s=%.3f below floor %.2f; clamping.", name, value, floor)
        return floor
    if value > ceiling:
        logger.warning("%s=%.3f above ceiling %.2f; clamping.", name, value, ceiling)
        return ceiling
    return value


def parse_positive_int_env(
    name: str,
    *,
    default: int,
    floor: int,
    ceiling: int,
) -> int:
    """Parse an int env var without ever raising.

    Same contract as :func:`parse_positive_float_env`, but the value must be a
    base-10 integer.  Float-looking values (``"1.5"``) are rejected as
    malformed so callers do not silently lose precision on a counter knob.
    """
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = int(raw.strip())
    except ValueError:
        logger.warning("Invalid %s=%r; using default %d.", name, raw, default)
        return default
    if value < floor:
        logger.warning("%s=%d below floor %d; clamping.", name, value, floor)
        return floor
    if value > ceiling:
        logger.warning("%s=%d above ceiling %d; clamping.", name, value, ceiling)
        return ceiling
    return value


def parse_optional_positive_int_env(
    name: str,
    *,
    default: int | None,
    floor: int,
    ceiling: int,
) -> int | None:
    """Parse an optional positive-int env var that supports a "no cap" sentinel.

    Designed for callers (e.g. ``httpx.Limits``) where ``None`` carries the
    semantic "no cap / library default" rather than zero.  Behaviour:

    - Unset, empty, or whitespace-only values return *default* silently.
    - The literal strings ``"none"``, ``"null"``, ``"unbounded"`` (case- and
      whitespace-insensitive) return ``None`` so operators can explicitly
      remove a cap from config without code changes.
    - Otherwise behaves like :func:`parse_positive_int_env`: malformed input
      logs a WARNING and returns *default*; out-of-range values clamp to
      ``[floor, ceiling]`` with a WARNING.
    """
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    normalized = raw.strip().lower()
    if normalized in {"none", "null", "unbounded"}:
        return None
    try:
        value = int(raw.strip())
    except ValueError:
        logger.warning("Invalid %s=%r; using default %r.", name, raw, default)
        return default
    if value < floor:
        logger.warning("%s=%d below floor %d; clamping.", name, value, floor)
        return floor
    if value > ceiling:
        logger.warning("%s=%d above ceiling %d; clamping.", name, value, ceiling)
        return ceiling
    return value
