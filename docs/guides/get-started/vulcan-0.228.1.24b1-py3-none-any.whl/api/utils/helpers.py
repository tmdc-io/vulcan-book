"""API helper utilities for validation and normalization."""

from __future__ import annotations

import typing as t

from fastapi import HTTPException
from vulcan.core.model.kind import ModelKindName

from api.context import EnvContext
from schema.metadata import ModelEntry


def validate_model(model_name: str, ctx: EnvContext) -> ModelEntry:
    """Validate model exists in environment metadata and return its ``ModelEntry``."""

    by_name = {m.name: m for m in ctx.metadata.models}
    if model_name in by_name:
        return by_name[model_name]
    raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")


def validate_timestamp_range(
    start_param: t.Optional[int],
    end_param: t.Optional[int],
    start_param_name: str = "start_ts",
    end_param_name: str = "end_ts",
) -> None:
    """Validate timestamp range parameters.
    
    Ensures that if both start and end timestamps are provided, start <= end.
    Raises HTTPException with 400 status if validation fails.
    
    Args:
        start_param: Start timestamp (e.g., start_ts or since_ts)
        end_param: End timestamp (e.g., end_ts)
        start_param_name: Name of start parameter for error message (default: "start_ts")
        end_param_name: Name of end parameter for error message (default: "end_ts")
    
    Raises:
        HTTPException: If start_param > end_param (both provided)
    """
    if start_param is not None and end_param is not None:
        if start_param > end_param:
            raise HTTPException(
                status_code=400,
                detail=f"{start_param_name} must be <= {end_param_name}"
            )


def normalize_kind(v: t.Any) -> t.Optional[ModelKindName]:
    """Normalize kind to enum."""
    if v is None or isinstance(v, ModelKindName):
        return v
    if isinstance(v, str):
        return ModelKindName[v.upper()]
    return v


def ExpandQuery(default: bool = False):
    """FastAPI dependency factory for parsing expand query parameter leniently."""
    from fastapi import Query, Depends
    
    # Boolean string values that map to True/False
    _TRUE_VALUES = {"true", "1", "yes", "on", "y", "t"}
    _FALSE_VALUES = {"false", "0", "no", "off", "n", "f", ""}
    
    def _parse_boolean(value: t.Union[str, bool, None]) -> bool:
        """Internal method to parse boolean query parameter with lenient string handling."""
        if isinstance(value, bool):
            return value
        
        if isinstance(value, str):
            normalized = value.lower().strip()
            if normalized in _TRUE_VALUES:
                return True
            if normalized in _FALSE_VALUES:
                return False
            # Unknown strings default to False (handles typos gracefully)
            return False
        
        # None or other types use default
        return default
    
    def _parse_expand(
        expand: t.Optional[str] = Query(
            None,
            description="Expand to include full details."
        ),
    ) -> bool:
        return _parse_boolean(expand)
    
    return Depends(_parse_expand)



