from __future__ import annotations

import asyncio
import functools
import hashlib
import json
import logging
import time
import typing as t
from collections import OrderedDict
from enum import Enum

from fastapi import Request

from api.settings import get_env_context_manager, get_environment
from api.utils.env import parse_positive_int_env

logger = logging.getLogger(__name__)

# Single-flight registry: coalesces concurrent misses on the same cache_key
# into a single ``func`` invocation. Map of cache_key -> asyncio.Future.
# Entries are removed after the primary computation settles so a subsequent
# request with the same key re-enters the cache lookup path (and, on an
# exception in the primary, retries from scratch rather than seeing a stale
# failure).
_inflight: t.Dict[str, "asyncio.Future[t.Any]"] = {}
_inflight_lock: t.Optional[asyncio.Lock] = None


def _get_inflight_lock() -> asyncio.Lock:
    """Lazily initialise the single-flight lock inside the running loop.

    Creating ``asyncio.Lock()`` at import time can bind the lock to a loop
    that will never run the app (e.g. pytest's implicit loop), leading to
    ``RuntimeError: ... attached to a different loop``. Building it on first
    use guarantees the lock is created in the loop that will actually hold it.
    """
    global _inflight_lock
    if _inflight_lock is None:
        _inflight_lock = asyncio.Lock()
    return _inflight_lock


class CachePolicy(str, Enum):
    PLAN_CHANGE = "plan_change"  # Expire on plan change
    RUN_CHANGE = "run_change"  # Expire on new run
    TTL = "ttl"  # Expire after TTL seconds


_MISSING = object()


class LRUCacheStorage:
    """LRU cache storage with size limit and TTL support."""

    def __init__(self, maxsize: int = 1000):
        # Cache entries: (value, timestamp, ttl)
        self._cache: OrderedDict[str, t.Tuple[t.Any, float, t.Optional[float]]] = OrderedDict()
        self.maxsize = maxsize
        self._hits = 0
        self._misses = 0

    def get(self, key: str, ttl: t.Optional[float] = None) -> t.Any:
        """Return the cached value or the ``_MISSING`` sentinel.

        Using a sentinel (rather than ``None``) lets callers distinguish between
        "not cached" and "cached as None/empty", preventing endpoints that
        legitimately return ``None``/empty lists from always recomputing.
        """
        if key in self._cache:
            value, timestamp, stored_ttl = self._cache[key]
            # Allow runtime TTL override (e.g., for TTL policy that passes ttl per-request)
            ttl_to_check = ttl if ttl is not None else stored_ttl

            if ttl_to_check is not None:
                age = time.time() - timestamp
                if age > ttl_to_check:
                    del self._cache[key]
                    self._misses += 1
                    return _MISSING

            # Promote to most recently used (LRU ordering)
            self._cache.move_to_end(key)
            self._hits += 1
            return value
        self._misses += 1
        return _MISSING

    def set(self, key: str, value: t.Any, ttl: t.Optional[float] = None) -> None:
        timestamp = time.time()
        if key in self._cache:
            # Update existing entry - promote to MRU
            self._cache.move_to_end(key)
        else:
            # Evict LRU entry if at capacity (popitem(last=False) removes oldest)
            if len(self._cache) >= self.maxsize:
                self._cache.popitem(last=False)
        self._cache[key] = (value, timestamp, ttl)

    def invalidate_pattern(self, pattern: str) -> int:
        keys_to_delete = [k for k in self._cache.keys() if k.startswith(pattern)]
        for key in keys_to_delete:
            del self._cache[key]
        return len(keys_to_delete)

    def clear(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def stats(self) -> dict:
        total = self._hits + self._misses
        hit_rate = (self._hits / total * 100) if total > 0 else 0
        return {
            "size": len(self._cache),
            "maxsize": self.maxsize,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate:.1f}%",
        }


_cache_storage = LRUCacheStorage(
    # 10K entries gives hot-path endpoints (metadata/list routes) headroom
    # to survive burst traffic without evicting recently-warmed keys.  Lower
    # bound protects against misconfiguration; upper bound protects against
    # unbounded RSS growth - 1M entries at ~1KB each is ~1GB, well above
    # what a single pod should hold.  Ops can tune via VULCAN_CACHE_MAXSIZE.
    maxsize=parse_positive_int_env(
        "VULCAN_CACHE_MAXSIZE", default=10_000, floor=256, ceiling=1_000_000
    )
)


def _make_cache_key(
    policy: CachePolicy,
    endpoint_path: str,
    environment: str | None,
    plan_version: int | None,
    run_version: int | None,
    params: t.Dict[str, t.Any],
) -> str:
    # Hash params to create stable cache key regardless of param order
    params_str = json.dumps(params, sort_keys=True, default=str)
    params_hash = hashlib.md5(params_str.encode()).hexdigest()[:8]

    parts = ["cache", "v1", policy.value]

    # Include version numbers for event-based policies; TTL uses time-based expiration
    if policy == CachePolicy.PLAN_CHANGE:
        parts.extend([environment or "default", str(plan_version or 0), endpoint_path, params_hash])
    elif policy == CachePolicy.RUN_CHANGE:
        parts.extend([environment or "default", str(run_version or 0), endpoint_path, params_hash])
    elif policy == CachePolicy.TTL:
        parts.extend([environment or "default", endpoint_path, params_hash])

    return ":".join(parts)


def _extract_request(*args, **kwargs) -> Request | None:
    request: Request | None = kwargs.get("request")
    if not request:
        for arg in args:
            if isinstance(arg, Request):
                return arg
    return request


def _build_cache_key_and_check(
    request: Request,
    policy: CachePolicy,
    key_params: t.List[str] | None,
    kwargs: dict,
    func_name: str,
    ttl: t.Optional[float] = None,
) -> tuple[str, t.Any] | None:
    try:
        manager = get_env_context_manager(request)
        environment = get_environment(request)
    except Exception as e:
        logger.warning(
            f"Cache decorator on {func_name} failed to get manager/environment: {e}, skipping cache"
        )
        return None

    plan_version = (
        manager.get_plan_version(environment) if policy == CachePolicy.PLAN_CHANGE else None
    )
    run_version = manager.get_run_version(environment) if policy == CachePolicy.RUN_CHANGE else None

    # Extract cache key parameters, excluding Request objects
    cache_params = {}
    if key_params:
        # Only include explicitly specified parameters
        for param_name in key_params:
            if param_name in kwargs:
                cache_params[param_name] = kwargs[param_name]
    else:
        # Include all non-Request parameters
        cache_params = {
            k: v for k, v in kwargs.items() if k != "request" and not isinstance(v, Request)
        }

    endpoint_path = request.url.path
    cache_key = _make_cache_key(
        policy=policy,
        endpoint_path=endpoint_path,
        environment=environment,
        plan_version=plan_version,
        run_version=run_version,
        params=cache_params,
    )

    cached_value = _cache_storage.get(cache_key, ttl=ttl)
    return (cache_key, cached_value)


def cached(
    policy: CachePolicy = CachePolicy.PLAN_CHANGE,
    key_params: t.List[str] | None = None,
    ttl: t.Optional[float] = None,
):
    """
    Cache decorator for FastAPI endpoints.

    Args:
        policy: Cache expiration policy (plan_change, run_change, ttl)
        key_params: List of parameter names to include in cache key.
                   If None, all parameters are included.
        ttl: Time-to-live in seconds. Required when policy=CachePolicy.TTL.

    Usage:
        @cached(policy=CachePolicy.PLAN_CHANGE)
        def list_models(ctx: EnvContext = Depends(...)):
            ...

        @cached(policy=CachePolicy.TTL, ttl=10)
        def get_snapshot(ctx: EnvContext = Depends(...)):
            ...
    """
    if policy == CachePolicy.TTL and ttl is None:
        raise ValueError("ttl parameter is required when policy=CachePolicy.TTL")

    def decorator(func):
        def _execute_with_cache(*args, **kwargs):
            """Shared cache logic for both sync and async endpoints."""
            request = _extract_request(*args, **kwargs)
            if not request:
                logger.warning(
                    f"Cache decorator on {func.__name__} but no Request found, skipping cache"
                )
                return None, None, None

            cache_result = _build_cache_key_and_check(
                request=request,
                policy=policy,
                key_params=key_params,
                kwargs=kwargs,
                func_name=func.__name__,
                ttl=ttl,
            )

            if cache_result is None:
                return None, None, None

            cache_key, cached_value = cache_result
            is_hit = cached_value is not _MISSING
            cache_status = "HIT" if is_hit else "MISS"

            request.state.cache_policy = policy.value.upper()
            request.state.cache_key = cache_key
            request.state.cache_status = cache_status

            logger.info(f"Cache: {cache_status} - {cache_key}")

            return request, cache_key, cached_value

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            request, cache_key, cached_value = _execute_with_cache(*args, **kwargs)

            if request is None:
                return await func(*args, **kwargs)

            if cached_value is not _MISSING:
                return cached_value

            # Single-flight coalescing: if another coroutine is already
            # computing this cache_key, await its result instead of
            # launching a second identical call. On exception the primary
            # propagates to all waiters AND removes the in-flight marker
            # so the next call retries cleanly (no poisoned key).
            loop = asyncio.get_running_loop()
            lock = _get_inflight_lock()
            async with lock:
                pending = _inflight.get(cache_key)
                if pending is None:
                    future: "asyncio.Future[t.Any]" = loop.create_future()
                    _inflight[cache_key] = future
                    is_primary = True
                else:
                    future = pending
                    is_primary = False

            if not is_primary:
                return await future

            try:
                result = await func(*args, **kwargs)
            except BaseException as exc:
                async with lock:
                    _inflight.pop(cache_key, None)
                if not future.done():
                    future.set_exception(exc)
                raise
            else:
                _cache_storage.set(cache_key, result, ttl=ttl)
                async with lock:
                    _inflight.pop(cache_key, None)
                if not future.done():
                    future.set_result(result)
                return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            request, cache_key, cached_value = _execute_with_cache(*args, **kwargs)

            if request is None:
                return func(*args, **kwargs)

            if cached_value is not _MISSING:
                return cached_value

            result = func(*args, **kwargs)
            _cache_storage.set(cache_key, result, ttl=ttl)
            return result

        # Return appropriate wrapper based on function type (async vs sync)
        import inspect

        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def get_cache_storage() -> LRUCacheStorage:
    return _cache_storage
