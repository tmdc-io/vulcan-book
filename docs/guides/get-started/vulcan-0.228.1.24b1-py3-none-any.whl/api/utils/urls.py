"""Centralized URL builder for API HATEOAS links.

This module provides a class-based URL builder that generates consistent,
configurable URLs for all API endpoints. It serves as the single source of
truth for API URL structure.

Example:
    >>> from api.utils.urls import urls
    >>> urls.model("b2b_saas.users")
    '/api/v1/models/b2b_saas.users'
    >>> urls.run("run_123")
    '/api/v1/runs/run_123'
"""

from __future__ import annotations

import typing as t


class URLBuilder:
    """Centralized URL builder for API endpoints.

    Provides type-safe, autocomplete-friendly methods for generating
    all API URLs. Configurable prefix allows for versioning and
    environment-specific deployments.
    """

    def __init__(self, prefix: str = "/api/v1"):
        """Initialize URL builder with API prefix."""
        self.prefix = prefix.rstrip("/")

    def _url(self, path: str) -> str:
        """Build URL with configured prefix."""
        if not path.startswith("/"):
            path = f"/{path}"
        return f"{self.prefix}{path}"

    # Query - Statement (core execution)
    def query_statement_detail(self, statement_id: str) -> str:
        """Get statement status."""
        return self._url(f"/query/statement/{statement_id}")

    def query_statement_result(self, statement_id: str) -> str:
        """Get statement result (supports ?format=json|yaml|csv|parquet)."""
        return self._url(f"/query/statement/{statement_id}/result")

    # Query - Perspectives (saved queries)
    def perspective_detail(self, slug: str) -> str:
        """Get perspective details."""
        return self._url(f"/perspectives/{slug}")

    def perspective_result(self, slug: str) -> str:
        """Get perspective result (supports ?format=json|yaml|csv|parquet)."""
        return self._url(f"/perspectives/{slug}/result")

    def perspective_refresh(self, slug: str) -> str:
        """Trigger manual perspective refresh."""
        return self._url(f"/perspectives/{slug}/refresh")

    # Activity (plans, runs)
    def plans(
        self,
        model_names: t.Optional[str] = None,
        success: t.Optional[bool] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        limit: t.Optional[int] = None,
        offset: t.Optional[int] = None,
    ) -> str:
        """List plans with optional filters."""
        url = self._url("/activity/plans")
        params = []
        if model_names:
            params.append(f"model_names={model_names}")
        if success is not None:
            params.append(f"success={str(success).lower()}")
        if start_ts is not None:
            params.append(f"start_ts={start_ts}")
        if end_ts is not None:
            params.append(f"end_ts={end_ts}")
        if limit is not None:
            params.append(f"limit={limit}")
        if offset is not None:
            params.append(f"offset={offset}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    def runs(
        self,
        model_names: t.Optional[str] = None,
        success: t.Optional[bool] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        limit: t.Optional[int] = None,
        offset: t.Optional[int] = None,
    ) -> str:
        """List runs with optional filters."""
        url = self._url("/activity/runs")
        params = []
        if model_names:
            params.append(f"model_names={model_names}")
        if success is not None:
            params.append(f"success={str(success).lower()}")
        if start_ts is not None:
            params.append(f"start_ts={start_ts}")
        if end_ts is not None:
            params.append(f"end_ts={end_ts}")
        if limit is not None:
            params.append(f"limit={limit}")
        if offset is not None:
            params.append(f"offset={offset}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    def plan(self, plan_id: str) -> str:
        """Single plan detail."""
        return self._url(f"/activity/plans/{plan_id}")

    def plan_git_diff(self, plan_id: str) -> str:
        """Git diff between the current plan and its previous plan."""
        return self._url(f"/activity/plans/{plan_id}/git-diff")

    def run(self, run_id: str) -> str:
        """Single run detail (includes quality and profile data)."""
        return self._url(f"/activity/runs/{run_id}")

    def notifications(
        self,
        run_id: t.Optional[str] = None,
        plan_id: t.Optional[str] = None,
        events: t.Optional[t.Sequence[str]] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
        limit: t.Optional[int] = None,
        offset: t.Optional[int] = None,
    ) -> str:
        """List notifications with optional filters."""
        url = self._url("/notifications")
        params = []
        if run_id:
            params.append(f"run_id={run_id}")
        if plan_id:
            params.append(f"plan_id={plan_id}")
        if events:
            for event in events:
                params.append(f"events={event}")
        if start_ts is not None:
            params.append(f"start_ts={start_ts}")
        if end_ts is not None:
            params.append(f"end_ts={end_ts}")
        if limit is not None:
            params.append(f"limit={limit}")
        if offset is not None:
            params.append(f"offset={offset}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    # Quality
    def quality_checks(self, model_name: t.Optional[str] = None, column: t.Optional[str] = None, dimension: t.Optional[str] = None) -> str:
        """List quality checks."""
        url = self._url("/quality/checks")
        params = []
        if model_name:
            params.append(f"model_name={model_name}")
        if column:
            params.append(f"column={column}")
        if dimension:
            params.append(f"dimension={dimension}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url
    
    def quality_check_runs(self, check_identity: str, model_name: t.Optional[str] = None, limit: t.Optional[int] = None, start_ts: t.Optional[int] = None, end_ts: t.Optional[int] = None) -> str:
        """Get check runs for a specific check (by identity hash)."""
        url = self._url(f"/quality/checks/{check_identity}")
        params = []
        if model_name:
            params.append(f"model_name={model_name}")
        if limit:
            params.append(f"limit={limit}")
        if start_ts:
            params.append(f"start_ts={start_ts}")
        if end_ts:
            params.append(f"end_ts={end_ts}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    def quality_check_runs_by_name(
        self,
        model_name: str,
        dimension: str,
        check_name: str,
        limit: t.Optional[int] = None,
        offset: t.Optional[int] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
    ) -> str:
        """Get check runs for a specific check (by natural key: model_name, dimension, check_name)."""
        from urllib.parse import quote

        # Preserve / in check_name for path:path (e.g. "users/has/rows")
        encoded_model = quote(model_name, safe="/")
        encoded_dimension = quote(dimension, safe="/")
        encoded_check_name = quote(check_name, safe="/")
        url = self._url(f"/quality/checks/by-name/{encoded_model}/{encoded_dimension}/{encoded_check_name}")
        params = []
        if limit:
            params.append(f"limit={limit}")
        if offset:
            params.append(f"offset={offset}")
        if start_ts:
            params.append(f"start_ts={start_ts}")
        if end_ts:
            params.append(f"end_ts={end_ts}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url
    
    def product_quality_summary(self) -> str:
        """Product-level quality summary (latest evaluation per check)."""
        return self._url("/quality")

    # Data quality (canonical; /quality is legacy)
    def dq_summary(self) -> str:
        """Product-level data quality summary."""
        return self._url("/dq")

    def dq_rules(
        self,
        model: t.Optional[str] = None,
        column: t.Optional[str] = None,
        dimension: t.Optional[str] = None,
    ) -> str:
        url = self._url("/dq/rules")
        params = []
        if model:
            params.append(f"model={model}")
        if column:
            params.append(f"column={column}")
        if dimension:
            params.append(f"dimension={dimension}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    def dq_rule_runs(
        self,
        identity: str,
        model: t.Optional[str] = None,
        limit: t.Optional[int] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
    ) -> str:
        url = self._url(f"/dq/rules/{identity}")
        params = []
        if model:
            params.append(f"model={model}")
        if limit:
            params.append(f"limit={limit}")
        if start_ts:
            params.append(f"start_ts={start_ts}")
        if end_ts:
            params.append(f"end_ts={end_ts}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url

    def dq_rule_runs_by_name(
        self,
        model: str,
        dimension: str,
        name: str,
        limit: t.Optional[int] = None,
        offset: t.Optional[int] = None,
        start_ts: t.Optional[int] = None,
        end_ts: t.Optional[int] = None,
    ) -> str:
        from urllib.parse import quote

        encoded_model = quote(model, safe="/")
        encoded_dimension = quote(dimension, safe="/")
        encoded_name = quote(name, safe="/")
        url = self._url(
            f"/dq/rules/by-name/{encoded_model}/{encoded_dimension}/{encoded_name}"
        )
        params = []
        if limit:
            params.append(f"limit={limit}")
        if offset:
            params.append(f"offset={offset}")
        if start_ts:
            params.append(f"start_ts={start_ts}")
        if end_ts:
            params.append(f"end_ts={end_ts}")
        if params:
            url = f"{url}?{'&'.join(params)}"
        return url


# Global singleton
urls = URLBuilder()
