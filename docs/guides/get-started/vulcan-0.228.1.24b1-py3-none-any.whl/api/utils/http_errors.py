"""HTTP JSON error envelopes and COMMON.* code literals for the Vulcan API layer.

Inspired by ``transpiler/server/errors.py``. The API stack does not import transpiler.

Each error body carries ``status``, plus ``error`` with ``code`` and ``message`` strings.
"""

from __future__ import annotations

from fastapi.responses import JSONResponse

# -----------------------------------------------------------------------------
# COMMON.* registry — snake_case identifiers map to COMPANY.DOT.UPPERCASE strings
# -----------------------------------------------------------------------------
COMMON_AUTH_MISSING_BEARER = "COMMON.AUTH.MISSING_BEARER"
COMMON_AUTH_BEARER_MALFORMED = "COMMON.AUTH.BEARER_MALFORMED"
COMMON_AUTH_INVALID_TOKEN = "COMMON.AUTH.INVALID_TOKEN"
COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED = "COMMON.AUTH.CLIENT_HEADERS_NOT_ALLOWED"
COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE = "COMMON.AUTH.AUTH_BACKEND_UNAVAILABLE"
COMMON_AUTH_FORBIDDEN = "COMMON.AUTH.FORBIDDEN"
COMMON_AUTH_TIMEOUT = "COMMON.AUTH.TIMEOUT"
COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE = "COMMON.AUTH.EXT_HOOK_INVALID_RESPONSE"
COMMON_AUTH_EXT_HOOK_FAILED = "COMMON.AUTH.EXT_HOOK_FAILED"
COMMON_AUTH_HEIMDALL_UNAVAILABLE = "COMMON.AUTH.HEIMDALL_UNAVAILABLE"


def json_error_response(status_code: int, code: str, message: str) -> JSONResponse:
    """
    Build a JSON error payload with ``status`` and nested ``error``.

    Args:
        status_code: HTTP status; also stored in the body's ``status`` field.
        code: Machine-readable ``COMMON.*`` (or other) error identifier.
        message: Human-readable message for API clients.

    Returns:
        FastAPI ``JSONResponse`` for the error envelope.
    """

    return JSONResponse(
        status_code=status_code,
        content={
            "status": status_code,
            "error": {"code": code, "message": message},
        },
    )
