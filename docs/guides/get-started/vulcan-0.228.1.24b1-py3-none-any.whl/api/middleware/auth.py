"""Bearer auth via Heimdall and optional after-authorize hook."""

from __future__ import annotations

import asyncio
import hashlib
import importlib
import logging
import sys
import time
import typing as t
from pathlib import Path
from typing import Protocol, Set

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp

from api.clients.heimdall.client import HeimdallException, extract_bearer_token
from api.clients.heimdall.models import AuthorizeResponse
from api.utils.cache import LRUCacheStorage, _MISSING
from api.utils.http_errors import (
    COMMON_AUTH_BEARER_MALFORMED,
    COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED,
    COMMON_AUTH_EXT_HOOK_FAILED,
    COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE,
    COMMON_AUTH_TIMEOUT,
    COMMON_AUTH_HEIMDALL_UNAVAILABLE,
    COMMON_AUTH_MISSING_BEARER,
    COMMON_AUTH_FORBIDDEN,
    COMMON_AUTH_INVALID_TOKEN,
    COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE,
    json_error_response,
)

from schema.auth import AuthExtensionContext, SecurityContext

from vulcan.core import analytics
from vulcan.core.config.heimdall import HeimdallConfig

logger = logging.getLogger(__name__)


def _record_policy_evaluation(
    duration_s: float,
    *,
    denied: bool = False,
    reason: str = "",
) -> None:
    try:
        analytics.collector.on_policy_evaluated(
            policy_type="heimdall",
            duration_s=duration_s,
            denied=denied,
            subject_type="user",
            reason=reason,
        )
    except Exception as e:
        logger.debug("on_policy_evaluated failed: %s", e)


DEFAULT_EXCLUDED_PATHS: Set[str] = {
    "/livez",
    "/readyz",
    "/docs",
    "/redoc",
    "/openapi.json",
}

# Internal/control-plane prefixes: no Bearer check (credentials or presign semantics live elsewhere).
DEFAULT_EXCLUDED_PREFIXES: Set[str] = {
    "/api/v1/_internal",
    "/api/v1/queue",
    "/api/v1/files",
}

FORBIDDEN_INBOUND_HEADERS: frozenset[str] = frozenset(("x-user",))

_HEIMDALL_AUTH_CACHE_MAXSIZE = 5000


def _is_forbidden_inbound_header(name: str) -> bool:
    lower = name.lower()
    if lower in FORBIDDEN_INBOUND_HEADERS:
        return True
    return lower.startswith("x-user-")


class AuthExtensionHook(Protocol):
    async def __call__(self, ctx: AuthExtensionContext) -> SecurityContext: ...


def _load_auth_extension_hook(
    project_path: Path,
    hook_spec: t.Optional[str],
) -> t.Optional[AuthExtensionHook]:
    trimmed = (hook_spec or "").strip()
    # No usable spec in config → skip loading (caller treats as no hook).
    if not trimmed:
        return None

    module_qualname, separator, callable_name = trimmed.partition(":")
    # ``partition`` only guarantees a delimiter when ``separator`` is ``":"``.
    if separator != ":" or not module_qualname.strip() or not callable_name.strip():
        raise ValueError(f"Invalid hook spec {trimmed!r}; expected 'module.path:callable'")

    project_root = project_path.expanduser().resolve()
    project_root_str = str(project_root)
    # Hooks live in the data product; ``import hooks.foo`` resolves only when root is first on sys.path.
    if project_root_str not in sys.path:
        sys.path.insert(0, project_root_str)

    module_name = module_qualname.strip()
    attribute_name = callable_name.strip()
    try:
        hook_module = importlib.import_module(module_name)
    except ImportError:
        logger.exception("Failed to import heimdall.after_authorize hook module %r", module_name)
        raise

    hook_callable = getattr(hook_module, attribute_name, None)
    if hook_callable is None:
        raise AttributeError(f"Module {module_name!r} has no attribute {attribute_name!r}")
    if not callable(hook_callable):
        raise TypeError(f"after_authorize hook {trimmed!r} is not callable")

    return t.cast(AuthExtensionHook, hook_callable)


def _attach_auth_response_headers(request: Request, response: Response) -> None:
    cache_status = getattr(request.state, "heimdall_cache", None)
    if cache_status is not None:
        response.headers["X-Heimdall-Cache"] = cache_status

    user_id = getattr(request.state, "user_id", None)
    if user_id is None:
        return

    response.headers["X-User"] = str(user_id)

    tags = getattr(request.state, "user_tags", ())
    response.headers["X-User-Tags"] = ",".join(tags)

    security_context = getattr(request.state, "security_context", None) or SecurityContext()
    for header_name, header_value in security_context.to_headers().items():
        response.headers[header_name] = header_value


class AuthorizationMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app: ASGIApp,
        heimdall_config: HeimdallConfig,
        *,
        project_path: Path,
    ):
        super().__init__(app)
        self.heimdall_config = heimdall_config
        self.enabled = heimdall_config.enabled
        self.auth_extension_hook = _load_auth_extension_hook(
            project_path,
            heimdall_config.after_authorize,
        )

        self.timeout = heimdall_config.timeout
        self.cache_timeout = heimdall_config.cache_timeout
        self._heimdall_auth_cache = (
            LRUCacheStorage(maxsize=_HEIMDALL_AUTH_CACHE_MAXSIZE)
            if self.cache_timeout > 0
            else None
        )
        self.excluded_paths = DEFAULT_EXCLUDED_PATHS.copy()
        self.excluded_prefixes = DEFAULT_EXCLUDED_PREFIXES.copy()

        if self.enabled:
            logger.info(
                "Authorization middleware enabled (excluded paths: %s, excluded prefixes: %s)",
                self.excluded_paths, self.excluded_prefixes
            )
        else:
            logger.warning(
                "Authorization middleware DISABLED (HEIMDALL_ENABLED=false) - "
                "all requests allowed without authentication"
            )

    async def _maybe_after_authorize_hook(
        self,
        request: Request,
        auth_response: AuthorizeResponse,
    ) -> tuple[t.Optional[SecurityContext], t.Optional[JSONResponse]]:
        hook = self.auth_extension_hook
        if not auth_response.valid or not auth_response.allow or hook is None:
            return None, None

        ctx = AuthExtensionContext(
            user_id=auth_response.user_id,
            user_tags=tuple(auth_response.user_tags),
            request_headers={k.lower(): v for k, v in request.headers.items()},
        )
        try:
            raw = await hook(ctx)
            if isinstance(raw, SecurityContext):
                return raw, None
            if raw is not None:
                return None, _auth_extension_misconfigured(request, type(raw).__name__)
            return SecurityContext(), None
        except Exception:
            return None, _auth_extension_failed(request)

    async def _heimdall_authorize_cached(
        self,
        request: Request,
        client: t.Any,
        authorization_header: str,
    ) -> tuple[float, AuthorizeResponse]:

        async def _heimdall() -> tuple[float, AuthorizeResponse]:
            t0 = time.perf_counter()
            auth_response = await client.authorize(authorization_header)
            return time.perf_counter() - t0, auth_response

        # cache_timeout=0 disables caching; call Heimdall on every request.
        if self._heimdall_auth_cache is None:
            request.state.heimdall_cache = "miss"
            return await _heimdall()

        token = extract_bearer_token(authorization_header)
        cache_key = f"heimdall:auth:{hashlib.sha256(token.encode('utf-8')).hexdigest()}"
        cached = self._heimdall_auth_cache.get(cache_key, ttl=self.cache_timeout)
        if cached is not _MISSING:
            request.state.heimdall_cache = "hit"
            logger.debug("Heimdall auth cache HIT key=%s", cache_key)
            # TODO(observability): emit Prometheus counters for Heimdall auth cache
            # hit/miss (e.g. vulcan_heimdall_auth_cache_total{result="hit|miss"} or reuse
            # vulcan_cache_* with api="heimdall"). Wire via emit_* facade + _offload like
            # emit_policy_evaluation.
            return 0.0, t.cast(AuthorizeResponse, cached)

        request.state.heimdall_cache = "miss"
        logger.debug("Heimdall auth cache MISS key=%s", cache_key)
        auth_duration, auth_response = await _heimdall()
        if auth_response.valid and auth_response.allow:
            # Cache the successful response
            self._heimdall_auth_cache.set(cache_key, auth_response, ttl=self.cache_timeout)
        return auth_duration, auth_response

    async def _authorize(
        self,
        request: Request,
        client: t.Any,
        authorization_header: str,
    ) -> tuple[
        float, # auth_duration
        float, # hook_duration  
        AuthorizeResponse, # auth_response
        t.Optional[SecurityContext], # hook_result
        t.Optional[JSONResponse], # hook_err
    ]:
        auth_duration, auth_response = await self._heimdall_authorize_cached(
            request,
            client,
            authorization_header,
        )

        # Optional product hook: enrich groups when Heimdall already allowed.
        hook_start = time.perf_counter()
        hook_result, hook_err = await self._maybe_after_authorize_hook(request, auth_response)
        hook_duration = time.perf_counter() - hook_start

        return auth_duration, hook_duration, auth_response, hook_result, hook_err

    async def dispatch(self, request: Request, call_next):
        if not self.enabled:
            return await call_next(request)

        if request.url.path in self.excluded_paths:
            return await call_next(request)

        for prefix in self.excluded_prefixes:
            if request.url.path.startswith(prefix):
                return await call_next(request)

        auth_header = request.headers.get("Authorization")

        if not auth_header:
            return _missing_authorization(request)

        if not auth_header.lower().startswith("bearer "):
            return _invalid_authorization_format(request)

        forbidden_present = sorted(
            {
                name.lower()
                for name in request.headers
                if _is_forbidden_inbound_header(name)
            }
        )
        if forbidden_present:
            names = ", ".join(forbidden_present)
            return _forbidden_inbound_headers(request, names)

        # Missing client here is a lifespan/bootstrap bug — fail closed, no silent allow.
        client = getattr(request.app.state, "heimdall_client", None)
        if client is None:
            return _heimdall_client_missing(request)

        _start = time.perf_counter()
        try:
            auth_duration, hook_duration, auth_response, hook_result, hook_err = (
                await asyncio.wait_for(
                    self._authorize(request, client, auth_header),
                    timeout=self.timeout,
                )
            )
        except asyncio.TimeoutError:
            return _auth_timeout(request, self.timeout)
        except HeimdallException as e:
            _record_policy_evaluation(
                time.perf_counter() - _start, denied=True, reason=e.error_code
            )
            return _heimdall_exception(request, e)

        if not auth_response.valid:
            _record_policy_evaluation(auth_duration, denied=True, reason="invalid_token")
            return _invalid_token(request, auth_response.error_message)

        if not auth_response.allow:
            _record_policy_evaluation(auth_duration, denied=True, reason="access_denied")
            return _access_denied(request, auth_response.user_id)

        if hook_err is not None:
            return hook_err

        _record_policy_evaluation(auth_duration)

        security_context = (
            SecurityContext()
            if hook_result is None
            else hook_result
        )

        logger.info(
            "Authorized user %s for %s %s (heimdall=%.3fs, hook=%.3fs)",
            auth_response.user_id,
            request.method,
            request.url.path,
            auth_duration,
            hook_duration,
        )

        request.state.user_id = auth_response.user_id
        request.state.user_tags = auth_response.user_tags
        request.state.security_context = security_context

        response = await call_next(request)
        # X-User* echo for downstream callers
        _attach_auth_response_headers(request, response)
        return response


# -----------------------------------------------------------------------------
# Dispatch helpers — JSON auth errors + logging (defined after middleware so the
# class body stays focused; names resolve at request time once import completes).
# -----------------------------------------------------------------------------

def _missing_authorization(request: Request) -> JSONResponse:
    logger.debug("Missing Authorization header for %s %s", request.method, request.url.path)
    return json_error_response(
        401,
        COMMON_AUTH_MISSING_BEARER,
        "Authentication required; send Authorization: Bearer <token>.",
    )


def _invalid_authorization_format(request: Request) -> JSONResponse:
    logger.error(
        "Invalid Authorization format for %s %s",
        request.method,
        request.url.path,
    )
    return json_error_response(
        401,
        COMMON_AUTH_BEARER_MALFORMED,
        "Invalid Authorization format. Expected: Bearer <token>",
    )


def _invalid_token(request: Request, detail: t.Optional[str]) -> JSONResponse:
    logger.error(
        "Token rejected for %s %s: %s",
        request.method,
        request.url.path,
        detail,
    )
    return json_error_response(
        401,
        COMMON_AUTH_INVALID_TOKEN,
        "The access token is invalid or expired.",
    )


def _forbidden_inbound_headers(request: Request, header_names: str) -> JSONResponse:
    logger.error(
        "Disallowed inbound request header(s) for %s %s: %s",
        request.method,
        request.url.path,
        header_names,
    )
    return json_error_response(
        400,
        COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED,
        (
            "These headers must not be sent by clients: "
            f"{header_names}"
        ),
    )


def _heimdall_client_missing(request: Request) -> JSONResponse:
    logger.critical(
        "Heimdall client missing from app.state while authorization is enabled; "
        "refusing %s %s",
        request.method,
        request.url.path,
    )
    return json_error_response(
        503,
        COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE,
        "Authentication is temporarily unavailable.",
    )


def _access_denied(request: Request, user_id: str) -> JSONResponse:
    logger.error(
        "Access denied for user %s on %s %s",
        user_id,
        request.method,
        request.url.path,
    )
    return json_error_response(403, COMMON_AUTH_FORBIDDEN, "Access denied")


def _auth_timeout(request: Request, timeout_s: float) -> JSONResponse:
    logger.error(
        "Heimdall authorize + enrichment hook exceeded heimdall.timeout=%.3fs for %s %s",
        timeout_s,
        request.method,
        request.url.path,
    )
    return json_error_response(
        503,
        COMMON_AUTH_TIMEOUT,
        (
            "Authorization exceeded heimdall.timeout (Heimdall + optional enrichment hook); "
            "increase timeout or shorten work per request."
        ),
    )


def _auth_extension_misconfigured(request: Request, got_kind: str) -> JSONResponse:
    logger.error(
        "Auth extension hook returned %s, expected SecurityContext for %s %s",
        got_kind,
        request.method,
        request.url.path,
    )
    return json_error_response(
        503,
        COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE,
        "Authorization extension misconfigured",
    )


def _auth_extension_failed(request: Request) -> JSONResponse:
    logger.exception(
        "Auth extension hook failed for %s %s",
        request.method,
        request.url.path,
    )
    return json_error_response(
        503,
        COMMON_AUTH_EXT_HOOK_FAILED,
        "Authorization extension failed",
    )


def _heimdall_exception(request: Request, exc: HeimdallException) -> JSONResponse:
    logger.error(
        "Heimdall authorization failed for %s %s: %s",
        request.method,
        request.url.path,
        exc,
        exc_info=True,
    )
    return json_error_response(
        exc.status_code,
        COMMON_AUTH_HEIMDALL_UNAVAILABLE,
        "Authentication service temporarily unavailable.",
    )
