"""API metrics middleware — all events go through the analytics collector (Pushgateway)."""

from __future__ import annotations

import logging
import time
from typing import Callable

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp

from vulcan.core import analytics

logger = logging.getLogger(__name__)

_QUERY_PATH_PREFIXES = (
    "/api/v1/query",
    "/api/v1/perspectives",
)


def _normalize_path(path: str) -> str:
    return path.split("?")[0].rstrip("/") or "/"


class VulcanMetricsMiddleware(BaseHTTPMiddleware):
    """Record HTTP and cache metrics via the analytics collector."""

    def __init__(
        self,
        app: ASGIApp,
        tenant: str,
        data_product: str,
    ):
        super().__init__(app)
        del tenant, data_product

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        normalized = _normalize_path(path)
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        status = str(response.status_code)

        try:
            analytics.collector.on_api_http_request(
                method=request.method,
                path=normalized,
                status=status,
                duration_s=elapsed,
            )
        except Exception as e:
            logger.debug("on_api_http_request failed: %s", e)

        is_query = any(path.startswith(p) for p in _QUERY_PATH_PREFIXES)
        if is_query:
            api = "graphql" if "/graphql" in path else "rest"
            cache_status = getattr(request.state, "cache_status", None)
            if cache_status == "HIT":
                try:
                    analytics.collector.on_cache_event(api=api, hit=True)
                except Exception as e:
                    logger.debug("on_cache_event failed: %s", e)
            elif cache_status == "MISS":
                try:
                    analytics.collector.on_cache_event(api=api, hit=False)
                except Exception as e:
                    logger.debug("on_cache_event failed: %s", e)

        return response
