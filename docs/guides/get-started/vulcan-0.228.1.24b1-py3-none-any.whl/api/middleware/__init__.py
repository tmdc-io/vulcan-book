"""API middleware module.

Provides middleware components for request processing.

Components:
- auth: Authorization middleware using Heimdall service
- metrics: HTTP and cache events via analytics collector (Pushgateway)
"""

from api.middleware.auth import AuthorizationMiddleware
from api.middleware.metrics import VulcanMetricsMiddleware

__all__ = [
    "AuthorizationMiddleware",
    "VulcanMetricsMiddleware",
]

