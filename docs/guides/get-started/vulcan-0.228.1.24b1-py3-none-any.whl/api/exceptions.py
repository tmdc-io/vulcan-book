import sys
import traceback
import typing as t

from fastapi import HTTPException
from starlette.status import HTTP_422_UNPROCESSABLE_CONTENT

from vulcan.utils.date import now_timestamp
from vulcan.utils.pydantic import PydanticModel
from vulcan.utils import debug_mode_enabled


class QueryExecutionError(Exception):
    """
    Non-HTTP exception for query execution failures.
    
    Raised by api/query_executor.py to indicate execution errors
    without coupling to FastAPI's HTTPException. The API layer
    translates this to HTTPException for HTTP responses.
    """
    def __init__(self, status_code: int, detail: t.Union[str, t.Dict[str, t.Any]]):
        self.status_code = status_code
        self.detail = detail
        super().__init__(str(detail))


class ApiExceptionPayload(PydanticModel):
    timestamp: int
    message: str
    origin: str
    status: t.Optional[int] = None
    trigger: t.Optional[str] = None
    type: t.Optional[str] = None
    description: t.Optional[str] = None
    traceback: t.Optional[str] = None
    stack: t.Optional[t.List[str]] = None


class ApiException(HTTPException):
    """
    API exception for FastAPI endpoints.
    
    Matches the implementation pattern from web/server/exceptions.py for consistency.
    """
    def __init__(
        self,
        origin: str,
        message: str,
        status_code: int = HTTP_422_UNPROCESSABLE_CONTENT,
        trigger: t.Optional[str] = None,
        include_traceback: t.Optional[bool] = None,
    ):
        super().__init__(status_code)
        error_type, error_value, error_traceback = sys.exc_info()

        self.message = message
        self.timestamp = now_timestamp()
        self.origin = origin
        self.trigger = trigger
        
        # Capture traceback details (always stored, but conditionally exposed)
        self._traceback_str = traceback.format_exc() if error_traceback else None
        self._error_type = str(error_type) if error_type else None
        self._error_value = str(error_value) if error_value else None
        self._stack = traceback.format_tb(error_traceback) if error_traceback else None
        
        # Determine if traceback should be included in response
        # Default: only include in debug mode, unless explicitly requested
        self._include_traceback = (
            include_traceback 
            if include_traceback is not None 
            else debug_mode_enabled()
        )

    def __str__(self) -> str:
        return f"Summary: {self.message}\n{self._error_value}\n{self._traceback_str}"

    def to_dict(self) -> t.Dict[str, t.Union[str, int, t.List[str]]]:
        """Convert exception to dictionary for JSON response.
        
        Traceback and stack are only included if debug mode is enabled
        or explicitly requested, to prevent exposing sensitive information.
        """
        payload = ApiExceptionPayload(
            status=self.status_code,
            timestamp=self.timestamp,
            message=self.message,
            origin=self.origin,
            trigger=self.trigger,
            type=self._error_type,
            description=self._error_value,
        )
        
        # Only include traceback details if explicitly requested or in debug mode
        if self._include_traceback:
            payload.traceback = self._traceback_str
            payload.stack = self._stack
        
        return payload.dict()
