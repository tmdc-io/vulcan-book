from __future__ import annotations

import logging
import os
import typing as t
from functools import lru_cache
from pathlib import Path

from fastapi import HTTPException, Request
from pydantic import Field

from vulcan.utils.pydantic import PydanticModel
from vulcan.core.query import ObjectStoreClient
from vulcan.core.state_sync.db.query import QueryState
from pgqueuer import QueueManager
from api.exceptions import ApiException
from api.context import EnvContext, EnvContextManager
from schema.auth import SecurityContext

from vulcan.core import constants as c

logger = logging.getLogger(__name__)

DEFAULT_ENVIRONMENT = c.PROD


class Settings(PydanticModel):
    """API settings loaded from environment variables.
    
    """

    project_path: Path = Field(
        default_factory=lambda: Path(os.getenv("PROJECT_PATH", "examples/b2b_saas"))
    )
    config: str = Field(default_factory=lambda: os.getenv("CONFIG", ""))
    gateway: t.Optional[str] = Field(default_factory=lambda: os.getenv("GATEWAY"))

@lru_cache()
def get_settings() -> Settings:
    """Return cached Settings instance."""
    return Settings()


def get_env_context_manager(request: Request) -> EnvContextManager:
    """FastAPI dependency to inject the shared EnvContextManager."""
    manager = request.app.extra.get("env_context_manager")
    if manager is None:
        raise ApiException(
            message="Environment context manager not initialized (application startup may have failed)",
            origin="API -> settings -> get_env_context_manager",
            status_code=503,  # Service Unavailable
        )
    return manager


def get_environment(request: Request) -> str:
    """FastAPI dependency to inject the environment."""
    # Determine environment from request
    # Priority: 1) Query param, 2) Header, 3) Default
    return (
        request.query_params.get("env")  # Query param: ?env=staging
        or request.headers.get("x-environment")  # Header: X-Environment: staging
        or DEFAULT_ENVIRONMENT  # Default: "prod"
    )

def get_env_context(request: Request) -> EnvContext:
    """FastAPI dependency to inject an EnvContext for the resolved environment."""
    # Get manager
    manager = get_env_context_manager(request)

    # Determine environment from request
    # Priority: 1) Query param, 2) Header, 3) Default
    environment = get_environment(request)

    # Return environment-specific context (validates environment exists)
    try:
        return manager.get_env_context(environment)
    except ValueError as e:
        # 404 Not Found - environment doesn't exist in the state database
        # This typically means: 1) Environment was never created via `vulcan plan <env>`
        # 2) State database was reset, or 3) Typo in environment name
        raise ApiException(
            message=f"Environment '{environment}' not found. Run 'vulcan plan {environment}' to create it.",
            origin="API -> settings -> get_env_context",
            status_code=404,
        )



def get_user(request: Request) -> t.Dict[str, t.Any]:
    """FastAPI dependency to inject user context from Heimdall authentication.

    Returns:
        Dict with user_id, user_tags, and security_context keys

    """
    user_id = getattr(request.state, "user_id", None) or "anonymous"
    user_tags = getattr(request.state, "user_tags", [])
    raw_context = getattr(request.state, "security_context", None)
    security_context = raw_context if isinstance(raw_context, SecurityContext) else SecurityContext()

    return {
        "user_id": user_id,
        "user_tags": user_tags,
        "security_context": security_context.to_dict(),
    }


def get_client_dialect(request: Request) -> t.Optional[str]:
    """
    FastAPI dependency to get client SQL dialect from request header.
    
    Header: X-Client-Dialect
    
    Returns:
        Client dialect (e.g., "mysql") or None if not specified.
        
    Used by internal endpoints (MySQL server → API) to indicate the client 
    speaks MySQL dialect and queries need transpilation to the target backend 
    (PostgreSQL/DuckDB/etc.).
    
    Note: Only used by /_internal/query/semantic/sql endpoint.
    Public endpoints ignore this header.
    """
    # HTTP headers are case-insensitive, FastAPI normalizes to lowercase
    return request.headers.get("x-client-dialect")


def get_object_store(request: Request) -> ObjectStoreClient:
    """FastAPI dependency - inject ObjectStoreClient."""
    store = request.app.extra.get("object_store")
    if not store:
        raise HTTPException(503, "Object store not configured")
    return store


def get_query_validator(request: Request):
    """FastAPI dependency - inject QueryValidator from EnvContext."""
    ctx = get_env_context(request)
    return ctx.query_validator


def get_queue_manager(request: Request) -> QueueManager:
    """FastAPI dependency - inject QueueManager."""
    return request.app.extra["qm"]


def get_default_gateway(request: Request) -> str:
    """FastAPI dependency - get default gateway."""
    return request.app.extra.get("default_gateway", "duckdb")


def get_query_state(request: Request) -> QueryState:
    """FastAPI dependency - inject QueryState."""
    return request.app.extra["query_state"]

def get_transpiler(request: Request):
    """FastAPI dependency - inject shared TranspilerClient."""
    client = request.app.extra.get("transpiler_client")
    if client is None:
        raise ApiException(
            message="Transpiler client not initialized (application startup may have failed)",
            origin="API -> settings -> get_transpiler",
            status_code=503,
        )
    return client


def get_graphql_client(request: Request):
    """FastAPI dependency - inject the shared GraphQL proxy ``httpx.AsyncClient``.

    The lifespan builds a single pooled ``httpx.AsyncClient`` with explicit
    ``httpx.Limits`` and stores it on ``app.state.graphql_client``; the
    GraphQL proxy handler reuses it instead of allocating a fresh client
    per request (audit §5.4).  A missing client here means the lifespan
    either has not started yet or crashed during init - fail closed with
    503 rather than letting the handler construct a one-shot client and
    mask the boot-time bug.
    """
    client = getattr(request.app.state, "graphql_client", None)
    if client is None:
        # Use a stable machine-readable code so probes / clients can branch on
        # it; mirrors how missing heimdall_client is surfaced (503 + token).
        raise HTTPException(
            status_code=503,
            detail="graphql_client_unavailable",
        )
    return client
