from __future__ import annotations

import logging
import typing as t

from fastapi import APIRouter, Depends, Query, Request
from pydantic import ConfigDict, Field as PydanticField

from api.context import EnvContext
from api.definitions import Link, Pagination
from api.exceptions import ApiException
from api.settings import get_env_context
from api.utils.async_blocking import run_blocking
from api.utils.urls import urls
from vulcan.core.notification import Notification, NotificationEvent
from vulcan.utils.pydantic import PydanticModel

logger = logging.getLogger(__name__)

router = APIRouter()


class NotificationLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    run: t.Optional[Link] = PydanticField(
        default=None,
        description="Link to associated run activity",
    )
    plan: t.Optional[Link] = PydanticField(
        default=None,
        description="Link to associated plan activity",
    )


class NotificationDetail(Notification):
    model_config = ConfigDict(populate_by_name=True)

    links: NotificationLinks = PydanticField(
        alias="_links",
        serialization_alias="_links",
        description="HATEOAS links to related resources",
    )

    @classmethod
    def from_core(cls, notification: Notification) -> "NotificationDetail":
        return cls(
            **notification.model_dump(),
            links=_build_notification_links(notification),
        )


class NotificationsListResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    environment: str
    notifications: t.List[NotificationDetail]
    total: int
    pagination: Pagination


def _build_notification_links(notification: Notification) -> NotificationLinks:
    return NotificationLinks(
        run=Link(href=urls.run(notification.run_id)) if notification.run_id else None,
        plan=Link(href=urls.plan(notification.plan_id)) if notification.plan_id else None,
    )


@router.get(
    "",
    summary="List notifications",
    response_model=NotificationsListResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Notifications returned successfully"},
        500: {"description": "Internal server error"},
    },
)
async def list_notifications(
    run_id: t.Optional[str] = Query(
        None,
        description="Filter by run id (wins over plan_id when both are set)",
    ),
    plan_id: t.Optional[str] = Query(
        None,
        description="Filter by plan id",
    ),
    events: t.Optional[t.List[NotificationEvent]] = Query(
        None,
        description="Filter by one or more event names (repeatable query param)",
    ),
    start_ts: t.Optional[int] = Query(
        None,
        description="Include notifications with created_ts >= this Unix timestamp (seconds)",
    ),
    end_ts: t.Optional[int] = Query(
        None,
        description="Include notifications with created_ts <= this Unix timestamp (seconds)",
    ),
    limit: int = Query(50, ge=1, le=100, description="Number of notifications to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> NotificationsListResponse:
    """
    List persisted notifications ordered by created time (newest first).

    Returns a flat chronological feed for the resolved environment. Use ``run_id``
    or ``plan_id`` for drill-down views linked from activity detail pages.
    """
    kwargs: t.Dict[str, t.Any] = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "events": events,
        "limit": limit,
        "offset": offset,
    }
    if run_id is not None:
        kwargs["run_id"] = run_id
    elif plan_id is not None:
        kwargs["plan_id"] = plan_id
    else:
        kwargs["environment"] = ctx.environment

    try:
        notifications, has_more = await run_blocking(
            ctx.context.state_sync.list_notifications,
            **kwargs,
        )
        notifications_with_links = [
            NotificationDetail.from_core(notification) for notification in notifications
        ]
        pagination = Pagination(
            limit=limit,
            offset=offset,
            has_more=has_more,
            order_by="created_ts",
            order_direction="desc",
        )
        return NotificationsListResponse(
            environment=ctx.environment,
            notifications=notifications_with_links,
            total=len(notifications_with_links),
            pagination=pagination,
        )
    except Exception as e:
        logger.error(f"Error fetching notifications: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch notifications: {e}",
            origin="API -> notifications -> list_notifications",
        )
