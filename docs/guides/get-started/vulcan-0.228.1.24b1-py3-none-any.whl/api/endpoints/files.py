"""Read-only file system endpoints for the API.

Provides read-only access to project files and directories.
"""

from __future__ import annotations

import os
import typing as t
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from starlette.status import HTTP_404_NOT_FOUND
from pydantic import Field as PydanticField, ConfigDict, field_validator

from vulcan.core import constants as c
from vulcan.utils.pydantic import PydanticModel, ValidationInfo

from api.settings import Settings, get_settings, get_env_context
from api.context import EnvContext
from api.utils.cache import cached, CachePolicy

router = APIRouter()


class File(PydanticModel):
    """File model for API responses."""

    model_config = ConfigDict(validate_default=True)

    name: str = PydanticField(description="File name")
    path: str = PydanticField(description="Relative file path from project root")
    extension: str = PydanticField(default="", description="File extension (e.g., '.py', '.sql')")
    content: t.Optional[str] = PydanticField(default=None, description="File content (None for binary files)")

    @field_validator("extension", mode="before")
    @classmethod
    def default_extension(cls, v: str, info: ValidationInfo) -> str:
        if "name" in info.data:
            return Path(info.data["name"]).suffix
        return v


class Directory(PydanticModel):
    """Directory model for API responses."""

    name: str = PydanticField(description="Directory name")
    path: str = PydanticField(description="Relative directory path from project root")
    directories: t.List["Directory"] = PydanticField(default_factory=list, description="Nested subdirectories")
    files: t.List[File] = PydanticField(default_factory=list, description="Files in this directory")


def validate_path(
    path: str,
    settings: Settings,
    ctx: EnvContext,
) -> str:
    """Validate that a path is within the project directory and not ignored.
    
    Args:
        path: Relative path to validate
        settings: API settings containing project_path
        ctx: Environment context for ignore patterns
        
    Returns:
        Validated path string
        
    Raises:
        HTTPException: 404 if path is outside project or matches ignore patterns
    """
    resolved_path = settings.project_path.resolve()
    full_path = (resolved_path / path).resolve()
    
    # Ensure path is within project directory
    try:
        full_path.relative_to(resolved_path)
    except ValueError:
        raise HTTPException(status_code=HTTP_404_NOT_FOUND, detail="Path outside project directory")
    
    # Check if path matches ignore patterns
    ignore_patterns = ctx.context.config.ignore_patterns if ctx.context.config else c.IGNORE_PATTERNS
    if any(full_path.match(pattern) for pattern in ignore_patterns):
        raise HTTPException(status_code=HTTP_404_NOT_FOUND, detail="Path matches ignore patterns")
    
    return path


@router.get(
    "",
    summary="List project files",
    response_model=Directory,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_files(
    settings: Settings = Depends(get_settings),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> Directory:
    """
    Get recursive directory listing of all project files.
    
    Returns a nested directory structure of all files and directories in the project, excluding
    ignored patterns (e.g., __pycache__, .git, etc.). The structure is recursive, showing all
    subdirectories and their contents.
    
    Files and directories matching ignore patterns defined in the project configuration are excluded
    from the response. Use this to browse the project structure programmatically or build file
    explorer interfaces.
    """
    return _get_directory(settings.project_path, settings, ctx)


@router.get(
    "/{path:path}",
    summary="Get file contents",
    response_model=File,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_file(
    path: str,
    settings: Settings = Depends(get_settings),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> File:
    """
    Get a single file with its contents.
    
    Returns file metadata and contents for a specific file in the project. The path must be
    relative to the project root and must not match any ignore patterns. Binary files return
    `content=None` since they cannot be read as text.
    
    Returns 404 if the file doesn't exist, the path is outside the project directory, or the
    path matches ignore patterns. Use this to read file contents programmatically or display
    file content in UIs.
    """
    # Validate path first
    validated_path = validate_path(path, settings, ctx)
    
    try:
        file_path = Path(validated_path)
        full_path = settings.project_path / file_path
        
        # Check if it's a directory
        if full_path.is_dir():
            raise HTTPException(
                status_code=HTTP_404_NOT_FOUND,
                detail="Path is a directory, use GET /files to list directories"
            )
        
        file = _get_file_with_content(full_path, str(file_path))
    except FileNotFoundError:
        raise HTTPException(status_code=HTTP_404_NOT_FOUND, detail="File not found")

    return file


def _get_directory(
    path: str | Path,
    settings: Settings,
    ctx: EnvContext,
) -> Directory:
    """Get directory structure recursively."""
    ignore_patterns = ctx.context.config.ignore_patterns if ctx.context.config else c.IGNORE_PATTERNS

    def walk_path(
        path: str | Path,
    ) -> tuple[list[Directory], list[File]]:
        directories = []
        files = []

        with os.scandir(path) as entries:
            for entry in entries:
                entry_path = Path(entry.path)
                if (
                    entry.name == "__pycache__"
                    or entry.name.startswith(".")
                    or any(entry_path.match(pattern) for pattern in ignore_patterns)
                ):
                    continue

                relative_path = entry_path.relative_to(settings.project_path)

                if entry.is_dir(follow_symlinks=False):
                    _directories, _files = walk_path(entry.path)
                    directories.append(
                        Directory(
                            name=entry.name,
                            path=str(relative_path.as_posix()),
                            directories=_directories,
                            files=_files,
                        )
                    )
                elif entry.is_file(follow_symlinks=False):
                    files.append(File(name=entry.name, path=str(relative_path.as_posix())))
        return sorted(directories, key=lambda x: x.name), sorted(files, key=lambda x: x.name)

    directories, files = walk_path(path)
    relative_path = str(Path(path).relative_to(settings.project_path))

    return Directory(
        name=os.path.basename(path),
        path="" if relative_path == "." else relative_path,
        directories=directories,
        files=files,
    )


def _get_file_with_content(file_path: Path, relative_path: str) -> File:
    """Get a file with its contents."""
    try:
        content = file_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise
    except Exception:
        # If we can't read the file (e.g., binary file), return None for content
        content = None

    return File(
        name=file_path.name,
        path=relative_path,
        content=content,
    )

