"""PGQ monitoring and status endpoints.

Exposes PGQ job status, queue statistics, and job history for monitoring
and debugging purposes.
"""

import logging
import typing as t
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Path
from pydantic import BaseModel, Field, ConfigDict
from pgqueuer import QueueManager
from pgqueuer.models import Log, LogStatistics, QueueStatistics, JOB_STATUS

logger = logging.getLogger(__name__)

router = APIRouter()


# Response Models
class JobStatusResponse(BaseModel):
    """Job status response."""
    
    job_id: int = Field(..., description="Job ID")
    status: str = Field(..., description="Current job status (queued, picked, successful, canceled, exception)")


class JobLogEntry(BaseModel):
    """Single log entry for a job."""
    
    created: t.Optional[str] = Field(None, description="ISO timestamp when log entry was created")
    status: str = Field(..., description="Job status at this log entry")
    priority: int = Field(..., description="Job priority")
    entrypoint: str = Field(..., description="Entrypoint name")
    traceback: t.Optional[dict] = Field(None, description="Exception traceback if status is 'exception'")
    aggregated: t.Optional[int] = Field(None, description="Number of aggregated log entries")


class JobHistoryResponse(BaseModel):
    """Job history response."""
    
    job_id: int = Field(..., description="Job ID")
    logs: t.List[JobLogEntry] = Field(..., description="List of log entries for this job")
    count: int = Field(..., description="Total number of log entries")


class QueueStatistic(BaseModel):
    """Single queue statistic entry."""
    
    entrypoint: str = Field(..., description="Entrypoint name")
    status: str = Field(..., description="Job status")
    priority: int = Field(..., description="Job priority")
    count: int = Field(..., description="Number of jobs with this status/priority")


class QueueLogEntry(BaseModel):
    """Single log entry from queue."""
    
    job_id: int = Field(..., description="PGQ job ID")
    created: t.Optional[str] = Field(None, description="ISO timestamp when log entry was created")
    status: str = Field(..., description="Job status")
    priority: int = Field(..., description="Job priority")
    entrypoint: str = Field(..., description="Entrypoint name")
    traceback: t.Optional[dict] = Field(None, description="Exception traceback if status is 'exception'")
    aggregated: t.Optional[int] = Field(None, description="Number of aggregated log entries")


class LogStatistic(BaseModel):
    """Single log statistic entry."""
    
    created: t.Optional[str] = Field(None, description="ISO timestamp when statistic was created")
    entrypoint: str = Field(..., description="Entrypoint name")
    status: str = Field(..., description="Job status")
    priority: int = Field(..., description="Job priority")
    count: int = Field(..., description="Number of jobs with this status/priority")


class EntrypointInfo(BaseModel):
    """Information about a registered entrypoint."""
    
    name: str = Field(..., description="Entrypoint name")
    concurrency_limit: int = Field(..., description="Maximum concurrent jobs allowed")
    requests_per_second: float = Field(..., description="Maximum requests per second")
    retry_timer_seconds: t.Optional[float] = Field(None, description="Retry timer in seconds (only set if configured)")


def get_queue_manager(request: Request) -> QueueManager:
    """Dependency to get QueueManager from app.extra."""
    qm = request.app.extra.get("qm")
    if not qm:
        raise HTTPException(status_code=503, detail="QueueManager not available")
    return qm


@router.get(
    "/jobs/{job_id}",
    summary="Get job status",
    response_model=JobStatusResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_job_status(
    job_id: int = Path(..., description="Job ID", ge=1),
    qm: QueueManager = Depends(get_queue_manager),
) -> JobStatusResponse:
    """
    Get the current status of a specific job.
    
    **What this is:**
    Returns the current status of a job by its ID (queued, picked, successful,
    canceled, or exception).
    
    **Why this helps:**
    - Check job execution status
    - Monitor job progress
    - Determine if a job completed or failed
    
    **How it works:**
    Queries PGQ for the job status by job ID. Returns 404 if job not found.
    """
    try:
        # Query PGQ job status (takes a list of job IDs)
        from pgqueuer.models import JobId
        statuses = await qm.queries.job_status([JobId(job_id)])
        
        if not statuses:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        # job_status returns list of tuples: [(job_id, status), ...]
        job_id_result, status = statuses[0]
        
        return JobStatusResponse(
            job_id=job_id,
            status=status,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get job status: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get job status: {e}")


@router.get(
    "/jobs/{job_id}/history",
    summary="Get job history",
    response_model=JobHistoryResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_job_history(
    job_id: int = Path(..., description="Job ID", ge=1),
    qm: QueueManager = Depends(get_queue_manager),
) -> JobHistoryResponse:
    """
    Get the complete execution history for a specific job.
    
    **What this is:**
    Returns all log entries for a job, showing its progression through different
    states (queued → picked → successful/failed) with timestamps and error details.
    
    **Why this helps:**
    - Debug failed jobs by viewing execution timeline
    - Understand job state transitions
    - Access exception tracebacks for failed jobs
    
    **How it works:**
    Retrieves all queue logs and filters by job_id. Returns chronological log
    entries with status changes and error information.
    """
    try:
        # Get all logs and filter by job_id
        logs = await qm.queries.queue_log()
        
        job_logs = [
            JobLogEntry(
                created=log.created.isoformat() if log.created else None,
                status=log.status,
                priority=log.priority,
                entrypoint=log.entrypoint,
                traceback=log.traceback.model_dump() if log.traceback else None,
                aggregated=log.aggregated,
            )
            for log in logs
            if log.job_id == job_id
        ]
        
        return JobHistoryResponse(
            job_id=job_id,
            logs=job_logs,
            count=len(job_logs),
        )
    except Exception as e:
        logger.error(f"Failed to get job history: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get job history: {e}")


@router.get(
    "/stats",
    summary="List queue statistics",
    response_model=t.List[QueueStatistic],
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_queue_statistics(
    entrypoint: t.Optional[str] = Query(None, description="Filter statistics by entrypoint name"),
    qm: QueueManager = Depends(get_queue_manager),
) -> t.List[QueueStatistic]:
    """
    Get current queue statistics grouped by entrypoint, status, and priority.
    
    **What this is:**
    Returns a breakdown of jobs currently in the queue, showing counts by state
    (queued, picked, etc.) for each entrypoint and priority level.
    
    **Why this helps:**
    - Monitor queue health and depth
    - Identify bottlenecks by entrypoint or priority
    - Track job distribution across states
    
    **How it works:**
    Queries PGQ for current queue size statistics. Supports optional filtering
    by entrypoint name.
    """
    try:
        # Get queue statistics
        stats = await qm.queries.queue_size()
        
        # Filter by entrypoint if provided
        if entrypoint:
            stats = [s for s in stats if s.entrypoint == entrypoint]
        
        return [
            QueueStatistic(
                entrypoint=stat.entrypoint,
                status=stat.status,
                priority=stat.priority,
                count=stat.count,
            )
            for stat in stats
        ]
    except Exception as e:
        logger.error(f"Failed to get queue statistics: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get queue statistics: {e}")


@router.get(
    "/logs",
    summary="List queue logs",
    response_model=t.List[QueueLogEntry],
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_queue_logs(
    entrypoint: t.Optional[str] = Query(None, description="Filter logs by entrypoint name"),
    status: t.Optional[str] = Query(
        None,
        description="Filter logs by status",
        pattern=f"^(?i)({'|'.join(JOB_STATUS.__args__)})$"
    ),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of logs to return"),
    qm: QueueManager = Depends(get_queue_manager),
) -> t.List[QueueLogEntry]:
    """
    Get recent job execution logs with optional filtering.
    
    **What this is:**
    Returns a list of log entries from the queue with job details, timestamps,
    status, and error information.
    
    **Why this helps:**
    - Monitor recent job activity
    - Debug issues by filtering failed jobs
    - Audit job execution history
    
    **How it works:**
    Retrieves queue logs from PGQ. Supports filtering by entrypoint and status,
    with configurable result limit (default 100, max 1000).
    """
    try:
        # Get all logs
        logs = await qm.queries.queue_log()
        
        # Apply filters
        filtered_logs = logs
        if entrypoint:
            filtered_logs = [log for log in filtered_logs if log.entrypoint == entrypoint]
        if status:
            # Normalize status to lowercase for case-insensitive comparison
            status_lower = status.lower()
            filtered_logs = [log for log in filtered_logs if log.status.lower() == status_lower]
        
        # Limit results
        filtered_logs = filtered_logs[:limit]
        
        return [
            QueueLogEntry(
                job_id=log.job_id,
                created=log.created.isoformat() if log.created else None,
                status=log.status,
                priority=log.priority,
                entrypoint=log.entrypoint,
                traceback=log.traceback.model_dump() if log.traceback else None,
                aggregated=log.aggregated,
            )
            for log in filtered_logs
        ]
    except Exception as e:
        logger.error(f"Failed to get queue logs: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get queue logs: {e}")


@router.get(
    "/logs/statistics",
    summary="List log statistics",
    response_model=t.List[LogStatistic],
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_log_statistics(
    entrypoint: t.Optional[str] = Query(None, description="Filter statistics by entrypoint name"),
    tail: t.Optional[int] = Query(None, ge=1, description="Number of recent entries to retrieve"),
    last_hours: t.Optional[int] = Query(None, ge=1, description="Time window in hours (e.g., 24 for last 24 hours)"),
    qm: QueueManager = Depends(get_queue_manager),
) -> t.List[LogStatistic]:
    """
    Get aggregated statistics from job execution logs.
    
    **What this is:**
    Returns aggregated counts of jobs grouped by entrypoint, status, and priority
    from historical log data.
    
    **Why this helps:**
    - Analyze job success rates and patterns
    - Generate reports on queue performance
    - Identify trends over time windows
    
    **How it works:**
    Aggregates log statistics from PGQ. Supports filtering by entrypoint and time
    window (last N hours or last N entries). If both tail and last_hours are provided,
    last_hours takes precedence.
    """
    try:
        # Convert last_hours to timedelta if provided
        last = timedelta(hours=last_hours) if last_hours else None
        
        # Get log statistics
        stats = await qm.queries.log_statistics(tail=tail, last=last)
        
        # Apply entrypoint filter if provided
        if entrypoint:
            stats = [s for s in stats if s.entrypoint == entrypoint]
        
        return [
            LogStatistic(
                created=stat.created.isoformat() if stat.created else None,
                entrypoint=stat.entrypoint,
                status=stat.status,
                priority=stat.priority,
                count=stat.count,
            )
            for stat in stats
        ]
    except Exception as e:
        logger.error(f"Failed to get log statistics: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get log statistics: {e}")


@router.get(
    "/entrypoints",
    summary="List entrypoints",
    response_model=t.List[EntrypointInfo],
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_entrypoints(
    qm: QueueManager = Depends(get_queue_manager),
) -> t.List[EntrypointInfo]:
    """
    Get list of all registered entrypoints with their configuration.
    
    **What this is:**
    Returns information about all entrypoints registered in the queue system,
    including concurrency limits, rate limits, and retry configuration.
    
    **Why this helps:**
    - Discover available queues and their capabilities
    - Understand entrypoint configuration and limits
    - Plan job submission based on queue settings
    
    **How it works:**
    Retrieves entrypoint registry from QueueManager and extracts configuration
    parameters for each registered entrypoint.
    """
    try:
        entrypoints = []
        for name, executor in qm.entrypoint_registry.items():
            # Get parameters from executor
            params = executor.parameters
            
            # Extract retry_timer (only set if present)
            retry_timer_seconds = None
            if hasattr(params, 'retry_timer') and params.retry_timer:
                retry_timer_seconds = params.retry_timer.total_seconds()
            
            entrypoints.append(
                EntrypointInfo(
                    name=name,
                    concurrency_limit=params.concurrency_limit,
                    requests_per_second=params.requests_per_second,
                    retry_timer_seconds=retry_timer_seconds,
                )
            )
        
        return entrypoints
    except Exception as e:
        logger.error(f"Failed to get entrypoints: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get entrypoints: {e}")


@router.get(
    "/pending",
    summary="List pending jobs",
    response_model=dict[str, int],
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
)
async def get_pending_jobs(
    entrypoints: t.Optional[t.List[str]] = Query(None, description="List of entrypoint names to check (defaults to all registered entrypoints)"),
    qm: QueueManager = Depends(get_queue_manager),
) -> dict[str, int]:
    """
    Get count of pending (queued) jobs per entrypoint.
    
    **What this is:**
    Returns a dictionary mapping entrypoint names to the number of jobs currently
    waiting to be processed in the queue.
    
    **Why this helps:**
    - Monitor queue depth and backlog
    - Identify entrypoints that may need scaling
    - Track job wait times and capacity
    
    **How it works:**
    Queries PGQ for queued work count per entrypoint. If no entrypoints specified,
    checks all registered entrypoints. Entrypoints that fail to query return count 0.
    """
    try:
        # If no entrypoints specified, get all registered entrypoints
        if not entrypoints:
            entrypoints = list(qm.entrypoint_registry.keys())
        
        # Get pending job count for each entrypoint
        pending_counts = {}
        for ep in entrypoints:
            try:
                count = await qm.queries.queued_work([ep])
                pending_counts[ep] = count
            except Exception as e:
                logger.warning(f"Failed to get pending jobs for {ep}: {e}")
                pending_counts[ep] = 0
        
        return pending_counts
    except Exception as e:
        logger.error(f"Failed to get pending jobs: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get pending jobs: {e}")

