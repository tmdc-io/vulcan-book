from __future__ import annotations

import logging
import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import Field as PydanticField

from api.context import EnvContext
from api.definitions import Pagination
from api.exceptions import ApiException
from api.settings import get_env_context, get_user
from api.utils.async_blocking import run_blocking
from vulcan.core.follower import (
    Follower,
    FollowerAnalytics,
    FollowerGranularity,
)
from vulcan.core.state_sync.db.follower import MAX_ANALYTICS_LIMIT
from vulcan.utils.pydantic import PydanticModel

logger = logging.getLogger(__name__)

router = APIRouter()


class FollowRequest(PydanticModel):
    metadata: t.Optional[t.Dict[str, t.Any]] = None


class FollowStatus(PydanticModel):
    is_follower: bool
    user_id: str
    active: t.Optional[bool] = None
    followed_at: t.Optional[int] = None
    metadata: t.Optional[t.Dict[str, t.Any]] = None


class FollowerListItem(PydanticModel):
    user_id: str
    followed_at: int
    metadata: t.Dict[str, t.Any] = PydanticField(default_factory=dict)


class FollowersListResponse(PydanticModel):
    followers: t.List[FollowerListItem]
    total: int
    pagination: Pagination


@router.post(
    "",
    summary="Follow this data product",
    response_model=Follower,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Follow state returned successfully"},
        500: {"description": "Internal server error"},
    },
)
async def follow(
    body: FollowRequest = FollowRequest(),
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> Follower:
    """
    Follow this data product for the authenticated user.

    Idempotent when the user is already an active follower.
    """
    user_id = user["user_id"]
    try:
        return await run_blocking(
            ctx.context.state_sync.follow,
            user_id,
            metadata=body.metadata,
        )
    except Exception as e:
        logger.error("Error following data product for %r: %s", user_id, e, exc_info=True)
        raise ApiException(
            message=f"Failed to follow data product: {e}",
            origin="API -> followers -> follow",
        )


@router.delete(
    "/me",
    summary="Unfollow this data product",
    response_model=Follower,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Unfollow state returned successfully"},
        404: {"description": "User has never followed this product"},
        500: {"description": "Internal server error"},
    },
)
async def unfollow(
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> Follower:
    """Unfollow this data product for the authenticated user."""
    user_id = user["user_id"]
    try:
        return await run_blocking(ctx.context.state_sync.unfollow, user_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error("Error unfollowing data product for %r: %s", user_id, e, exc_info=True)
        raise ApiException(
            message=f"Failed to unfollow data product: {e}",
            origin="API -> followers -> unfollow",
        )


@router.get(
    "/me",
    summary="Get current user's follow status",
    response_model=FollowStatus,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Follow state returned successfully"},
        500: {"description": "Internal server error"},
    },
)
async def get_my_follow_status(
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> FollowStatus:
    """Return whether the authenticated user follows this data product."""
    user_id = user["user_id"]
    try:
        follower = await run_blocking(ctx.context.state_sync.get_follower, user_id)
    except Exception as e:
        logger.error("Error fetching follow state for %r: %s", user_id, e, exc_info=True)
        raise ApiException(
            message=f"Failed to fetch follow state: {e}",
            origin="API -> followers -> get_my_follow_status",
        )

    if follower is None:
        return FollowStatus(is_follower=False, user_id=user_id)

    return FollowStatus(
        is_follower=follower.active,
        user_id=follower.user_id,
        active=follower.active,
        followed_at=follower.followed_at,
        metadata=follower.metadata,
    )


@router.get(
    "/analytics",
    summary="Follower analytics",
    response_model=FollowerAnalytics,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Analytics returned successfully"},
        400: {"description": "Invalid analytics parameters"},
        500: {"description": "Internal server error"},
    },
)
async def analytics(
    granularity: t.Optional[FollowerGranularity] = Query(
        None,
        description="Bucket size for time series; omit for current active count only",
    ),
    offset: int = Query(0, ge=0, description="Buckets to skip counting back from the present"),
    limit: int = Query(
        30,
        ge=1,
        le=MAX_ANALYTICS_LIMIT,
        description="Number of buckets to return when granularity is set",
    ),
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> FollowerAnalytics:
    """
    Return active follower count and optional bucket-based analytics.

    Without ``granularity``, only ``total_active`` is returned. With
    ``granularity``, each bucket reports how many users were actively
    following at ``period_end``.
    """
    del user  # Auth required; identity is not used for analytics.
    try:
        return await run_blocking(
            ctx.context.state_sync.get_follower_analytics,
            granularity=granularity,
            limit=limit,
            offset=offset,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error fetching follower analytics: %s", e, exc_info=True)
        raise ApiException(
            message=f"Failed to fetch follower analytics: {e}",
            origin="API -> followers -> analytics",
        )


@router.get(
    "",
    summary="List active followers",
    response_model=FollowersListResponse,
    responses={
        200: {"description": "Followers returned successfully"},
        500: {"description": "Internal server error"},
    },
)
async def list_followers(
    limit: int = Query(50, ge=1, le=100, description="Number of followers to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    ctx: EnvContext = Depends(get_env_context),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> FollowersListResponse:
    """List active followers ordered by ``followed_at`` descending."""
    del user  # Auth required; listing is not scoped to the caller.
    try:
        followers, has_more = await run_blocking(
            ctx.context.state_sync.list_followers,
            limit=limit,
            offset=offset,
        )
    except Exception as e:
        logger.error("Error listing followers: %s", e, exc_info=True)
        raise ApiException(
            message=f"Failed to list followers: {e}",
            origin="API -> followers -> list_followers",
        )

    items = [
        FollowerListItem(
            user_id=follower.user_id,
            followed_at=follower.followed_at,
            metadata=follower.metadata,
        )
        for follower in followers
    ]
    return FollowersListResponse(
        followers=items,
        total=len(items),
        pagination=Pagination(
            limit=limit,
            offset=offset,
            has_more=has_more,
            order_by="followed_at",
            order_direction="desc",
        ),
    )
