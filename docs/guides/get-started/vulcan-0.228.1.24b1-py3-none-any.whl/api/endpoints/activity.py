import logging
import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field as PydanticField, ConfigDict

from api.context import EnvContext
from api.definitions import Link, Pagination
from api.exceptions import ApiException
from api.settings import get_env_context
from api.utils.async_blocking import run_blocking
from api.utils.urls import urls
from api.utils.helpers import validate_model
from api.utils.cache import cached, CachePolicy
from vulcan.core.activity import (
    PlanActivity,
    RunActivityWithChecksAndProfile,
)
from vulcan.core.soda3.spec import CheckResult, ModelProfile
from vulcan.utils.git import GitClient
from vulcan.utils.pydantic import PydanticModel

logger = logging.getLogger(__name__)
MAX_GIT_DIFF_SIZE = 512_000

router = APIRouter()


class PlanLinks(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    self_link: Link = PydanticField(alias="self", serialization_alias="self", description="Self reference link")
    previous: t.Optional[Link] = PydanticField(default=None, description="Link to previous plan")
    commit: t.Optional[Link] = PydanticField(default=None, description="Link to the plan commit")
    git_diff: t.Optional[Link] = PydanticField(default=None, description="Link to the plan git diff")


class PlanGitDiffLinks(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,
    )

    self_link: Link = PydanticField(alias="self", serialization_alias="self", description="Self reference link")
    current_plan: Link = PydanticField(description="Link to the current plan")
    previous_plan: t.Optional[Link] = PydanticField(default=None, description="Link to the previous plan")


class GitCommitDetail(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    sha: str
    message: str
    author_name: str
    author_email: str
    authored_at: str
    commit_url: t.Optional[str] = None


class Plan(PlanActivity):
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    links: PlanLinks = PydanticField(alias="_links", serialization_alias="_links", description="HATEOAS links to related resources")
    
    @classmethod
    def from_core(cls, plan_activity: PlanActivity, links: PlanLinks) -> "Plan":
        return cls(**plan_activity.model_dump(exclude_none=True), links=links)


class PlanGitDiffResponse(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,
    )

    git_diff: t.Optional[str] = None
    commits: t.List[GitCommitDetail] = PydanticField(default_factory=list)
    message: t.Optional[str] = None
    truncated: bool = PydanticField(
        default=False,
        description=(
            "True when ``git_diff`` was trimmed to ``MAX_GIT_DIFF_SIZE`` bytes. "
            "Clients should treat ``git_diff`` as a best-effort prefix and fetch "
            "the commit range directly for the full diff."
        ),
    )
    links: PlanGitDiffLinks = PydanticField(alias="_links", serialization_alias="_links", description="HATEOAS links to related resources")


class RunLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)
    self_link: Link = PydanticField(alias="self", serialization_alias="self", description="Self reference link")
    plan: t.Optional[Link] = PydanticField(default=None, description="Link to associated plan")


class RunDetail(RunActivityWithChecksAndProfile):
    model_config = ConfigDict(populate_by_name=True)
    links: RunLinks = PydanticField(alias="_links", serialization_alias="_links", description="HATEOAS links to related resources")


class ModelRunsResponse(PydanticModel):
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    model_name: str
    environment: str
    runs: t.List[RunDetail]
    total: int
    pagination: Pagination


class RunsListResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)
    
    environment: str
    runs: t.List[RunDetail]
    total: int
    pagination: Pagination


class ModelLatestRun(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    model_name: str
    run: t.Optional[RunDetail] = None


class ModelsLatestRunsResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    environment: str
    models: t.List[ModelLatestRun]


def _build_plan_links(plan_row: PlanActivity) -> PlanLinks:
    return PlanLinks(
        self_link=Link(href=urls.plan(plan_row.plan_id)),
        previous=Link(href=urls.plan(plan_row.prev_plan_id)) if plan_row.prev_plan_id else None,
        commit=Link(href=plan_row.git_commit_url) if plan_row.git_commit_url else None,
        git_diff=Link(href=urls.plan_git_diff(plan_row.plan_id)),
    )


def _build_plan_git_diff_links(
    plan_row: PlanActivity, previous_plan_id: t.Optional[str] = None
) -> PlanGitDiffLinks:
    return PlanGitDiffLinks(
        self_link=Link(href=urls.plan_git_diff(plan_row.plan_id)),
        current_plan=Link(href=urls.plan(plan_row.plan_id)),
        previous_plan=Link(href=urls.plan(previous_plan_id)) if previous_plan_id else None,
    )


def _build_run_links(run_id: str, plan_id: t.Optional[str] = None) -> RunLinks:
    return RunLinks(
        self_link=Link(href=urls.run(run_id)),
        plan=Link(href=urls.plan(plan_id)) if plan_id else None,
    )


class PlansListResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    environment: str
    plans: t.List[Plan]
    total: int
    pagination: Pagination


@router.get(
    "/plans",
    summary="List plans",
    response_model=PlansListResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Plans returned successfully"},
        500: {"description": "Internal server error"},
    },
)
@cached(policy=CachePolicy.PLAN_CHANGE)
async def list_plans(
    model_names: t.Optional[str] = Query(
        None,
        description="Comma-separated model names to filter plans that directly affected any of these models",
    ),
    limit: int = Query(20, ge=1, le=100, description="Number of plans to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None,
        description="Filter plans >= this timestamp (Unix seconds)",
    ),
    end_ts: t.Optional[int] = Query(
        None,
        description="Filter plans <= this timestamp (Unix seconds)",
    ),
    success: t.Optional[bool] = Query(
        None,
        description="Filter by success (true=successful, false=failed)",
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> PlansListResponse:
    """
    List plans ordered by start time (newest first).

    Use query parameters to filter by model names (directly affected), time range, or success status.
    Returns plan deployment details including changes, affected models, and backfill info.
    """
    models = (
        [m.strip() for m in model_names.split(",") if m.strip()]
        if model_names
        else None
    )
    try:
        plans = await run_blocking(
            ctx.context.state_sync.list_plans,
            environment=ctx.environment,
            model_names=models,
            limit=limit,
            offset=offset,
            start_ts=start_ts,
            end_ts=end_ts,
            success=success,
        )
        plans_with_links = [
            Plan.from_core(p, _build_plan_links(p))
            for p in plans
        ]
        has_more = len(plans) == limit
        pagination = Pagination(
            limit=limit,
            offset=offset,
            has_more=has_more,
            order_by="start_ts",
            order_direction="desc",
        )
        return PlansListResponse(
            environment=ctx.environment,
            plans=plans_with_links,
            total=len(plans_with_links),
            pagination=pagination,
        )
    except Exception as e:
        logger.error(f"Error fetching plans: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch plans: {e}",
            origin="API -> activity -> list_plans",
        )


@router.get(
    "/plans/{plan_id}",
    summary="Get plan",
    response_model=Plan,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Plan returned successfully"},
        404: {"description": "Plan not found"},
    },
)
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_plan(
    plan_id: str,
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
):
    """
    Get detailed information for a specific plan deployment.
    
    Returns complete plan information including what changed (added, removed, modified models),
    which models were affected directly and indirectly, backfill requirements, execution metadata,
    and links to related plans. Use this to understand what a plan deployment changed and its impact.
    
    """
    plans = await run_blocking(ctx.context.state_sync.list_plans, plan_id=plan_id)
    plan_row = plans[0] if plans else None

    if not plan_row:
        raise HTTPException(404, f"Plan '{plan_id}' not found")

    return Plan.from_core(
        plan_row,
        _build_plan_links(plan_row),
    )


def _collect_git_diff_payload(
    git_client: GitClient,
    prev_sha: str,
    curr_sha: str,
) -> t.Tuple[t.List[GitCommitDetail], t.Optional[str], bool, t.Optional[str]]:
    """Collect commits + diff for the SHA range and apply truncation.

    Pure synchronous helper so the whole git interaction (``list_commits`` +
    ``diff`` + ``MAX_GIT_DIFF_SIZE`` trim) runs as a single ``run_blocking``
    bounce. ``GitClient`` shells out to ``git``, which is blocking I/O; running
    these inline on the event loop stalls every other request for the duration
    of the diff (audit §5.3 follow-up).

    Returns a ``(commits, git_diff, truncated, diff_error)`` tuple. Failures
    from either ``list_commits`` or ``diff`` are captured into ``diff_error``
    rather than raised so the caller can still return a best-effort response
    with a human-readable message (mirrors the pre-F1 inline behavior,
    exercised by ``test_get_plan_git_diff_returns_message_when_git_diff_fails``).
    """
    try:
        commits = [
            GitCommitDetail(
                sha=c.sha,
                message=c.message,
                author_name=c.author_name,
                author_email=c.author_email,
                authored_at=c.authored_at,
                commit_url=git_client.commit_url(c.sha),
            )
            for c in git_client.list_commits(prev_sha, curr_sha)
        ]
    except Exception as exc:
        return [], None, False, str(exc)

    try:
        git_diff = git_client.diff(prev_sha, curr_sha)
    except Exception as exc:
        return commits, None, False, str(exc)

    truncated = False
    if len(git_diff) > MAX_GIT_DIFF_SIZE:
        git_diff = f"{git_diff[:MAX_GIT_DIFF_SIZE]}\n... (truncated)"
        truncated = True
    return commits, git_diff, truncated, None


@router.get(
    "/plans/{plan_id}/git-diff",
    summary="Get git diff for a plan",
    response_model=PlanGitDiffResponse,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Git diff returned successfully"},
        404: {"description": "Plan not found"},
        500: {"description": "Internal server error"},
    },
)
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_plan_git_diff(
    plan_id: str,
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> PlanGitDiffResponse:
    """
    Get the formatted git diff between a plan and the previous plan in the same environment.

    The comparison is based on plan sequence within the same environment, so dev and prod
    histories remain isolated.
    """
    try:
        plans = await run_blocking(ctx.context.state_sync.list_plans, plan_id=plan_id)
        current_plan_row = plans[0] if plans else None
        if not current_plan_row:
            raise HTTPException(404, f"Plan '{plan_id}' not found")

        previous_plans = []
        if current_plan_row.plan_seq > 1:
            previous_plans = await run_blocking(
                ctx.context.state_sync.list_plans,
                environment=current_plan_row.environment,
                plan_seq=current_plan_row.plan_seq - 1,
                limit=1,
            )

        previous_plan_row = previous_plans[0] if previous_plans else None
        if not previous_plan_row:
            return PlanGitDiffResponse(
                git_diff=None,
                commits=[],
                message="no previous plan found",
                links=_build_plan_git_diff_links(current_plan_row),
            )

        git_diff: t.Optional[str] = None
        commits: t.List[GitCommitDetail] = []
        message: t.Optional[str] = None
        truncated = False
        try:
            if not current_plan_row.git_commit_sha or not previous_plan_row.git_commit_sha:
                message = "Git diff unavailable: missing commit SHA"
            else:
                commits, git_diff, truncated, diff_error = await run_blocking(
                    _collect_git_diff_payload,
                    ctx.context.git_client,
                    previous_plan_row.git_commit_sha,
                    current_plan_row.git_commit_sha,
                )
                if diff_error is not None:
                    logger.error(
                        f"Error generating git diff for plan {plan_id}: {diff_error}"
                    )
                    message = f"Git diff unavailable: {diff_error}"
                elif truncated:
                    message = "Git diff truncated"
        except Exception as e:
            logger.error(f"Error generating git diff for plan {plan_id}: {e}", exc_info=True)
            message = f"Git diff unavailable: {e}"

        return PlanGitDiffResponse(
            git_diff=git_diff,
            commits=commits,
            message=message,
            truncated=truncated,
            links=_build_plan_git_diff_links(current_plan_row, previous_plan_row.plan_id),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching git diff for plan {plan_id}: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch git diff for plan {plan_id}: {e}",
            origin="API -> activity -> get_plan_git_diff",
        )


@router.get(
    "/runs",
    summary="List runs",
    response_model=RunsListResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Runs returned successfully"},
        500: {"description": "Internal server error"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_runs(
    model_names: t.Optional[str] = Query(
        None,
        description="Comma-separated model names to filter runs that executed any of these models",
    ),
    success: t.Optional[bool] = Query(
        None,
        description="Filter by success (true=successful, false=failed)",
    ),
    start_ts: t.Optional[int] = Query(
        None,
        description="Filter runs >= this timestamp (Unix seconds)",
    ),
    end_ts: t.Optional[int] = Query(
        None,
        description="Filter runs <= this timestamp (Unix seconds)",
    ),
    limit: int = Query(20, ge=1, le=100, description="Number of runs to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> RunsListResponse:
    """
    List runs ordered by start time (newest first).
    
    Use query parameters to filter by model names, success status, or time range.
    Returns full run details including quality checks and profile data.
    """
    models = (
        [m.strip() for m in model_names.split(",") if m.strip()]
        if model_names
        else None
    )
    try:
        runs = await run_blocking(
            ctx.context.state_sync.list_runs,
            environment=ctx.environment,
            model_names=models,
            success=success,
            start_ts=start_ts,
            end_ts=end_ts,
            limit=limit,
            offset=offset,
        )
        runs_with_links = [
            RunDetail(
                **run.model_dump(exclude_none=True),
                links=_build_run_links(run.run_id, run.plan_id),
            )
            for run in runs
        ]
        has_more = len(runs) == limit
        pagination = Pagination(
            limit=limit,
            offset=offset,
            has_more=has_more,
            order_by="start_ts",
            order_direction="desc",
        )
        return RunsListResponse(
            environment=ctx.environment,
            runs=runs_with_links,
            total=len(runs_with_links),
            pagination=pagination,
        )
    except Exception as e:
        logger.error(f"Error fetching runs: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch runs: {e}",
            origin="API -> activity -> list_runs",
        )


@router.get(
    "/runs/{run_id}",
    summary="Get run",
    response_model=RunDetail,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Run returned successfully"},
        404: {"description": "Run not found"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_run(
    run_id: str,
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> RunDetail:
    """
    Get complete information for a specific run execution.
    
    Returns unified run information including execution status, performance metrics for all executed models,
    quality check results (if available), and data profiling statistics (if available). Quality checks and
    profiles are grouped by model name and include all models executed in the run.
    
    Quality and profile fields are `None` if no quality checks or profiling were performed for the run.
    This is not an error condition - it simply means those features weren't enabled for that execution.
    
    To list runs, use GET /activity/runs. To list runs for a model, use GET /activity/models/{model_name}/runs.
    """
    runs = await run_blocking(ctx.context.state_sync.list_runs, run_id=run_id)
    run_activity_with_checks = runs[0] if runs else None

    if not run_activity_with_checks:
        raise HTTPException(404, f"Run '{run_id}' not found")
    
    return RunDetail(
        **run_activity_with_checks.model_dump(exclude_none=True),
        links=_build_run_links(run_activity_with_checks.run_id, run_activity_with_checks.plan_id),
    )


@router.get(
    "/models/{model_name}/runs",
    summary="List model runs",
    response_model=ModelRunsResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Model runs returned successfully"},
        400: {"description": "Invalid query parameters"},
        404: {"description": "Model not found"},
        500: {"description": "Internal server error"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_model_runs(
    model_name: str,
    limit: int = Query(20, ge=1, le=100, description="Number of runs to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter runs >= this timestamp (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter runs <= this timestamp (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
):
    """
    Get execution history for a specific model.
    
    Returns a paginated list of runs that executed the specified model, including execution metrics,
    quality checks, and profile data filtered to that model. Returns the same structure as
    `/activity/runs/{run_id}`, but filtered to show only the specified model's execution details.
    
    Run-level metrics (`start_ts`, `end_ts`, `success`, `rows_affected`, `evaluation_ms`)
    represent the entire run execution, not just this model. Use query parameters `start_ts` and `end_ts`
    to filter by time range, or `limit` and `offset` to control pagination.
    
    To get complete run information for all models in a run, use `/activity/runs/{run_id}`.
    """
    model_entry = validate_model(model_name, ctx)

    try:
        runs = await run_blocking(
            ctx.context.state_sync.list_runs,
            environment=ctx.environment,
            model_names=[model_entry.name],
            limit=limit,
            offset=offset,
            start_ts=start_ts,
            end_ts=end_ts,
        )
        
        # Convert to RunDetail (adds HATEOAS links)
        runs_with_links = [
            RunDetail(
                **run.model_dump(exclude_none=True),
                links=_build_run_links(run.run_id, run.plan_id),
            )
            for run in runs
        ]
        
        # Build pagination
        has_more = len(runs) == limit
        pagination = Pagination(
            limit=limit,
            offset=offset,
            has_more=has_more,
            order_by="start_ts",
            order_direction="desc",
        )

        return ModelRunsResponse(
            model_name=model_entry.name,
            environment=ctx.environment,
            runs=runs_with_links,
            total=len(runs_with_links),
            pagination=pagination,
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error fetching model runs: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch runs for model '{model_name}': {e}",
            origin="API -> activity -> list_model_runs",
        )


@router.get(
    "/models",
    summary="List models (latest run)",
    response_model=ModelsLatestRunsResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Models returned successfully"},
        500: {"description": "Internal server error"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_models_latest_runs(
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> ModelsLatestRunsResponse:
    """
    List all models in the environment with their latest run information.

    Each model includes at most one run (the latest by start_ts). If a model has
    never been run, the run field is null.
    """
    all_models = sorted({m.name for m in ctx.metadata.models})
    try:
        latest_map = await run_blocking(
            ctx.context.state_sync.list_latest_runs_by_model,
            environment=ctx.environment,
            model_names=all_models,
        )

        items: t.List[ModelLatestRun] = []
        for model_name in all_models:
            run = latest_map.get(model_name)
            run_detail = (
                RunDetail(
                    **run.model_dump(exclude_none=True),
                    links=_build_run_links(run.run_id, run.plan_id),
                )
                if run
                else None
            )
            items.append(ModelLatestRun(model_name=model_name, run=run_detail))

        # Stable ordering: name asc, then latest start_ts desc
        items.sort(key=lambda x: x.model_name)
        items.sort(key=lambda x: x.run.start_ts if x.run else -1, reverse=True)

        return ModelsLatestRunsResponse(
            environment=ctx.environment,
            models=items,
        )
    except Exception as e:
        logger.error(f"Error fetching latest runs by model: {e}", exc_info=True)
        raise ApiException(
            message=f"Failed to fetch latest runs by model: {e}",
            origin="API -> activity -> list_models_latest_runs",
        )
