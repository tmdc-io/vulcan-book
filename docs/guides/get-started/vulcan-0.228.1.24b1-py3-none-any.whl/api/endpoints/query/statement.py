from __future__ import annotations

import logging
import time
import typing as t

import math
from datetime import date, datetime

import yaml

from starlette.requests import Request
from fastapi import APIRouter, HTTPException, Query, Header, Depends, Response
from fastapi.responses import RedirectResponse, JSONResponse

from vulcan.core.query import ObjectStoreClient
from vulcan.core.query.definitions import QueryStatus, QueryRequest, QueryResult
from vulcan.utils.errors import ObjectStoreError

from api.context import EnvContext
from api.settings import get_env_context, get_object_store
from api.definitions import Link
from api.utils.async_blocking import run_blocking
from api.utils.urls import urls
from api.endpoints.query import (
    resolve_format,
    apply_filtering,
    is_request_stale,
    make_statement_links,
    timestamp_to_iso,
)
from api.endpoints.query.models import (
    StatementDetail,
    StatementResult,
    StatementResultLinks,
    PrimaryReq,
    CacheInfo,
)


logger = logging.getLogger(__name__)
router = APIRouter()


def _get_staleness_headers(is_stale: bool) -> t.Dict[str, str]:
    """
    Get HTTP headers for staleness indication.

    Adds an Is-Stale header when result is stale, allowing clients to detect
    when results may be outdated due to underlying model changes.

    Args:
        is_stale: Whether the result is stale

    Returns:
        Dictionary with Is-Stale header if stale, empty dict otherwise
    """
    if is_stale:
        return {"Is-Stale": "true"}
    return {}


def _wrap_statement_detail_with_staleness(
    statement_detail: StatementDetail,
    ctx: EnvContext,
) -> t.Union[StatementDetail, Response]:
    """
    Check staleness and wrap StatementDetail in Response with header if stale.

    Only checks staleness for completed statements (SUCCESS status) that have
    a completed_at timestamp and depends_on models. If stale, wraps the response
    in a JSONResponse with Is-Stale header.

    Args:
        statement_detail: The StatementDetail to check and wrap
        ctx: EnvContext containing model freshness information

    Returns:
        StatementDetail if fresh or not applicable,
        JSONResponse with Is-Stale header if stale
    """
    # Only check staleness if status is SUCCESS (has result) and completed_at exists
    # Incomplete statements (QUEUED, IN_PROGRESS, FAILED) cannot be stale
    if statement_detail.status != QueryStatus.SUCCESS or not statement_detail.completed_at:
        return statement_detail

    # Staleness check requires depends_on models
    # If no dependencies, result cannot be stale
    if not statement_detail.depends_on:
        return statement_detail

    # Step 1: Convert completed_at ISO string to Unix milliseconds
    # This is needed for comparison with model freshness timestamps
    try:
        completed_dt = datetime.fromisoformat(statement_detail.completed_at.replace("Z", "+00:00"))
        ts_ms = int(completed_dt.timestamp() * 1000)
    except (ValueError, AttributeError):
        # If timestamp parsing fails, skip staleness check
        return statement_detail

    # Step 2: Check if models changed after result was created
    is_stale = ctx.did_models_change_after(
        ts=ts_ms,
        model_names=statement_detail.depends_on,
    )

    # Step 3: Wrap in Response with header if stale
    if is_stale:
        logger.info(
            "Result marked as stale: request_id=%s..., depends_on=%s",
            statement_detail.id[:16],
            statement_detail.depends_on,
        )
        return JSONResponse(
            content=statement_detail.model_dump(exclude_none=True),
            headers=_get_staleness_headers(is_stale=True),
        )

    return statement_detail


def _build_statement_detail(
    req: QueryRequest,
    result: t.Optional[QueryResult] = None,
    primary_req: t.Optional[QueryRequest] = None,
) -> StatementDetail:
    """
    Convert QueryRequest and optional QueryResult to StatementDetail response model.

    Handles all three execution strategies and populates appropriate metadata:
    - from_cache: Result available immediately, includes cache metadata
    - await_primary: Request deduplicated, includes primary request metadata
    - execute: Uses request's own execution status and timing

    Args:
        req: QueryRequest object containing request details
        result: Optional QueryResult object (if available)
        primary_req: Optional primary QueryRequest (required for await_primary strategy)

    Returns:
        StatementDetail response model with status, metadata, and HATEOAS links

    Raises:
        ValueError: If await_primary strategy is used without primary_req
    """
    current_ts = time.time()
    primary_info: t.Optional[PrimaryReq] = None
    cache_info: t.Optional[CacheInfo] = None

    if req.strategy == "from_cache":
        # Strategy: from_cache
        # Result is immediately available, treat as SUCCESS
        status = QueryStatus.SUCCESS
        has_result = bool(req.result_id)
        cached_at_seconds = req.cached_at_ts / 1000.0
        cache_info = CacheInfo(
            cached_at=timestamp_to_iso(req.cached_at_ts),
            age_seconds=int(current_ts - cached_at_seconds),
        )
    elif req.strategy == "await_primary":
        # Strategy: await_primary
        # Status and result come from primary request
        if not primary_req:
            raise ValueError("primary_req required for await_primary strategy")
        status = primary_req.execution_status
        has_result = status == QueryStatus.SUCCESS
        primary_info = PrimaryReq(
            request_id=primary_req.request_id,
            status=primary_req.execution_status,
            submitted_at=timestamp_to_iso(primary_req.submitted_ts),
            submitted_by=primary_req.submitted_by,
            started_at=(
                timestamp_to_iso(primary_req.execution_start_ts)
                if primary_req.execution_start_ts
                else None
            ),
            elapsed_ms=int((current_ts - (primary_req.submitted_ts / 1000.0)) * 1000),
        )
    else:
        # Strategy: execute
        # Use request's own execution status
        status = req.execution_status
        has_result = status == QueryStatus.SUCCESS

    # Determine completed_at timestamp with priority:
    # 1. result.created_ts (most accurate, when result exists)
    # 2. primary_req.execution_end_ts (for await_primary strategy)
    # 3. req.execution_end_ts (fallback)
    completed_at_ts = None
    if result and result.created_ts:
        completed_at_ts = result.created_ts
    elif req.strategy == "await_primary" and primary_req and primary_req.execution_end_ts:
        completed_at_ts = primary_req.execution_end_ts
    elif req.execution_end_ts:
        completed_at_ts = req.execution_end_ts

    return StatementDetail(
        id=req.request_id,
        status=status,
        fingerprint=req.fingerprint,
        depends_on=req.depends_on,
        sql=req.sql_query,
        params=req.params,
        submitted_at=timestamp_to_iso(req.submitted_ts),
        started_at=(timestamp_to_iso(req.execution_start_ts) if req.execution_start_ts else None),
        completed_at=(timestamp_to_iso(completed_at_ts) if completed_at_ts else None),
        queue_wait_ms=req.queue_wait_time_ms,
        execution_duration_ms=req.execution_duration_ms,
        row_count=result.row_count if result else None,
        size_bytes=result.size_bytes if result else None,
        columns=result.columns if result else None,
        references=(
            {
                col: [[model, field] for model, field in refs]
                for col, refs in result.references.items()
            }
            if result and result.references
            else None
        ),
        error=req.error_message,
        meta=req.meta,
        query_type=req.query_type,
        semantic_query=req.semantic_query,
        rest_query=req.rest_query,
        graphql_query=req.graphql_query,
        primary=primary_info,
        cache=cache_info,
        links=make_statement_links(
            request_id=req.request_id,
            primary_request_id=primary_req.request_id if primary_req else None,
            include_result=has_result,
        ),
    )


def _to_json(
    df: t.Any,
    schema: t.List[t.Dict[str, str]],
    statement_id: str,
    is_stale: t.Optional[bool] = None,
) -> t.Union[StatementResult, Response]:
    """
    Convert DataFrame to JSON format with HATEOAS links.

    Converts pandas DataFrame to JSON-serializable format, handling numpy types,
    NaN, infinity, datetime, and timestamp values. Includes staleness header
    if result is stale.

    Args:
        df: DataFrame to convert (may already be filtered)
        schema: Full result schema (all columns)
        statement_id: Statement ID for self link
        is_stale: Optional flag indicating if result is stale

    Returns:
        StatementResult with data and links if fresh,
        JSONResponse with Is-Stale header if stale
    """
    # Step 1: Filter schema to match selected columns
    selected_cols = [str(c) for c in df.columns.tolist()]
    filtered_schema = [col for col in schema if col["name"] in selected_cols]

    # Step 2: Convert DataFrame rows using _normalize_scalar_for_json
    # This handles numpy types, NaN, infinity, datetime properly
    rows = [
        [_normalize_scalar_for_json(value) for value in row]
        for row in df.itertuples(index=False, name=None)
    ]

    # Step 3: Build StatementResult response
    result = StatementResult(
        cols=selected_cols,
        rows=rows,
        types=filtered_schema,
        row_count=len(df),
        size_bytes=int(df.memory_usage(deep=True).sum()),
        links=StatementResultLinks(
            self=Link(href=urls.query_statement_result(statement_id)),
        ),
    )

    # Step 4: Wrap in Response with header if stale
    if is_stale:
        return JSONResponse(
            content=result.model_dump(exclude_none=True),
            headers=_get_staleness_headers(is_stale=True),
        )

    return result


def _to_yaml(df: t.Any, is_stale: t.Optional[bool] = None) -> Response:
    """
    Convert DataFrame to YAML (list of objects).

    Args:
        df: DataFrame to convert
        is_stale: Optional flag indicating if result is stale

    Returns:
        Response with YAML content and optional staleness header
    """
    data = df.to_dict(orient="records")
    yaml_content = yaml.dump(data, default_flow_style=False, allow_unicode=True)

    return Response(
        content=yaml_content,
        media_type="application/yaml",
        headers=_get_staleness_headers(is_stale=is_stale or False),
    )


def _to_csv(df: t.Any, is_stale: t.Optional[bool] = None) -> Response:
    """
    Convert DataFrame to CSV with headers.

    Args:
        df: DataFrame to convert
        is_stale: Optional flag indicating if result is stale

    Returns:
        Response with CSV content and optional staleness header
    """
    csv_content = df.to_csv(index=False)

    return Response(
        content=csv_content,
        media_type="text/csv",
        headers=_get_staleness_headers(is_stale=is_stale or False),
    )


def _normalize_scalar_for_json(value: t.Any) -> t.Any:
    """Convert DataFrame scalar values into JSON-serializable values."""
    import numpy as np
    import pandas as pd

    if isinstance(value, np.generic):
        value = value.item()

    if value is None:
        return None

    if isinstance(value, (pd.Timestamp, datetime, np.datetime64)):
        if pd.isna(value):
            return None
        return pd.to_datetime(value).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    if isinstance(value, date):
        return value.isoformat()

    if isinstance(value, float) and not math.isfinite(value):
        return None
    is_na = pd.isna(value)
    if isinstance(is_na, (bool, np.bool_)) and is_na:
        return None
    return value


def _elapsed_ms(start: float) -> int:
    return int((time.perf_counter() - start) * 1000)


def _log_result_phase(
    *,
    statement_id: str,
    phase: str,
    elapsed_ms: int,
    result_id: t.Optional[str] = None,
    resolved_format: t.Optional[str] = None,
) -> None:
    logger.debug(
        "statement_result phase=%s statement_id=%s result_id=%s format=%s elapsed_ms=%s",
        phase,
        statement_id,
        result_id,
        resolved_format,
        elapsed_ms,
    )


def _classify_object_store_error(
    *,
    error: Exception,
    action: str,
    result_id: str,
) -> HTTPException:
    message = str(error).lower()
    is_not_found = (
        isinstance(error, FileNotFoundError) or "not found" in message or "no such file" in message
    )
    is_transient = any(
        token in message
        for token in (
            "timeout",
            "timed out",
            "connection",
            "temporarily unavailable",
            "throttle",
            "too many requests",
        )
    )
    if is_not_found:
        return HTTPException(404, f"Result artifact not found for '{result_id}'")
    if is_transient:
        return HTTPException(503, f"Object store unavailable while {action}")
    if isinstance(error, ObjectStoreError):
        return HTTPException(502, f"Object store error while {action}")
    return HTTPException(500, f"Failed to {action}")


@router.get(
    "/statement/{id}",
    summary="Get statement status",
    description=(
        "Returns statement status (ACCEPTED, QUEUED, IN_PROGRESS, SUCCESS, FAILED). "
        "Poll this endpoint until SUCCESS or FAILED."
    ),
    operation_id="get_statement",
    response_model=StatementDetail,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    responses={
        200: {"description": "Statement metadata and current status"},
        404: {"description": "Statement not found"},
    },
)
async def get_statement(
    id: str,
    ctx: EnvContext = Depends(get_env_context),
):
    """
    Get statement execution status and metadata.

    Returns the current execution status (`ACCEPTED`, `QUEUED`, `IN_PROGRESS`, `SUCCESS`, `FAILED`)
    and metadata for a submitted statement. Retrieves statement request from query state.
    Supports multiple execution strategies (`execute`, `from_cache`, `await_primary`). Poll
    until status is `SUCCESS` or `FAILED`. When `SUCCESS`, use `_links.result` to fetch data.
    """
    query_state = ctx.context.state_sync.query_state

    # Offload sync QueryState/EngineAdapter calls to the API I/O thread pool
    # so concurrent handlers, health probes, and the scheduler keep running.
    stmt_req = await run_blocking(query_state.get_request_by_id, id)
    if not stmt_req:
        raise HTTPException(404, f"Statement {id} not found")

    # Step 1: Handle await_primary strategy
    if stmt_req.strategy == "await_primary":
        primary_req = await run_blocking(query_state.get_request_by_id, stmt_req.primary_request_id)
        if not primary_req:
            raise HTTPException(500, "Primary request not found")

        result = None
        if primary_req.execution_status == QueryStatus.SUCCESS and primary_req.result_id:
            result = await run_blocking(query_state.get_result_by_id, primary_req.result_id)

        statement_detail = _build_statement_detail(stmt_req, result=result, primary_req=primary_req)
        return _wrap_statement_detail_with_staleness(statement_detail, ctx)

    # Step 2: Handle from_cache strategy
    if stmt_req.strategy == "from_cache":
        result = (
            await run_blocking(query_state.get_result_by_id, stmt_req.result_id)
            if stmt_req.result_id
            else None
        )
        statement_detail = _build_statement_detail(stmt_req, result)
        return _wrap_statement_detail_with_staleness(statement_detail, ctx)

    # Step 3: Handle execute strategy
    result = None
    if stmt_req.execution_status == QueryStatus.SUCCESS and stmt_req.result_id:
        result = await run_blocking(query_state.get_result_by_id, stmt_req.result_id)

    statement_detail = _build_statement_detail(stmt_req, result)
    return _wrap_statement_detail_with_staleness(statement_detail, ctx)


@router.get(
    "/statement/{id}/result",
    summary="Get statement result",
    description=(
        "Supports parquet (redirect), json, yaml, csv. "
        "Text formats support limit/offset/columns filtering."
    ),
    operation_id="get_statement_result",
    response_model=StatementResult,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
    responses={
        307: {
            "description": "Redirect to presigned Parquet URL (format=parquet)",
            "headers": {"Location": {"schema": {"type": "string"}}},
        },
        200: {
            "description": "Result in requested text format (json/yaml/csv)",
        },
        400: {"description": "Invalid columns requested"},
        404: {"description": "Result not available"},
        406: {"description": "Unsupported format"},
    },
)
async def get_statement_result(
    request: Request,
    id: str,
    format: t.Optional[str] = Query(
        default=None,
        description="Response format: 'parquet' (default), 'json', 'yaml', or 'csv'",
    ),
    limit: t.Optional[int] = Query(
        default=None,
        ge=0,
        description="Max rows to return (text formats only)",
    ),
    offset: t.Optional[int] = Query(
        default=0,
        ge=0,
        description="Skip first N rows (text formats only)",
    ),
    columns: t.Optional[str] = Query(
        default=None,
        description="Comma-separated column names (text formats only)",
    ),
    accept: str = Header(default="application/octet-stream"),
    ctx: EnvContext = Depends(get_env_context),
    object_store: ObjectStoreClient = Depends(get_object_store),
):
    """
    Get query result data in multiple formats.

    Returns query result data in the requested format (parquet, json, yaml, or csv)
    with optional filtering for text formats. Retrieves result from object store.
    Parquet format returns `307` redirect to presigned S3 URL. Text formats (json/yaml/csv)
    support limit, offset, and column filtering. Result must be available (statement
    status `SUCCESS`).
    """
    query_state = ctx.context.state_sync.query_state
    phase_start = time.perf_counter()

    # Step 1: Get request and resolve result_id based on execution strategy
    stmt_req = await run_blocking(query_state.get_request_by_id, id)
    _log_result_phase(
        statement_id=id,
        phase="request_lookup",
        elapsed_ms=_elapsed_ms(phase_start),
    )
    if not stmt_req:
        raise HTTPException(404, f"Statement {id} not found")

    result_id: t.Optional[str] = None

    phase_start = time.perf_counter()
    if stmt_req.strategy == "await_primary":
        primary_req = await run_blocking(query_state.get_request_by_id, stmt_req.primary_request_id)
        if not primary_req:
            raise HTTPException(500, "Primary request not found")

        if primary_req.execution_status != QueryStatus.SUCCESS or not primary_req.result_id:
            raise HTTPException(
                404,
                f"Result not available. Primary status: {primary_req.execution_status}",
            )

        result_id = primary_req.result_id

    elif stmt_req.strategy == "from_cache":
        # Strategy: from_cache
        # Result should be immediately available (set on request creation)
        if not stmt_req.result_id:
            raise HTTPException(500, "Cache result not found")
        result_id = stmt_req.result_id

    else:  # strategy='execute'
        # Strategy: execute
        # Result comes from own execution
        if stmt_req.execution_status != QueryStatus.SUCCESS or not stmt_req.result_id:
            raise HTTPException(
                404,
                f"Result not available. Statement status: {stmt_req.execution_status}",
            )
        result_id = stmt_req.result_id
    _log_result_phase(
        statement_id=id,
        phase="strategy_resolution",
        elapsed_ms=_elapsed_ms(phase_start),
        result_id=result_id,
    )

    # Step 2: Get result metadata from database
    phase_start = time.perf_counter()
    result = await run_blocking(query_state.get_result_by_id, result_id)
    _log_result_phase(
        statement_id=id,
        phase="result_metadata_lookup",
        elapsed_ms=_elapsed_ms(phase_start),
        result_id=result_id,
    )
    if not result:
        raise HTTPException(404, "Result metadata not found")

    # Step 3: Check staleness
    request_id_for_staleness = stmt_req.request_id
    if stmt_req.strategy == "await_primary":
        request_id_for_staleness = stmt_req.primary_request_id

    phase_start = time.perf_counter()
    is_stale, _ = await is_request_stale(
        request_id=request_id_for_staleness,
        query_state=query_state,
        env_context=ctx,
    )
    _log_result_phase(
        statement_id=id,
        phase="staleness_check",
        elapsed_ms=_elapsed_ms(phase_start),
        result_id=result.result_id,
    )

    # Step 4: Determine response format from query param or Accept header
    resolved_format = resolve_format(format, accept)

    # Step 5: Handle Parquet format (redirect to presigned URL, no filtering)
    if resolved_format == "parquet":
        # Parquet format doesn't support filtering (returns full file)
        # Log warning if filtering params were provided
        if limit or offset or columns:
            logger.warning(
                "Filtering params ignored for Parquet format: limit=%s, offset=%s, columns=%s",
                limit,
                offset,
                columns,
                extra={"request_id": id},
            )

        # Generate presigned URL for direct S3 access (blocking boto/S3 call).
        phase_start = time.perf_counter()
        try:
            presigned_url = await run_blocking(
                object_store.generate_presigned_url,
                result_id=result.result_id,
                expiry_mins=60,
            )
            _log_result_phase(
                statement_id=id,
                phase="presigned_url_generation",
                elapsed_ms=_elapsed_ms(phase_start),
                result_id=result.result_id,
                resolved_format=resolved_format,
            )
        except Exception as e:  # pragma: no cover - defensive logging
            http_error = _classify_object_store_error(
                error=e,
                action="generate presigned URL",
                result_id=result.result_id,
            )
            logger.warning(
                "Presigned URL generation failed: statement_id=%s result_id=%s status=%s error=%s",
                id,
                result.result_id,
                http_error.status_code,
                e,
                exc_info=http_error.status_code >= 500,
            )
            raise http_error

        # Return 307 redirect to presigned URL with staleness header if needed
        return RedirectResponse(
            url=presigned_url,
            status_code=307,
            headers=_get_staleness_headers(is_stale=is_stale),
        )

    # Step 6: Handle text formats (JSON/YAML/CSV) with filtering support.
    # ``get_result`` downloads and parses a Parquet file, and ``apply_filtering``
    # runs pandas ops — both are CPU/I/O-bound and must stay off the loop.
    phase_start = time.perf_counter()
    try:
        df = await run_blocking(object_store.get_result, result_id)
        _log_result_phase(
            statement_id=id,
            phase="result_fetch",
            elapsed_ms=_elapsed_ms(phase_start),
            result_id=result.result_id,
            resolved_format=resolved_format,
        )
    except Exception as e:  # pragma: no cover - defensive logging
        http_error = _classify_object_store_error(
            error=e,
            action="read result from object store",
            result_id=result.result_id,
        )
        logger.warning(
            "Result fetch failed: statement_id=%s result_id=%s status=%s error=%s",
            id,
            result.result_id,
            http_error.status_code,
            e,
            exc_info=http_error.status_code >= 500,
        )
        raise http_error

    phase_start = time.perf_counter()
    filtered_df = await run_blocking(apply_filtering, df, limit, offset, columns, result.columns)
    _log_result_phase(
        statement_id=id,
        phase="filtering",
        elapsed_ms=_elapsed_ms(phase_start),
        result_id=result.result_id,
        resolved_format=resolved_format,
    )

    # Log filtering details if applied (for debugging and monitoring)
    if limit or offset or columns:
        logger.debug(
            "Applied filters to %s result: limit=%s, offset=%s, columns=%s, "
            "original_rows=%s, filtered_rows=%s",
            resolved_format,
            limit,
            offset,
            columns,
            len(df),
            len(filtered_df),
            extra={"request_id": id},
        )

    # Step 7: Serialize to requested format.  These all iterate over or
    # materialize the full DataFrame — keep them off the event loop.
    phase_start = time.perf_counter()
    if resolved_format == "json":
        response = await run_blocking(
            _to_json, filtered_df, result.columns, statement_id=id, is_stale=is_stale
        )
        _log_result_phase(
            statement_id=id,
            phase="serialize_json",
            elapsed_ms=_elapsed_ms(phase_start),
            result_id=result.result_id,
            resolved_format=resolved_format,
        )
        return response
    if resolved_format == "yaml":
        response = await run_blocking(_to_yaml, filtered_df, is_stale=is_stale)
        _log_result_phase(
            statement_id=id,
            phase="serialize_yaml",
            elapsed_ms=_elapsed_ms(phase_start),
            result_id=result.result_id,
            resolved_format=resolved_format,
        )
        return response
    if resolved_format == "csv":
        response = await run_blocking(_to_csv, filtered_df, is_stale=is_stale)
        _log_result_phase(
            statement_id=id,
            phase="serialize_csv",
            elapsed_ms=_elapsed_ms(phase_start),
            result_id=result.result_id,
            resolved_format=resolved_format,
        )
        return response

    # Should never reach here due to resolve_format validation
    # But include as defensive programming
    raise HTTPException(500, f"Unexpected format: {resolved_format}")
