from __future__ import annotations

from enum import Enum


class QueryType(str, Enum):
    RAW_SQL = "RAW_SQL"
    SEMANTIC_SQL = "SEMANTIC_SQL"
    SEMANTIC_REST = "SEMANTIC_REST"
    SEMANTIC_GRAPHQL = "SEMANTIC_GRAPHQL"
    SEMANTIC_METRIC = "SEMANTIC_METRIC"
