from __future__ import annotations

import typing as t
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import Field as PydanticField
from vulcan.utils.pydantic import PydanticModel

from api.definitions import Link, Pagination  # Import Pagination at runtime for Pydantic validation
from vulcan.core.query.definitions import QueryStatusEnum, QueryStrategy
from vulcan.core.types import Tag, Term  # Import at runtime for Pydantic validation
from schema.rest_query import RestQuery
from api.endpoints.query.types import QueryType

if TYPE_CHECKING:
    from vulcan.core.query.definitions import Perspective, QueryRequest


# Execution metadata (internal dataclasses)
@dataclass
class PrimaryMetadata:
    request_id: str
    status: QueryStatusEnum  # QueryStatus value
    submitted_at: float  # Unix timestamp in seconds
    submitted_by: t.Optional[str]
    started_at: t.Optional[float]  # Unix timestamp in seconds (None if not started yet)


@dataclass
class CacheMetadata:
    cached_at: float  # Unix timestamp
    age_seconds: int


@dataclass
class QueryExecutionResult:
    strategy: QueryStrategy
    request_id: str  # New request ID (always created now)
    fingerprint: str
    normalized_sql: str
    depends_on: t.List[str]
    job_id: t.Optional[int] = None  # Job ID (only set for strategy='execute')

    # Optional metadata based on strategy
    primary_metadata: t.Optional[PrimaryMetadata] = None
    cache_metadata: t.Optional[CacheMetadata] = None


# Statement response models
class PrimaryReq(PydanticModel):
    request_id: str
    status: QueryStatusEnum
    submitted_at: str
    submitted_by: t.Optional[str] = None
    started_at: t.Optional[str] = None
    elapsed_ms: int


class CacheInfo(PydanticModel):
    cached_at: str
    age_seconds: int


class StatementLinks(PydanticModel):
    self: Link
    primary: t.Optional[Link] = None
    result: t.Optional[Link] = None


class StatementAccepted(PydanticModel):
    id: str
    status: QueryStatusEnum
    strategy: QueryStrategy = PydanticField(description="Execution strategy (from_cache, await_primary, execute)")
    fingerprint: str = PydanticField(description="SHA-256 hash of normalized SQL + params")
    sql: str
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = PydanticField(
        default=None,
        description="Query parameters (dict for named params or list for positional params)",
    )
    depends_on: t.Optional[t.List[str]] = None
    submitted_at: str
    meta: t.Optional[t.Dict[str, t.Any]] = None
    cols_mapping: t.Optional[t.Dict[str, str]] = PydanticField(
        default=None,
        description=(
            "Optional map of result column names to semantic roles (e.g. measure vs time dimension)."
        ),
    )
    query_type: t.Optional[QueryType] = None
    job_id: t.Optional[int] = None

    primary: t.Optional[PrimaryReq] = None
    cache: t.Optional[CacheInfo] = None

    links: StatementLinks = PydanticField(
        alias="_links",
        serialization_alias="_links",
        description="HATEOAS links",
    )

    model_config = {"populate_by_name": True}


class StatementDetail(PydanticModel):
    id: str
    status: QueryStatusEnum
    fingerprint: t.Optional[str] = PydanticField(default=None, description="SHA-256 hash of normalized SQL + params")
    sql: t.Optional[str] = None
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = PydanticField(
        default=None,
        description="Query parameters (dict for named params or list for positional params)",
    )
    depends_on: t.Optional[t.List[str]] = None
    submitted_at: str
    started_at: t.Optional[str] = None
    completed_at: t.Optional[str] = None
    queue_wait_ms: t.Optional[int] = None
    execution_duration_ms: t.Optional[int] = None
    row_count: t.Optional[int] = None
    size_bytes: t.Optional[int] = None
    columns: t.Optional[t.List[t.Dict[str, str]]] = None
    references: t.Optional[t.Dict[str, t.List[t.List[str]]]] = PydanticField(
        default=None,
        description="Field lineage mapping {column_name: [[model_name, field_name], ...]}"
    )
    error: t.Optional[str] = None
    meta: t.Optional[t.Dict[str, t.Any]] = None
    query_type: t.Optional[QueryType] = None
    semantic_query: t.Optional[str] = None
    rest_query: t.Optional[t.Dict[str, t.Any]] = None
    graphql_query: t.Optional[str] = None

    primary: t.Optional[PrimaryReq] = None
    cache: t.Optional[CacheInfo] = None

    links: StatementLinks = PydanticField(
        alias="_links",
        serialization_alias="_links",
        description="HATEOAS links",
    )

    model_config = {"populate_by_name": True}


class StatementResultLinks(PydanticModel):
    self: Link


class StatementResult(PydanticModel):
    cols: t.List[str]
    rows: t.List[t.List[t.Any]]
    types: t.List[t.Dict[str, str]]
    row_count: int
    size_bytes: int
    links: StatementResultLinks = PydanticField(
        alias="_links",
        serialization_alias="_links",
        description="HATEOAS links",
    )
    
    model_config = {"populate_by_name": True, "exclude_none": True}


# Perspective request/response models
class PerspectiveCreateRequest(PydanticModel):
    name: str = PydanticField(...)
    description: t.Optional[str] = None
    tags: t.List[Tag] = PydanticField(default_factory=list)
    terms: t.List[Term] = PydanticField(default_factory=list)
    statement_id: str = PydanticField(..., description="Statement ID to save from (must be SUCCESS)")
    slug: t.Optional[str] = None
    auto_refresh: bool = True
    is_public: bool = False
    allowed_user_ids: t.List[str] = PydanticField(default_factory=list)

    model_config = {"extra": "ignore"}


class PerspectiveUpdateRequest(PydanticModel):
    name: t.Optional[str] = None
    description: t.Optional[str] = None
    tags: t.Optional[t.List[Tag]] = None
    terms: t.Optional[t.List[Term]] = None
    statement_id: t.Optional[str] = PydanticField(default=None, description="Statement ID to update from (must be SUCCESS)")
    auto_refresh: t.Optional[bool] = None
    is_public: t.Optional[bool] = None
    allowed_user_ids: t.Optional[t.List[str]] = None

    model_config = {"extra": "ignore"}


class PerspectiveLinks(PydanticModel):
    self: Link
    statement_detail: t.Optional[Link] = None
    result: t.Optional[Link] = None
    refresh_statement: t.Optional[Link] = None


class QueryInfo(PydanticModel):
    sql_query: str
    normalized_sql: t.Optional[str] = None
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None
    depends_on: t.Optional[t.List[str]] = None
    gateway: t.Optional[str] = None
    query_type: t.Optional[QueryType] = None
    semantic_query: t.Optional[str] = None
    rest_query: t.Optional[t.Dict[str, t.Any]] = None
    graphql_query: t.Optional[str] = None
    meta: t.Optional[t.Dict[str, t.Any]] = None
#     ttl: int = PydanticField(
#         default=0,
#         description="Cache TTL hint in minutes (0=never expires, or 5-43200)",
#     )
    
    model_config = {"populate_by_name": True}
    
    @classmethod
    def from_request(cls, request: t.Union["QueryRequest", t.Any]) -> "QueryInfo":
        return cls(
            sql_query=request.sql_query,
            normalized_sql=request.normalized_sql,
            params=request.params,
            depends_on=request.depends_on,
            gateway=request.gateway,
            query_type=request.query_type,
            semantic_query=request.semantic_query,
            rest_query=request.rest_query,
            graphql_query=request.graphql_query,
            meta=request.meta,
#             ttl=request.ttl,
        )


class PerspectiveDetailView(PydanticModel):
    id: str
    slug: str
    name: str
    description: t.Optional[str] = None
    tags: t.List[str] = PydanticField(default_factory=list)
    terms: t.List[str] = PydanticField(default_factory=list)
    owner: str
    request_id: t.Optional[str] = None
    auto_refresh: bool = True
    is_public: bool = False
    allowed_user_ids: t.List[str] = PydanticField(default_factory=list)
    created_at: str
    updated_at: str
    created_by: t.Optional[str] = None
    updated_by: t.Optional[str] = None
    # Query fields directly (denormalized from perspective)
    sql_query: str
    normalized_sql: t.Optional[str] = None
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None
    depends_on: t.Optional[t.List[str]] = None
    gateway: t.Optional[str] = None
    query_type: t.Optional[QueryType] = None
    semantic_query: t.Optional[str] = None
    rest_query: t.Optional[t.Dict[str, t.Any]] = None
    graphql_query: t.Optional[str] = None
    meta: t.Optional[t.Dict[str, t.Any]] = None
#     ttl: int = 0
    links: PerspectiveLinks = PydanticField(alias="_links", serialization_alias="_links", description="HATEOAS links")

    model_config = {"populate_by_name": True}


class PerspectiveListView(PydanticModel):
    id: str = PydanticField(alias="perspective_id")
    slug: str
    name: str
    description: t.Optional[str] = None
    tags: t.List[Tag] = PydanticField(default_factory=list)
    terms: t.List[Term] = PydanticField(default_factory=list)
    owner: str
    request_id: t.Optional[str] = None
    auto_refresh: bool = True
    is_public: bool
    allowed_user_ids: t.List[str] = PydanticField(default_factory=list)
    created_at: str
    updated_at: str
    created_by: t.Optional[str] = None
    updated_by: t.Optional[str] = None
    links: PerspectiveLinks = PydanticField(alias="_links", serialization_alias="_links", description="HATEOAS links")

    model_config = {"populate_by_name": True}
    
    @classmethod
    def from_perspective(cls, perspective: "Perspective", links: PerspectiveLinks) -> "PerspectiveListView":
        # Import here to avoid circular import (models.py -> __init__.py)
        from api.endpoints.query import timestamp_to_iso
        
        return cls(
            perspective_id=perspective.perspective_id,
            slug=perspective.slug,
            name=perspective.name,
            description=perspective.description,
            tags=perspective.tags,
            terms=perspective.terms,
            owner=perspective.owner,
            request_id=perspective.request_id,
            auto_refresh=perspective.auto_refresh,
            is_public=perspective.is_public,
            allowed_user_ids=perspective.allowed_user_ids,
            created_at=timestamp_to_iso(perspective.created_at),
            updated_at=timestamp_to_iso(perspective.updated_at),
            created_by=perspective.created_by,
            updated_by=perspective.updated_by,
            links=links,
        )


class PerspectivesListResponse(PydanticModel):
    items: t.List[PerspectiveListView]
    pagination: Pagination
    
    model_config = {"populate_by_name": True}


# Query request models
class StatementRequest(PydanticModel):
    sql: str = PydanticField(...)
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]] = None
#     ttl: int = PydanticField(
#         default=0,
#         ge=0,
#         le=43200,
#         description=(
#             "Cache TTL hint in minutes (0=never expires, or 5-43200). "
#             "Honored only by streaming gateways like DataOS Hapi."
#         ),
#     )
    meta: t.Optional[t.Dict[str, t.Any]] = None
    model_config = {"extra": "ignore"}
# 
#     @field_validator("ttl")
#     @classmethod
#     def validate_ttl(cls, v: int) -> int:
#         if v == 0 or 5 <= v <= 43200:
#             return v
#         raise ValueError("ttl must be 0 (never expires) or between 5 and 43200 minutes")


class RestQueryRequest(PydanticModel):
    query: RestQuery = PydanticField(...)
    graphql_body: t.Optional[str] = None
    meta: t.Optional[t.Dict[str, t.Any]] = None
#     ttl: int = PydanticField(
#         default=0,
#         ge=0,
#         le=43200,
#         description="Cache TTL in minutes (0=never expires, or 5-43200)",
#     )

    model_config = {"extra": "ignore"}
# 
#     @field_validator("ttl")
#     @classmethod
#     def validate_ttl(cls, v: int) -> int:
#         if v == 0 or 5 <= v <= 43200:
#             return v
#         raise ValueError("ttl must be 0 (never expires) or between 5 and 43200 minutes")


class SqlQueryRequest(PydanticModel):
    sql: str = PydanticField(..., min_length=1)
    meta: t.Optional[t.Dict[str, t.Any]] = None
#     ttl: int = PydanticField(
#         default=0,
#         ge=0,
#         le=43200,
#         description="Cache TTL in minutes (0=never expires, or 5-43200)",
#     )

    model_config = {"extra": "ignore"}
# 
#     @field_validator("ttl")
#     @classmethod
#     def validate_ttl(cls, v: int) -> int:
#         if v == 0 or 5 <= v <= 43200:
#             return v
#         raise ValueError("ttl must be 0 (never expires) or between 5 and 43200 minutes")
