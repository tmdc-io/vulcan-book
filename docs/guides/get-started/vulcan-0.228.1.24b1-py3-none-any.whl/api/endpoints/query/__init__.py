from __future__ import annotations

import asyncio
import logging
import time
import typing as t
from dataclasses import dataclass
from datetime import datetime

import pandas as pd
import pydantic
import yaml

from fastapi import HTTPException, Response, APIRouter
from pydantic import Field as PydanticField

from vulcan.utils import random_id
from vulcan.utils.pydantic import PydanticModel
from vulcan.core.query import ObjectStoreClient
from api.utils.query_validator import QueryValidator, ValidatedQuery
from vulcan.utils.errors import QueryValidationError
from vulcan.core import constants as c
from vulcan.core.query.definitions import (
    QueryStrategy,
    QueryRequest,
    QueryResult,
    QueryStatus,
    QueryStatusEnum,
    QueryFingerprintResult,
    Perspective,
)
from vulcan.core.state_sync.db.query import QueryState
from pgqueuer import QueueManager

from schema.rest_query import RestQuery

from api.definitions import Link
from api.utils.async_blocking import run_blocking
from api.utils.urls import urls
from api.worker.executor import QueryJobPayload
from api.exceptions import QueryExecutionError
from api.context import EnvContext
from vulcan.core import analytics

logger = logging.getLogger(__name__)


async def _fire_hera_perspective_sync(
    qm: QueueManager,
    perspective_id: str,
    environment: str,
) -> None:
    """Fire-and-forget Hera enqueue for a single perspective. Errors are logged, never raised."""
    try:
        from api.worker.hera_jobs import enqueue_hera_perspective_sync

        await enqueue_hera_perspective_sync(qm, environment, perspective_id)
    except Exception as exc:
        logger.warning("Hera perspective sync failed (id=%s): %s", perspective_id[:16], exc)


# Type alias for supported result formats
ResultFormat = t.Literal["parquet", "json", "yaml", "csv"]


def timestamp_to_iso(ts: int) -> str:
    """Convert Unix timestamp (milliseconds) to ISO 8601 string."""
    return datetime.fromtimestamp(ts / 1000).isoformat()


def make_statement_links(
    *,
    request_id: str,
    primary_request_id: t.Optional[str] = None,
    include_result: bool = False,
) -> "StatementLinks":
    from api.endpoints.query.models import StatementLinks

    return StatementLinks(
        self=Link(href=urls.query_statement_detail(request_id)),
        primary=(
            Link(href=urls.query_statement_detail(primary_request_id))
            if primary_request_id
            else None
        ),
        result=(Link(href=urls.query_statement_result(request_id)) if include_result else None),
    )


def build_statement_accepted(
    req: "QueryRequest", exec_result: "QueryExecutionResult"
) -> "StatementAccepted":
    from api.endpoints.query.models import (
        QueryExecutionResult,
        StatementAccepted,
        PrimaryReq,
        CacheInfo,
    )
    from vulcan.core.query.definitions import QueryStatus, QueryRequest

    current_ts = time.time()
    primary_req: t.Optional[PrimaryReq] = None
    cache_info: t.Optional[CacheInfo] = None
    primary_request_id: t.Optional[str] = None
    include_result = False

    if exec_result.strategy == "from_cache":
        status = QueryStatus.SUCCESS
        include_result = True
        if exec_result.cache_metadata:
            cache_info = CacheInfo(
                cached_at=timestamp_to_iso(int(exec_result.cache_metadata.cached_at * 1000)),
                age_seconds=exec_result.cache_metadata.age_seconds,
            )
    elif exec_result.strategy == "await_primary":
        primary_meta = exec_result.primary_metadata
        status = primary_meta.status if primary_meta else QueryStatus.QUEUED
        if primary_meta:
            primary_req = PrimaryReq(
                request_id=primary_meta.request_id,
                status=primary_meta.status,
                submitted_at=timestamp_to_iso(int(primary_meta.submitted_at * 1000)),
                submitted_by=primary_meta.submitted_by,
                started_at=(
                    timestamp_to_iso(int(primary_meta.started_at * 1000))
                    if primary_meta.started_at
                    else None
                ),
                elapsed_ms=int((current_ts - primary_meta.submitted_at) * 1000),
            )
            primary_request_id = primary_meta.request_id
    else:
        status = QueryStatus.QUEUED

    return StatementAccepted(
        id=req.request_id,
        status=status,
        strategy=exec_result.strategy,
        fingerprint=exec_result.fingerprint,
        sql=req.sql_query,
        params=req.params,
        depends_on=req.depends_on,
        submitted_at=timestamp_to_iso(req.submitted_ts),
        meta=req.meta,
        query_type=req.query_type,
        job_id=exec_result.job_id,
        primary=primary_req,
        cache=cache_info,
        links=make_statement_links(
            request_id=req.request_id,
            primary_request_id=primary_request_id,
            include_result=include_result,
        ),
    )


async def is_request_stale(
    request_id: str,
    query_state: "QueryState",
    env_context: "EnvContext",
) -> t.Tuple[bool, t.Optional["QueryRequest"]]:
    """Check if a request is stale based on model freshness."""
    query_request = await run_blocking(query_state.get_request_by_id, request_id)
    if not query_request:
        return False, None

    depends_on = query_request.depends_on or []
    completed_ts = query_request.execution_end_ts or query_request.submitted_ts

    is_stale = env_context.did_models_change_after(
        ts=completed_ts,
        model_names=depends_on,
    )

    return is_stale, query_request


async def submit_perspective_refresh_by_id(
    perspective_id: str,
    env_context: EnvContext,
    query_state: QueryState,
    qm: QueueManager,
) -> "StatementAccepted":
    """Submit a perspective refresh by ID (fetches perspective internally)."""
    perspective = await run_blocking(query_state.get_perspective_by_id, perspective_id)
    if not perspective:
        raise QueryExecutionError(
            status_code=404,
            detail=f"Perspective '{perspective_id}' not found",
        )
    return await submit_perspective_refresh(
        perspective=perspective,
        env_context=env_context,
        query_state=query_state,
        qm=qm,
    )


async def submit_perspective_refresh(
    perspective: Perspective,
    env_context: EnvContext,
    query_state: QueryState,
    qm: QueueManager,
) -> "StatementAccepted":
    """Submit a perspective refresh using denormalized query fields."""
    logger.info(f"Refreshing perspective: '{perspective.slug}'")

    if not perspective.sql_query:
        raise QueryExecutionError(
            status_code=400,
            detail="Perspective has no query definition",
        )

    try:
        rest_query = RestQuery.from_storage(perspective.rest_query)
    except pydantic.ValidationError as e:
        raise QueryExecutionError(
            status_code=400,
            detail=f"Perspective '{perspective.slug}' has invalid stored rest_query: {e}",
        ) from e

    accepted = await submit_sql_via_flow(
        sql=perspective.sql_query,
        params=perspective.params,
        ttl=perspective.ttl,
        meta=perspective.meta,
        gateway=perspective.gateway or "default",
        qv=env_context.query_validator,
        qm=qm,
        query_state=query_state,
        env_context=env_context,
        retry_on_recent_failure=False,
        query_type=perspective.query_type,
        semantic_query=perspective.semantic_query,
        rest_query=rest_query,
        graphql_query=perspective.graphql_query,
        perspective_id=perspective.perspective_id,
    )

    if accepted.strategy == "from_cache" and perspective.perspective_id:
        try:
            await run_blocking(
                query_state._update_request_id_for_perspective,
                perspective_id=perspective.perspective_id,
                request_id=accepted.id,
            )
            if env_context.environment == c.PROD:
                asyncio.create_task(
                    _fire_hera_perspective_sync(
                        qm,
                        perspective.perspective_id,
                        env_context.environment,
                    )
                )
        except Exception as e:
            logger.warning(f"Failed to update perspective request_id: {e}", exc_info=True)

    return accepted


async def _execute_or_reuse_query(
    sql: str,
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]],
    gateway: str,
    ttl: int,
    meta: t.Optional[t.Dict],
    qv: QueryValidator,
    query_state: QueryState,
    qm: QueueManager,
    env_context: EnvContext,
    submitted_by: t.Optional[str] = None,
    retry_on_recent_failure: bool = False,
    query_type: t.Optional[str] = None,
    semantic_query: t.Optional[str] = None,
    rest_query: t.Optional[t.Dict[str, t.Any]] = None,
    graphql_query: t.Optional[str] = None,
    perspective_id: t.Optional[str] = None,
) -> QueryExecutionResult:
    """Core query execution with caching, deduplication, and execution strategies."""
    try:
        validation = qv.validate_query(sql, params, query_type=query_type)
    except QueryValidationError as e:
        raise QueryExecutionError(
            status_code=400, detail={"error": e.error_type, "message": e.message}
        )

    fingerprint = validation.fingerprint
    normalized_sql = validation.normalized_sql
    depends_on = validation.depends_on

    fingerprint_result = await run_blocking(query_state.get_fingerprint_result, fingerprint)
    if fingerprint_result:
        depends_on = fingerprint_result.depends_on or []
        result_ts = fingerprint_result.result_created_ts
        is_stale = env_context.did_models_change_after(
            ts=result_ts,
            model_names=depends_on,
        )
        if not is_stale:
            try:
                analytics.collector.on_cache_event(api="query", hit=True)
            except Exception as e:
                logger.debug("on_cache_event failed: %s", e)
            return await _handle_cache_hit(
                fingerprint_result=fingerprint_result,
                fingerprint=fingerprint,
                sql=sql,
                normalized_sql=normalized_sql,
                params=params,
                gateway=gateway,
                submitted_by=submitted_by,
                depends_on=depends_on,
                ttl=ttl,
                meta=meta,
                query_type=query_type,
                semantic_query=semantic_query,
                rest_query=rest_query,
                graphql_query=graphql_query,
                perspective_id=perspective_id,
                query_state=query_state,
            )
        logger.info("Fingerprint found but stale: fingerprint=%s...", fingerprint[:16])

    in_flight = await run_blocking(query_state.get_in_flight_request_by_fingerprint, fingerprint)
    if in_flight:
        return await _handle_in_flight(
            in_flight=in_flight,
            fingerprint=fingerprint,
            sql=sql,
            normalized_sql=normalized_sql,
            params=params,
            gateway=gateway,
            submitted_by=submitted_by,
            depends_on=depends_on,
            ttl=ttl,
            meta=meta,
            query_type=query_type,
            semantic_query=semantic_query,
            rest_query=rest_query,
            graphql_query=graphql_query,
            perspective_id=perspective_id,
            query_state=query_state,
        )

    await _check_recent_failures(
        fingerprint=fingerprint,
        retry_on_recent_failure=retry_on_recent_failure,
        query_state=query_state,
    )

    try:
        analytics.collector.on_cache_event(api="query", hit=False)
    except Exception as e:
        logger.debug("on_cache_event failed: %s", e)
    return await _handle_new_execution(
        fingerprint=fingerprint,
        sql=sql,
        normalized_sql=normalized_sql,
        params=params,
        gateway=gateway,
        submitted_by=submitted_by,
        depends_on=depends_on,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query,
        graphql_query=graphql_query,
        perspective_id=perspective_id,
        query_state=query_state,
        qm=qm,
        env_context=env_context,
    )


async def submit_sql_via_flow(
    *,
    sql: str,
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]],
    ttl: int = 0,
    meta: t.Optional[t.Dict[str, t.Any]],
    gateway: str,
    qv: QueryValidator,
    qm: QueueManager,
    query_state: QueryState,
    env_context: EnvContext,
    retry_on_recent_failure: bool = False,
    query_type: t.Optional[str] = None,
    semantic_query: t.Optional[str] = None,
    rest_query: t.Optional[RestQuery] = None,
    graphql_query: t.Optional[str] = None,
    perspective_id: t.Optional[str] = None,
    submitted_by: t.Optional[str] = None,
) -> StatementAccepted:
    """Submit SQL query through execution flow and return StatementAccepted response."""
    rest_query_wire: t.Optional[t.Dict[str, t.Any]] = (
        rest_query.model_dump(exclude_none=True, by_alias=True)
        if rest_query is not None
        else None
    )
    exec_result = await _execute_or_reuse_query(
        sql=sql,
        params=params,
        gateway=gateway,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query_wire,
        graphql_query=graphql_query,
        perspective_id=perspective_id,
        qv=qv,
        query_state=query_state,
        qm=qm,
        env_context=env_context,
        submitted_by=submitted_by,
        retry_on_recent_failure=retry_on_recent_failure,
    )

    req = await run_blocking(query_state.get_request_by_id, exec_result.request_id)
    if not req:
        raise HTTPException(500, "Failed to create statement")

    return build_statement_accepted(req, exec_result)


def resolve_format(format_param: t.Optional[str], accept_header: str) -> ResultFormat:
    """Determine response format from query param or Accept header."""
    if format_param:
        valid_formats: t.List[ResultFormat] = ["parquet", "json", "yaml", "csv"]
        normalized = format_param.lower()
        if normalized not in valid_formats:
            raise HTTPException(
                406,
                f"Format '{format_param}' not supported. Use: {', '.join(valid_formats)}",
            )
        return normalized  # type: ignore[return-value]

    if "application/json" in accept_header:
        return "json"
    if "application/yaml" in accept_header or "text/yaml" in accept_header:
        return "yaml"
    if "text/csv" in accept_header:
        return "csv"
    return "parquet"


def apply_filtering(
    df: pd.DataFrame,
    limit: t.Optional[int],
    offset: int,
    columns: t.Optional[str],
    schema: t.List[t.Dict[str, str]],
) -> pd.DataFrame:
    """Apply limit, offset, and column filtering to DataFrame."""
    if columns:
        requested_cols = [c.strip() for c in columns.split(",") if c.strip()]
        available_cols = [col["name"] for col in schema]
        invalid_cols = [c for c in requested_cols if c not in available_cols]

        if invalid_cols:
            raise HTTPException(
                400,
                f"Invalid columns requested: {invalid_cols}. Available: {available_cols}",
            )

        df = df[requested_cols]

    start = offset if offset is not None else 0
    end = None if limit is None else (start + limit)

    return df.iloc[start:end]


async def _handle_cache_hit(
    fingerprint_result: QueryFingerprintResult,
    fingerprint: str,
    sql: str,
    normalized_sql: str,
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]],
    gateway: str,
    submitted_by: t.Optional[str],
    depends_on: t.Optional[t.List[str]],
    ttl: int,
    meta: t.Optional[t.Dict],
    query_type: t.Optional[str],
    semantic_query: t.Optional[str],
    rest_query: t.Optional[t.Dict[str, t.Any]],
    graphql_query: t.Optional[str],
    perspective_id: t.Optional[str],
    query_state: QueryState,
) -> QueryExecutionResult:
    """Handle cache hit: create request with strategy='from_cache' and link to cached result."""
    request_id = random_id()
    current_ts = time.time()

    await run_blocking(
        query_state.create_request,
        request_id=request_id,
        strategy="from_cache",
        fingerprint=fingerprint,
        sql_query=sql,
        normalized_sql=normalized_sql,
        params=params,
        gateway=gateway,
        submitted_by=submitted_by,
        depends_on=depends_on,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query,
        graphql_query=graphql_query,
        perspective_id=perspective_id,
        cached_at_ts=fingerprint_result.cached_at_ts,
        result_id=fingerprint_result.result_id,
    )

    logger.info(
        "Fingerprint hit: fingerprint=%s..., request_id=%s...",
        fingerprint[:16],
        request_id[:16],
    )

    from api.endpoints.query.models import CacheMetadata

    return QueryExecutionResult(
        strategy="from_cache",
        request_id=request_id,
        fingerprint=fingerprint,
        normalized_sql=normalized_sql,
        depends_on=depends_on,
        job_id=None,
        cache_metadata=CacheMetadata(
            cached_at=fingerprint_result.cached_at_ts / 1000.0,
            age_seconds=int(current_ts - (fingerprint_result.cached_at_ts / 1000.0)),
        ),
    )


async def _handle_in_flight(
    in_flight: QueryRequest,
    fingerprint: str,
    sql: str,
    normalized_sql: str,
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]],
    gateway: str,
    submitted_by: t.Optional[str],
    depends_on: t.Optional[t.List[str]],
    ttl: int,
    meta: t.Optional[t.Dict],
    query_type: t.Optional[str],
    semantic_query: t.Optional[str],
    rest_query: t.Optional[t.Dict[str, t.Any]],
    graphql_query: t.Optional[str],
    perspective_id: t.Optional[str],
    query_state: QueryState,
) -> QueryExecutionResult:
    """Handle deduplication: create request with strategy='await_primary' linking to primary."""
    request_id = random_id()
    await run_blocking(
        query_state.create_request,
        request_id=request_id,
        strategy="await_primary",
        fingerprint=fingerprint,
        sql_query=sql,
        normalized_sql=normalized_sql,
        params=params,
        gateway=gateway,
        submitted_by=submitted_by,
        depends_on=depends_on,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query,
        graphql_query=graphql_query,
        perspective_id=perspective_id,
        primary_request_id=in_flight.request_id,
    )

    logger.info(
        "Request deduplicated: fingerprint=%s..., request_id=%s..., primary=%s...",
        fingerprint[:16],
        request_id[:16],
        in_flight.request_id[:16],
    )

    from api.endpoints.query.models import PrimaryMetadata

    return QueryExecutionResult(
        strategy="await_primary",
        request_id=request_id,
        fingerprint=fingerprint,
        normalized_sql=normalized_sql,
        depends_on=depends_on,
        job_id=None,
        primary_metadata=PrimaryMetadata(
            request_id=in_flight.request_id,
            status=in_flight.execution_status,
            submitted_at=in_flight.submitted_ts / 1000.0,
            submitted_by=in_flight.submitted_by,
            started_at=(
                in_flight.execution_start_ts / 1000.0 if in_flight.execution_start_ts else None
            ),
        ),
    )


async def _check_recent_failures(
    fingerprint: str,
    retry_on_recent_failure: bool,
    query_state: QueryState,
) -> None:
    """Check for recent failures and prevent retry if found (within last 5 minutes)."""
    if retry_on_recent_failure:
        return

    recent_failed = await run_blocking(
        query_state.get_recent_failed_execution_by_fingerprint,
        fingerprint,
        window_seconds=300,
    )
    if not recent_failed:
        return

    current_ts = time.time()
    last_failed_at_ms = recent_failed.execution_end_ts
    age_seconds = (
        int(current_ts - (last_failed_at_ms / 1000.0)) if last_failed_at_ms is not None else None
    )

    logger.info(
        "Recent failed execution for fingerprint=%s..., last_request_id=%s...",
        fingerprint[:16],
        recent_failed.request_id[:16],
    )
    raise QueryExecutionError(
        status_code=400,
        detail={
            "error": "RECENT_FAILURE",
            "message": (
                "An identical query failed recently. Fix the error before retrying "
                "or set retry_on_recent_failure=true to override."
            ),
            "last_failed_at": last_failed_at_ms,
            "age_seconds": age_seconds,
            "submitted_by": recent_failed.submitted_by,
            "last_error": (recent_failed.error_message or "")[:512],
        },
    )


async def _handle_new_execution(
    fingerprint: str,
    sql: str,
    normalized_sql: str,
    params: t.Optional[t.Union[t.Dict[str, t.Any], t.List[t.Any]]],
    gateway: str,
    submitted_by: t.Optional[str],
    depends_on: t.Optional[t.List[str]],
    ttl: int,
    meta: t.Optional[t.Dict],
    query_type: t.Optional[str],
    semantic_query: t.Optional[str],
    rest_query: t.Optional[t.Dict[str, t.Any]],
    graphql_query: t.Optional[str],
    perspective_id: t.Optional[str],
    query_state: QueryState,
    qm: QueueManager,
    env_context: EnvContext,
) -> QueryExecutionResult:
    """Handle new execution: create request and enqueue for background processing."""
    request_id = random_id()

    await run_blocking(
        query_state.create_request,
        request_id=request_id,
        strategy="execute",
        fingerprint=fingerprint,
        sql_query=sql,
        normalized_sql=normalized_sql,
        params=params,
        gateway=gateway,
        submitted_by=submitted_by,
        depends_on=depends_on,
        ttl=ttl,
        meta=meta,
        query_type=query_type,
        semantic_query=semantic_query,
        rest_query=rest_query,
        graphql_query=graphql_query,
        perspective_id=perspective_id,
        execution_status=QueryStatus.ACCEPTED,
    )

    payload = QueryJobPayload(
        request_id=request_id,
        fingerprint=fingerprint,
        gateway=gateway,
        sql=sql,
        params=params,
        ttl_minutes=ttl,
        depends_on=depends_on,
        environment=env_context.environment,
        perspective_id=perspective_id,
    )

    try:
        job_ids = await qm.queries.enqueue(
            ["query_execution"],
            [payload.model_dump_json().encode("utf-8")],
        )
        job_id = job_ids[0] if job_ids else None
        await run_blocking(query_state.mark_request_queued, request_id, job_id)

        logger.info(
            "Query enqueued: request_id=%s..., job_id=%s",
            request_id[:16],
            job_id,
        )
    except Exception as e:
        logger.exception("Failed to enqueue job")
        await run_blocking(query_state.mark_request_failed, request_id, f"Enqueue failed: {str(e)}")
        raise QueryExecutionError(
            status_code=500,
            detail="Failed to enqueue query for execution",
        )

    return QueryExecutionResult(
        strategy="execute",
        request_id=request_id,
        fingerprint=fingerprint,
        normalized_sql=normalized_sql,
        depends_on=depends_on,
        job_id=job_id,
    )


from fastapi import APIRouter

from .statement import router as statement_router
from .query import router as query_router
from .metric import router as metric_router

from .models import (
    StatementAccepted,
    StatementDetail,
    StatementResult,
    StatementResultLinks,
    PrimaryReq,
    CacheInfo,
    StatementLinks,
    PrimaryMetadata,
    CacheMetadata,
    QueryExecutionResult,
    PerspectiveCreateRequest,
    PerspectiveUpdateRequest,
    PerspectiveLinks,
    PerspectiveDetailView,
    PerspectiveListView,
    PerspectivesListResponse,
    StatementRequest,
    RestQueryRequest,
    SqlQueryRequest,
)

router = APIRouter()
router.include_router(statement_router)
router.include_router(query_router)
router.include_router(metric_router, prefix="/metric")
