"""Metric query endpoint.

This repo previously exposed a dedicated metric route which accepted a metric name plus
optional slice/filters and executed it by translating to the existing semantic REST query
shape (Cube-compatible) and submitting through the shared statement flow.

The original implementation lived on branches which still had the legacy semantic catalog
types. In the OSI-merged codebase, metric definitions are loaded from the Vulcan Context's
semantic metric models, so this endpoint is implemented as a thin adapter over
`POST /api/v1/query/semantic/rest`.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from pydantic import Field
from pgqueuer import QueueManager
from schema.filters import RestFilterExpression
from schema.rest_query import RestQuery
from vulcan.core.query.transpiler import TranspilerClient
from vulcan.core.state_sync.db.query import QueryState
from vulcan.utils.pydantic import PydanticModel

from schema.types import MetricGranularityValue
from schema.metadata import ModelEntry as MetadataModelEntry
from schema.auth import SecurityContext

from api.context import EnvContext
from api.endpoints.query import submit_sql_via_flow
from api.endpoints.query.models import StatementAccepted
from api.endpoints.query.query import _transpile_or_http_error
from api.endpoints.query.types import QueryType
from api.settings import (
    get_default_gateway,
    get_env_context,
    get_query_state,
    get_query_validator,
    get_queue_manager,
    get_transpiler,
    get_user,
)
from api.utils.urls import urls

logger = logging.getLogger(__name__)
router = APIRouter()


@dataclass(frozen=True, slots=True)
class MetricQueryPlan:
    metric_name: str
    measure_ref: str
    time_ref: str
    dimension_map: dict[str, str]
    segments: t.Optional[t.List[str]]
    default_granularity: MetricGranularityValue

    @classmethod
    def from_metadata(cls, entry: MetadataModelEntry) -> "MetricQueryPlan":
        measure_ref: t.Optional[str] = None
        time_ref: t.Optional[str] = None
        dimension_map: dict[str, str] = {}
        segments: t.List[str] = []

        for col in entry.columns or []:
            ref = f"{entry.name}.{col.name}"
            if col.name == "measure":
                measure_ref = ref
            elif col.name == "ts":
                time_ref = ref
            elif col.kind == "dimension":
                dimension_map[col.name] = ref
            elif col.kind == "segment":
                segments.append(ref)

        if not measure_ref or not time_ref:
            raise HTTPException(
                status_code=500,
                detail=f"Metric '{entry.name}' missing measure/ts in metadata export",
            )
        if entry.default_granularity is None:
            raise HTTPException(
                status_code=500,
                detail=f"Metric '{entry.name}' missing default_granularity in metadata export",
            )

        return cls(
            metric_name=entry.name,
            measure_ref=measure_ref,
            time_ref=time_ref,
            dimension_map=dimension_map,
            segments=segments or None,
            default_granularity=entry.default_granularity,
        )


class MetricQueryRequest(PydanticModel):
    """POST body for metric queries with dimensions and ad-hoc filters.

    Dimensions use alias names defined on the metric (e.g. 'plan_type_1').
    Filter members must use fully-qualified refs (e.g. 'arr_growth.industry').
    """

    dimensions: t.Optional[t.List[str]] = None
    granularity: t.Optional[MetricGranularityValue] = None
    timezone: t.Optional[str] = None
    filters: t.Optional[t.List[RestFilterExpression]] = None
    limit: int = Field(default=10000, ge=1, le=50000)
    offset: int = Field(default=0, ge=0)

    model_config = {"extra": "ignore"}


def _metric_from_context(ctx: EnvContext, metric_name: str) -> t.Optional[MetadataModelEntry]:
    return ctx.metrics_by_name.get(metric_name)


def _effective_metric_granularity(
    metric_default: MetricGranularityValue,
    requested: t.Optional[MetricGranularityValue],
) -> MetricGranularityValue:
    return requested if requested is not None else metric_default


def build_rest_query(
    plan: MetricQueryPlan,
    *,
    granularity: MetricGranularityValue,
    dimensions: t.Optional[t.List[str]] = None,
    filters: t.Optional[t.List[RestFilterExpression]] = None,
    timezone: str = "UTC",
    timezone_name: t.Optional[str] = None,
    limit: int = 10000,
    offset: int = 0,
) -> RestQuery:
    if timezone_name is not None:
        timezone = timezone_name

    measure = plan.measure_ref
    ts = plan.time_ref
    alias_map = plan.dimension_map
    segments = plan.segments

    resolved_dimensions: t.Optional[t.List[str]] = None
    if dimensions:
        requested = [d.strip() for d in dimensions if isinstance(d, str) and d.strip()]
        requested = list(dict.fromkeys(requested))
        available = set(alias_map.keys())
        unknown = sorted(set(requested) - available)
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=(f"Unknown dimension(s) for metric '{plan.metric_name}': {unknown}. "
                        f"Available dimensions: {sorted(available)}"),
            )
        resolved_dimensions = [alias_map[d] for d in requested] or None

    time_dimensions = [{"dimension": ts, "granularity": granularity}]

    kwargs: dict[str, t.Any] = dict(
        measures=[measure],
        dimensions=resolved_dimensions,
        segments=segments,
        timeDimensions=time_dimensions,
        filters=filters,
        limit=limit,
        offset=offset,
    )
    kwargs["timezone"] = timezone

    return RestQuery(**kwargs)



async def _transpile_and_submit(
    *,
    metric_name: str,
    rest_query: RestQuery,
    request: Request,
    response: Response,
    ctx: EnvContext,
    transpiler: TranspilerClient,
    qv,
    query_state: QueryState,
    qm: QueueManager,
    default_gateway: str,
    user: t.Dict[str, t.Any],
) -> StatementAccepted:
    dialect = ctx.get_dialect(default_gateway)
    auth_headers = {"Authorization": auth} if (auth := request.headers.get("Authorization")) else None

    transpiler_response = await _transpile_or_http_error(
        rest_query,
        invalid_msg="Invalid metric query",
        disable_post_processing=True,
        user=user.get("user_id"),
        security_context=SecurityContext.from_dict(user.get("security_context") or {}),
        transpiler=transpiler,
        dialect=dialect,
        ctx=ctx,
        auth_headers=auth_headers,
    )

    accepted = await submit_sql_via_flow(
        sql=transpiler_response.wrapped_sql_statement,
        params=transpiler_response.sql_params,
        ttl=0,
        meta={"metric_name": metric_name},
        gateway=default_gateway,
        qv=qv,
        qm=qm,
        query_state=query_state,
        env_context=ctx,
        query_type=QueryType.SEMANTIC_METRIC.value,
        rest_query=rest_query,
        submitted_by=user.get("user_id", ""),
    )

    response.headers["Location"] = urls.query_statement_detail(accepted.id)
    return accepted


@router.get(
    "/{metric_name}",
    summary="Submit metric query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    status_code=202,
    responses={
        202: {"description": "Statement accepted; use `_links` to poll status and fetch results."},
        400: {"description": "Invalid metric query or SQL generation failed"},
        404: {"description": "Metric not found"},
        502: {"description": "Transpiler error"},
    },
)
async def get_metric(
    request: Request,
    response: Response,
    metric_name: str,
    dimensions: t.Optional[str] = Query(
        default=None,
        description="Comma-separated dimension names (aliases defined on the metric)",
    ),
    granularity: t.Optional[MetricGranularityValue] = Query(
        default=None,
        description="Time-series granularity (second, minute, hour, day, week, month, quarter, year)",
    ),
    timezone: t.Optional[str] = Query(default=None, description="Timezone for time dimensions"),
    limit: int = Query(default=10000, ge=1, le=50000, description="Max rows"),
    offset: int = Query(default=0, ge=0, description="Rows to skip"),
    ctx: EnvContext = Depends(get_env_context),
    transpiler: TranspilerClient = Depends(get_transpiler),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> StatementAccepted:
    metric = _metric_from_context(ctx, metric_name)
    if not metric:
        raise HTTPException(status_code=404, detail=f"Metric '{metric_name}' not found")

    plan = MetricQueryPlan.from_metadata(metric)
    effective_granularity = _effective_metric_granularity(plan.default_granularity, granularity)

    dimensions_list = [d.strip() for d in dimensions.split(",") if d.strip()] if dimensions else None

    rest_query = build_rest_query(
        plan,
        dimensions=dimensions_list,
        granularity=effective_granularity,
        timezone=timezone or "UTC",
        limit=limit,
        offset=offset,
    )

    return await _transpile_and_submit(
        metric_name=metric_name,
        rest_query=rest_query,
        request=request,
        response=response,
        ctx=ctx,
        transpiler=transpiler,
        qv=qv,
        query_state=query_state,
        qm=qm,
        default_gateway=default_gateway,
        user=user,
    )


@router.post(
    "/{metric_name}",
    summary="Submit customizable metric query",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    status_code=202,
    responses={
        202: {"description": "Statement accepted; use `_links` to poll status and fetch results."},
        400: {"description": "Invalid metric query or SQL generation failed"},
        404: {"description": "Metric not found"},
        502: {"description": "Transpiler error"},
    },
)
async def post_metric(
    request: Request,
    response: Response,
    metric_name: str,
    body: MetricQueryRequest,
    ctx: EnvContext = Depends(get_env_context),
    transpiler: TranspilerClient = Depends(get_transpiler),
    qv=Depends(get_query_validator),
    query_state: QueryState = Depends(get_query_state),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
) -> StatementAccepted:
    metric = _metric_from_context(ctx, metric_name)
    if not metric:
        raise HTTPException(status_code=404, detail=f"Metric '{metric_name}' not found")

    plan = MetricQueryPlan.from_metadata(metric)
    effective_granularity = _effective_metric_granularity(plan.default_granularity, body.granularity)

    rest_query = build_rest_query(
        plan,
        dimensions=body.dimensions,
        granularity=effective_granularity,
        filters=body.filters,
        timezone=body.timezone or "UTC",
        limit=body.limit,
        offset=body.offset,
    )

    return await _transpile_and_submit(
        metric_name=metric_name,
        rest_query=rest_query,
        request=request,
        response=response,
        ctx=ctx,
        transpiler=transpiler,
        qv=qv,
        query_state=query_state,
        qm=qm,
        default_gateway=default_gateway,
        user=user,
    )
