from fastapi import APIRouter

from api.endpoints import info, query, pgq, files
from api.endpoints.activity import router as activity_router
from api.endpoints.notifications import router as notifications_router
from api.endpoints.followers import router as followers_router
from api.endpoints import metadata
from api.endpoints.quality import router as quality_router
from api.endpoints.dq import router as dq_router
from api.endpoints.query.perspectives import router as perspectives_router
from api.endpoints._internal import router as internal_router

# ============================================================
# Root Router - Operational endpoints (mounted at /)
# ============================================================
# These endpoints are for Kubernetes probes, health checks, and service info.
# They are NOT versioned as they are operational, not business API.
root_router = APIRouter()
root_router.include_router(info.router)

# ============================================================
# API Router - Business endpoints (mounted at /api/v1)
# ============================================================
api_router = APIRouter()

# Metadata endpoints (models, semantic schema, exports)
api_router.include_router(metadata.router, prefix="/metadata", tags=["Metadata"])

# Quality endpoints (legacy; prefer /dq)
api_router.include_router(quality_router, prefix="/quality", tags=["Quality"])

# Data quality endpoints (canonical)
api_router.include_router(dq_router, prefix="/dq", tags=["Data Quality"])

# Activity endpoints (plans, runs)
api_router.include_router(activity_router, prefix="/activity", tags=["Activity"])

# Notifications feed (persisted notification events)
api_router.include_router(notifications_router, prefix="/notifications", tags=["Notifications"])

# Followers (data product followers)
api_router.include_router(followers_router, prefix="/followers", tags=["Followers"])

# Query endpoints (statement, semantic, graphql)
api_router.include_router(query.router, prefix="/query", tags=["Data"])

# Perspectives endpoints
api_router.include_router(perspectives_router, prefix="/perspectives", tags=["Perspectives"])

# Hidden endpoints (not in OpenAPI schema)
api_router.include_router(files.router, prefix="/files", tags=["Files"], include_in_schema=False)
api_router.include_router(pgq.router, prefix="/queue", tags=["Task Queue"], include_in_schema=False)
api_router.include_router(internal_router, prefix="/_internal", tags=["Internal"], include_in_schema=False)
