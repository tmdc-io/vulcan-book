from __future__ import annotations

import typing as t
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import Field as PydanticField

from vulcan.utils.pydantic import PydanticModel
from api.context import EnvContextManager
from api.settings import get_env_context_manager
from api.utils.cache import cached, CachePolicy

router = APIRouter()


class Meta(PydanticModel):
    """API metadata."""

    version: str = PydanticField(description="API version")
    project: str = PydanticField(description="Project name")
    environments: t.Optional[t.List[str]] = PydanticField(default=None, description="List of available environments")
    db_types: t.Optional[t.Dict[str, str]] = PydanticField(default=None, description="Mapping of gateway names to database types")
    # TODO: Add more fields (environment, uptime_seconds, vulcan_version, etc.)

# TODO -> check PGQ, statestore connection, source connection etc! 

@router.get("/livez")
def liveness(request: Request = None):
    """
    Kubernetes liveness probe endpoint.
    
    Returns a simple health check response indicating the API is alive and responding.
    Used by Kubernetes to determine if the container should be restarted.
    """
    return {"status": "alive"}


@router.get("/readyz")
def readiness(request: Request = None):
    """
    Kubernetes readiness probe endpoint.

    Returns ``{"status": "ready"}`` only when the API server is able to serve
    traffic.  Currently checks the supervised worker health flag; additional
    dependency checks (DB ping, PGQ ping, object-store ping) are intentionally
    left as future work because they must remain cheap enough to run on the
    probe interval without adding load.
    """
    app = request.app if request is not None else None
    # Default to `False` on missing attribute: if the supervisor has not yet
    # scheduled (pre-lifespan race, test fixture omission), the correct answer
    # is "not ready", not "ready".
    worker_healthy = False
    if app is not None:
        worker_healthy = getattr(app.state, "worker_healthy", False)

    if not worker_healthy:
        return JSONResponse(
            status_code=503,
            content={"status": "unhealthy", "reason": "worker_unavailable"},
        )
    return {"status": "ready"}


# @router.get(
#     "/",
#     response_model=Meta,
#     response_model_exclude_unset=True,
#     response_model_exclude_none=True,  # Exclude None values from serialization (cleaner JSON responses)
# )
# def get_info(manager: EnvContextManager = Depends(get_env_context_manager)):
#     # Get project name from context config
#     project_name = "vulcan"
#     if hasattr(manager.context.config, "project_name"):
#         project_name = manager.context.config.project_name

#     # Get db_types from context (gateway types)
#     db_types = {}
#     if hasattr(manager.context, "gateways"):
#         for gateway_name, gateway in manager.context.gateways.items():
#             if hasattr(gateway, "connection_type"):
#                 db_types[gateway_name] = str(gateway.connection_type)

#     return Meta(
#         version="0.1.0",
#         project=project_name,
#         environments=list(manager._env_contexts.keys()),
#         db_types=db_types,
#     )


