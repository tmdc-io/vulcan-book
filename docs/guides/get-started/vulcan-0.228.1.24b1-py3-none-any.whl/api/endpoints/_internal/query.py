"""
Internal query endpoints for service-to-service communication.

Path: /_internal/query/semantic/sql
  - Accepts X-Client-Dialect header for MySQL→target dialect transpilation
  - Used by MySQL server for semantic SQL execution
"""

from __future__ import annotations

import logging
import typing as t
import uuid
from decimal import Decimal, InvalidOperation

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from pgqueuer import QueueManager
from sqlglot import exp, parse_one
from vulcan.core.state_sync.db.query import QueryState
from schema.metadata import Metadata
from schema.auth import SecurityContext
from vulcan.core.query.transpiler import TranspilerClient, get_transpiler_params_from_snapshots
from vulcan.utils.errors import TranspilerError

from api.endpoints.query.query import SqlQueryRequest
from api.endpoints.query import StatementAccepted, submit_sql_via_flow
from api.settings import (
    get_user,
    get_client_dialect,
    get_query_state,
    get_queue_manager,
    get_default_gateway,
    get_transpiler,
    get_env_context,
    get_query_validator,
)
from api.context import EnvContext
from api.utils.query_validator import QueryValidator
from api.utils.urls import urls
from api.endpoints.query.types import QueryType


logger = logging.getLogger(__name__)

router = APIRouter()


def _fix_powerbi_single_value_query(sql: str, client_dialect: t.Optional[str]) -> str:
    """Rewrite Power BI's single-value filter pattern: SELECT `C1` FROM (...) LIMIT 1.

    This runs only for MySQL client dialect and only when the outer SELECT projects a
    single column named C1. In that case we replace the projection with SELECT * and
    keep the LIMIT unchanged (always LIMIT 1 for this pattern).
    """
    if client_dialect != "mysql":
        return sql

    # Quick guard: only inspect queries that mention C1 at all.
    if "`C1`" not in sql and "`c1`" not in sql and " C1" not in sql and " c1" not in sql:
        return sql

    try:
        parsed = parse_one(sql, dialect="mysql")
    except Exception:
        # If parsing fails, leave the query unchanged.
        return sql

    select = parsed.find(exp.Select)
    if not isinstance(select, exp.Select):
        return sql

    projections = list(select.expressions)
    if len(projections) != 1:
        return sql

    col = projections[0]
    # exp.Alias / exp.Column both support alias_or_name; fall back gracefully otherwise.
    name = getattr(col, "alias_or_name", None)
    if not isinstance(name, str):
        name = getattr(col, "name", None)
    if not isinstance(name, str) or name.upper() != "C1":
        return sql

    # Replace SELECT C1 with SELECT *
    select.set("expressions", [exp.Star()])

    try:
        return parsed.sql(dialect="mysql")
    except Exception:
        # If serialization fails for any reason, fall back to original SQL.
        return sql


def _normalize_scientific_numeric_literals(sql: str, client_dialect: t.Optional[str]) -> str:
    """Rewrite scientific-notation numeric literals to plain decimals for MySQL clients."""
    if client_dialect != "mysql":
        return sql

    try:
        parsed = parse_one(sql, dialect="mysql")
    except Exception:
        return sql

    changed = False

    for node in parsed.walk():
        if not isinstance(node, exp.Literal) or not node.is_number:
            continue

        literal = node.this
        if "e" not in literal.lower():
            continue

        try:
            plain = format(Decimal(literal), "f")
            if "." in plain:
                plain = plain.rstrip("0").rstrip(".")
        except (InvalidOperation, ValueError):
            continue

        if plain in {"", "-"}:
            plain = "0"

        if plain != literal:
            node.replace(exp.Literal.number(plain))
            changed = True

    if not changed:
        return sql

    try:
        return parsed.sql(dialect="mysql")
    except Exception:
        return sql


def _boolean_dimension_names(metadata: Metadata) -> t.Set[str]:
    """Collect names that identify boolean dimensions (export ``Metadata`` shape).

    Aligns with catalog-based detection: semantic models only, dimension fields with
    logical type ``boolean``, plus qualified names and physical column names from
    ``depends_on``.
    """
    names: t.Set[str] = set()
    for model in metadata.models:
        if model.source_type != "semantic":
            continue
        for col in model.columns:
            if col.kind != "dimension" or col.ltype != "boolean":
                continue
            names.add(col.name.lower())
            names.add(f"{model.name}.{col.name}".lower())
            for dep in col.depends_on:
                if dep.column:
                    names.add(dep.column.lower())
    return names


def _fix_powerbi_boolean_dimension_query(
    sql: str,
    client_dialect: t.Optional[str],
    metadata: Metadata,
) -> str:
    """Rewrite Power BI's boolean-dimension CAST(bool AS DOUBLE) for Snowflake compat.

    Power BI wraps boolean columns with ``CAST(Cn AS DOUBLE)`` for null-safe sorting.
    Snowflake rejects direct BOOLEAN→DOUBLE casts.  This function:

    1. Finds inner alias definitions like ``IS_ACTIVE AS C1`` where the source
       column is a boolean dimension (per environment metadata export).
    2. Replaces every ``CAST(Cn AS DOUBLE/FLOAT)`` for those aliases with
       ``CASE WHEN Cn THEN 1 ELSE 0 END``.

    Handles single-column and multi-column boolean selections.
    """
    if client_dialect != "mysql":
        return sql

    boolean_dimension_names = _boolean_dimension_names(metadata)
    if not boolean_dimension_names:
        return sql

    try:
        parsed = parse_one(sql, dialect="mysql")
    except Exception:
        return sql

    select = parsed.find(exp.Select)
    if not isinstance(select, exp.Select):
        return sql

    # At least one outermost projection must be a boolean dimension.
    has_boolean_projection = False
    for proj in select.expressions:
        name = getattr(proj, "alias_or_name", None) or getattr(proj, "name", None)
        if isinstance(name, str) and name.lower() in boolean_dimension_names:
            has_boolean_projection = True
            break

    if not has_boolean_projection:
        return sql

    # Collect C-aliases (C1, C2, …) that map to boolean dimension columns
    # by inspecting inner alias definitions like ``IS_ACTIVE AS C1``.
    boolean_c_aliases: t.Set[str] = set()
    for node in parsed.walk():
        if not isinstance(node, exp.Alias):
            continue
        alias_name = node.alias
        source = node.this
        if (
            isinstance(source, exp.Column)
            and isinstance(alias_name, str)
            and len(alias_name) >= 2
            and alias_name[0].upper() == "C"
            and alias_name[1:].isdigit()
            and source.name.lower() in boolean_dimension_names
        ):
            boolean_c_aliases.add(alias_name.upper())

    if not boolean_c_aliases:
        return sql

    # Replace every CAST(Cn AS DOUBLE/FLOAT) where Cn is a boolean C-alias.
    changed = False
    for node in list(parsed.walk()):
        if (
            isinstance(node, exp.Cast)
            and isinstance(node.this, exp.Column)
            and node.this.name.upper() in boolean_c_aliases
            and isinstance(node.args.get("to"), exp.DataType)
            and node.args["to"].is_type(
                exp.DataType.Type.DOUBLE,
                exp.DataType.Type.FLOAT,
                exp.DataType.Type.UDOUBLE,
            )
        ):
            try:
                col_sql = node.this.sql(dialect="mysql")
                replacement = parse_one(
                    f"CASE WHEN {col_sql} THEN 1 ELSE 0 END",
                    dialect="mysql",
                )
                node.replace(replacement)
                changed = True
            except Exception:
                continue

    if not changed:
        return sql

    try:
        return parsed.sql(dialect="mysql")
    except Exception:
        return sql


@router.post(
    "/semantic/sql",
    response_model=StatementAccepted,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    status_code=202,
)
async def internal_semantic_sql(
    request: Request,
    response: Response,
    sql_request: SqlQueryRequest,
    gateway: str = Query(default=None),
    # For MySQL → API internal calls we default to disabling Cube post-processing.
    # The Transpiler is used purely as a compiler; result shaping happens in Vulcan.
    disable_post_processing: bool = Query(default=True),
    retry_on_recent_failure: bool = Query(default=False),
    query_state: QueryState = Depends(get_query_state),
    ctx: EnvContext = Depends(get_env_context),
    qv: QueryValidator = Depends(get_query_validator),
    qm: QueueManager = Depends(get_queue_manager),
    default_gateway: str = Depends(get_default_gateway),
    user: t.Dict[str, t.Any] = Depends(get_user),
    transpiler: TranspilerClient = Depends(get_transpiler),
    client_dialect: t.Optional[str] = Depends(get_client_dialect),
):
    """
    Internal endpoint for semantic SQL query execution with dialect transpilation.

    Used by: MySQL server (service-to-service calls)

    Features (not in public endpoint):
    - X-Client-Dialect header: Transpiles MySQL syntax to target dialect before processing

    Flow:
    1. If X-Client-Dialect is set, transpile input SQL (MySQL → target)
    2. Send to Transpiler service for semantic compilation
    3. Execute via statement flow
    4. Return 202 Accepted with statement ID
    """
    exec_gateway = gateway or default_gateway

    # Step 1: Apply Power BI-specific rewrites before any dialect normalization,
    # so we see the original MySQL syntax.
    fixed_sql = _fix_powerbi_single_value_query(sql_request.sql, client_dialect)
    fixed_sql = _fix_powerbi_boolean_dimension_query(fixed_sql, client_dialect, ctx.metadata)
    fixed_sql = _normalize_scientific_numeric_literals(fixed_sql, client_dialect)

    # Step 2: Transpile input SQL if client dialect differs from target. This
    # normalizes MySQL syntax (backticks, IFNULL, etc.) before Transpiler processing.
    sql_to_transpile = fixed_sql

    if client_dialect:
        from api.utils.sql_transpiler import (
            convert_sql_dialect,
            get_gateway_dialect,
            SQLTranspilationError,
        )

        target_dialect = get_gateway_dialect(exec_gateway)
        if client_dialect.lower() != target_dialect:
            try:
                sql_to_transpile = convert_sql_dialect(
                    fixed_sql, source=client_dialect, target=target_dialect
                )
                logger.info(
                    "Internal semantic SQL: transpiled %s → %s",
                    client_dialect,
                    target_dialect,
                )
            except SQLTranspilationError as e:
                logger.error("SQL transpilation failed: %s", e.message)
                raise HTTPException(
                    400,
                    detail={
                        "error": "SQL_TRANSPILATION_ERROR",
                        "message": e.message,
                        "client_dialect": client_dialect,
                        "target_dialect": target_dialect,
                    },
                )

    dialect = ctx.get_dialect(exec_gateway)
    params = get_transpiler_params_from_snapshots(ctx.context, ctx.environment)
    params["request_id"] = str(uuid.uuid4())

    auth_headers = (
        {"Authorization": auth} if (auth := request.headers.get("Authorization")) else None
    )
    try:
        transpiler_response = await transpiler.transpile(
            sql_to_transpile,
            user=user["user_id"],
            security_context=SecurityContext.from_dict(user["security_context"]),
            disable_post_processing=disable_post_processing,
            dialect=dialect,
            schema=params["schema"],
            tenant_id=params["tenant_id"],
            request_id=params["request_id"],
            db_type=params["db_type"],
            name=params["name"],
            headers=auth_headers,
        )
    except TranspilerError as e:
        logger.error("Transpiler error: %s", e)
        if e.is_connection_error:
            raise HTTPException(
                503,
                detail={
                    "error": "TRANSPILER_UNAVAILABLE",
                    "message": "Semantic query service is temporarily unavailable. Please try again.",
                },
            )
        # Provide user-friendly error message for query errors
        raise HTTPException(
            400,
            detail={
                "error": "SEMANTIC_QUERY_ERROR",
                "message": e.user_message,
                "hint": "Check your query syntax. Ensure all non-aggregated columns are in GROUP BY clause.",
            },
        )

    generated_sql = transpiler_response.wrapped_sql_statement
    sql_params = transpiler_response.sql_params

    # Step 3: Execute SQL using statement flow
    logger.info("Executing compiled SQL via statement flow")

    meta = {
        "query_style": "internal_semantic_sql",
        "semantic_sql": sql_request.model_dump(exclude_none=True),
        "client_dialect": client_dialect,
    }

    accepted = await submit_sql_via_flow(
        sql=generated_sql,
        params=sql_params,
        # ttl=sql_request.ttl,
        ttl=0,
        meta=meta,
        gateway=exec_gateway,
        qv=qv,
        qm=qm,
        query_state=query_state,
        env_context=ctx,
        retry_on_recent_failure=retry_on_recent_failure,
        query_type=QueryType.SEMANTIC_SQL.value,
        submitted_by=user["user_id"],
    )

    response.headers["Location"] = urls.query_statement_detail(accepted.id)
    return accepted
