"""
Internal API endpoints - not exposed in OpenAPI schema.

These endpoints are for service-to-service communication only:
- MySQL server → API (semantic SQL execution)

All internal endpoints are mounted under /_internal/ prefix.
"""
from fastapi import APIRouter

from api.endpoints._internal import query

router = APIRouter()

# Query endpoints (MySQL server → API)
# Path: /_internal/query/*
router.include_router(query.router, prefix="/query")
