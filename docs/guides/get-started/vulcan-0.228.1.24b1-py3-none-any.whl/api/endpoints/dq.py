"""Data quality endpoints: product summary and rules."""

from __future__ import annotations

import typing as t

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field as PydanticField, ConfigDict

from api.context import EnvContext
from api.definitions import Link, SelfLink
from api.settings import get_env_context
from api.utils.async_blocking import run_blocking
from api.utils.cache import cached, CachePolicy
from api.utils.urls import urls
from schema.types import DQDimension
from vulcan.core.soda3.spec import (
    CheckRuns,
    CheckResultWithRunId as CoreCheckRun,
    CheckOutcome,
    ProductQualitySummary,
)
from vulcan.utils.pydantic import PydanticModel

router = APIRouter()


class RuleRunLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    run: Link


class RuleRun(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    outcome: CheckOutcome
    outcome_reasons: t.Optional[t.Dict[str, t.Any]] = None
    diagnostics: t.Dict[str, t.Any] = PydanticField(default_factory=dict)
    run_id: str
    start_ts: int
    end_ts: t.Optional[int] = None
    links: RuleRunLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class RuleDefLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    self_link: Link = PydanticField(
        alias="self", serialization_alias="self", description="Link to rule detail page"
    )


class RuleDef(PydanticModel):
    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    identity: str
    name: t.Optional[str] = None
    type: t.Optional[str] = None
    column: t.Optional[str] = None
    dimension: DQDimension
    definition: t.Optional[str] = None
    model: t.Optional[str] = None

    runs: t.List[RuleRun] = PydanticField(default_factory=list)
    links: RuleDefLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class RulesResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    rules: t.List[RuleDef]
    total: int
    links: SelfLink = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


class RuleDetailLinks(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    self_link: Link = PydanticField(
        alias="self", serialization_alias="self", description="Self reference link"
    )
    rules: Link


class RuleDetailResponse(PydanticModel):
    model_config = ConfigDict(populate_by_name=True)

    rule: RuleDef
    links: RuleDetailLinks = PydanticField(
        alias="_links", serialization_alias="_links", description="HATEOAS links"
    )


def _extract_run(core_check_run: CoreCheckRun) -> RuleRun:
    """Extract run-only data from core CheckRun, removing metadata redundancy."""
    return RuleRun(
        outcome=core_check_run.outcome,
        outcome_reasons=core_check_run.outcome_reasons,
        diagnostics=core_check_run.diagnostics,
        run_id=core_check_run.run_id,
        start_ts=core_check_run.start_ts,
        end_ts=core_check_run.end_ts,
        links=RuleRunLinks(run=Link(href=urls.run(core_check_run.run_id))),
    )


def _rule_runs_to_def(check_runs: CheckRuns) -> RuleDef:
    runs = [_extract_run(run) for run in check_runs.runs]

    return RuleDef(
        identity=check_runs.check_identity,
        name=check_runs.check_name,
        type=check_runs.check_type,
        column=check_runs.column_name,
        dimension=check_runs.dimension,
        definition=check_runs.definition,
        model=check_runs.model_name,
        runs=runs,
        links=RuleDefLinks(
            self_link=Link(href=urls.dq_rule_runs(check_runs.check_identity))
        ),
    )


@router.get(
    "",
    summary="Get data quality summary",
    response_model=ProductQualitySummary,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Data quality summary returned successfully"},
        404: {"description": "No data quality data for environment"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_summary(
    as_of_ts: t.Optional[int] = Query(
        None,
        description=(
            "Unix timestamp in seconds. When set, summary uses each rule's latest "
            "outcome with start_ts <= as_of_ts. Omit for the current summary."
        ),
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> ProductQualitySummary:
    """
    Get product-level data quality summary for the current environment.

    Returns aggregated quality metrics using the latest evaluation per rule.
    Pass ``as_of_ts`` (Unix seconds) for a point-in-time snapshot. Metrics are
    grouped by dimension (e.g., completeness, accuracy, timeliness) and include
    pass/fail/warn/error counts and pass rates. ``latest_evaluated_at`` in the
    response is in milliseconds.
    """
    environment = ctx.environment
    summary = await run_blocking(
        ctx.context.state_sync.get_quality_summary,
        environment=environment,
        as_of_ts=as_of_ts,
    )

    if not summary:
        raise HTTPException(
            status_code=404,
            detail=f"No data quality data found for environment '{environment}'",
        )

    return summary


@router.get(
    "/rules",
    summary="List rules",
    response_model=RulesResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Data quality rules returned successfully"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_rules(
    model: t.Optional[str] = Query(
        None, description="Comma-separated model names. Omit for all."
    ),
    column: t.Optional[str] = Query(None, description="Filter by column. Omit for all."),
    dimension: t.Optional[DQDimension] = Query(
        None, description="Filter by ODPS data quality dimension. Omit for all."
    ),
    runs_per_rule: int = Query(
        default=10, ge=1, le=100, description="Runs per rule (default 10)"
    ),
    limit: int = Query(default=100, ge=1, le=1000, description="Max rules to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> RulesResponse:
    """
    List all data quality rules with their latest execution status.

    Returns a catalog of all unique rules that have been executed, including rule
    metadata (identity, name, type, dimension, definition) and the most recent
    execution results. Each rule's ``runs`` array contains up to ``runs_per_rule``
    executions (default 10), ordered by most recent first.
    """
    model_names = None
    if model:
        model_names = [m.strip() for m in model.split(",") if m.strip()]

    check_runs_list = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        model_names=model_names,
        column_name=column,
        dimension=dimension,
        runs_per_check=runs_per_rule,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    check_runs_list = check_runs_list or []
    rule_defs = [_rule_runs_to_def(cr) for cr in check_runs_list]

    query_params = []
    if model:
        query_params.append(f"model={model}")
    if column:
        query_params.append(f"column={column}")
    if dimension:
        query_params.append(f"dimension={dimension}")
    if runs_per_rule != 10:
        query_params.append(f"runs_per_rule={runs_per_rule}")
    if limit != 100:
        query_params.append(f"limit={limit}")
    if offset:
        query_params.append(f"offset={offset}")
    if start_ts is not None:
        query_params.append(f"start_ts={start_ts}")
    if end_ts is not None:
        query_params.append(f"end_ts={end_ts}")
    query_string = "&".join(query_params) if query_params else ""

    return RulesResponse(
        rules=rule_defs,
        total=len(rule_defs),
        links=SelfLink(
            self_link=Link(
                href=f"{urls.dq_rules()}?{query_string}"
                if query_string
                else urls.dq_rules()
            )
        ),
    )


@router.get(
    "/rules/by-name/{model}/{dimension}/{name:path}",
    summary="Get rule by name",
    response_model=RuleDetailResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Rule runs returned successfully"},
        404: {"description": "Rule not found or has no runs"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_rule_by_name(
    model: str,
    dimension: DQDimension,
    name: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Max runs to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> RuleDetailResponse:
    """
    Get execution history for a specific rule by natural key.

    Lookup by (model, dimension, name) instead of identity hash.
    Supports name with slashes via path:path (e.g. users/has/rows).
    Same response as GET /rules/{identity}.
    """
    check_identity = await run_blocking(
        ctx.context.state_sync.get_check_identity_by_natural_key,
        environment=ctx.environment,
        model_name=model,
        dimension=dimension,
        check_name=name,
    )
    if not check_identity:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Rule not found: {model}/{dimension}/{name} "
                f"for environment '{ctx.environment}'"
            ),
        )

    result = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        check_identity=check_identity,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail=f"Rule '{name}' has no runs for environment '{ctx.environment}'",
        )

    rule_def = _rule_runs_to_def(result[0])

    links = RuleDetailLinks(
        self_link=Link(
            href=urls.dq_rule_runs_by_name(
                model=model,
                dimension=dimension,
                name=name,
                limit=limit if limit != 20 else None,
                offset=offset or None,
                start_ts=start_ts,
                end_ts=end_ts,
            )
        ),
        rules=Link(href=urls.dq_rules()),
    )

    return RuleDetailResponse(
        rule=rule_def,
        links=links,
    )


@router.get(
    "/rules/{identity}",
    summary="Get rule",
    response_model=RuleDetailResponse,
    response_model_by_alias=True,
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
    responses={
        200: {"description": "Rule runs returned successfully"},
        404: {"description": "Rule not found or has no runs"},
        422: {"description": "Invalid query parameters"},
    },
)
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_rule(
    identity: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Max runs to return"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
    start_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time >= this (Unix seconds)"
    ),
    end_ts: t.Optional[int] = Query(
        None, description="Filter: rule evaluation start time <= this (Unix seconds)"
    ),
    ctx: EnvContext = Depends(get_env_context),
    request: Request = None,
) -> RuleDetailResponse:
    """
    Get execution history for a specific data quality rule.

    Returns the execution history of a rule across multiple runs, showing how its
    outcome changed over time. The ``runs`` array contains executions ordered by
    most recent first.
    """
    result = await run_blocking(
        ctx.context.state_sync.list_checks,
        environment=ctx.environment,
        check_identity=identity,
        limit=limit,
        offset=offset,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Rule '{identity}' not found or has no runs "
                f"for environment '{ctx.environment}'"
            ),
        )

    query_params = []
    if limit != 20:
        query_params.append(f"limit={limit}")
    if offset:
        query_params.append(f"offset={offset}")
    if start_ts is not None:
        query_params.append(f"start_ts={start_ts}")
    if end_ts is not None:
        query_params.append(f"end_ts={end_ts}")
    query_string = "&".join(query_params) if query_params else ""

    rule_def = _rule_runs_to_def(result[0])

    links = RuleDetailLinks(
        self_link=Link(
            href=f"{urls.dq_rule_runs(identity)}?{query_string}"
            if query_string
            else urls.dq_rule_runs(identity)
        ),
        rules=Link(href=urls.dq_rules()),
    )

    return RuleDetailResponse(
        rule=rule_def,
        links=links,
    )
