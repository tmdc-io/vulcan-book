from __future__ import annotations

import asyncio
import typing as t

from vulcan.core import analytics
from vulcan.core.analytics.queue_poller import start_queue_depth_poller


async def init_api_observability(
    tenant: str,
    data_product: str,
    queue_manager: t.Any,
) -> t.Optional[t.Any]:
    """Start the queue-depth poller when analytics Prometheus push is configured.

    ``tenant`` and ``data_product`` are accepted for API back-compat; labels
    come from ``init_collector_from_config`` on the collector's dispatcher.
    """
    del tenant, data_product

    if not analytics.collector.has_prometheus_push():
        return None

    return asyncio.create_task(start_queue_depth_poller(queue_manager=queue_manager))
