"""
Entry point for uvicorn to start the Vulcan API server.

Usage:
    uvicorn api.app:app --reload
    uvicorn api.app:app --host 0.0.0.0 --port 8000
"""

from api.main import create_app

app = create_app()
