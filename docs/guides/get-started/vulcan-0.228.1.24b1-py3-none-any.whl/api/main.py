from contextlib import AsyncExitStack, asynccontextmanager
from collections.abc import AsyncIterator
import asyncio
import functools
import logging
import os
import time
import typing as t
from functools import lru_cache

from fastapi import FastAPI, Request
from fastapi.openapi.docs import get_redoc_html
from fastapi.responses import HTMLResponse, JSONResponse
from pgqueuer import QueueManager
from pgqueuer.db import AsyncpgPoolDriver
from starlette.middleware.gzip import GZipMiddleware
from starlette.status import HTTP_422_UNPROCESSABLE_CONTENT, HTTP_500_INTERNAL_SERVER_ERROR
import asyncpg

from api.context import EnvContextManager
from api.coordinator import WatcherLeaderCoordinator
from api.endpoints import api_router, root_router
from api.exceptions import ApiException
from api.middleware import AuthorizationMiddleware, VulcanMetricsMiddleware
from api.observability import init_api_observability
from api.utils.env import (
    parse_optional_positive_int_env,
    parse_positive_float_env,
    parse_positive_int_env,
)
from api.worker import start_worker
from vulcan import Context, configure_logging
from vulcan.core import constants as c
from vulcan.core.query.transpiler import TranspilerClient, make_transpiler_client
from vulcan.utils import debug_mode_enabled
from vulcan.utils.errors import ConfigError, TranspilerError

logger = logging.getLogger(__name__)


def _configure_logging():
    """Configure logging using Vulcan logging configuration."""
    root_logger = logging.getLogger()

    # Only skip if Vulcan logging is already configured (not just any handler).
    # Uvicorn adds its own handlers before importing the app module, so checking
    # for any handler would skip our configuration entirely.
    from vulcan import CustomFormatter

    if any(isinstance(h.formatter, CustomFormatter) for h in root_logger.handlers):
        return

    _log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    force_debug = _log_level == "DEBUG"

    # Use Vulcan configure_logging which handles rebranding, formatters, etc.
    configure_logging(
        force_debug=force_debug,
        write_to_stdout=True,  # Write to stdout for API server
        write_to_file=False,  # Don't write to files for API server
        ignore_warnings=False,
    )

    debug = force_debug or debug_mode_enabled()

    # Configure uvicorn loggers to match
    log_level = logging.DEBUG if debug else logging.INFO
    logging.getLogger("uvicorn").setLevel(log_level)
    logging.getLogger("uvicorn.error").setLevel(log_level)
    logging.getLogger("uvicorn.access").setLevel(log_level)

    # Suppress noisy third-party library logs (similar to Vulcan's snowflake suppression)
    # Soda logs are verbose and not useful for API server users
    if not debug:
        logging.getLogger("soda").setLevel(logging.WARNING)
        logging.getLogger("soda.scan").setLevel(logging.WARNING)
        logging.getLogger("soda.telemetry").setLevel(logging.WARNING)
        logging.getLogger("soda.telemetry.soda_telemetry").setLevel(logging.WARNING)


# Configure logging at module import time
_configure_logging()

# Supervisor knobs controlling worker restart behaviour and readiness flag.
#
# All four are env-configurable so staging / perf-test / prod can tune
# without a code change.  Defaults are chosen for prod: ~3 min detection
# lag at the 30 s backoff cap, 10 s startup grace before flipping healthy,
# and a 5 min quiet window before resetting the failure counter.
#
# Environment variables:
#   VULCAN_WORKER_MAX_BACKOFF_S          (default 30.0,  bounds [1.0, 600.0])
#   VULCAN_WORKER_MAX_CONSECUTIVE_FAILURES (default 8,   bounds [1, 100])
#   VULCAN_WORKER_STARTUP_GRACE_S        (default 10.0,  bounds [1.0, 300.0])
#   VULCAN_WORKER_QUIET_WINDOW_S         (default 300.0, bounds [30.0, 3600.0])
_WORKER_MAX_BACKOFF_S = parse_positive_float_env(
    "VULCAN_WORKER_MAX_BACKOFF_S", default=30.0, floor=1.0, ceiling=600.0
)
_WORKER_MAX_CONSECUTIVE_FAILURES = parse_positive_int_env(
    "VULCAN_WORKER_MAX_CONSECUTIVE_FAILURES", default=8, floor=1, ceiling=100
)
_WORKER_STARTUP_GRACE_S = parse_positive_float_env(
    "VULCAN_WORKER_STARTUP_GRACE_S", default=10.0, floor=1.0, ceiling=300.0
)
_WORKER_QUIET_WINDOW_S = parse_positive_float_env(
    "VULCAN_WORKER_QUIET_WINDOW_S", default=300.0, floor=30.0, ceiling=3600.0
)

# Initial backoff after the first worker failure, and the value we reset to
# after surviving a quiet window.  Not env-configurable (exponential growth
# plus the env-tunable cap already covers ops knobs); kept module-level so
# unit tests can monkey-patch it to sub-second values.
_WORKER_INITIAL_BACKOFF_S = 1.0

# Errors that indicate a code or configuration bug rather than a transient
# runtime hiccup.  The supervisor must not mask these behind retries — let
# the process die fast so Kubernetes restarts and CrashLoopBackoff surfaces
# the problem instead of 10 min of quiet retries.
_NONRECOVERABLE_WORKER_ERRORS: tuple[type[BaseException], ...] = (
    ImportError,
    SyntaxError,
    ConfigError,
)


async def _promote_worker_after_grace(app: FastAPI) -> None:
    """Flip ``worker_healthy`` to True after the startup grace window, then
    sleep the quiet window before returning normally.

    The supervisor inspects this task's completion state on the next loop
    iteration to detect the "quiet window survived" condition (``done() and
    not cancelled() and exception() is None``) and uses it as the signal to
    reset ``consecutive_failures`` and ``backoff``.

    Cancelled by the supervisor whenever ``start_worker`` returns or raises.
    """
    await asyncio.sleep(_WORKER_STARTUP_GRACE_S)
    app.state.worker_healthy = True
    logger.info(
        "Worker healthy after %.1fs startup grace window.",
        _WORKER_STARTUP_GRACE_S,
    )
    await asyncio.sleep(_WORKER_QUIET_WINDOW_S)


async def _supervised_worker(
    ctx: t.Any,
    qm: t.Any,
    query_state: t.Any,
    object_store: t.Any,
    pgq_config: t.Any,
    manager: "EnvContextManager",
    app: FastAPI,
) -> None:
    """Run the worker forever as a state machine.

    States (see the mermaid diagram in the supervisor hardening plan):

    * ``UnhealthyCold`` — initial state and the state re-entered after every
      backoff sleep.  ``worker_healthy`` is ``False`` until the grace window
      elapses.
    * ``HealthyGrace`` — the promote-companion task flipped the flag to
      ``True`` because ``start_worker`` survived ``STARTUP_GRACE_S`` without
      raising.
    * ``HealthyQuiet`` — the promote task additionally survived
      ``QUIET_WINDOW_S``; on the next iteration the supervisor resets the
      failure counter and backoff.
    * ``BackingOff`` — ``start_worker`` returned or raised; sleep before
      retrying.  The counter increments each visit; crossing
      ``MAX_CONSECUTIVE_FAILURES`` flips ``worker_healthy=False``.
    * ``NonRecoverable`` — ``start_worker`` raised a config / import error;
      supervisor re-raises so ``_worker_done_callback`` can flip the flag
      and Kubernetes takes over via CrashLoopBackoff.
    """
    app.state.worker_healthy = False
    consecutive_failures = 0
    backoff = _WORKER_INITIAL_BACKOFF_S

    while True:
        promote_task = asyncio.create_task(
            _promote_worker_after_grace(app),
            name="worker-promote-grace",
        )
        clean_return = False
        try:
            await start_worker(ctx, qm, query_state, object_store, pgq_config, manager)
            clean_return = True
        except asyncio.CancelledError:
            promote_task.cancel()
            logger.info("Worker task cancelled")
            raise
        except _NONRECOVERABLE_WORKER_ERRORS as e:
            promote_task.cancel()
            app.state.worker_healthy = False
            logger.critical(
                "Worker hit non-recoverable error %s: %s; not retrying.",
                type(e).__name__,
                e,
                exc_info=True,
            )
            raise
        except Exception as e:
            logger.error(
                "Worker task failed (%s/%s): %s. Restarting in %.1fs",
                consecutive_failures + 1,
                _WORKER_MAX_CONSECUTIVE_FAILURES,
                e,
                backoff,
                exc_info=True,
            )
        finally:
            if not promote_task.done():
                promote_task.cancel()

        if clean_return:
            logger.error("start_worker returned cleanly; treating as unexpected failure.")

        # If the promote task ran all the way through its quiet-window sleep
        # without being cancelled or raising, the worker survived long enough
        # that we can confidently treat this new failure as the start of a
        # fresh streak rather than appending to a lifetime counter.
        if (
            promote_task.done()
            and not promote_task.cancelled()
            and promote_task.exception() is None
        ):
            if consecutive_failures > 0 or backoff > _WORKER_INITIAL_BACKOFF_S:
                logger.info("Sustained quiet window; resetting failure counter and backoff.")
            consecutive_failures = 0
            backoff = _WORKER_INITIAL_BACKOFF_S

        consecutive_failures += 1
        if consecutive_failures >= _WORKER_MAX_CONSECUTIVE_FAILURES:
            logger.critical(
                "Worker task failed %s consecutive times; marking unhealthy.",
                consecutive_failures,
            )
            app.state.worker_healthy = False

        try:
            await asyncio.sleep(backoff)
        except asyncio.CancelledError:
            raise
        backoff = min(backoff * 2.0, _WORKER_MAX_BACKOFF_S)


def _worker_done_callback(task: asyncio.Task, *, app: FastAPI) -> None:
    """Log the supervised worker's final status and flip readiness off on any
    non-cancelled exit.

    The supervisor is expected to run forever; any return from the task is
    either a cancellation (normal shutdown) or a bug.  In the buggy case we
    mark readiness unhealthy so Kubernetes drains the pod via the probe.
    """
    try:
        task.result()
        logger.critical(
            "Supervised worker exited cleanly; this should never happen. "
            "Flipping readiness off so Kubernetes restarts the pod."
        )
        app.state.worker_healthy = False
    except asyncio.CancelledError:
        logger.info("Worker task cancelled")
    except Exception as e:
        logger.critical(
            "Supervised worker task terminated unexpectedly: %s",
            e,
            exc_info=True,
        )
        app.state.worker_healthy = False


async def _refresh_perspectives_for_expired_fingerprints(
    since_ts_ns: int,
    state_sync,
    manager: EnvContextManager,
    app: FastAPI,
):
    """Refresh perspectives based on expired fingerprints from _query_fingerprints.

    This is more efficient than dependency-based refresh because it directly
    matches perspectives to expired cache entries via fingerprint.

    Args:
        since_ts_ns: Timestamp in nanoseconds to query expired fingerprints from
        state_sync: EngineAdapterStateSync instance
        manager: EnvContextManager instance
        app: FastAPI app instance (for accessing app.extra)
    """
    try:
        import asyncio
        from api.endpoints.query import submit_perspective_refresh as refresh_perspective
        from api.utils.async_blocking import run_blocking

        query_state = state_sync.query_state

        # Convert nanoseconds to milliseconds for timestamp comparison
        since_ts_ms = since_ts_ns // 1_000_000
        logger.debug(
            f"Querying perspectives with expired fingerprints "
            f"(since_ts_ns={since_ts_ns}, since_ts_ms={since_ts_ms})"
        )

        # Pagination parameters
        PAGE_SIZE = 100
        offset = 0
        total_refreshed = 0

        while True:
            # ``list_perspectives_to_refresh`` is a synchronous SQL call that
            # can return up to PAGE_SIZE rows per page; running it inline on
            # the event loop freezes every request handler for the duration
            # of the query.  Offload to the API I/O pool so the watcher stays
            # cooperative with the rest of the app.
            perspectives, has_more = await run_blocking(
                query_state.list_perspectives_to_refresh,
                since_ts_ms,
                limit=PAGE_SIZE,
                offset=offset,
            )

            if not perspectives:
                logger.info(
                    f"No perspectives to refresh (since_ts_ms={since_ts_ms}, offset={offset})"
                )
                break

            logger.info(
                f"Processing batch: {len(perspectives)} perspective(s) "
                f"(offset={offset}, has_more={has_more})"
            )

            # Get environment context
            default_env = manager.context.config.default_target_environment
            env_ctx = manager.get_env_context(default_env)
            qm = app.extra["qm"]

            # Refresh each perspective concurrently
            refresh_tasks = [refresh_perspective(p, env_ctx, query_state, qm) for p in perspectives]

            results = await asyncio.gather(*refresh_tasks, return_exceptions=True)

            # Count successes
            successful = sum(1 for r in results if not isinstance(r, Exception))

            # Log errors
            for perspective, result in zip(perspectives, results):
                if isinstance(result, Exception):
                    logger.error(
                        f"Failed to refresh perspective '{perspective.slug}': {result}",
                        exc_info=True,
                    )

            total_refreshed += successful

            logger.info(
                f"Batch complete: {successful}/{len(perspectives)} enqueued successfully "
                f"(total: {total_refreshed})"
            )

            # Check if more pages
            if not has_more:
                break

            offset += PAGE_SIZE

        logger.info(
            f"Perspective refresh complete: {total_refreshed} perspective(s) enqueued "
            f"(since_ts_ms={since_ts_ms})"
        )
    except Exception as e:
        logger.error(f"Error refreshing perspectives by fingerprints: {e}", exc_info=True)


async def env_change_watcher_task(
    manager: EnvContextManager,
    state_sync,
    app: FastAPI,
    coordinator: WatcherLeaderCoordinator,
    sleep_seconds: int = 5,
):
    """Watches for environment changes and triggers appropriate updates.

    Uses :class:`WatcherLeaderCoordinator` for leader election so that
    only one replica runs the polling loop when multiple replicas share
    the same state database.

    On first leadership acquisition the leader sets ``coordinator.startup_done``
    so downstream logic can treat startup as complete (no external sync enqueue).

    Calls fetch_plan_run_activity_since and makes smart decisions:
    - plan changes -> Full environment rebuild
    - run-only changes -> Incremental run info update

    Note: Timestamps are in nanoseconds for precise chronological ordering.
          last_ts stores the updated_ts_ns from fetch_plan_run_activity_since().
    """
    last_ts = 0
    logger.info(
        "Environment change watcher started (polling every %ds)",
        sleep_seconds,
    )

    while True:
        try:
            if not await coordinator.ensure_leadership():
                await asyncio.sleep(sleep_seconds)
                continue

            if not coordinator.startup_done:
                coordinator.mark_startup_done()

            # ``fetch_plan_run_activity_since`` performs synchronous DB I/O
            # via the Vulcan engine adapter; offload so a slow state-store
            # query cannot pause every active request on this replica.
            from api.utils.async_blocking import run_blocking

            changes, max_ts_ns = await run_blocking(
                state_sync.fetch_plan_run_activity_since, last_ts
            )

            for change in changes:
                env = change.environment

                if change.has_plan:
                    logger.info(f"Plan changes detected for '{env}'. Rebuilding environment...")
                    await manager.on_plan_change(env)
                    if env == c.PROD:
                        from api.worker.hera_jobs import enqueue_hera_full_sync

                        qm = app.extra.get("qm")
                        env_ctx = manager.get_env_context(env)
                        plan_id = getattr(env_ctx, "plan_id", None)
                        if qm is not None and plan_id:
                            result = await enqueue_hera_full_sync(
                                qm,
                                env,
                                plan_id=plan_id,
                                update_run_status=bool(change.has_run),
                            )
                            logger.info("hera_full_sync enqueued (env=%s): %s", env, result)
                        elif qm is not None:
                            logger.warning("Skipping Hera full sync; no plan_id for env=%s", env)
                        else:
                            logger.debug("Skipping Hera full sync enqueue; no queue manager")

                if change.has_run:
                    logger.info(f"Run changes detected for '{env}'. Updating run cache...")
                    await manager.on_run_change(env)
                    if env == c.PROD and not change.has_plan:
                        from api.worker.hera_jobs import enqueue_hera_run_status

                        qm = app.extra.get("qm")
                        if qm is not None:
                            result = await enqueue_hera_run_status(qm, env)
                            logger.info("hera_run_status enqueued (env=%s): %s", env, result)
                        else:
                            logger.debug("Skipping Hera run-status enqueue; no queue manager")

                if change.has_plan or change.has_run:
                    logger.info(
                        f"Change detected: has_plan={change.has_plan}, has_run={change.has_run}, "
                        f"last_ts={last_ts}, max_ts_ns={max_ts_ns}"
                    )

                    if last_ts != 0:
                        logger.info(
                            f"Triggering perspective refresh for expired fingerprints "
                            f"(since_ts_ns={last_ts}, since_ts_ms={last_ts // 1_000_000})"
                        )
                        await _refresh_perspectives_for_expired_fingerprints(
                            since_ts_ns=last_ts,
                            state_sync=state_sync,
                            manager=manager,
                            app=app,
                        )
                    else:
                        logger.debug("Skipping perspective refresh on cold start (last_ts=0)")

                    last_ts = max_ts_ns
                    logger.debug(f"Updated checkpoint: last_ts={last_ts}")

        except Exception as e:
            logger.error(f"Environment change watcher error: {e}", exc_info=True)

        await asyncio.sleep(sleep_seconds)


@lru_cache()
def _get_vulcan_context(path: str, config: str, gateway: str | None) -> Context:
    """
    Build and cache Vulcan context.

    This is expensive (loads all models, parses SQL, etc.)
    Cached to prevent accidental double-creation during startup.
    """
    context = Context(paths=path, config=config, gateway=gateway, load=False)
    context.load()
    return context


@lru_cache()
def _get_env_context_manager(path: str, config: str, gateway: str | None) -> EnvContextManager:
    """
    Build and cache EnvContextManager.

    This is VERY expensive:
    - Builds EnvContext for default environment ("prod") (metadata and semantic schema)
    - Fetches latest run info from ActivityState

    Cached to prevent accidental double-creation during startup.
    """
    vulcan_ctx = _get_vulcan_context(path, config, gateway)
    return EnvContextManager(vulcan_ctx)


def _get_state_conn_and_schema(ctx: Context, gateway: str):
    """Resolve PostgreSQL state connection and schema for the query service."""
    # Prefer dedicated state connection; fall back to gateway connection.
    state_conn = ctx.config.get_state_connection(gateway) or ctx.config.get_connection(gateway)

    if not state_conn:
        raise ValueError(
            f"❌ No connection configured for gateway '{gateway}'. "
            "Query service requires a PostgreSQL connection for metadata storage."
        )
    if state_conn.type_ != "postgres":
        raise ValueError(
            f"❌ Query service requires PostgreSQL connection, got: {state_conn.type_}. "
            "The query service uses this connection for metadata storage (job queue and audit tables)."
        )

    state_schema = ctx.config.get_state_schema(gateway) or c.SQLMESH
    if not state_schema:
        raise ValueError(
            f"❌ No state_schema configured for gateway '{gateway}'. "
            "Query service requires a schema for metadata tables."
        )

    return state_conn, state_schema


async def _init_transpiler_client(ctx: Context) -> TranspilerClient:
    """Create the shared TranspilerClient for the app lifetime."""
    client = make_transpiler_client(ctx.config)
    # Open underlying HTTP client once for the app lifetime
    await client.__aenter__()
    return client


async def _safe_close_http_client(client: t.Any, name: str) -> None:
    """Close a shared async HTTP client, swallowing close-time errors.

    Used as an ``AsyncExitStack.push_async_callback`` shim so that a teardown
    failure on one client never masks the original startup error or stops the
    stack from unwinding the rest of the registered callbacks.
    """
    try:
        await client.__aexit__(None, None, None)
    except Exception:
        logger.debug("Error closing %s client", name, exc_info=True)


async def _init_heimdall_client(ctx: Context) -> t.Any:
    """Create the shared HeimdallClient for the app lifetime.

    Returns ``None`` when authorization is disabled so the middleware can
    treat "disabled" and "missing client" as distinct states.
    """
    from api.clients.heimdall import HeimdallClient

    heimdall_cfg = ctx.config.heimdall
    if not heimdall_cfg.enabled:
        return None

    client = HeimdallClient(
        base_url=heimdall_cfg.base_url,
        timeout=heimdall_cfg.timeout,
    )
    # Open the underlying httpx.AsyncClient once for the app lifetime so the
    # first user request does not pay the AsyncClient-construction cost.
    await client.__aenter__()
    return client


async def _init_graphql_client(ctx: Context) -> t.Any:
    """Create the shared ``httpx.AsyncClient`` for the GraphQL proxy.

    The GraphQL proxy handler previously opened a fresh
    ``httpx.AsyncClient`` per request, which paid the full TCP + TLS
    handshake on every call and leaked sockets into TIME_WAIT under burst
    (audit §5.4).  Here we build a single client at lifespan startup so the
    pool is shared across requests.  ``httpx.Limits`` is still wired in so
    ops can size the pool per environment without touching code, but the
    defaults intentionally match httpx's built-in behaviour (no caps,
    5 s keepalive expiry) to preserve pre-DATAOS-1031 semantics; operators
    opt in to bounded pools by setting ``VULCAN_GRAPHQL_POOL_*``.  The
    handler reads it via ``app.state.graphql_client`` and fails closed with
    503 if it's missing.
    """
    import httpx

    max_connections = parse_optional_positive_int_env(
        "VULCAN_GRAPHQL_POOL_MAX", default=None, floor=10, ceiling=500
    )
    max_keepalive = parse_optional_positive_int_env(
        "VULCAN_GRAPHQL_POOL_KEEPALIVE", default=None, floor=1, ceiling=500
    )
    keepalive_expiry = parse_positive_float_env(
        "VULCAN_GRAPHQL_POOL_KEEPALIVE_EXPIRY_S",
        default=5.0,
        floor=1.0,
        ceiling=300.0,
    )

    client = httpx.AsyncClient(
        timeout=ctx.config.graphql.timeout,
        limits=httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive,
            keepalive_expiry=keepalive_expiry,
        ),
    )
    await client.__aenter__()
    return client


def _init_object_store(ctx: Context):
    """Initialize and validate the object store if configured."""
    if not ctx.config.object_store:
        return None

    from vulcan.core.query import ObjectStoreClient

    object_store_config = ctx.config.object_store
    object_store = ObjectStoreClient(
        object_store_config,
        tenant=getattr(ctx.config, "tenant", None),
        project=getattr(ctx.config, "name", None),
    )

    try:
        object_store.validate_connection()
    except Exception as e:
        logger.error("Object store validation failed: %s", e)
        raise RuntimeError(
            "Failed to initialize object store. Query API cannot start without valid object store. "
            f"Error: {e}"
        )

    return object_store


async def _log_postgres_max_connections(
    db_pool: asyncpg.Pool, *, pool_min: int, pool_max: int
) -> None:
    """Log the live ``max_connections`` setting alongside pool sizing.

    Best-effort: any failure here (connection churn during boot, restricted
    role, etc.) is logged at WARNING and swallowed so the pod still boots.
    Works for any Postgres backend — Azure, Aurora, CloudSQL, self-hosted —
    because it asks the server directly rather than relying on vendor-specific
    APIs.

    Operators read this log to decide how much headroom they have before
    raising ``VULCAN_PG_POOL_MAX`` above the conservative default of 10.
    """
    try:
        async with db_pool.acquire() as conn:
            row = await conn.fetchrow("SHOW max_connections")
        max_conn_raw = row["max_connections"] if row else None
        try:
            max_conn: t.Union[int, str] = (
                int(max_conn_raw) if max_conn_raw is not None else "<unknown>"
            )
        except (TypeError, ValueError):
            max_conn = str(max_conn_raw)
        logger.info(
            "Postgres state pool ready: max_connections=%s, pool_min=%s, pool_max=%s, "
            "configured VULCAN_PG_POOL_{MIN=%s, MAX=%s}",
            max_conn,
            pool_min,
            pool_max,
            os.getenv("VULCAN_PG_POOL_MIN", "<unset>"),
            os.getenv("VULCAN_PG_POOL_MAX", "<unset>"),
        )
    except Exception as exc:
        logger.warning(
            "Failed to probe Postgres max_connections (pool_min=%s, pool_max=%s): %s",
            pool_min,
            pool_max,
            exc,
        )


async def _init_pgq(db_pool: asyncpg.Pool, schema: str) -> QueueManager:
    """Initialize PGQueuer and install its schema."""
    driver = AsyncpgPoolDriver(db_pool)
    # Use schema-specific channel name to isolate events per schema
    # This ensures different schemas (e.g., b2b_saas, manager) don't interfere
    channel_name = f"ch_pgqueuer_api_{schema}"
    qm = QueueManager(driver, channel=channel_name)

    from pgqueuer.queries import Queries

    qm.queries = Queries(driver)

    try:
        await qm.queries.install()
        logger.info(
            "PGQueuer initialized successfully in schema: %s (channel: %s)", schema, channel_name
        )
    except Exception as e:
        # Tables might already exist, which is fine
        logger.debug("PGQueuer schema already exists: %s", e)

    return qm


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator:
    """
    Application lifespan manager.

    Handles:
    - EnvContextManager initialization
    - PGQueuer connection pool setup
    - Worker and watcher task management
    - Graceful shutdown
    """
    from api.settings import get_settings

    # Configure logging first, before Vulcan context initialization
    _configure_logging()

    # Size the anyio threadpool limiter explicitly so the FastAPI sync-handler
    # fallback + every ``asyncio.to_thread`` / library ``run_in_executor`` call
    # shares a known pool.  The default of 40 matches anyio's own built-in
    # default and is sized for the actual users of this pool today: ~5 sync
    # route handlers, ~7 ``asyncio.to_thread`` callsites, the 15 metrics-emit
    # opportunistic
    # library work; ~27 worst-case concurrent tokens with comfortable headroom.
    # Operators sustaining 1-3K RPS or running many sync handlers should bump
    # ``VULCAN_ANYIO_THREADS`` (e.g. ``200``).  Bounds [40, 1000]: anything
    # below 40 regresses below anyio's own default, anything above 1000
    # invites kernel-thread pressure on a single pod.  Note: the API's hot
    # path uses the dedicated ``run_blocking`` pool (``VULCAN_API_IO_WORKERS``),
    # not this one, so this knob is *not* the throughput lever.
    try:
        import anyio.to_thread

        _anyio_threads = parse_positive_int_env(
            "VULCAN_ANYIO_THREADS", default=40, floor=40, ceiling=1000
        )
        anyio.to_thread.current_default_thread_limiter().total_tokens = _anyio_threads
        logger.info(
            "anyio threadpool limiter sized to %d tokens (VULCAN_ANYIO_THREADS=%s)",
            _anyio_threads,
            os.getenv("VULCAN_ANYIO_THREADS", "<unset>"),
        )
    except Exception as exc:
        logger.warning("Failed to configure anyio threadpool limiter: %s", exc)

    settings = get_settings()

    # Initialize EnvContextManager and Vulcan context
    manager = _get_env_context_manager(
        str(settings.project_path),
        settings.config,
        settings.gateway,
    )
    ctx = manager.context

    # Get PGQ config from Vulcan config
    pgq_config = ctx.config.pgq

    # Resolve gateway (use default if not specified)
    gateway = settings.gateway or ctx.config.default_gateway_name

    # Resolve state connection and schema
    state_conn, state_schema = _get_state_conn_and_schema(ctx, gateway)

    # All shared HTTP clients are registered with an ``AsyncExitStack`` so
    # that any failure later in startup (object store init, asyncpg pool
    # creation, pgqueuer install, ...) still tears them down.  Without this
    # stack a single failed boot leaks three ``httpx.AsyncClient``
    # instances - each holding its own connection pool and background
    # tasks - until the process is restarted (audit §5.2 follow-up).
    async with AsyncExitStack() as http_clients:
        # Initialize shared Transpiler client
        transpiler_client = await _init_transpiler_client(ctx)
        http_clients.push_async_callback(_safe_close_http_client, transpiler_client, "Transpiler")

        # Initialize shared Heimdall client so the AuthorizationMiddleware reads
        # a single long-lived httpx.AsyncClient from app.state instead of
        # lazily creating one on the first request.  ``None`` when auth is
        # disabled via config.
        heimdall_client = await _init_heimdall_client(ctx)
        app.state.heimdall_client = heimdall_client
        if heimdall_client is not None:
            http_clients.push_async_callback(_safe_close_http_client, heimdall_client, "Heimdall")

        # Initialize the shared GraphQL proxy httpx.AsyncClient so the handler
        # reuses a pooled client instead of allocating a fresh one per request.
        graphql_client = await _init_graphql_client(ctx)
        app.state.graphql_client = graphql_client
        if graphql_client is not None:
            http_clients.push_async_callback(
                _safe_close_http_client, graphql_client, "GraphQL proxy"
            )

        # Initialize object store
        object_store = _init_object_store(ctx)

        # Build connection DSN for pgqueuer
        connection_dsn = (
            f"postgresql://{state_conn.user}:{state_conn.password}"
            f"@{state_conn.host}:{state_conn.port}/{state_conn.database}"
        )

        # Create asyncpg connection pool using context manager.
        # Pool sizing and per-command timeout are tunable via env so ops can
        # raise the ceiling without redeploying code.  Defaults match the
        # pre-DATAOS-1031 baseline (2 idle / 10 max per pod) so existing
        # deployments retain their historical behaviour; operators targeting
        # higher RPS opt in by setting ``VULCAN_PG_POOL_MIN`` /
        # ``VULCAN_PG_POOL_MAX`` (e.g. 10/50) after confirming headroom via
        # the boot-time log from ``_log_postgres_max_connections``.
        pool_min = parse_positive_int_env("VULCAN_PG_POOL_MIN", default=2, floor=1, ceiling=100)
        pool_max = parse_positive_int_env("VULCAN_PG_POOL_MAX", default=10, floor=1, ceiling=500)
        command_timeout = parse_positive_float_env(
            "VULCAN_PG_COMMAND_TIMEOUT_S", default=30.0, floor=1.0, ceiling=300.0
        )
        if pool_min > pool_max:
            # Refuse to boot with a nonsensical pool size rather than letting
            # asyncpg raise a less-obvious error deeper in its init path.
            logger.warning(
                "VULCAN_PG_POOL_MIN=%d > VULCAN_PG_POOL_MAX=%d; clamping min to max",
                pool_min,
                pool_max,
            )
            pool_min = pool_max

        async with asyncpg.create_pool(
            connection_dsn,
            min_size=pool_min,
            max_size=pool_max,
            command_timeout=command_timeout,
            server_settings={"search_path": state_schema},
        ) as db_pool:
            # Runtime pool-headroom visibility.  Works for any Postgres vendor:
            # we issue ``SHOW max_connections`` against the live server and log
            # it alongside the pool sizing so operators know how much headroom
            # they have before bumping ``VULCAN_PG_POOL_MAX``.
            # Best-effort: a failure here must never crash lifespan.
            await _log_postgres_max_connections(db_pool, pool_min=pool_min, pool_max=pool_max)

            # Initialize pgqueuer and install schema
            qm = await _init_pgq(db_pool, state_schema)

            # Store ALL dependencies in app.extra for dependency injection
            app.extra["env_context_manager"] = manager
            app.extra["qm"] = qm
            app.extra["query_state"] = ctx.state_sync.query_state
            app.extra["object_store"] = object_store
            app.extra["default_gateway"] = gateway
            app.extra["transpiler_client"] = transpiler_client

            manager.qm = qm
            default_env = ctx.config.default_target_environment
            env_ctx = manager.get_env_context(default_env)
            app.extra["default_env_context"] = env_ctx

            # Leader coordinator: dedicated connection for advisory lock.
            watcher_coordinator = WatcherLeaderCoordinator(connection_dsn, state_schema)

            # Start worker and watcher tasks, store in app.state.
            # Use a supervisor so transient worker errors (e.g. brief PG outages)
            # result in backoff-and-retry rather than a hard process exit.
            #
            # Initialise `worker_healthy=False`: the supervisor flips it to True
            # only after the startup grace window elapses without raising, which
            # prevents the pre-subscription cold-start false positive on /readyz.
            app.state.worker_healthy = False
            app.state.worker_task = asyncio.create_task(
                _supervised_worker(
                    ctx,
                    qm,
                    ctx.state_sync.query_state,
                    object_store,
                    pgq_config,
                    manager,
                    app,
                )
            )
            app.state.worker_task.add_done_callback(
                functools.partial(_worker_done_callback, app=app)
            )

            app.state.watcher_task = asyncio.create_task(
                env_change_watcher_task(
                    manager,
                    ctx.state_sync,
                    app,
                    coordinator=watcher_coordinator,
                    sleep_seconds=5,
                )
            )

            # Start background Prometheus metrics pusher (if Pushgateway is configured)
            try:
                app.state.queue_depth_task = await init_api_observability(
                    env_ctx.tenant,
                    env_ctx.product,
                    qm,
                )
            except Exception as e:
                logger.debug(f"Metrics pusher not started: {e}")

            logger.info("Background tasks started")

            try:
                yield
            finally:
                # Cancel worker task FIRST so any in-flight run_blocking() call
                # on the API I/O pool can unwind before we drain that pool below.
                logger.info("Shutting down worker task...")
                app.state.worker_task.cancel()
                try:
                    await app.state.worker_task
                except asyncio.CancelledError:
                    pass

                # Cancel watcher task (also uses run_blocking for plan/run activity).
                logger.info("Shutting down activity watcher...")
                app.state.watcher_task.cancel()
                try:
                    await app.state.watcher_task
                except asyncio.CancelledError:
                    pass

                # Cancel queue depth polling task (if started)
                if hasattr(app.state, "queue_depth_task"):
                    app.state.queue_depth_task.cancel()
                    try:
                        await app.state.queue_depth_task
                    except asyncio.CancelledError:
                        pass

                # Stop the background Pushgateway pusher thread BEFORE shutting
                # down the metrics emit pool.  The pusher's loop sleeps on a
                # ``threading.Event``; without this signal it would sit on the
                # next ``max_backoff`` interval (up to 60 s under a dead
                # gateway) and SIGTERM would hang long enough for Kubernetes
                # to escalate to SIGKILL.  Best-effort: a stuck pusher is a
                # daemon thread that dies with the process.
                try:
                    from vulcan.core import analytics

                    analytics.collector.shutdown(flush=True)
                except Exception:
                    logger.warning("Failed to shut down analytics collector", exc_info=True)

                # Shut down the API I/O thread pool used by run_blocking(). At this
                # point the worker/watcher tasks have already been cancelled, so
                # there should be no live async callers of the pool; the bounded
                # drain inside the helper still waits for any stragglers.
                try:
                    from api.utils.async_blocking import shutdown_api_io_executor

                    shutdown_api_io_executor()
                except Exception:
                    logger.warning("Failed to shutdown API I/O executor", exc_info=True)

                # Release leader lock (closes dedicated connection)
                await watcher_coordinator.release()

        # Exiting the asyncpg ``create_pool`` block closes the pool.  The
        # outer ``AsyncExitStack`` then unwinds the HTTP client callbacks
        # registered above (LIFO: GraphQL -> Heimdall -> Transpiler), each
        # wrapped by ``_safe_close_http_client`` so a close error never
        # masks the original startup failure.


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    from pathlib import Path

    from api.settings import get_settings

    settings = get_settings()

    # Get the cached EnvContextManager (same instance used in lifespan)
    # This gives us access to ctx.config.heimdall for middleware setup
    manager = _get_env_context_manager(
        str(settings.project_path),
        settings.config,
        settings.gateway,
    )
    default_env = manager.context.config.default_target_environment
    env_ctx = manager.get_env_context(default_env)
    heimdall_config = manager.context.config.heimdall

    app = FastAPI(
        title="Vulcan API",
        version="0.1.0",  # TODO: Update to the actual version
        description="Vulcan Project API - Models, lineage, query, and telemetry",
        lifespan=lifespan,
        openapi_tags=[
            {
                "name": "Metadata",
                "description": "Models, semantic schema, and metadata exports.",
            },
            {
                "name": "Quality",
                "description": (
                    "Legacy quality API (/quality). Deprecated — use Data Quality "
                    "(`/dq`) instead."
                ),
            },
            {
                "name": "Data Quality",
                "description": (
                    "Canonical data quality API: product summary and DQ rules "
                    "with execution history."
                ),
            },
            {
                "name": "Activity",
                "description": "Plans, runs, and model activity history.",
            },
            {
                "name": "Notifications",
                "description": "Notification feed",
            },
            {
                "name": "Data",
                "description": "Query execution (statement, semantic, GraphQL).",
            },
            {
                "name": "Perspectives",
                "description": "Saved queries and perspective refresh.",
            },
        ],
        # Disable default redoc to use custom one with stable CDN
        redoc_url=None,
        swagger_ui_parameters={"syntaxHighlight.theme": "monokai"},
        redirect_slashes=False,  # Disable automatic trailing slash redirects for consistent API behavior
    )

    # Heimdall + after_authorize hook: shared client on app.state (lifespan);
    # hook import uses project_path inside AuthorizationMiddleware.
    app.add_middleware(
        AuthorizationMiddleware,
        heimdall_config=heimdall_config,
        project_path=Path(settings.project_path),
    )

    # HTTP and cache metrics (push via analytics collector / Pushgateway).
    app.add_middleware(
        VulcanMetricsMiddleware,
        tenant=env_ctx.tenant,
        data_product=env_ctx.product,
    )

    # GZipMiddleware is added LAST so Starlette wraps it as the outermost
    # middleware; it therefore sees the final response body and can
    # compress it before bytes leave the pod.  ``minimum_size=1024`` skips
    # tiny bodies (health probes, small errors) where compression cost
    # dominates the size win.  Streaming responses (FileResponse,
    # StreamingResponse - used by BI-artefact endpoints) keep streaming;
    # GZipMiddleware compresses chunk-by-chunk for those.
    app.add_middleware(GZipMiddleware, minimum_size=1024)

    # Custom ReDoc endpoint with stable CDN URL
    @app.get("/redoc", include_in_schema=False)
    async def custom_redoc_html() -> HTMLResponse:
        """Custom ReDoc page with stable CDN URL"""
        return get_redoc_html(
            openapi_url=app.openapi_url,
            title=f"{app.title} - ReDoc",
            redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@2.1.3/bundles/redoc.standalone.js",
        )

    # Cache header middleware - adds X-Cache headers from request.state
    @app.middleware("http")
    async def add_cache_header(request: Request, call_next):
        """Middleware to add X-Cache headers from request.state."""
        response = await call_next(request)
        # Check if cache status was set by cache decorator
        if hasattr(request.state, "cache_status"):
            response.headers["X-Cache-State"] = request.state.cache_status
        # Check if cache policy was set by cache decorator
        if hasattr(request.state, "cache_policy"):
            response.headers["X-Cache-Expiry-Policy"] = request.state.cache_policy

        # Check if cache key was set by cache decorator
        # TODO: Remove this later! Need it to understand caching behavior for the time being!
        if hasattr(request.state, "cache_key"):
            response.headers["X-Cache-Key"] = request.state.cache_key
        return response

    # Root-level operational endpoints (health checks, service info)
    app.include_router(root_router)

    # Versioned API endpoints
    app.include_router(api_router, prefix="/api/v1")

    # Exception handlers
    @app.exception_handler(TranspilerError)
    async def handle_transpiler_error(request: Request, e: TranspilerError) -> JSONResponse:
        logger.error("Transpiler error: %s (code=%d)", str(e), e.code)

        transpiler_code = None
        data = e.response_data
        if isinstance(data, dict):
            err = data.get("error")
            if isinstance(err, dict):
                transpiler_code = err.get("code")

        if 400 <= e.code < 500:
            status = e.code
            error_code = transpiler_code or "TRANSPILER.QUERY.INVALID"
        elif e.is_connection_error:
            status = 503
            error_code = transpiler_code or "TRANSPILER.SERVICE.UNAVAILABLE"
        elif 500 <= e.code < 600:
            status = 502
            error_code = transpiler_code or "TRANSPILER.UPSTREAM.ERROR"
        else:
            status = 502
            error_code = "TRANSPILER.UNKNOWN"

        content = {
            "status": status,
            "error": {
                "code": error_code,
                "message": e.user_message,
            },
        }
        return JSONResponse(status_code=status, content=content)

    @app.exception_handler(ApiException)
    async def handle_api_exception(request: Request, e: ApiException) -> JSONResponse:
        """Handle ApiException with rich error context"""

        logger.error(
            "API exception: %s (status=%d, origin=%s)",
            e.message,
            e.status_code,
            e.origin,
            exc_info=True,  # Include full traceback in logs
        )
        return JSONResponse(status_code=e.status_code, content=e.to_dict())

    @app.exception_handler(Exception)
    async def handle_uncaught_exception(request: Request, e: Exception) -> JSONResponse:
        """Catch-all for unexpected exceptions - sanitize response, log full details"""
        import traceback

        # Always log full error details server-side
        logger.error(
            "Uncaught exception in API endpoint: %s %s",
            request.method,
            request.url.path,
            exc_info=True,  # Include full traceback in logs
        )

        # Determine user-friendly error message based on exception type
        error_type_name = type(e).__name__

        # Categorize errors for better user messages
        if isinstance(e, (ValueError, TypeError, AttributeError)):
            user_message = f"Invalid request: {str(e)}"
            status_code = HTTP_422_UNPROCESSABLE_CONTENT
        elif isinstance(e, (KeyError, IndexError)):
            user_message = "Invalid data structure encountered"
            status_code = HTTP_422_UNPROCESSABLE_CONTENT
        elif "yaml" in error_type_name.lower() or "serialization" in str(e).lower():
            user_message = "Failed to serialize data. Please check your semantic model definitions."
            status_code = HTTP_500_INTERNAL_SERVER_ERROR
        else:
            # Generic error message for unexpected exceptions
            user_message = "An unexpected error occurred while processing your request."
            status_code = HTTP_500_INTERNAL_SERVER_ERROR

        # Create ApiException with sanitized message
        # Include traceback only in debug mode
        api_exception = ApiException(
            origin=f"API -> main -> handle_uncaught_exception -> {error_type_name}",
            message=user_message,
            status_code=status_code,
            include_traceback=debug_mode_enabled(),  # Only expose traceback in debug mode
        )

        return JSONResponse(
            status_code=status_code,
            content=api_exception.to_dict(),
        )

    return app
